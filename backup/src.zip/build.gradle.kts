plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.woif.modmenu"
    compileSdk = 34
    ndkVersion = "27.0.12077973"

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    defaultConfig {
        applicationId = "com.woif.modmenu"
        minSdk = 28
        targetSdk = 34
        versionCode = 105
        versionName = "2.0.5"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // M Woif distribution split:
    // - stable   = customer APK, package com.woif.modmenu
    // - internal = our test APK, package com.woif.modmenu.internal
    //
    // Internal-only source code must live under app/src/internal/.
    // It is therefore not compiled or packaged into the stable APK.
    flavorDimensions += "distribution"

    productFlavors {
        create("stable") {
            dimension = "distribution"
            buildConfigField("boolean", "INTERNAL_BUILD", "false")

            // Production Giant/Super uses the same ARM64 in-process bridge
            // that is already proven in the Internal/Lab build.
            buildConfigField("boolean", "GAME_EFFECT_BRIDGE_ENABLED", "true")

            // MuMu is x86_64, but CookieRun's libgame.so is ARM64 and is
            // executed through libnb/native bridge.  The module JNI library
            // loaded inside CookieRun must therefore also be ARM64.
            ndk {
                abiFilters += listOf("arm64-v8a")
            }
        }

        create("internal") {
            dimension = "distribution"
            applicationIdSuffix = ".internal"
            buildConfigField("boolean", "INTERNAL_BUILD", "true")
            buildConfigField("boolean", "GAME_EFFECT_BRIDGE_ENABLED", "true")

            // Lab-only in-process backend: force the JNI library to ARM64 so
            // MuMu/libnb executes the same ISA as libgame.so. Stable keeps its
            // existing ABI packaging unchanged.
            ndk {
                abiFilters += listOf("arm64-v8a")
            }

            // Experimental in-process AUTO/Play2 native probes are compiled
            // only for the Lab flavor. Stable still exposes no active trigger.
            externalNativeBuild {
                cmake {
                    cppFlags += "-DMWOIF_INTERNAL_BUILD=1"
                }
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    compileOnly("de.robv.android.xposed:api:82")
}

// -----------------------------------------------------------------------------
// V18.4.4 - Stable release validation gate
// -----------------------------------------------------------------------------
//
// Manual:
//   gradlew.bat :app:validateMwoifStableRelease
//
// Automatic:
//   assembleStableRelease / bundleStableRelease / packageStableRelease
// -----------------------------------------------------------------------------

val validateMwoifStableRelease by tasks.registering {
    group = "verification"
    description = "Validate M Woif stable catalog/flavor/release invariants."

    doLast {
        val errors = mutableListOf<String>()

        fun requireContains(
            text: String,
            needle: String,
            error: String
        ) {
            if (!text.contains(needle)) {
                errors += error
            }
        }

        val catalogFile =
            file("src/main/java/com/woif/modmenu/FeatureCatalog.kt")
        val crgProfileFile =
            file("src/main/java/com/woif/modmenu/CrgProfile.kt")
        val mainStringsFile =
            file("src/main/res/values/strings.xml")
        val internalStringsFile =
            file("src/internal/res/values/strings.xml")
        val internalProbeFile =
            file(
                "src/internal/java/com/woif/modmenu/" +
                        "NaturalTriggerProbeBackend.kt"
            )
        val accidentalMainProbeFile =
            file(
                "src/main/java/com/woif/modmenu/" +
                        "NaturalTriggerProbeBackend.kt"
            )
        val internalAutoStateProbeFile =
            file(
                "src/internal/java/com/woif/modmenu/" +
                        "AutoStateProbeBackend.kt"
            )
        val accidentalMainAutoStateProbeFile =
            file(
                "src/main/java/com/woif/modmenu/" +
                        "AutoStateProbeBackend.kt"
            )
        val internalPowderPumpLabBackendFile =
            file(
                "src/internal/java/com/woif/modmenu/" +
                        "PowderPumpLabBackend.kt"
            )
        val accidentalMainPowderPumpLabBackendFile =
            file(
                "src/main/java/com/woif/modmenu/" +
                        "PowderPumpLabBackend.kt"
            )

        listOf(
            catalogFile,
            crgProfileFile,
            mainStringsFile,
            internalStringsFile
        ).forEach {
            if (!it.isFile) {
                errors += "Missing required release file: ${it.path}"
            }
        }

        if (errors.isEmpty()) {
            val catalogText = catalogFile.readText()
            val crgText = crgProfileFile.readText()
            val mainStrings = mainStringsFile.readText()
            val internalStrings = internalStringsFile.readText()

            val expectedFeatures =
                linkedMapOf(
                    "F01_GAME_SPEED" to "f01",
                    "F02_HP" to "f02",
                    "F03_GIANT" to "f03",
                    "F04_SUPER" to "f04",
                    "F05_POWER_PLUS" to "f05",
                    "F06_RUN_REWARD" to "f06",
                    "F07_POTATO" to "f07",
                    "F08_BASE_SPEED" to "f08",
                    "F09_RECOVERY" to "f09",
                    "F10_UNLIMITED_JUMP" to "f10"
                )

            expectedFeatures.forEach { (name, id) ->
                val regex =
                    Regex(
                        """const\s+val\s+$name\s*=\s*"$id""""
                    )

                if (!regex.containsMatchIn(catalogText)) {
                    errors +=
                        "FeatureCatalog mismatch: $name must map to $id"
                }
            }

            if (
                Regex("""const\s+val\s+F1[1-9]_""")
                    .containsMatchIn(catalogText)
            ) {
                errors +=
                    "Unapproved f11+ feature constant found in public release catalog"
            }

            val droppedControlRegex =
                Regex(
                    """Control\s*\(\s*key\s*=\s*"(MAGNET|PET_SKILL)"""",
                    setOf(RegexOption.MULTILINE)
                )

            if (droppedControlRegex.containsMatchIn(catalogText)) {
                errors +=
                    "Dropped Magnet/Pet Skill control returned to release catalog"
            }

            if (
                Regex(
                    """persistEnabled\s*=\s*true"""
                ).containsMatchIn(catalogText)
            ) {
                errors +=
                    "Runtime ON/OFF persistence is forbidden in public release"
            }

            requireContains(
                crgText,
                "FeatureCatalog.SERVER_FEATURE_IDS",
                "CrgProfile.CLIENT_FEATURE_IDS must come from FeatureCatalog"
            )

            requireContains(
                mainStrings,
                "<string name=\"app_name\">M Woif</string>",
                "Stable app_name must be exactly M Woif"
            )

            if (mainStrings.contains("M Woif Lab")) {
                errors +=
                    "Lab branding leaked into main/stable string resources"
            }

            requireContains(
                internalStrings,
                "<string name=\"app_name\">M Woif Lab</string>",
                "Internal flavor must keep distinct Lab branding"
            )

            if (!internalProbeFile.isFile) {
                errors +=
                    "Internal probe backend is missing from src/internal"
            }

            if (accidentalMainProbeFile.exists()) {
                errors +=
                    "Internal probe backend leaked into src/main"
            }

            if (!internalAutoStateProbeFile.isFile) {
                errors +=
                    "Internal AUTO A1 state probe backend is missing from src/internal"
            }

            if (accidentalMainAutoStateProbeFile.exists()) {
                errors +=
                    "Internal AUTO A1 state probe backend leaked into src/main"
            }

            if (!internalPowderPumpLabBackendFile.isFile) {
                errors +=
                    "Internal Powder Pump Lab backend is missing from src/internal"
            }

            if (accidentalMainPowderPumpLabBackendFile.exists()) {
                errors +=
                    "Internal Powder Pump Lab backend leaked into src/main"
            }

            val gradleText = file("build.gradle.kts").readText()

            requireContains(
                gradleText,
                """buildConfigField("boolean", "INTERNAL_BUILD", "false")""",
                "Stable flavor must compile INTERNAL_BUILD=false"
            )

            requireContains(
                gradleText,
                """applicationIdSuffix = ".internal"""",
                "Internal flavor must keep .internal applicationIdSuffix"
            )

            requireContains(
                gradleText,
                """buildConfigField("boolean", "INTERNAL_BUILD", "true")""",
                "Internal flavor must compile INTERNAL_BUILD=true"
            )
        }

        if (errors.isNotEmpty()) {
            throw GradleException(
                buildString {
                    appendLine("M Woif Stable Release Validation FAILED")
                    errors.forEachIndexed { index, error ->
                        appendLine("${index + 1}. $error")
                    }
                }
            )
        }

        logger.lifecycle(
            "M Woif Stable Release Validation PASS • " +
                    "f01-f10 catalog locked • dropped features absent • " +
                    "stable/internal split verified"
        )
    }
}

tasks.matching {
    it.name == "assembleStableRelease" ||
            it.name == "bundleStableRelease" ||
            it.name == "packageStableRelease"
}.configureEach {
    dependsOn(validateMwoifStableRelease)
}

