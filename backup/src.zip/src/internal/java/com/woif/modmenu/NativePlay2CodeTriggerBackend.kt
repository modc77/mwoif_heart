package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/**
 * Internal/Lab AUTO A2 probe.
 *
 * The actual Play #2 call executes inside CookieRun on the hooked game thread.
 * This backend only requests that call and then verifies the normal run-start
 * invariant through StageService +0x08 Character / +0x10 Controller.
 */
class NativePlay2CodeTriggerBackend {
    companion object {
        private const val IMAGE_BASE = 0x00100000L
        private const val STAGE_SERVICE_GLOBAL_GH = 0x021C49E0L
        private const val VERIFY_TIMEOUT_MS = 12_000L
        private const val POLL_MS = 100L

        private val memory = RootProcessMemory()

        @JvmStatic
        @Synchronized
        fun trigger(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "AUTO A2 • INTERNAL_BUILD_REQUIRED"
            }

            if (!memory.hasRoot() && !memory.requestRoot(context)) {
                return "AUTO A2 • ROOT_NOT_READY"
            }

            val before = observeRunState()
                ?: return "AUTO A2 • RUNTIME_NOT_READY"

            if (before.running) {
                return render(
                    status = "ALREADY_RUNNING",
                    bridge = "not called",
                    state = before,
                    elapsedMs = 0L
                )
            }

            DevConsole.log(
                "AUTO-A2",
                "Code Play2 request • pid=${before.pid} stageService=${hex(before.stageService)}"
            )

            val bridge = InProcessGameControl.play2CodeTrigger(
                context.applicationContext,
                timeoutMs = 4500L
            )

            if (!bridge.ok) {
                val state = observeRunState() ?: before
                return render(
                    status = "TRIGGER_FAILED",
                    bridge = bridge.message,
                    state = state,
                    elapsedMs = 0L
                )
            }

            val started = SystemClock.elapsedRealtime()
            var last = before
            while (SystemClock.elapsedRealtime() - started <= VERIFY_TIMEOUT_MS) {
                val current = observeRunState()
                if (current != null) {
                    last = current
                    if (current.running) {
                        val elapsed = SystemClock.elapsedRealtime() - started
                        val result = render(
                            status = "RUN_STARTED",
                            bridge = bridge.message,
                            state = current,
                            elapsedMs = elapsed
                        )
                        DevConsole.log(
                            "AUTO-A2",
                            "RUN_STARTED after ${elapsed}ms • char=${hex(current.character)} ctrl=${hex(current.controller)}"
                        )
                        return result
                    }
                }
                SystemClock.sleep(POLL_MS)
            }

            val elapsed = SystemClock.elapsedRealtime() - started
            DevConsole.log(
                "AUTO-A2",
                "dispatch returned but RUN not observed after ${elapsed}ms"
            )
            return render(
                status = "DISPATCHED_BUT_RUN_NOT_OBSERVED",
                bridge = bridge.message,
                state = last,
                elapsedMs = elapsed
            )
        }

        private data class RunState(
            val pid: Int,
            val elfBase: Long,
            val stageServiceGlobal: Long,
            val stageService: Long,
            val character: Long,
            val controller: Long
        ) {
            val running: Boolean
                get() = isPointer(character) && isPointer(controller)
        }

        private fun observeRunState(): RunState? {
            val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
            val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
            if (ranges.isEmpty()) return null

            val candidates = LinkedHashSet<Long>()
            ranges.forEach { range ->
                candidates += range.start
                if (range.offset > 0L && range.start > range.offset) {
                    candidates += range.start - range.offset
                }
            }

            val elfBase = candidates.firstOrNull { validateArm64Elf(pid, it) } ?: return null
            val stageGlobal = elfBase + (STAGE_SERVICE_GLOBAL_GH - IMAGE_BASE)
            val stageService = memory.readLong(pid, stageGlobal) ?: 0L
            val character = if (isPointer(stageService)) {
                memory.readLong(pid, stageService + 0x08L) ?: 0L
            } else 0L
            val controller = if (isPointer(stageService)) {
                memory.readLong(pid, stageService + 0x10L) ?: 0L
            } else 0L

            return RunState(
                pid = pid,
                elfBase = elfBase,
                stageServiceGlobal = stageGlobal,
                stageService = stageService,
                character = character,
                controller = controller
            )
        }

        private fun validateArm64Elf(pid: Int, address: Long): Boolean {
            val header = memory.readBytes(pid, address, 0x40) ?: return false
            if (header.size < 0x40) return false
            val machine = ByteBuffer.wrap(header, 0x12, 2)
                .order(ByteOrder.LITTLE_ENDIAN)
                .short.toInt() and 0xFFFF
            return (header[0].toInt() and 0xFF) == 0x7F &&
                (header[1].toInt() and 0xFF) == 0x45 &&
                (header[2].toInt() and 0xFF) == 0x4C &&
                (header[3].toInt() and 0xFF) == 0x46 &&
                (header[4].toInt() and 0xFF) == 2 &&
                machine == 0xB7
        }

        private fun render(
            status: String,
            bridge: String,
            state: RunState,
            elapsedMs: Long
        ): String = buildString {
            appendLine("=== AUTO A2 • CODE PLAY #2 ===")
            appendLine("status=$status")
            appendLine("bridge=$bridge")
            appendLine("elapsedMs=$elapsedMs")
            appendLine("pid=${state.pid}")
            appendLine("elfBase=${hex(state.elfBase)}")
            appendLine("stageServiceGlobal=${hex(state.stageServiceGlobal)}")
            appendLine("stageService=${hex(state.stageService)}")
            appendLine("character=${hex(state.character)}")
            appendLine("controller=${hex(state.controller)}")
            append("RUNNING=${state.running}")
        }

        private fun isPointer(value: Long): Boolean =
            value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

        private fun hex(value: Long): String =
            if (value == 0L) "0x0" else "0x${value.toString(16).uppercase(Locale.US)}"
    }
}
