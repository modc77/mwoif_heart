package com.woif.modmenu

import android.content.Context
import android.util.Log
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * INTERNAL / READ-ONLY probe backend for f03 Giant and f04 Super.
 *
 * This build intentionally performs no game-memory writes for f03/f04.
 * The existing Giant/Super switches are repurposed as probe toggles so we can
 * observe the live Character, effect vector and selected gameplay-state keys
 * while the game naturally enters/leaves Giant/Super states.
 */
class NaturalTriggerProbeBackend(
    context: Context,
    private val memory: RootProcessMemory
) : NativeEffectMod.Backend {

    companion object {
        private const val TAG = "WOIF_PROBE"
        private const val SAMPLE_MS = 150L
        private const val HEARTBEAT_LOG_MS = 2_000L
        private const val POINTER_MIN = 0x10000L
        private const val POINTER_MAX = 0x0000FFFFFFFFFFFFL
        private const val MAX_BUCKET_COUNT = 1_000_000L
        private const val MAX_BUCKET_CHAIN = 256
        private const val MAX_LIST_CHAIN = 4096

        // State-map keys confirmed around Giant/Super-related natural paths.
        // These are diagnostic reads only; no value is modified.
        private val WATCH_KEYS = intArrayOf(
            0x386,
            0x327,
            0x88A,
            0x200,
            0x616,
            0x62B
        )
    }

    private data class Runtime(
        val pid: Int,
        val moduleStart: Long,
        val moduleEnd: Long,
        val bias: Long,
        val stageServiceGlobal: Long
    )

    private data class CharacterSources(
        val service: Long,
        val direct: Long,
        val fallback: Long,
        val selected: Long,
        val selectedSource: String
    )

    private data class EffectRow(
        val index: Int,
        val pointer: Long,
        val vptr: Long?,
        val directId: Int?,
        val adjustedId: Int?
    )

    private data class Snapshot(
        val summary: String,
        val detailFingerprint: String,
        val detailLines: List<String>
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val profiles = ConcurrentHashMap<String, NativeEffectProfile>()
    private val desired = ConcurrentHashMap<String, Boolean>()
    private val statuses = ConcurrentHashMap<String, String>()

    @Volatile
    private var task: ScheduledFuture<*>? = null

    @Volatile
    private var closed = false

    @Volatile
    private var lastFingerprint = ""

    @Volatile
    private var lastHeartbeatLogAt = 0L

    override fun cacheProfile(profile: NativeEffectProfile): NativeEffectMod.ActionResult {
        if (
            profile.featureId != CrgProfile.FEATURE_GIANT &&
            profile.featureId != CrgProfile.FEATURE_SUPER
        ) {
            return failure(
                "PROFILE_FEATURE_MISMATCH",
                "Probe profile ไม่ถูกต้อง"
            )
        }

        profiles[profile.featureId] = profile
        statuses.putIfAbsent(
            profile.featureId,
            "Probe พร้อม • ON = เริ่มอ่านค่าแบบ Read-only"
        )
        ensureTask()

        return success("Read-only Probe Profile พร้อม")
    }

    override fun enable(
        profile: NativeEffectProfile,
        callback: (NativeEffectMod.ActionResult) -> Unit
    ) {
        val cached = cacheProfile(profile)
        if (!cached.ok) {
            callback(cached)
            return
        }

        desired[profile.featureId] = true
        statuses[profile.featureId] = "Probe ON • กำลังอ่าน Runtime..."
        ensureTask()

        executor.execute {
            val snapshot = captureSnapshot()
            val result = if (snapshot == null) {
                failure(
                    "PROBE_NOT_READY",
                    "Probe ON • รอ CookieRun / libgame / Stage"
                )
            } else {
                publish(snapshot, force = true)
                success(snapshot.summary)
            }

            statuses[profile.featureId] = result.message
            callback(result)
        }
    }

    override fun disable(
        featureId: String,
        callback: (NativeEffectMod.ActionResult) -> Unit
    ) {
        desired[featureId] = false
        statuses[featureId] = "Probe OFF • ไม่มีการเขียน Memory"
        callback(success("Probe OFF • Read-only"))
    }

    override fun isEnabled(featureId: String): Boolean =
        desired[featureId] == true

    override fun statusText(featureId: String): String =
        statuses[featureId] ?: "Probe ยังไม่ได้เปิด"

    override fun restoreFeatureBlockingBestEffort(featureId: String): NativeEffectMod.ActionResult {
        desired[featureId] = false
        statuses[featureId] = "Probe OFF • ไม่มีค่าที่ต้อง Restore"
        return success("Probe OFF • ไม่มี Memory write")
    }

    override fun restoreAllBlockingBestEffort(): NativeEffectMod.ActionResult {
        desired.keys.forEach { desired[it] = false }
        profiles.keys.forEach {
            statuses[it] = "Probe OFF • ไม่มีค่าที่ต้อง Restore"
        }
        return success("Read-only Probe หยุดแล้ว")
    }

    override fun shutdown(restore: Boolean) {
        if (closed) {
            return
        }

        desired.keys.forEach { desired[it] = false }
        closed = true
        task?.cancel(false)
        task = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (task != null || closed) {
            return
        }

        task = executor.scheduleWithFixedDelay(
            {
                try {
                    probeTick()
                } catch (e: Exception) {
                    Log.e(TAG, "probeTick", e)
                }
            },
            SAMPLE_MS,
            SAMPLE_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun probeTick() {
        if (closed || desired.values.none { it }) {
            return
        }

        val snapshot = captureSnapshot()
        if (snapshot == null) {
            desired.keys
                .filter { desired[it] == true }
                .forEach {
                    statuses[it] = "Probe ON • รอ CookieRun / Stage"
                }
            return
        }

        publish(snapshot, force = false)

        desired.keys
            .filter { desired[it] == true }
            .forEach {
                statuses[it] = snapshot.summary
            }
    }

    private fun publish(snapshot: Snapshot, force: Boolean) {
        val now = System.currentTimeMillis()
        val changed = snapshot.detailFingerprint != lastFingerprint
        val heartbeatDue = now - lastHeartbeatLogAt >= HEARTBEAT_LOG_MS

        if (!force && !changed && !heartbeatDue) {
            return
        }

        lastFingerprint = snapshot.detailFingerprint
        lastHeartbeatLogAt = now

        Log.i(TAG, "============================================================")
        Log.i(TAG, snapshot.summary)
        snapshot.detailLines.forEach { Log.i(TAG, it) }
    }

    private fun captureSnapshot(): Snapshot? {
        val giant = profiles[CrgProfile.FEATURE_GIANT]
        val superProfile = profiles[CrgProfile.FEATURE_SUPER]
        val baseProfile = giant ?: superProfile ?: return null

        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return null
        }

        val runtime = resolveRuntime(baseProfile) ?: return null
        val sources = resolveCharacterSources(runtime, baseProfile)
        val character = sources.selected

        val hpProfile = SecureProfileManager.getHp()
        val stateValues = readWatchedStateValues(runtime, hpProfile)

        if (!isPointer(character)) {
            val summary =
                "Probe ON • Stage Character ยังไม่พร้อม • direct=${hex(sources.direct)} fallback=${hex(sources.fallback)}"

            val details = buildList {
                add("pid=${runtime.pid} lib=${hex(runtime.moduleStart)}..${hex(runtime.moduleEnd)}")
                add("service=${hex(sources.service)} direct=${hex(sources.direct)} fallback=${hex(sources.fallback)}")
                add("state=${stateValues.second}")
            }

            return Snapshot(
                summary = summary,
                detailFingerprint = details.joinToString("|"),
                detailLines = details
            )
        }

        val rows = readEffects(runtime, character, baseProfile)
        val giantPresent = giant?.let { profile ->
            rows.any { matchesEffect(runtime, it, profile) }
        } ?: false
        val superPresent = superProfile?.let { profile ->
            rows.any { matchesEffect(runtime, it, profile) }
        } ?: false

        val summary =
            "Probe ON • ${sources.selectedSource} • effects=${rows.size} • Giant=${if (giantPresent) "YES" else "NO"} • Super=${if (superPresent) "YES" else "NO"}"

        val details = buildList {
            add("pid=${runtime.pid} lib=${hex(runtime.moduleStart)}..${hex(runtime.moduleEnd)} bias=${hex(runtime.bias)}")
            add("service=${hex(sources.service)} direct=${hex(sources.direct)} fallback=${hex(sources.fallback)} selected=${hex(character)} source=${sources.selectedSource}")
            add("char.vptr=${hex(memory.readLong(runtime.pid, character) ?: 0L)} effectOwner(+5E0)=${hex(memory.readLong(runtime.pid, character + 0x5E0L) ?: 0L)}")
            add("state=${stateValues.second}")
            rows.forEach { row ->
                add(
                    "effect[${row.index}] ptr=${hex(row.pointer)} vptr=${hex(row.vptr ?: 0L)} idD=${row.directId ?: -1} idA=${row.adjustedId ?: -1}"
                )
            }
        }

        val fingerprintParts = mutableListOf<String>()
        fingerprintParts += hex(character)
        fingerprintParts += sources.selectedSource
        fingerprintParts += stateValues.first
        rows.forEach {
            fingerprintParts += "${hex(it.pointer)}:${hex(it.vptr ?: 0L)}:${it.directId}:${it.adjustedId}"
        }

        return Snapshot(
            summary = summary,
            detailFingerprint = fingerprintParts.joinToString("|"),
            detailLines = details
        )
    }

    private fun resolveRuntime(profile: NativeEffectProfile): Runtime? {
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
        val maps = memory.maps(pid)
        val libMaps = maps.filter { it.path.contains("libgame.so") }
        if (libMaps.isEmpty()) {
            return null
        }

        val moduleStart = libMaps.minOf { it.start }
        val moduleEnd = libMaps.maxOf { it.end }
        val bias = moduleStart - profile.imageBase

        return Runtime(
            pid = pid,
            moduleStart = moduleStart,
            moduleEnd = moduleEnd,
            bias = bias,
            stageServiceGlobal = bias + profile.stageServiceGlobal
        )
    }

    private fun resolveCharacterSources(
        runtime: Runtime,
        profile: NativeEffectProfile
    ): CharacterSources {
        val service = memory.readLong(
            runtime.pid,
            runtime.stageServiceGlobal
        ) ?: 0L

        if (!isPointer(service)) {
            return CharacterSources(0L, 0L, 0L, 0L, "NONE")
        }

        val direct = memory.readLong(
            runtime.pid,
            service + profile.serviceCharacterOffset
        ) ?: 0L

        val jelly = memory.readLong(
            runtime.pid,
            service + profile.serviceJellyManagerOffset
        ) ?: 0L

        val fallback = if (isPointer(jelly)) {
            memory.readLong(
                runtime.pid,
                jelly + profile.jellyManagerCharacterOffset
            ) ?: 0L
        } else {
            0L
        }

        val directValid = isRuntimeCharacter(runtime, direct)
        val fallbackValid = isRuntimeCharacter(runtime, fallback)

        return when {
            directValid -> CharacterSources(service, direct, fallback, direct, "DIRECT")
            fallbackValid -> CharacterSources(service, direct, fallback, fallback, "FALLBACK")
            else -> CharacterSources(service, direct, fallback, 0L, "NONE")
        }
    }

    private fun isRuntimeCharacter(runtime: Runtime, pointer: Long): Boolean {
        if (!isPointer(pointer)) {
            return false
        }

        val vptr = memory.readLong(runtime.pid, pointer) ?: return false
        return vptr in runtime.moduleStart until runtime.moduleEnd
    }

    private fun readEffects(
        runtime: Runtime,
        character: Long,
        profile: NativeEffectProfile
    ): List<EffectRow> {
        val begin = memory.readLong(
            runtime.pid,
            character + profile.effectBeginOffset
        ) ?: return emptyList()
        val end = memory.readLong(
            runtime.pid,
            character + profile.effectEndOffset
        ) ?: return emptyList()
        val cap = memory.readLong(
            runtime.pid,
            character + profile.effectCapOffset
        ) ?: return emptyList()

        if (begin == 0L && end == 0L && cap == 0L) {
            return emptyList()
        }

        if (
            !isPointer(begin) ||
            end < begin ||
            cap < end ||
            (end - begin) % 8L != 0L
        ) {
            return emptyList()
        }

        val count = ((end - begin) / 8L)
            .coerceIn(0L, profile.maxEffects.toLong())
            .toInt()

        return buildList {
            for (index in 0 until count) {
                val pointer = memory.readLong(
                    runtime.pid,
                    begin + index * 8L
                ) ?: continue

                if (!isPointer(pointer)) {
                    continue
                }

                add(
                    EffectRow(
                        index = index,
                        pointer = pointer,
                        vptr = memory.readLong(runtime.pid, pointer),
                        directId = memory.readInt(
                            runtime.pid,
                            pointer + profile.effectIdDirectOffset
                        ),
                        adjustedId = memory.readInt(
                            runtime.pid,
                            pointer + profile.effectIdAdjustedOffset
                        )
                    )
                )
            }
        }
    }

    private fun matchesEffect(
        runtime: Runtime,
        row: EffectRow,
        profile: NativeEffectProfile
    ): Boolean {
        val expectedVptr = runtime.bias + profile.effectVptr

        if (row.vptr == expectedVptr && row.directId == profile.effectId) {
            return true
        }

        if (row.adjustedId == profile.effectId && row.pointer >= POINTER_MIN + 8L) {
            val adjustedVptr = memory.readLong(runtime.pid, row.pointer - 8L)
            if (adjustedVptr == expectedVptr) {
                return true
            }
        }

        return false
    }

    private fun readWatchedStateValues(
        runtime: Runtime,
        profile: HpProfile?
    ): Pair<String, String> {
        if (profile == null) {
            return "HP_PROFILE_NONE" to "HP profile ยังไม่พร้อม"
        }

        val stateGlobal = runtime.bias + profile.a1
        val state = memory.readLong(runtime.pid, stateGlobal) ?: 0L
        if (!isPointer(state)) {
            return "state=0" to "state=NONE"
        }

        val values = WATCH_KEYS.map { key ->
            key to readStateInt(runtime.pid, state, key, profile)
        }

        val compact = values.joinToString(",") { (key, value) ->
            "${key.toString(16).uppercase()}=${value ?: "?"}"
        }

        return "${hex(state)}|$compact" to "${hex(state)} [$compact]"
    }

    /**
     * Generic read-only reader for the protected gameplay-state map layout
     * already verified by f02 HP. It never allocates, inserts or writes nodes.
     */
    private fun readStateInt(
        pid: Int,
        state: Long,
        propertyKey: Int,
        p: HpProfile
    ): Int? {
        val node = findStateNode(pid, state, propertyKey, p) ?: return null
        val field = node + p.b7

        val valueType = memory.readInt(pid, field + p.b8) ?: return null
        val encryptedFlag = memory.readByteUnsigned(pid, field + p.ba) ?: return null
        val valuePtr = memory.readLong(pid, field + p.b9) ?: return null
        val keyPtr = memory.readLong(pid, field + p.bb) ?: 0L

        if (!isPointer(valuePtr)) {
            return null
        }

        val raw = memory.readInt(pid, valuePtr) ?: return null
        val encrypted = (encryptedFlag and 1) == 1

        return if (encrypted && (valueType == 1 || valueType == 6)) {
            if (!isPointer(keyPtr)) {
                null
            } else {
                val xorKey = memory.readInt(pid, keyPtr) ?: return null
                raw xor xorKey
            }
        } else if (valueType == 2) {
            null
        } else {
            raw
        }
    }

    private fun findStateNode(
        pid: Int,
        state: Long,
        propertyKey: Int,
        p: HpProfile
    ): Long? {
        val map = state + p.b0
        val bucketArray = memory.readLong(pid, map + p.b1)
        val bucketCount = memory.readLong(pid, map + p.b2)

        if (
            bucketArray != null &&
            isPointer(bucketArray) &&
            bucketCount != null &&
            bucketCount > 0L &&
            bucketCount <= MAX_BUCKET_COUNT
        ) {
            val unsignedKey = propertyKey.toLong() and 0xFFFFFFFFL
            val bucket = unsignedKey % bucketCount
            val predecessor = memory.readLong(
                pid,
                bucketArray + bucket * 8L
            )

            var node = if (predecessor != null && isPointer(predecessor)) {
                memory.readLong(pid, predecessor + p.b4)
            } else {
                null
            }

            var guard = 0
            while (node != null && isPointer(node) && guard < MAX_BUCKET_CHAIN) {
                val storedKey = memory.readInt(pid, node + p.b6)
                val storedHash = memory.readLong(pid, node + p.b5)

                if (storedKey == propertyKey && storedHash == unsignedKey) {
                    return node
                }

                node = memory.readLong(pid, node + p.b4)
                guard += 1
            }
        }

        var node = memory.readLong(pid, map + p.b3)
        var guard = 0

        while (node != null && isPointer(node) && guard < MAX_LIST_CHAIN) {
            if (memory.readInt(pid, node + p.b6) == propertyKey) {
                return node
            }

            node = memory.readLong(pid, node + p.b4)
            guard += 1
        }

        return null
    }

    private fun isPointer(value: Long): Boolean =
        value >= POINTER_MIN &&
            value < POINTER_MAX &&
            value % 8L == 0L

    private fun hex(value: Long): String =
        "0x" + value.toULong().toString(16).uppercase()

    private fun success(message: String): NativeEffectMod.ActionResult =
        NativeEffectMod.ActionResult(true, null, message)

    private fun failure(code: String, message: String): NativeEffectMod.ActionResult =
        NativeEffectMod.ActionResult(false, code, message)
}
