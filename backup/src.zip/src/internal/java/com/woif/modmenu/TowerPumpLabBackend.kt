package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.util.Locale

/**
 * Internal-only Tower of Frozen Waves controlled verifier.
 *
 * V2.0 Warp architecture:
 * - READ state from CookieRun with RootProcessMemory.
 * - The user manually selects/enters Tower stages.
 * - As soon as a fresh ActiveMission and Character are ready, Tower Lab:
 *     1) warps the authoritative forward-position field to the calibrated
 *        point immediately before the exit gate;
 *     2) normalizes the current Mission source to exact requiredValue.
 * - No Cookie Base Speed / Giant / Super / Game Speed assist is used.
 * - conditionType 1/2 use the typed GameStats source via RootProcessMemory.
 * - conditionType 0 uses the existing in-process game-thread exact-stat route.
 * - Derived success booleans are not root-forced; CookieRun evaluates the source.
 * - Never writes totalStar, bestStage, completedFlag, pendingCommit, or server result.
 * - Normal Gate / Result / AfterPlay / commit lifecycle is still owned by the game.
 */
class TowerPumpLabBackend {
    companion object {
        private const val IMAGE_BASE = 0x00100000L
        private const val TOWER_MANAGER_GLOBAL_GH = 0x0225C918L
        private const val GAME_STATS_GLOBAL_GH = 0x02259800L

        // Verified by Lua V4 controlled write:
        // StageService -> Character -> Character+0x78 -> Transform/Object
        // authoritative forward position = object+0x30.
        private const val STAGE_SERVICE_GLOBAL_GH = 0x02259220L
        private const val STAGE_SERVICE_CHARACTER_OFFSET = 0x08L
        private const val STAGE_SERVICE_JELLY_MANAGER_OFFSET = 0x20L
        private const val JELLY_MANAGER_CHARACTER_OFFSET = 0x788L
        private const val CHARACTER_TRANSFORM_PTR_OFFSET = 0x78L
        private const val TRANSFORM_FORWARD_POSITION_OFFSET = 0x30L

        // LAB V2.0.6 policy:
        // Door distance differs by Tower floor (observed ~68k and ~84k).
        // Use a deliberately far forward target in Lab. Runtime testing showed
        // that overshooting the exit still triggers/counts, while a short target
        // can stop before the exit on longer stages.
        //
        // Payload promotion must move this value to f14 profile/JSON instead of
        // hardcoding it in the final Payload.
        private const val LAB_WARP_TARGET_FORWARD = 250000.0f

        private const val PREPARE_POLL_MS = 100L
        private const val PREPARE_WAIT_MS = 7_000L
        private const val RESULT_POLL_MS = 100L
        private const val RESULT_WAIT_MS = 2_500L
        private const val AUTO_PASS_POLL_MS = 50L

        // V2.0.6 run-start trigger:
        // Do NOT count time while the loading screen is visible.
        // Lua RUN_START_WATCH proved that the authoritative field stays at 0
        // during loading, then moves continuously once the Cookie actually runs.
        //
        // Source:
        // Character+0x78 -> Transform/Object +0x30
        private const val RUN_START_MIN_STEP = 1.0f
        private const val RUN_START_MIN_TOTAL_MOVE = 12.0f
        private const val RUN_START_REQUIRED_MOVING_SAMPLES = 4

        // V2.0.6 verified Slide-duration special case.
        // Lua proved that Type0/index5 has no RB-tree source while progress is 0/N.
        // One real Slide sample creates the node, then raw=required*1,000,000 passes.
        // The app performs that one tiny Slide input automatically; the user does not.
        private const val TYPE0_SLIDE_INDEX = 5
        private const val TYPE0_SLIDE_RAW_SCALE = 1_000_000L
        private const val TYPE0_SLIDE_X = 0.875f
        private const val TYPE0_SLIDE_Y = 0.885f
        private const val TYPE0_SLIDE_SOURCE_WAIT_MS = 1_500L
        private const val TYPE0_SLIDE_SOURCE_POLL_MS = 25L
        private const val TYPE0_SLIDE_EVAL_WAIT_MS = 3_000L
        private const val TYPE0_SLIDE_EVAL_POLL_MS = 50L

        private const val BOOL_FALSE_ENCODED = 0x6B
        private const val BOOL_TRUE_ENCODED = 0x6C

        private val memory = RootProcessMemory()

        private data class TowerLiveState(
            val running: Boolean = false,
            val phase: String = "READY",
            val message: String = "พร้อมทดสอบ",
            val floor: Int = 0,
            val missionOrder: Int = 0,
            val bestStage: Int = 0,
            val missionFloor: Int = 0,
            val conditionType: Int = -1,
            val conditionIndex: Int = -1,
            val comparator: Int = -1,
            val requiredValue: Long = 0L,
            val rawCondition: Int = 0,
            val secondaryState: Int = 0,
            val finalSuccess: Int = 0,
            val pendingUnlock: Int = 0,
            val pendingCommit: Int = 0,
            val completedFlag: Int = 0,
            val managerStateByte: Int = 0,
            val errorStage: String = "NONE",
            val errorRc: String = "0"
        )

        private data class RootTowerSnapshot(
            val pid: Int,
            val libgameBase: Long,
            val managerGlobal: Long,
            val manager: Long,
            val activeMission: Long,
            val statsManager: Long,
            val currentFloor: Long,
            val missionOrder: Long,
            val bestStage: Long,
            val missionId: Long,
            val missionFloor: Long,
            val conditionType: Int,
            val conditionIndex: Int,
            val comparator: Int,
            val requiredValue: Long,
            val rawCondition: Int,
            val secondaryState: Int,
            val finalSuccess: Int,
            val pendingUnlock: Int,
            val pendingCommit: Int,
            val completedFlag: Int,
            val missionStateFlag: Int,
            val managerStateByte: Int
        )

        private data class WarpResult(
            val ok: Boolean,
            val report: String
        )

        private data class ForwardSample(
            val ok: Boolean,
            val character: Long = 0L,
            val transformObject: Long = 0L,
            val field: Long = 0L,
            val forward: Float = Float.NaN,
            val route: String = "NONE",
            val reason: String = "UNKNOWN"
        )

        private data class ReadResult(
            val ok: Boolean,
            val stage: String,
            val rc: String,
            val report: String,
            val snapshot: RootTowerSnapshot? = null
        )

        private data class BaseCandidate(
            val base: Long,
            val source: String,
            val accepted: Boolean,
            val score: Int,
            val reason: String,
            val managerGlobal: Long = 0L,
            val manager: Long = 0L,
            val activeMission: Long = 0L,
            val managerStateByte: Int = -1,
            val pendingUnlock: Int = -1,
            val pendingCommit: Int = -1,
            val finalSuccess: Int = -1,
            val rawCondition: Int = -1,
            val secondaryState: Int = -1,
            val currentFloor: Long = -1L,
            val missionOrder: Long = -1L,
            val bestStage: Long = -1L
        )

        @Volatile
        private var liveState = TowerLiveState()

        @Volatile
        private var lastFullReport = "ยังไม่มี Tower Lab report"

        @Volatile
        private var lastFailedReport = "NONE"

        @Volatile
        private var lastResolverReport = "ยังไม่มี Runtime Resolver report"

        @Volatile
        private var autoPassEnabled = false

        @Volatile
        private var autoPassThread: Thread? = null

        @Volatile
        private var lastAutoMissionKey = "NONE"

        @Volatile
        private var lastAutoWriteReport = "NONE"

        private fun value(text: String, key: String): String? =
            Regex("(?m)^${Regex.escape(key)}=([^\\r\\n]+)$")
                .find(text)
                ?.groupValues
                ?.getOrNull(1)
                ?.trim()

        private fun intValue(text: String, key: String, fallback: Int = 0): Int =
            value(text, key)?.toIntOrNull() ?: fallback

        private fun longValue(text: String, key: String, fallback: Long = 0L): Long =
            value(text, key)?.toLongOrNull() ?: fallback

        private fun publishFromReport(
            report: String,
            running: Boolean,
            phaseOverride: String? = null,
            messageOverride: String? = null,
            errorStage: String = "NONE",
            errorRc: String = "0"
        ) {
            val old = liveState
            liveState = TowerLiveState(
                running = running,
                phase = phaseOverride ?: value(report, "phase") ?: old.phase,
                message = messageOverride ?: value(report, "RESULT") ?: old.message,
                floor = intValue(report, "currentFloor", old.floor),
                missionOrder = intValue(report, "missionOrder", old.missionOrder),
                bestStage = intValue(report, "bestStage", old.bestStage),
                missionFloor = intValue(report, "missionFloor", old.missionFloor),
                conditionType = intValue(report, "conditionType", old.conditionType),
                conditionIndex = intValue(report, "conditionIndex", old.conditionIndex),
                comparator = intValue(report, "comparator", old.comparator),
                requiredValue = longValue(report, "requiredValue", old.requiredValue),
                rawCondition = intValue(report, "rawCondition", old.rawCondition),
                secondaryState = intValue(report, "secondaryState", old.secondaryState),
                finalSuccess = intValue(report, "finalSuccess", old.finalSuccess),
                pendingUnlock = intValue(report, "pendingUnlock", old.pendingUnlock),
                pendingCommit = intValue(report, "pendingCommit", old.pendingCommit),
                completedFlag = intValue(report, "completedFlag", old.completedFlag),
                managerStateByte = intValue(report, "managerStateByte", old.managerStateByte),
                errorStage = errorStage,
                errorRc = errorRc
            )
        }

        private fun fail(stage: String, report: String, rcOverride: String? = null): String {
            val rc = rcOverride ?: value(report, "rc") ?: "UNKNOWN"
            val friendlyMessage = when (stage) {
                "ROOT_NOT_READY" ->
                    "Root ยังไม่พร้อม • ดู DEV"
                "GAME_PID_NOT_FOUND" ->
                    "ยังไม่พบ Process เกม • เปิด CookieRun ก่อน"
                "LIBGAME_NOT_FOUND" ->
                    "หา libgame.so ไม่เจอ • ดู DEV"
                "MANAGER_NULL" ->
                    "ยังไม่พบ Tower Manager • เข้า Tower ก่อน"
                "ACTIVE_MISSION_NULL" ->
                    "ยังไม่พบ Active Mission • เข้า Stage และรอ Mission ขึ้นก่อน"
                "NO_VALID_TOWER_BASE" ->
                    "ยังหา Tower Runtime ที่ผ่าน Validation ไม่เจอ • ดู DEV"
                "WAIT_FRESH_MISSION_TIMEOUT" ->
                    "รอ Mission ใหม่ใน Stage ไม่ทัน • ดู DEV"
                "NATIVE_ACTION_ROUTE" ->
                    "อ่าน Tower ได้แล้ว • แต่คำสั่งทดสอบ Native ยังไม่ผ่าน"
                else ->
                    "มีข้อผิดพลาด • ดู DEV"
            }

            lastFailedReport = report
            lastFullReport = report
            publishFromReport(
                report = report,
                running = false,
                phaseOverride = "ERROR",
                messageOverride = friendlyMessage,
                errorStage = stage,
                errorRc = rc
            )

            report.lineSequence().take(260).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("TOWER", line)
            }
            return report
        }

        @JvmStatic
        fun getLiveUiState(): String {
            val s = liveState
            return buildString {
                appendLine("running=${s.running}")
                appendLine("phase=${s.phase}")
                appendLine("message=${s.message}")
                appendLine("floor=${s.floor}")
                appendLine("missionOrder=${s.missionOrder}")
                appendLine("bestStage=${s.bestStage}")
                appendLine("missionFloor=${s.missionFloor}")
                appendLine("conditionType=${s.conditionType}")
                appendLine("conditionIndex=${s.conditionIndex}")
                appendLine("comparator=${s.comparator}")
                appendLine("requiredValue=${s.requiredValue}")
                appendLine("rawCondition=${s.rawCondition}")
                appendLine("secondaryState=${s.secondaryState}")
                appendLine("finalSuccess=${s.finalSuccess}")
                appendLine("pendingUnlock=${s.pendingUnlock}")
                appendLine("pendingCommit=${s.pendingCommit}")
                appendLine("completedFlag=${s.completedFlag}")
                appendLine("managerStateByte=${s.managerStateByte}")
                appendLine("errorStage=${s.errorStage}")
                append("errorRc=${s.errorRc}")
            }
        }

        /**
         * Read-only Tower state through the same RootProcessMemory transport
         * already proven by Powder Lab. No game memory is written here.
         */
        private fun stateReport(context: Context): InProcessGameControl.Result {
            val result = readTowerState(context.applicationContext)
            return InProcessGameControl.Result(result.ok, result.report)
        }

        private fun readTowerState(context: Context): ReadResult {
            if (!memory.hasRoot() && !memory.requestRoot(context)) {
                return readFailure(
                    stage = "ROOT_NOT_READY",
                    rc = "ROOT",
                    detail = "RootProcessMemory is not ready"
                )
            }

            val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
                ?: return readFailure(
                    stage = "GAME_PID_NOT_FOUND",
                    rc = "-301",
                    detail = "package=${CrgProfile.GAME_PACKAGE}"
                )

            val maps = memory.maps(pid)
            if (maps.isEmpty()) {
                return readFailure(
                    stage = "MAPS_EMPTY",
                    rc = "-302",
                    detail = "pid=$pid maps=0"
                )
            }

            val candidate = findTowerCandidate(pid, maps)
                ?: return readFailure(
                    stage = "NO_VALID_TOWER_BASE",
                    rc = "-303",
                    detail = buildString {
                        appendLine("pid=$pid")
                        appendLine("libgameRanges=${maps.count { it.path.contains("libgame.so") }}")
                        append(lastResolverReport)
                    }
                )

            val base = candidate.base
            val managerGlobal = candidate.managerGlobal
            val manager = candidate.manager
            val statsGlobal = base + (GAME_STATS_GLOBAL_GH - IMAGE_BASE)

            val currentFloor = decodeProtected32(pid, maps, manager + 0x008L)
                ?: return protectedFailure("CURRENT_FLOOR", pid, base, manager, 0L)
            val missionOrder = decodeProtected32(pid, maps, manager + 0x030L)
                ?: return protectedFailure("MISSION_ORDER", pid, base, manager, 0L)
            val bestStage = decodeProtected32(pid, maps, manager + 0x058L)
                ?: return protectedFailure("BEST_STAGE", pid, base, manager, 0L)

            val rawCondition = decodeProtectedBool(pid, maps, manager + 0x0A8L)
                ?: return protectedFailure("RAW_CONDITION", pid, base, manager, 0L)
            val secondaryState = decodeProtectedBool(pid, maps, manager + 0x0D0L)
                ?: return protectedFailure("SECONDARY_STATE", pid, base, manager, 0L)
            val finalSuccess = decodeProtectedBool(pid, maps, manager + 0x080L)
                ?: return protectedFailure("FINAL_SUCCESS", pid, base, manager, 0L)

            val pendingUnlock = memory.readByteUnsigned(pid, manager + 0x0F8L)
                ?: return directFailure("PENDING_UNLOCK", pid, base, manager, 0L)
            val pendingCommit = memory.readByteUnsigned(pid, manager + 0x0F9L)
                ?: return directFailure("PENDING_COMMIT", pid, base, manager, 0L)
            val managerStateByte = memory.readByteUnsigned(pid, manager + 0x180L)
                ?: return directFailure("MANAGER_STATE", pid, base, manager, 0L)

            val activeMission = memory.readLong(pid, manager + 0x100L) ?: 0L
            val statsManager = if (isMapped(maps, statsGlobal, 8)) {
                memory.readLong(pid, statsGlobal) ?: 0L
            } else {
                0L
            }

            if (!isPointer(activeMission) || !isMapped(maps, activeMission, 0x1F9)) {
                val snapshot = RootTowerSnapshot(
                    pid = pid,
                    libgameBase = base,
                    managerGlobal = managerGlobal,
                    manager = manager,
                    activeMission = 0L,
                    statsManager = statsManager,
                    currentFloor = currentFloor,
                    missionOrder = missionOrder,
                    bestStage = bestStage,
                    missionId = 0L,
                    missionFloor = 0L,
                    conditionType = -1,
                    conditionIndex = -1,
                    comparator = -1,
                    requiredValue = 0L,
                    rawCondition = rawCondition,
                    secondaryState = secondaryState,
                    finalSuccess = finalSuccess,
                    pendingUnlock = pendingUnlock and 1,
                    pendingCommit = pendingCommit and 1,
                    completedFlag = 0,
                    missionStateFlag = 0,
                    managerStateByte = managerStateByte
                )

                val report = buildTowerReport(
                    snapshot = snapshot,
                    result = "WAIT",
                    phase = "WAIT_ACTIVE_MISSION",
                    rc = "0",
                    resolverScore = candidate.score
                )

                return ReadResult(
                    ok = true,
                    stage = "WAIT_ACTIVE_MISSION",
                    rc = "0",
                    report = report,
                    snapshot = snapshot
                )
            }

            val missionId = decodeProtected32(pid, maps, activeMission + 0x018L)
                ?: return protectedFailure("MISSION_ID", pid, base, manager, activeMission)
            val missionFloor = decodeProtected32(pid, maps, activeMission + 0x140L)
                ?: return protectedFailure("MISSION_FLOOR", pid, base, manager, activeMission)
            val requiredValue = decodeProtected64(pid, maps, activeMission + 0x1F8L)
                ?: return protectedFailure("REQUIRED_VALUE", pid, base, manager, activeMission)

            val conditionType = memory.readInt(pid, activeMission + 0x190L)
                ?: return directFailure("CONDITION_TYPE", pid, base, manager, activeMission)
            val conditionIndex = memory.readInt(pid, activeMission + 0x194L)
                ?: return directFailure("CONDITION_INDEX", pid, base, manager, activeMission)
            val comparator = memory.readInt(pid, activeMission + 0x1C8L)
                ?: return directFailure("COMPARATOR", pid, base, manager, activeMission)
            val completedFlag = memory.readByteUnsigned(pid, activeMission + 0x1CDL)
                ?: return directFailure("COMPLETED_FLAG", pid, base, manager, activeMission)
            val missionStateFlag = memory.readByteUnsigned(pid, activeMission + 0x1CEL)
                ?: return directFailure("MISSION_STATE_FLAG", pid, base, manager, activeMission)

            val snapshot = RootTowerSnapshot(
                pid = pid,
                libgameBase = base,
                managerGlobal = managerGlobal,
                manager = manager,
                activeMission = activeMission,
                statsManager = statsManager,
                currentFloor = currentFloor,
                missionOrder = missionOrder,
                bestStage = bestStage,
                missionId = missionId,
                missionFloor = missionFloor,
                conditionType = conditionType,
                conditionIndex = conditionIndex,
                comparator = comparator,
                requiredValue = requiredValue,
                rawCondition = rawCondition,
                secondaryState = secondaryState,
                finalSuccess = finalSuccess,
                pendingUnlock = pendingUnlock and 1,
                pendingCommit = pendingCommit and 1,
                completedFlag = completedFlag and 1,
                missionStateFlag = missionStateFlag and 1,
                managerStateByte = managerStateByte
            )

            val report = buildTowerReport(
                snapshot = snapshot,
                result = "OK",
                phase = "READ_STATE",
                rc = "0",
                resolverScore = candidate.score
            )

            return ReadResult(
                ok = true,
                stage = "READ_STATE",
                rc = "0",
                report = report,
                snapshot = snapshot
            )
        }

        private fun buildTowerReport(
            snapshot: RootTowerSnapshot,
            result: String,
            phase: String,
            rc: String,
            resolverScore: Int
        ): String = buildString {
            appendLine("TOWER_LAB")
            appendLine("readBuild=V1_9_MISSION_SOURCE_AUTO_PASS")
            appendLine("readRoute=ROOT_PROCESS_MEMORY")
            appendLine("resolver=STRICT_V2_1_PORT")
            appendLine("resolverScore=$resolverScore")
            appendLine("baseMode=STRICT_VALIDATED_LIBGAME_RANGE_ROOT")
            appendLine("RESULT=$result")
            appendLine("phase=$phase")
            appendLine("rc=$rc")
            appendLine("pid=${snapshot.pid}")
            appendLine("libgameBase=${hex(snapshot.libgameBase)}")
            appendLine("managerGlobal=${hex(snapshot.managerGlobal)}")
            appendLine("manager=${hex(snapshot.manager)}")
            appendLine("activeMission=${hex(snapshot.activeMission)}")
            appendLine("statsManager=${hex(snapshot.statsManager)}")
            appendLine("currentFloor=${snapshot.currentFloor}")
            appendLine("missionOrder=${snapshot.missionOrder}")
            appendLine("bestStage=${snapshot.bestStage}")
            appendLine("missionId=${snapshot.missionId}")
            appendLine("missionFloor=${snapshot.missionFloor}")
            appendLine("conditionType=${snapshot.conditionType}")
            appendLine("conditionIndex=${snapshot.conditionIndex}")
            appendLine("comparator=${snapshot.comparator}")
            appendLine("requiredValue=${snapshot.requiredValue}")
            appendLine("rawCondition=${snapshot.rawCondition}")
            appendLine("secondaryState=${snapshot.secondaryState}")
            appendLine("finalSuccess=${snapshot.finalSuccess}")
            appendLine("pendingUnlock=${snapshot.pendingUnlock}")
            appendLine("pendingCommit=${snapshot.pendingCommit}")
            appendLine("completedFlag=${snapshot.completedFlag}")
            appendLine("missionStateFlag=${snapshot.missionStateFlag}")
            append("managerStateByte=${snapshot.managerStateByte}")
        }

        private fun waitForFreshMission(context: Context): ReadResult {
            val started = SystemClock.elapsedRealtime()
            var latest = readTowerState(context)

            while (SystemClock.elapsedRealtime() - started <= PREPARE_WAIT_MS) {
                val snapshot = latest.snapshot
                if (latest.ok && snapshot != null) {
                    val fresh =
                        snapshot.managerStateByte == 0 &&
                            snapshot.activeMission != 0L &&
                            snapshot.completedFlag == 0 &&
                            snapshot.currentFloor in 1L..100L &&
                            snapshot.missionFloor in 1L..100L &&
                            snapshot.missionOrder in 1L..3L

                    if (fresh) {
                        return latest
                    }

                    publishFromReport(
                        report = latest.report,
                        running = true,
                        phaseOverride = "WAIT_FRESH_MISSION",
                        messageOverride = when {
                            snapshot.managerStateByte != 0 ->
                                "พบ Tower แล้ว • กำลังรอเข้า Stage"
                            snapshot.activeMission == 0L ->
                                "เข้า Stage แล้ว • กำลังรอ Active Mission"
                            snapshot.completedFlag != 0 ->
                                "กำลังรอ Mission ใหม่ที่ยังไม่ผ่าน"
                            else ->
                                "กำลังรอ Mission พร้อม..."
                        }
                    )
                }

                SystemClock.sleep(PREPARE_POLL_MS)
                latest = readTowerState(context)
            }

            val timeoutReport = buildString {
                appendLine("TOWER_LAB")
                appendLine("readBuild=V1_9_MISSION_SOURCE_AUTO_PASS")
                appendLine("RESULT=ERROR")
                appendLine("phase=WAIT_FRESH_MISSION")
                appendLine("rc=-320")
                appendLine("errorStage=WAIT_FRESH_MISSION_TIMEOUT")
                appendLine("waitedMs=$PREPARE_WAIT_MS")
                appendLine("--- LAST ROOT STATE ---")
                append(latest.report)
            }

            return ReadResult(
                ok = false,
                stage = "WAIT_FRESH_MISSION_TIMEOUT",
                rc = "-320",
                report = timeoutReport,
                snapshot = latest.snapshot
            )
        }

        @JvmStatic
        @Synchronized
        fun refreshState(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "TOWER LAB • INTERNAL_BUILD_REQUIRED"
            }

            val state = readTowerState(context.applicationContext)
            if (!state.ok) {
                return fail(state.stage, state.report, state.rc)
            }

            val snapshot = state.snapshot
            val readyForTest =
                snapshot != null &&
                    snapshot.managerStateByte == 0 &&
                    snapshot.activeMission != 0L &&
                    snapshot.completedFlag == 0 &&
                    snapshot.currentFloor in 1L..100L &&
                    snapshot.missionOrder in 1L..3L

            val phase = when {
                snapshot != null && snapshot.pendingCommit == 1 -> "RESULT_PENDING"
                snapshot != null && snapshot.completedFlag == 1 && snapshot.pendingCommit == 0 ->
                    "STAR_COMMITTED"
                readyForTest -> "READY_FOR_TEST"
                snapshot == null -> "WAIT_TOWER"
                snapshot.managerStateByte != 0 -> "WAIT_STAGE"
                snapshot.activeMission == 0L -> "WAIT_ACTIVE_MISSION"
                else -> "READY"
            }

            val message = when {
                snapshot != null && snapshot.pendingCommit == 1 ->
                    "เข้า Result แล้ว • กำลังรอเกมบันทึกดาว"
                snapshot != null && snapshot.completedFlag == 1 && snapshot.pendingCommit == 0 ->
                    "ดาวของ Mission นี้ถูกบันทึกแล้ว"
                readyForTest -> "พร้อมทดสอบ 1 ดาว • Mission ใหม่พร้อมแล้ว"
                snapshot == null -> "กำลังรอ Tower..."
                snapshot.managerStateByte != 0 ->
                    "อ่าน Tower สำเร็จ • อยู่หน้า Tower/กำลังรอเข้า Stage"
                snapshot.activeMission == 0L ->
                    "อ่าน Tower สำเร็จ • กำลังรอ Active Mission"
                else -> "อ่านสถานะ Tower สำเร็จ"
            }

            lastFullReport = buildString {
                appendLine("=== M WOIF LAB • TOWER STATE V1.5 ===")
                appendLine("READ_ROUTE=ROOT_PROCESS_MEMORY")
                appendLine("RESOLVER=STRICT_V2_1_PORT")
                appendLine("READY_FOR_TEST=$readyForTest")
                append(state.report)
            }

            publishFromReport(
                report = state.report,
                running = false,
                phaseOverride = phase,
                messageOverride = message
            )

            lastFullReport.lineSequence().take(320).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("TOWER", line)
            }

            return lastFullReport
        }

        private data class Protected32WriteResult(
            val ok: Boolean,
            val fieldAddress: Long,
            val p8: Long,
            val p10: Long,
            val p18: Long,
            val before: Long,
            val target: Long,
            val after: Long,
            val reason: String
        )

        private data class ConditionApplyResult(
            val ok: Boolean,
            val report: String
        )

        /**
         * Finds an RB-tree value using the exact node layout used by the
         * Tower/GameStats containers observed in libgame:
         *   node+0x00 left, node+0x08 right,
         *   node+0x20 int key, node+0x28 value pointer.
         *
         * headerRootAddress points to the tree root pointer itself.
         */
        private fun findRbTreeValue(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            headerRootAddress: Long,
            key: Int
        ): Long {
            if (!isMapped(maps, headerRootAddress, 8)) return 0L

            var node = memory.readLong(pid, headerRootAddress) ?: 0L
            var candidate = 0L
            var guard = 0

            while (
                isPointer(node) &&
                isMapped(maps, node, 0x30) &&
                guard < 256
            ) {
                val nodeKey = memory.readInt(pid, node + 0x20L) ?: return 0L

                if (key <= nodeKey) {
                    candidate = node
                }

                node = memory.readLong(
                    pid,
                    node + if (nodeKey < key) 0x08L else 0x00L
                ) ?: 0L
                guard += 1
            }

            if (!isPointer(candidate) || !isMapped(maps, candidate, 0x30)) {
                return 0L
            }

            val candidateKey = memory.readInt(pid, candidate + 0x20L) ?: return 0L
            if (candidateKey != key) return 0L

            val value = memory.readLong(pid, candidate + 0x28L) ?: 0L
            return if (isPointer(value) && isMapped(maps, value, 8)) value else 0L
        }

        /**
         * Resolve FUN_01320CE0(statsManager, type, conditionIndex) in read-only
         * form by traversing the same two RB-trees from RootProcessMemory.
         *
         * Outer map: statsManager+0x78 keyed by conditionType (1/2)
         * Inner map: typedContainer+0x08 keyed by conditionIndex
         */
        private fun resolveTypedStatObject(
            snapshot: RootTowerSnapshot,
            maps: List<RootProcessMemory.MapEntry>
        ): Pair<Long, Long> {
            if (snapshot.conditionType !in 1..2) return 0L to 0L
            if (!isPointer(snapshot.statsManager)) return 0L to 0L

            val typeContainer = findRbTreeValue(
                snapshot.pid,
                maps,
                snapshot.statsManager + 0x78L,
                snapshot.conditionType
            )
            if (!isPointer(typeContainer)) return 0L to 0L

            val statObject = findRbTreeValue(
                snapshot.pid,
                maps,
                typeContainer + 0x08L,
                snapshot.conditionIndex
            )
            return typeContainer to statObject
        }

        /**
         * Exact protected-32 writer for the FUN_00D654F8/FUN_00D65324 family.
         * It updates all three encoded copies and preserves the class-specific
         * third-copy masks derived from the currently valid value.
         */
        private fun writeProtected32PreserveMask(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            field: Long,
            target: Int
        ): Protected32WriteResult {
            val p8 = memory.readLong(pid, field + 0x08L) ?: 0L
            val p10 = memory.readLong(pid, field + 0x10L) ?: 0L
            val p18 = memory.readLong(pid, field + 0x18L) ?: 0L

            if (
                !isPointer(p8) || !isPointer(p10) || !isPointer(p18) ||
                !isMapped(maps, p8, 4) ||
                !isMapped(maps, p10, 4) ||
                !isMapped(maps, p18, 4)
            ) {
                return Protected32WriteResult(
                    false, field, p8, p10, p18, -1L,
                    target.toLong() and 0xFFFF_FFFFL, -1L,
                    "PROTECTED_PTR_INVALID"
                )
            }

            val old8 = memory.readBytes(pid, p8, 4)
                ?: return Protected32WriteResult(false, field, p8, p10, p18, -1L, target.toLong() and 0xFFFF_FFFFL, -1L, "READ_P8_FAILED")
            val old10 = memory.readBytes(pid, p10, 4)
                ?: return Protected32WriteResult(false, field, p8, p10, p18, -1L, target.toLong() and 0xFFFF_FFFFL, -1L, "READ_P10_FAILED")
            val old18 = memory.readBytes(pid, p18, 4)
                ?: return Protected32WriteResult(false, field, p8, p10, p18, -1L, target.toLong() and 0xFFFF_FFFFL, -1L, "READ_P18_FAILED")

            if (old8.size != 4 || old10.size != 4 || old18.size != 4) {
                return Protected32WriteResult(false, field, p8, p10, p18, -1L, target.toLong() and 0xFFFF_FFFFL, -1L, "ENCODED_SIZE_INVALID")
            }

            val before = decodeProtected32(pid, maps, field)
                ?: return Protected32WriteResult(false, field, p8, p10, p18, -1L, target.toLong() and 0xFFFF_FFFFL, -1L, "DECODE_BEFORE_FAILED")

            val oldBits = before.toInt()
            val oldB0 = oldBits and 0xFF
            val oldB1 = (oldBits ushr 8) and 0xFF
            val oldB2 = (oldBits ushr 16) and 0xFF
            val oldB3 = (oldBits ushr 24) and 0xFF

            val mask0 = (old18[0].toInt() and 0xFF) xor oldB3
            val mask1 = (old18[1].toInt() and 0xFF) xor oldB2
            val mask2 = (old18[2].toInt() and 0xFF) xor oldB1
            val mask3 = (old18[3].toInt() and 0xFF) xor oldB0

            val b0 = target and 0xFF
            val b1 = (target ushr 8) and 0xFF
            val b2 = (target ushr 16) and 0xFF
            val b3 = (target ushr 24) and 0xFF

            // Exact inverse of decodeProtected32() for the first two copies.
            val e8 = byteArrayOf(
                (((b3 xor 0xC5) + 1) and 0xFF).toByte(),
                (((b2 xor 0x39) + 1) and 0xFF).toByte(),
                (((b1 xor 0xC5) + 1) and 0xFF).toByte(),
                (((b0 xor 0x39) + 1) and 0xFF).toByte()
            )
            val e10 = byteArrayOf(
                (((b0 xor 0x6A) + 1) and 0xFF).toByte(),
                (((b1 xor 0x94) + 1) and 0xFF).toByte(),
                (((b2 xor 0x6A) + 1) and 0xFF).toByte(),
                (((b3 xor 0x94) + 1) and 0xFF).toByte()
            )
            val e18 = byteArrayOf(
                (b3 xor mask0).toByte(),
                (b2 xor mask1).toByte(),
                (b1 xor mask2).toByte(),
                (b0 xor mask3).toByte()
            )

            val paused = memory.pause(pid)
            return try {
                val wrote =
                    memory.writeBytes(pid, p8, e8) &&
                        memory.writeBytes(pid, p10, e10) &&
                        memory.writeBytes(pid, p18, e18)

                val after = decodeProtected32(pid, maps, field) ?: -1L
                val targetUnsigned = target.toLong() and 0xFFFF_FFFFL

                val verify18 = memory.readBytes(pid, p18, 4)
                val thirdCopyOk = verify18 != null && verify18.size == 4 &&
                    ((verify18[0].toInt() and 0xFF) xor mask0) == b3 &&
                    ((verify18[1].toInt() and 0xFF) xor mask1) == b2 &&
                    ((verify18[2].toInt() and 0xFF) xor mask2) == b1 &&
                    ((verify18[3].toInt() and 0xFF) xor mask3) == b0

                val ok = wrote && after == targetUnsigned && thirdCopyOk
                if (!ok) {
                    memory.writeBytes(pid, p8, old8)
                    memory.writeBytes(pid, p10, old10)
                    memory.writeBytes(pid, p18, old18)
                }

                Protected32WriteResult(
                    ok = ok,
                    fieldAddress = field,
                    p8 = p8,
                    p10 = p10,
                    p18 = p18,
                    before = before,
                    target = targetUnsigned,
                    after = if (ok) after else (decodeProtected32(pid, maps, field) ?: -1L),
                    reason = if (ok) "OK" else "VERIFY_FAILED_ROLLED_BACK"
                )
            } finally {
                if (paused) memory.resume(pid)
            }
        }

        private fun readAuthoritativeForward(snapshot: RootTowerSnapshot): ForwardSample {
            val maps = memory.maps(snapshot.pid)
            if (maps.isEmpty()) {
                return ForwardSample(false, reason = "ROOT_MAPS_EMPTY")
            }

            val stageServiceGlobal =
                snapshot.libgameBase + (STAGE_SERVICE_GLOBAL_GH - IMAGE_BASE)

            if (!isMapped(maps, stageServiceGlobal, 8)) {
                return ForwardSample(false, reason = "STAGE_SERVICE_GLOBAL_UNMAPPED")
            }

            val stageService =
                memory.readLong(snapshot.pid, stageServiceGlobal) ?: 0L
            if (!isPointer(stageService) || !isMapped(maps, stageService, 0x28)) {
                return ForwardSample(false, reason = "STAGE_SERVICE_NOT_READY")
            }

            var character = memory.readLong(
                snapshot.pid,
                stageService + STAGE_SERVICE_CHARACTER_OFFSET
            ) ?: 0L
            var route = "DIRECT"

            if (!isPointer(character) || !isMapped(maps, character, 0x80)) {
                val jellyManager = memory.readLong(
                    snapshot.pid,
                    stageService + STAGE_SERVICE_JELLY_MANAGER_OFFSET
                ) ?: 0L

                character = if (
                    isPointer(jellyManager) &&
                    isMapped(maps, jellyManager + JELLY_MANAGER_CHARACTER_OFFSET, 8)
                ) {
                    memory.readLong(
                        snapshot.pid,
                        jellyManager + JELLY_MANAGER_CHARACTER_OFFSET
                    ) ?: 0L
                } else {
                    0L
                }
                route = "JELLY_FALLBACK"
            }

            if (!isPointer(character) || !isMapped(maps, character, 0x80)) {
                return ForwardSample(false, reason = "CHARACTER_NOT_READY")
            }

            val transformObject = memory.readLong(
                snapshot.pid,
                character + CHARACTER_TRANSFORM_PTR_OFFSET
            ) ?: 0L
            if (
                !isPointer(transformObject) ||
                !isMapped(
                    maps,
                    transformObject + TRANSFORM_FORWARD_POSITION_OFFSET,
                    4
                )
            ) {
                return ForwardSample(
                    false,
                    character = character,
                    route = route,
                    reason = "TRANSFORM_NOT_READY"
                )
            }

            val field = transformObject + TRANSFORM_FORWARD_POSITION_OFFSET
            val forward = memory.readFloat(snapshot.pid, field)
            if (forward == null || !forward.isFinite()) {
                return ForwardSample(
                    false,
                    character = character,
                    transformObject = transformObject,
                    field = field,
                    route = route,
                    reason = "FORWARD_INVALID"
                )
            }

            return ForwardSample(
                ok = true,
                character = character,
                transformObject = transformObject,
                field = field,
                forward = forward,
                route = route,
                reason = "OK"
            )
        }

        private fun warpCharacterToExit(snapshot: RootTowerSnapshot): WarpResult {
            val maps = memory.maps(snapshot.pid)
            if (maps.isEmpty()) {
                return WarpResult(false, "RESULT=ERROR\nphase=WARP_ROOT_MAPS_EMPTY")
            }

            val stageServiceGlobal =
                snapshot.libgameBase + (STAGE_SERVICE_GLOBAL_GH - IMAGE_BASE)

            if (!isMapped(maps, stageServiceGlobal, 8)) {
                return WarpResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER WARP V2.0.6 ===")
                        appendLine("RESULT=WAIT_CHARACTER")
                        appendLine("phase=STAGE_SERVICE_GLOBAL_UNMAPPED")
                        append("stageServiceGlobal=${hex(stageServiceGlobal)}")
                    }
                )
            }

            val stageService = memory.readLong(snapshot.pid, stageServiceGlobal) ?: 0L
            if (!isPointer(stageService) || !isMapped(maps, stageService, 0x28)) {
                return WarpResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER WARP V2.0.6 ===")
                        appendLine("RESULT=WAIT_CHARACTER")
                        appendLine("phase=STAGE_SERVICE_NOT_READY")
                        append("stageService=${hex(stageService)}")
                    }
                )
            }

            var character = memory.readLong(
                snapshot.pid,
                stageService + STAGE_SERVICE_CHARACTER_OFFSET
            ) ?: 0L
            var characterRoute = "DIRECT"

            if (!isPointer(character) || !isMapped(maps, character, 0x80)) {
                val jellyManager = memory.readLong(
                    snapshot.pid,
                    stageService + STAGE_SERVICE_JELLY_MANAGER_OFFSET
                ) ?: 0L

                character = if (
                    isPointer(jellyManager) &&
                    isMapped(maps, jellyManager + JELLY_MANAGER_CHARACTER_OFFSET, 8)
                ) {
                    memory.readLong(
                        snapshot.pid,
                        jellyManager + JELLY_MANAGER_CHARACTER_OFFSET
                    ) ?: 0L
                } else {
                    0L
                }
                characterRoute = "JELLY_FALLBACK"
            }

            if (!isPointer(character) || !isMapped(maps, character, 0x80)) {
                return WarpResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER WARP V2.0.6 ===")
                        appendLine("RESULT=WAIT_CHARACTER")
                        appendLine("phase=CHARACTER_NOT_READY")
                        appendLine("stageService=${hex(stageService)}")
                        append("character=${hex(character)}")
                    }
                )
            }

            val transformObject = memory.readLong(
                snapshot.pid,
                character + CHARACTER_TRANSFORM_PTR_OFFSET
            ) ?: 0L

            if (
                !isPointer(transformObject) ||
                !isMapped(
                    maps,
                    transformObject + TRANSFORM_FORWARD_POSITION_OFFSET,
                    4
                )
            ) {
                return WarpResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER WARP V2.0.6 ===")
                        appendLine("RESULT=WAIT_CHARACTER")
                        appendLine("phase=TRANSFORM_NOT_READY")
                        appendLine("character=${hex(character)}")
                        append("transformObject=${hex(transformObject)}")
                    }
                )
            }

            val field =
                transformObject + TRANSFORM_FORWARD_POSITION_OFFSET
            val before = memory.readFloat(snapshot.pid, field)
            if (before == null || !before.isFinite()) {
                return WarpResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER WARP V2.0.6 ===")
                        appendLine("RESULT=ERROR")
                        appendLine("phase=WARP_READ_BEFORE_FAILED")
                        append("field=${hex(field)}")
                    }
                )
            }

            val writeOk = memory.writeFloat(
                snapshot.pid,
                field,
                LAB_WARP_TARGET_FORWARD
            )
            val after = memory.readFloat(snapshot.pid, field)
            val verified =
                writeOk &&
                    after != null &&
                    kotlin.math.abs(after - LAB_WARP_TARGET_FORWARD) <= 1.0f

            val report = buildString {
                appendLine("=== M WOIF LAB • TOWER WARP V2.0.6 ===")
                appendLine("RESULT=${if (verified) "WARP_POSITION_SET" else "ERROR"}")
                appendLine("ACTION_ROUTE=ROOT_AUTHORITATIVE_FORWARD_POSITION")
                appendLine("pid=${snapshot.pid}")
                appendLine("libgameBase=${hex(snapshot.libgameBase)}")
                appendLine("stageServiceGlobal=${hex(stageServiceGlobal)}")
                appendLine("stageService=${hex(stageService)}")
                appendLine("character=${hex(character)}")
                appendLine("characterRoute=$characterRoute")
                appendLine("transformObject=${hex(transformObject)}")
                appendLine("field=${hex(field)}")
                appendLine("fieldRoute=Character+0x78->Object+0x30")
                appendLine("before=$before")
                appendLine("target=$LAB_WARP_TARGET_FORWARD")
                appendLine("after=${after ?: "null"}")
                appendLine("writeOk=$writeOk")
                append("verified=$verified")
            }
            return WarpResult(verified, report)
        }

        /**
         * V2.0 writes the actual mission progress source for typed Tower
         * conditions (conditionType 1/2). The game then re-evaluates its own
         * raw/secondary/final success booleans naturally.
         *
         * Direct writes to rawCondition/secondary/finalSuccess are intentionally
         * removed because the evaluator overwrites those derived states while
         * the underlying mission progress is still below the requirement.
         */
        private fun applyMissionSourceRoot(snapshot: RootTowerSnapshot): ConditionApplyResult {
            val maps = memory.maps(snapshot.pid)
            if (maps.isEmpty()) {
                return ConditionApplyResult(false, "RESULT=ERROR\nphase=ROOT_MAPS_EMPTY")
            }

            if (snapshot.conditionType !in 1..2) {
                return ConditionApplyResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER SOURCE V2.0 ===")
                        appendLine("RESULT=UNSUPPORTED_SOURCE_TYPE")
                        appendLine("ACTION_ROUTE=WARP_THEN_EXACT_MISSION_SOURCE")
                        appendLine("conditionType=${snapshot.conditionType}")
                        appendLine("conditionIndex=${snapshot.conditionIndex}")
                        append("reason=TYPE0_USES_DIFFERENT_GAME_STATS_STORAGE")
                    }
                )
            }

            if (snapshot.requiredValue < 0L || snapshot.requiredValue > 0x7FFF_FFFFL) {
                return ConditionApplyResult(
                    false,
                    "RESULT=ERROR\nphase=REQUIRED_VALUE_RANGE\nrequiredValue=${snapshot.requiredValue}"
                )
            }

            val (typeContainer, statObject) = resolveTypedStatObject(snapshot, maps)
            if (!isPointer(typeContainer) || !isPointer(statObject)) {
                return ConditionApplyResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER SOURCE V2.0 ===")
                        appendLine("RESULT=WAIT_TYPED_STAT_OBJECT")
                        appendLine("ACTION_ROUTE=WARP_THEN_EXACT_MISSION_SOURCE")
                        appendLine("statsManager=${hex(snapshot.statsManager)}")
                        appendLine("conditionType=${snapshot.conditionType}")
                        appendLine("conditionIndex=${snapshot.conditionIndex}")
                        appendLine("typeContainer=${hex(typeContainer)}")
                        append("typedStatObject=${hex(statObject)}")
                    }
                )
            }

            val valueField = statObject + 0x50L
            val target = snapshot.requiredValue.toInt()
            val write = writeProtected32PreserveMask(
                snapshot.pid,
                maps,
                valueField,
                target
            )

            val report = buildString {
                appendLine("=== M WOIF LAB • TOWER SOURCE V2.0 ===")
                appendLine("RESULT=${if (write.ok) "MISSION_SOURCE_SET" else "ERROR"}")
                appendLine("ACTION_ROUTE=WARP_THEN_EXACT_MISSION_SOURCE")
                appendLine("DERIVED_SUCCESS_BOOL_WRITE=DISABLED")
                appendLine("USER_FLOW=PLAY_MANUAL_EXIT_MANUAL")
                appendLine("pid=${snapshot.pid}")
                appendLine("manager=${hex(snapshot.manager)}")
                appendLine("activeMission=${hex(snapshot.activeMission)}")
                appendLine("missionId=${snapshot.missionId}")
                appendLine("currentFloor=${snapshot.currentFloor}")
                appendLine("missionOrder=${snapshot.missionOrder}")
                appendLine("missionFloor=${snapshot.missionFloor}")
                appendLine("conditionType=${snapshot.conditionType}")
                appendLine("conditionIndex=${snapshot.conditionIndex}")
                appendLine("comparator=${snapshot.comparator}")
                appendLine("requiredValue=${snapshot.requiredValue}")
                appendLine("statsManager=${hex(snapshot.statsManager)}")
                appendLine("typeContainer=${hex(typeContainer)}")
                appendLine("typedStatObject=${hex(statObject)}")
                appendLine("valueField=${hex(valueField)}")
                appendLine("currentBefore=${write.before}")
                appendLine("target=${write.target}")
                appendLine("currentAfter=${write.after}")
                appendLine("p8=${hex(write.p8)}")
                appendLine("p10=${hex(write.p10)}")
                appendLine("p18=${hex(write.p18)}")
                append("writeReason=${write.reason}")
            }

            lastAutoWriteReport = report
            return ConditionApplyResult(write.ok, report)
        }

        /**
         * V2.0.6 controlled special case for Type0/index5 ("Slide for N seconds").
         *
         * Proven by Lua:
         * - At 0/N the GameStats Type0 RB-tree has no key=5 node.
         * - One tiny real Slide input creates the node.
         * - The node itself is a protected-int source.
         * - raw target = requiredValue * 1,000,000.
         * - After the source reaches target, CookieRun sets rawCondition=1 itself.
         *
         * This helper therefore does NOT invent/create RB-tree nodes and does NOT
         * write derived Tower success booleans. It reproduces the proven sequence:
         * auto Slide once -> wait key=5 -> write real source -> wait evaluator.
         */
        private fun applyType0Index5AutoSlideSource(
            context: Context,
            snapshot: RootTowerSnapshot
        ): ConditionApplyResult {
            if (
                snapshot.conditionType != 0 ||
                snapshot.conditionIndex != TYPE0_SLIDE_INDEX
            ) {
                return ConditionApplyResult(
                    false,
                    "RESULT=ERROR\nphase=TYPE0_INDEX5_WRONG_MISSION"
                )
            }

            if (snapshot.requiredValue <= 0L) {
                return ConditionApplyResult(
                    false,
                    "RESULT=ERROR\nphase=TYPE0_INDEX5_REQUIRED_INVALID\nrequiredValue=${snapshot.requiredValue}"
                )
            }

            val rawTargetLong =
                snapshot.requiredValue * TYPE0_SLIDE_RAW_SCALE

            if (rawTargetLong <= 0L || rawTargetLong > 0x7FFF_FFFFL) {
                return ConditionApplyResult(
                    false,
                    "RESULT=ERROR\nphase=TYPE0_INDEX5_RAW_TARGET_RANGE\nrawTarget=$rawTargetLong"
                )
            }

            val metrics = context.applicationContext.resources.displayMetrics
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val tapX =
                (TYPE0_SLIDE_X.coerceIn(0f, 1f) * (width - 1)).toInt()
            val tapY =
                (TYPE0_SLIDE_Y.coerceIn(0f, 1f) * (height - 1)).toInt()

            // Exact same root tap route already used by BotLabController.
            val tapOk = RootMemoryClient.botTap(tapX, tapY)
            if (!tapOk) {
                return ConditionApplyResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER TYPE0 INDEX5 V2.0.6 ===")
                        appendLine("RESULT=ERROR")
                        appendLine("phase=AUTO_SLIDE_TAP_FAILED")
                        appendLine("tapX=$tapX")
                        append("tapY=$tapY")
                    }
                )
            }

            // The game creates the Type0/key5 protected-stat node from the real
            // Slide event. Poll only for that natural object.
            var maps = memory.maps(snapshot.pid)
            var statObject = 0L
            val sourceDeadline =
                SystemClock.elapsedRealtime() + TYPE0_SLIDE_SOURCE_WAIT_MS

            while (SystemClock.elapsedRealtime() < sourceDeadline) {
                if (maps.isEmpty()) {
                    maps = memory.maps(snapshot.pid)
                }

                statObject = findRbTreeValue(
                    snapshot.pid,
                    maps,
                    snapshot.statsManager + 0x30L,
                    TYPE0_SLIDE_INDEX
                )

                if (isPointer(statObject)) {
                    break
                }

                SystemClock.sleep(TYPE0_SLIDE_SOURCE_POLL_MS)
            }

            if (!isPointer(statObject)) {
                return ConditionApplyResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER TYPE0 INDEX5 V2.0.6 ===")
                        appendLine("RESULT=ERROR")
                        appendLine("phase=SOURCE_NOT_CREATED_AFTER_AUTO_SLIDE")
                        appendLine("statsManager=${hex(snapshot.statsManager)}")
                        appendLine("conditionIndex=${snapshot.conditionIndex}")
                        appendLine("waitMs=$TYPE0_SLIDE_SOURCE_WAIT_MS")
                        appendLine("tapX=$tapX")
                        append("tapY=$tapY")
                    }
                )
            }

            // Refresh maps once after the game allocated/attached the node.
            maps = memory.maps(snapshot.pid)
            if (maps.isEmpty()) {
                return ConditionApplyResult(
                    false,
                    "RESULT=ERROR\nphase=MAPS_EMPTY_AFTER_SOURCE_CREATE"
                )
            }

            val rawBefore =
                decodeProtected32(snapshot.pid, maps, statObject)

            val write = writeProtected32PreserveMask(
                snapshot.pid,
                maps,
                statObject,
                rawTargetLong.toInt()
            )

            if (!write.ok) {
                return ConditionApplyResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER TYPE0 INDEX5 V2.0.6 ===")
                        appendLine("RESULT=ERROR")
                        appendLine("phase=SOURCE_WRITE_FAILED")
                        appendLine("statObject=${hex(statObject)}")
                        appendLine("rawBefore=$rawBefore")
                        appendLine("rawTarget=$rawTargetLong")
                        appendLine("currentAfter=${write.after}")
                        append("writeReason=${write.reason}")
                    }
                )
            }

            // Critical difference from the failed pre-seed attempt:
            // do NOT Warp immediately after writing. Lua showed rawCondition can
            // become true shortly after the real source reaches target. Wait for
            // CookieRun's evaluator before Warp.
            var rawCondition = 0
            var sourceFinal =
                decodeProtected32(snapshot.pid, maps, statObject)

            val evalDeadline =
                SystemClock.elapsedRealtime() + TYPE0_SLIDE_EVAL_WAIT_MS

            while (SystemClock.elapsedRealtime() < evalDeadline) {
                rawCondition =
                    decodeProtectedBool(
                        snapshot.pid,
                        maps,
                        snapshot.manager + 0x0A8L
                    ) ?: 0

                sourceFinal =
                    decodeProtected32(snapshot.pid, maps, statObject)

                if (rawCondition == 1) {
                    break
                }

                SystemClock.sleep(TYPE0_SLIDE_EVAL_POLL_MS)
            }

            val ok = rawCondition == 1
            val report = buildString {
                appendLine("=== M WOIF LAB • TOWER TYPE0 INDEX5 V2.0.6 ===")
                appendLine(
                    "RESULT=${if (ok) "MISSION_CONDITION_REACHED" else "SOURCE_SET_WAIT_EVALUATOR_TIMEOUT"}"
                )
                appendLine("ACTION_ROUTE=AUTO_SLIDE_CREATE_NODE_THEN_ROOT_EXACT_SOURCE")
                appendLine("MANUAL_SLIDE_REQUIRED=false")
                appendLine("AUTO_SLIDE_TAP=true")
                appendLine("conditionType=${snapshot.conditionType}")
                appendLine("conditionIndex=${snapshot.conditionIndex}")
                appendLine("requiredValue=${snapshot.requiredValue}")
                appendLine("rawTarget=$rawTargetLong")
                appendLine("statObject=${hex(statObject)}")
                appendLine("rawBefore=$rawBefore")
                appendLine("rawAfterWrite=${write.after}")
                appendLine("rawFinal=$sourceFinal")
                appendLine("rawCondition=$rawCondition")
                appendLine("tapX=$tapX")
                appendLine("tapY=$tapY")
                appendLine("sourceWaitMs=$TYPE0_SLIDE_SOURCE_WAIT_MS")
                appendLine("evaluatorWaitMs=$TYPE0_SLIDE_EVAL_WAIT_MS")
                appendLine("DERIVED_SUCCESS_BOOL_WRITE=DISABLED")
                appendLine("WARP_DURING_PREPARE=DISABLED")
                append("COMMIT_WRITE=DISABLED")
            }

            lastAutoWriteReport = report
            return ConditionApplyResult(ok, report)
        }

        /**
         * conditionType 0 already has a verified exact-stat game-thread route in
         * the in-process native bridge. It is invoked only after the gate trigger.
         */
        private fun applyType0MissionExact(
            context: Context,
            snapshot: RootTowerSnapshot
        ): ConditionApplyResult {
            if (snapshot.conditionType != 0) {
                return ConditionApplyResult(
                    false,
                    "RESULT=ERROR\nphase=TYPE0_ROUTE_WRONG_TYPE\nconditionType=${snapshot.conditionType}"
                )
            }

            val app = context.applicationContext
            val ping = InProcessGameControl.ping(app, 2_000L)
            if (!ping.ok) {
                return ConditionApplyResult(
                    false,
                    buildString {
                        appendLine("=== M WOIF LAB • TOWER TYPE0 V2.0 ===")
                        appendLine("RESULT=ERROR")
                        appendLine("ACTION_ROUTE=INPROCESS_GAME_THREAD_EXACT_STAT")
                        appendLine("phase=BRIDGE_NOT_READY")
                        append("bridge=${ping.message}")
                    }
                )
            }

            val action = InProcessGameControl.towerTestMissionSuccess(app, 2_500L)
            val ok = action.ok &&
                !action.message.contains("RESULT=ERROR") &&
                !action.message.contains("UNSUPPORTED_CONDITION_TYPE")

            val report = buildString {
                appendLine("=== M WOIF LAB • TOWER TYPE0 V2.0 ===")
                appendLine("RESULT=${if (ok) "MISSION_SOURCE_SET" else "ERROR"}")
                appendLine("ACTION_ROUTE=INPROCESS_GAME_THREAD_EXACT_STAT")
                appendLine("TRIGGER=WARP_STAGE_ENTRY")
                appendLine("conditionType=${snapshot.conditionType}")
                appendLine("conditionIndex=${snapshot.conditionIndex}")
                appendLine("requiredValue=${snapshot.requiredValue}")
                appendLine("bridge=${ping.message}")
                append("native=${action.message}")
            }

            lastAutoWriteReport = report
            return ConditionApplyResult(ok, report)
        }

        private fun applyMissionExact(
            context: Context,
            snapshot: RootTowerSnapshot
        ): ConditionApplyResult = when (snapshot.conditionType) {
            0 -> applyType0MissionExact(context, snapshot)
            1, 2 -> applyMissionSourceRoot(snapshot)
            else -> ConditionApplyResult(
                false,
                buildString {
                    appendLine("=== M WOIF LAB • TOWER APPLY V2.0 ===")
                    appendLine("RESULT=UNSUPPORTED_SOURCE_TYPE")
                    appendLine("conditionType=${snapshot.conditionType}")
                    appendLine("conditionIndex=${snapshot.conditionIndex}")
                    append("requiredValue=${snapshot.requiredValue}")
                }
            )
        }

        private fun isFreshManualStage(snapshot: RootTowerSnapshot): Boolean =
            snapshot.managerStateByte == 0 &&
                snapshot.activeMission != 0L &&
                snapshot.completedFlag == 0 &&
                snapshot.currentFloor in 1L..100L &&
                snapshot.missionFloor in 1L..100L &&
                snapshot.missionOrder in 1L..3L

        private fun missionKey(snapshot: RootTowerSnapshot): String =
            "${snapshot.currentFloor}:${snapshot.missionOrder}:${snapshot.missionId}:${hex(snapshot.activeMission)}"

        private fun autoPassLoop(context: Context) {
            val app = context.applicationContext
            var completedActionMissionKey = "NONE"
            var lastAttemptAt = 0L

            // V2.0.6:
            // Do not use a fixed timer. Track the exact authoritative forward
            // field and arm Warp only after sustained real movement.
            var observedMissionKey = "NONE"

            var runCharacter = 0L
            var runTransform = 0L
            var runStartForward = Float.NaN
            var runLastForward = Float.NaN
            var runMovingSamples = 0
            var runStartDetected = false

            while (autoPassEnabled) {
                val read = readTowerState(app)
                val snapshot = read.snapshot

                if (!autoPassEnabled) break

                if (!read.ok || snapshot == null) {
                    liveState = liveState.copy(
                        running = true,
                        phase = "ARMED_WAIT_RUNTIME",
                        message = "ปั้มเปิดอยู่ • กำลังรอ Tower/เกมพร้อม",
                        errorStage = if (read.ok) "NONE" else read.stage,
                        errorRc = if (read.ok) "0" else read.rc
                    )
                    lastFullReport = buildString {
                        appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                        appendLine("RESULT=WAIT_RUNTIME")
                        appendLine("AUTO_PASS=ON")
                        append(read.report)
                    }
                    SystemClock.sleep(AUTO_PASS_POLL_MS)
                    continue
                }

                publishFromReport(
                    report = read.report,
                    running = true,
                    phaseOverride = liveState.phase,
                    messageOverride = liveState.message
                )

                val mission =
                    if (isFreshManualStage(snapshot)) missionKey(snapshot) else "NONE"

                if (mission == "NONE") {
                    observedMissionKey = "NONE"
                    runCharacter = 0L
                    runTransform = 0L
                    runStartForward = Float.NaN
                    runLastForward = Float.NaN
                    runMovingSamples = 0
                    runStartDetected = false
                } else if (mission != observedMissionKey) {
                    observedMissionKey = mission
                    completedActionMissionKey = "NONE"
                    lastAttemptAt = 0L

                    runCharacter = 0L
                    runTransform = 0L
                    runStartForward = Float.NaN
                    runLastForward = Float.NaN
                    runMovingSamples = 0
                    runStartDetected = false
                }

                var runSample: ForwardSample? = null
                var runStep = 0.0f
                var runTotalMove = 0.0f

                if (
                    mission != "NONE" &&
                    completedActionMissionKey != mission &&
                    !runStartDetected
                ) {
                    runSample = readAuthoritativeForward(snapshot)

                    if (runSample.ok) {
                        val sameObject =
                            runSample.character == runCharacter &&
                                runSample.transformObject == runTransform

                        if (!sameObject) {
                            runCharacter = runSample.character
                            runTransform = runSample.transformObject
                            runStartForward = runSample.forward
                            runLastForward = runSample.forward
                            runMovingSamples = 0
                        } else if (runLastForward.isFinite()) {
                            runStep = runSample.forward - runLastForward
                            runTotalMove =
                                if (runStartForward.isFinite()) {
                                    runSample.forward - runStartForward
                                } else {
                                    0.0f
                                }

                            if (runStep >= RUN_START_MIN_STEP) {
                                runMovingSamples += 1
                            } else if (runStep < -RUN_START_MIN_STEP) {
                                runStartForward = runSample.forward
                                runMovingSamples = 0
                            } else if (runMovingSamples > 0) {
                                runMovingSamples -= 1
                            }

                            if (
                                runMovingSamples >= RUN_START_REQUIRED_MOVING_SAMPLES &&
                                runTotalMove >= RUN_START_MIN_TOTAL_MOVE
                            ) {
                                runStartDetected = true
                            }

                            runLastForward = runSample.forward
                        }
                    }
                }

                when {
                    snapshot.pendingCommit == 1 -> {
                        liveState = liveState.copy(
                            running = true,
                            phase = "RESULT_PENDING",
                            message = "ถึง Result แล้ว • รอเกม Commit ดาว",
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }

                    snapshot.completedFlag == 1 -> {
                        liveState = liveState.copy(
                            running = true,
                            phase = "STAR_COMMITTED_WAIT_NEXT",
                            message = "ดาวบันทึกแล้ว • เลือก Mission/ด่านถัดไปได้เลย",
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }

                    snapshot.managerStateByte != 0 -> {
                        observedMissionKey = "NONE"
                        completedActionMissionKey = "NONE"
                        lastAttemptAt = 0L
                        runCharacter = 0L
                        runTransform = 0L
                        runStartForward = Float.NaN
                        runLastForward = Float.NaN
                        runMovingSamples = 0
                        runStartDetected = false
                        liveState = liveState.copy(
                            running = true,
                            phase = "ARMED_WAIT_STAGE",
                            message = "ปั้มเปิดอยู่ • กดเริ่ม Tower เองได้เลย",
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }

                    snapshot.activeMission == 0L -> {
                        observedMissionKey = "NONE"
                        runCharacter = 0L
                        runTransform = 0L
                        runStartForward = Float.NaN
                        runLastForward = Float.NaN
                        runMovingSamples = 0
                        runStartDetected = false
                        liveState = liveState.copy(
                            running = true,
                            phase = "WAIT_ACTIVE_MISSION",
                            message = "เข้า Stage แล้ว • รอ Mission/Character พร้อม",
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }

                    isFreshManualStage(snapshot) &&
                        completedActionMissionKey != mission &&
                        !runStartDetected -> {
                        val sample = runSample
                        liveState = liveState.copy(
                            running = true,
                            phase = "WAIT_RUN_START",
                            message = if (sample?.ok == true) {
                                "Stage โหลดแล้ว • รอ Cookie เริ่มวิ่งจริง (${runMovingSamples}/${RUN_START_REQUIRED_MOVING_SAMPLES})"
                            } else {
                                "กำลังโหลด Stage • รอ Character/Transform พร้อม"
                            },
                            errorStage = "NONE",
                            errorRc = "0"
                        )

                        lastFullReport = buildString {
                            appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                            appendLine("RESULT=WAIT_RUN_START")
                            appendLine("MISSION_KEY=$mission")
                            appendLine("trigger=AUTHORITATIVE_FORWARD_MOVEMENT")
                            appendLine("requiredMovingSamples=$RUN_START_REQUIRED_MOVING_SAMPLES")
                            appendLine("minStep=$RUN_START_MIN_STEP")
                            appendLine("minTotalMove=$RUN_START_MIN_TOTAL_MOVE")
                            appendLine("movingSamples=$runMovingSamples")
                            appendLine("runStartDetected=$runStartDetected")
                            if (sample != null) {
                                appendLine("sampleOk=${sample.ok}")
                                appendLine("sampleReason=${sample.reason}")
                                appendLine("character=${hex(sample.character)}")
                                appendLine("transformObject=${hex(sample.transformObject)}")
                                appendLine("forwardField=${hex(sample.field)}")
                                appendLine("forward=${sample.forward}")
                                appendLine("step=$runStep")
                                appendLine("totalMove=$runTotalMove")
                            }
                            appendLine("--- ROOT STATE ---")
                            append(read.report)
                        }
                    }

                    isFreshManualStage(snapshot) &&
                        runStartDetected &&
                        snapshot.conditionType == 0 &&
                        snapshot.conditionIndex == TYPE0_SLIDE_INDEX &&
                        completedActionMissionKey != mission -> {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastAttemptAt < 120L) {
                            liveState = liveState.copy(
                                running = true,
                                phase = "WAIT_WARP_READY",
                                message = "Slide Mission • รอเตรียม source",
                                errorStage = "NONE",
                                errorRc = "0"
                            )
                        } else {
                            lastAttemptAt = now
                            lastAutoMissionKey = mission

                            liveState = liveState.copy(
                                running = true,
                                phase = "WAIT_WARP_READY",
                                message = "Slide Mission • กำลังแตะ Slide อัตโนมัติ + ตั้ง 45/45",
                                errorStage = "NONE",
                                errorRc = "0"
                            )

                            val prepared =
                                applyType0Index5AutoSlideSource(app, snapshot)

                            if (!prepared.ok) {
                                lastFailedReport = prepared.report
                                lastFullReport = buildString {
                                    appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                                    appendLine("RESULT=TYPE0_INDEX5_PREPARE_RETRY")
                                    appendLine("MISSION_KEY=$mission")
                                    appendLine("--- TYPE0 INDEX5 PREPARE ---")
                                    append(prepared.report)
                                }

                                liveState = liveState.copy(
                                    running = true,
                                    phase = "WAIT_WARP_READY",
                                    message = "Slide Mission ยังไม่พร้อม • กำลังลองใหม่",
                                    errorStage = "TYPE0_INDEX5_PREPARE",
                                    errorRc = "RETRY"
                                )
                            } else {
                                // Only Warp AFTER CookieRun's own evaluator has
                                // already turned rawCondition on.
                                val warp = warpCharacterToExit(snapshot)

                                if (!warp.ok) {
                                    lastFullReport = buildString {
                                        appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                                        appendLine("RESULT=TYPE0_INDEX5_WAIT_WARP_READY")
                                        appendLine("MISSION_KEY=$mission")
                                        appendLine("--- TYPE0 INDEX5 PREPARE ---")
                                        appendLine(prepared.report)
                                        appendLine("--- WARP ---")
                                        append(warp.report)
                                    }

                                    liveState = liveState.copy(
                                        running = true,
                                        phase = "WAIT_WARP_READY",
                                        message = "Slide Mission ผ่านแล้ว • รอ Character พร้อมสำหรับ Warp",
                                        errorStage = "NONE",
                                        errorRc = "0"
                                    )
                                } else {
                                    // Do not call the old Type0 native setter here.
                                    // The real source already passed and rawCondition=1.
                                    completedActionMissionKey = mission
                                    lastAutoMissionKey = mission
                                    lastAutoWriteReport = buildString {
                                        appendLine("--- TYPE0 INDEX5 PREPARE ---")
                                        appendLine(prepared.report)
                                        appendLine("--- WARP ---")
                                        append(warp.report)
                                    }

                                    lastFullReport = buildString {
                                        appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                                        appendLine("RESULT=TYPE0_INDEX5_SOURCE_PASS_THEN_WARP")
                                        appendLine("MISSION_KEY=$mission")
                                        appendLine("MANUAL_SLIDE_REQUIRED=false")
                                        appendLine("AUTO_SLIDE_TAP=true")
                                        appendLine("WARP_TARGET_FORWARD=$LAB_WARP_TARGET_FORWARD")
                                        appendLine("--- TYPE0 INDEX5 PREPARE ---")
                                        appendLine(prepared.report)
                                        appendLine("--- WARP ---")
                                        append(warp.report)
                                    }

                                    liveState = liveState.copy(
                                        running = true,
                                        phase = "WARPED_MISSION_SET_WAIT_GATE",
                                        message = "Slide Mission ผ่านแล้ว • Warp แล้ว • รอ Gate/Result",
                                        errorStage = "NONE",
                                        errorRc = "0"
                                    )
                                }
                            }
                        }
                    }

                    isFreshManualStage(snapshot) &&
                        runStartDetected &&
                        completedActionMissionKey != mission -> {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastAttemptAt < 120L) {
                            liveState = liveState.copy(
                                running = true,
                                phase = "WAIT_WARP_READY",
                                message = "Stage พร้อม • รอ Character พร้อมสำหรับ Warp",
                                errorStage = "NONE",
                                errorRc = "0"
                            )
                        } else {
                            lastAttemptAt = now
                            lastAutoMissionKey = mission
                            liveState = liveState.copy(
                                running = true,
                                phase = "WARP_AND_APPLY_MISSION",
                                message = "เข้า Stage แล้ว • กำลังวาร์ปหน้าประตู + ทำ Mission ให้ผ่าน",
                                errorStage = "NONE",
                                errorRc = "0"
                            )

                            val warp = warpCharacterToExit(snapshot)
                            if (!warp.ok) {
                                lastFullReport = buildString {
                                    appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                                    appendLine("RESULT=WAIT_WARP_READY")
                                    appendLine("MISSION_KEY=$mission")
                                    appendLine("--- ROOT STATE ---")
                                    appendLine(read.report)
                                    appendLine("--- WARP ---")
                                    append(warp.report)
                                }
                                liveState = liveState.copy(
                                    running = true,
                                    phase = "WAIT_WARP_READY",
                                    message = "Mission พร้อม • รอ Character พร้อมสำหรับ Warp",
                                    errorStage = "NONE",
                                    errorRc = "0"
                                )
                            } else {
                                val applied = applyMissionExact(app, snapshot)
                                if (applied.ok) {
                                    completedActionMissionKey = mission
                                    lastAutoMissionKey = mission
                                    lastAutoWriteReport = buildString {
                                        appendLine("--- WARP ---")
                                        appendLine(warp.report)
                                        appendLine("--- MISSION ---")
                                        append(applied.report)
                                    }
                                    lastFullReport = buildString {
                                        appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                                        appendLine("RESULT=WARP_AND_MISSION_SET")
                                        appendLine("AUTO_PASS=ON")
                                        appendLine("MISSION_KEY=$mission")
                                        appendLine("WARP_TARGET_FORWARD=$LAB_WARP_TARGET_FORWARD")
                                        appendLine("--- ROOT BEFORE ---")
                                        appendLine(read.report)
                                        appendLine("--- WARP ---")
                                        appendLine(warp.report)
                                        appendLine("--- MISSION APPLY ---")
                                        append(applied.report)
                                    }
                                    liveState = liveState.copy(
                                        running = true,
                                        phase = "WARPED_MISSION_SET_WAIT_GATE",
                                        message = "วาร์ปหน้าประตูแล้ว • Mission ตั้งเป้าครบ • รอ Gate/Result",
                                        errorStage = "NONE",
                                        errorRc = "0"
                                    )
                                } else {
                                    lastFailedReport = applied.report
                                    lastFullReport = buildString {
                                        appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                                        appendLine("RESULT=MISSION_APPLY_RETRY")
                                        appendLine("MISSION_KEY=$mission")
                                        appendLine("--- WARP ---")
                                        appendLine(warp.report)
                                        appendLine("--- MISSION APPLY ---")
                                        append(applied.report)
                                    }
                                    liveState = liveState.copy(
                                        running = true,
                                        phase = "MISSION_APPLY_RETRY",
                                        message = "วาร์ปแล้ว • Mission ยังตั้งไม่สำเร็จ • กำลังลองใหม่",
                                        errorStage = "MISSION_APPLY",
                                        errorRc = "WRITE"
                                    )
                                }
                            }
                        }
                    }

                    isFreshManualStage(snapshot) &&
                        snapshot.rawCondition == 1 &&
                        snapshot.finalSuccess == 1 &&
                        snapshot.secondaryState == 1 -> {
                        liveState = liveState.copy(
                            running = true,
                            phase = "MISSION_PASSED_WAIT_RESULT",
                            message = "Mission ผ่าน + ถึง Gate แล้ว • รอ Result",
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }

                    isFreshManualStage(snapshot) &&
                        completedActionMissionKey == mission -> {
                        liveState = liveState.copy(
                            running = true,
                            phase = "WARPED_MISSION_SET_WAIT_GATE",
                            message = if (
                                snapshot.rawCondition == 1 &&
                                snapshot.finalSuccess == 1
                            ) {
                                "Mission ผ่านแล้ว • อยู่หน้าประตู • รอ Gate/Result"
                            } else {
                                "วาร์ปแล้ว • Mission ตั้งเป้าครบ • รอเกมประเมิน"
                            },
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }

                    else -> {
                        liveState = liveState.copy(
                            running = true,
                            phase = "ARMED_WAIT_MISSION",
                            message = "ปั้มเปิดอยู่ • รอ Mission ใหม่",
                            errorStage = "NONE",
                            errorRc = "0"
                        )
                    }
                }

                SystemClock.sleep(AUTO_PASS_POLL_MS)
            }

            autoPassThread = null
        }

        @JvmStatic
        @Synchronized
        fun startAutoPass(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "TOWER LAB • INTERNAL_BUILD_REQUIRED"
            }

            if (autoPassEnabled) {
                return "TOWER_AUTO_PASS\nRESULT=ALREADY_ON\nAUTO_PASS=ON"
            }

            val app = context.applicationContext
            if (!memory.hasRoot() && !memory.requestRoot(app)) {
                return fail(
                    "ROOT_NOT_READY",
                    "TOWER_AUTO_PASS\nRESULT=ERROR\nphase=ROOT_NOT_READY\nrc=ROOT"
                )
            }

            autoPassEnabled = true
            lastAutoMissionKey = "NONE"
            lastAutoWriteReport = "NONE"
            liveState = liveState.copy(
                running = true,
                phase = "ARMED_WAIT_STAGE",
                message = "ปั้มเปิดแล้ว • กดเล่น Tower เองได้เลย",
                errorStage = "NONE",
                errorRc = "0"
            )

            val worker = Thread({ autoPassLoop(app) }, "MWOIF-TOWER-AUTO-PASS")
            worker.isDaemon = true
            autoPassThread = worker
            worker.start()

            lastFullReport = buildString {
                appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                appendLine("RESULT=STARTED")
                appendLine("AUTO_PASS=ON")
                appendLine("WARP_TRIGGER=AUTHORITATIVE_FORWARD_RUN_START")
                appendLine("TYPE0_ROUTE=INPROCESS_GAME_THREAD_EXACT_STAT")
            appendLine("TYPE0_INDEX5_ROUTE=AUTO_SLIDE_CREATE_NODE_THEN_ROOT_RAW_REQUIRED_X1000000")
            appendLine("TYPE0_INDEX5_MANUAL_SLIDE_REQUIRED=false")
            appendLine("TYPE0_INDEX5_WAIT_RAW_CONDITION_BEFORE_WARP=true")
                appendLine("TYPE1_2_ROUTE=ROOT_TYPED_MISSION_SOURCE_EXACT")
                appendLine("MISSION_APPLY=AT_GATE_ONLY")
                appendLine("POLL_MS=$AUTO_PASS_POLL_MS")
                appendLine("DIRECT_TOTAL_STAR_WRITE=DISABLED")
                appendLine("DIRECT_BEST_STAGE_WRITE=DISABLED")
                appendLine("DIRECT_COMPLETED_FLAG_WRITE=DISABLED")
                appendLine("DIRECT_PENDING_COMMIT_WRITE=DISABLED")
                append("MESSAGE=เข้า Stage เอง • พร้อมแล้ววาร์ปหน้าประตู + ตั้ง Mission = requiredValue ทันที • Result/Commit ปล่อยเกมทำเอง")
            }
            return lastFullReport
        }

        @JvmStatic
        @Synchronized
        fun stopAutoPass(): String {
            autoPassEnabled = false
            autoPassThread?.interrupt()
            autoPassThread = null

            liveState = liveState.copy(
                running = false,
                phase = "STOPPED",
                message = "ปั้ม Tower ปิดแล้ว",
                errorStage = "NONE",
                errorRc = "0"
            )

            lastFullReport = buildString {
                appendLine("=== M WOIF LAB • TOWER WARP PASS V2.0.6 ===")
                appendLine("RESULT=STOPPED")
                appendLine("AUTO_PASS=OFF")
                appendLine("LAST_MISSION_KEY=$lastAutoMissionKey")
                append("LAST_WRITE_AVAILABLE=${lastAutoWriteReport != "NONE"}")
            }
            return lastFullReport
        }

        /**
         * Backward-compatible one-shot entry used by older Lab UI builds.
         * V1.9 changes the actual mission progress source for typed conditions.
         */
        @JvmStatic
        @Synchronized
        fun runOneStarTest(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "TOWER LAB • INTERNAL_BUILD_REQUIRED"
            }

            val read = waitForFreshMission(context.applicationContext)
            if (!read.ok || read.snapshot == null) {
                return fail(read.stage, read.report, read.rc)
            }

            val warp = warpCharacterToExit(read.snapshot)
            if (!warp.ok) {
                lastFullReport = buildString {
                    appendLine("=== M WOIF LAB • TOWER ONE SHOT V2.0.6 ===")
                    appendLine("RESULT=WAIT_WARP_READY")
                    appendLine("--- BEFORE ---")
                    appendLine(read.report)
                    appendLine("--- WARP ---")
                    append(warp.report)
                }
                return lastFullReport
            }

            val applied = applyMissionExact(context.applicationContext, read.snapshot)
            if (!applied.ok) {
                return fail("MISSION_APPLY", applied.report, "WRITE")
            }

            SystemClock.sleep(250L)
            val after = readTowerState(context.applicationContext)
            val success =
                after.snapshot?.rawCondition == 1 &&
                    after.snapshot.finalSuccess == 1

            lastFullReport = buildString {
                appendLine("=== M WOIF LAB • TOWER ONE SHOT V2.0.6 ===")
                appendLine("RESULT=${if (success) "WARPED_MISSION_PASSED_WAIT_GATE" else "WARP_AND_MISSION_SET_WAIT_GAME"}")
                appendLine("--- BEFORE ---")
                appendLine(read.report)
                appendLine("--- WARP ---")
                appendLine(warp.report)
                appendLine("--- APPLY ---")
                appendLine(applied.report)
                appendLine("--- AFTER ---")
                append(after.report)
            }

            publishFromReport(
                report = after.report,
                running = false,
                phaseOverride = if (success) {
                    "WARPED_MISSION_PASSED_WAIT_GATE"
                } else {
                    "WARPED_MISSION_SET_WAIT_GATE"
                },
                messageOverride = if (success) {
                    "วาร์ปหน้าประตูแล้ว • Mission ผ่าน • รอ Gate/Result"
                } else {
                    "วาร์ปหน้าประตูแล้ว • ตั้ง Mission แล้ว • รอเกมยืนยัน"
                },
                errorStage = "NONE",
                errorRc = "0"
            )
            return lastFullReport
        }

        @JvmStatic
        fun getDevDiagnostics(): String = buildString {
            appendLine("=== TOWER PUMP DEV ===")
            appendLine("MODE=INTERNAL_WARP_EXACT_MISSION_V2_0_6")
            appendLine("READ_ROUTE=ROOT_PROCESS_MEMORY")
            appendLine("RESOLVER=STRICT_V2_1_PORT")
            appendLine("PREPARE_POLL_MS=$PREPARE_POLL_MS")
            appendLine("PREPARE_WAIT_MS=$PREPARE_WAIT_MS")
            appendLine("ACTION_ROUTE=WARP_THEN_EXACT_MISSION_SOURCE")
            appendLine("SUPPORTED_CONDITION_TYPES=0,1,2")
            appendLine("RESULT_POLICY=WARP_AND_EXACT_MISSION_THEN_NORMAL_GATE_RESULT")
            appendLine("POLICY=MANUAL_ENTER_WARP_IMMEDIATE_EXACT_MISSION")
            appendLine("TYPE0_NATIVE_ACTION=ENABLED_AFTER_WARP")
            appendLine("AUTO_PASS_ENABLED=$autoPassEnabled")
            appendLine("AUTO_PASS_POLL_MS=$AUTO_PASS_POLL_MS")
            appendLine("RUN_START_SOURCE=Character+0x78->Object+0x30")
            appendLine("RUN_START_MIN_STEP=$RUN_START_MIN_STEP")
            appendLine("RUN_START_MIN_TOTAL_MOVE=$RUN_START_MIN_TOTAL_MOVE")
            appendLine("RUN_START_REQUIRED_MOVING_SAMPLES=$RUN_START_REQUIRED_MOVING_SAMPLES")
            appendLine("WARP_ROUTE=StageService->Character+0x78->Object+0x30")
            appendLine("WARP_TARGET_FORWARD=$LAB_WARP_TARGET_FORWARD")
            appendLine("THREE_MOD_ASSIST=DISABLED_FOR_WARP_MODE")
            appendLine("WARP_TRIGGER=AUTHORITATIVE_FORWARD_RUN_START")
            appendLine("MISSION_APPLY_TIMING=IMMEDIATELY_AFTER_WARP")
            appendLine("TYPE0_ROUTE=INPROCESS_GAME_THREAD_EXACT_STAT")
            appendLine("TYPE1_2_ROUTE=ROOT_TYPED_SOURCE_EXACT_REQUIRED")
            appendLine("GAME_SPEED_CONTROL=DISABLED_FOR_TOWER")
            appendLine("WRITE_RAW_CONDITION=DISABLED_DERIVED_STATE")
            appendLine("WRITE_SECONDARY_STATE=DISABLED_READ_ONLY")
            appendLine("WRITE_FINAL_SUCCESS=DISABLED_DERIVED_STATE")
            appendLine("DIRECT_PENDING_COMMIT_WRITE=DISABLED")
            appendLine("DIRECT_TOTAL_STAR_WRITE=DISABLED")
            appendLine("DIRECT_BEST_STAGE_WRITE=DISABLED")
            appendLine("DIRECT_COMPLETED_FLAG_WRITE=DISABLED")
            appendLine()
            appendLine("[LIVE]")
            appendLine(getLiveUiState())
            appendLine()
            appendLine("[LAST REPORT]")
            appendLine(lastFullReport)
            appendLine()
            appendLine("[RUNTIME RESOLVER]")
            appendLine(lastResolverReport)
            appendLine()
            appendLine("[LAST AUTO WRITE]")
            appendLine(lastAutoWriteReport)
            appendLine()
            appendLine("[LAST FAILED REPORT]")
            append(lastFailedReport)
        }

        @JvmStatic
        fun resetDevReport(): String {
            autoPassEnabled = false
            autoPassThread?.interrupt()
            autoPassThread = null
            lastAutoMissionKey = "NONE"
            lastAutoWriteReport = "NONE"
            liveState = TowerLiveState(
                running = false,
                phase = "STOPPED",
                message = "ปั้ม Tower ปิดอยู่"
            )
            lastFullReport = "ยังไม่มี Tower Lab report"
            lastFailedReport = "NONE"
            lastResolverReport = "ยังไม่มี Runtime Resolver report"
            return "TOWER PUMP DEV • RESET_OK"
        }

        @JvmStatic
        fun recordExternalFailure(report: String) {
            fail("APP_REFLECTION", report)
        }

        private fun findTowerCandidate(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>
        ): BaseCandidate? {
            val libRanges = maps.filter { it.path.contains("libgame.so") }
            if (libRanges.isEmpty()) {
                lastResolverReport = "candidateCount=0\nreason=NO_LIBGAME_RANGE"
                return null
            }

            val sources = linkedMapOf<Long, String>()
            libRanges.forEach { range ->
                sources.putIfAbsent(
                    range.start,
                    "range.start:${range.path}"
                )

                if (range.offset > 0L && range.start > range.offset) {
                    sources.putIfAbsent(
                        range.start - range.offset,
                        "range.start-offset:${range.path}"
                    )
                }
            }

            val results = sources
                .map { (base, source) ->
                    validateTowerCandidate(pid, maps, base, source)
                }
                .sortedWith(
                    compareByDescending<BaseCandidate> { it.accepted }
                        .thenByDescending { it.score }
                        .thenBy { it.base }
                )

            lastResolverReport = buildResolverReport(results)
            return results.firstOrNull { it.accepted }
        }

        private fun validateTowerCandidate(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            base: Long,
            source: String
        ): BaseCandidate {
            fun reject(
                reason: String,
                score: Int = 0,
                managerGlobal: Long = 0L,
                manager: Long = 0L,
                activeMission: Long = 0L,
                managerStateByte: Int = -1,
                pendingUnlock: Int = -1,
                pendingCommit: Int = -1,
                finalSuccess: Int = -1,
                rawCondition: Int = -1,
                secondaryState: Int = -1,
                currentFloor: Long = -1L,
                missionOrder: Long = -1L,
                bestStage: Long = -1L
            ) = BaseCandidate(
                base = base,
                source = source,
                accepted = false,
                score = score,
                reason = reason,
                managerGlobal = managerGlobal,
                manager = manager,
                activeMission = activeMission,
                managerStateByte = managerStateByte,
                pendingUnlock = pendingUnlock,
                pendingCommit = pendingCommit,
                finalSuccess = finalSuccess,
                rawCondition = rawCondition,
                secondaryState = secondaryState,
                currentFloor = currentFloor,
                missionOrder = missionOrder,
                bestStage = bestStage
            )

            val managerGlobal = base + (TOWER_MANAGER_GLOBAL_GH - IMAGE_BASE)
            if (!isMapped(maps, managerGlobal, 8)) {
                return reject(
                    reason = "MANAGER_GLOBAL_UNMAPPED",
                    managerGlobal = managerGlobal
                )
            }

            var score = 1
            val manager = memory.readLong(pid, managerGlobal) ?: 0L
            if (!isPointer(manager) || !isMapped(maps, manager, 0x181)) {
                return reject(
                    reason = "MANAGER_INVALID",
                    score = score,
                    managerGlobal = managerGlobal,
                    manager = manager
                )
            }
            score += 4

            val managerStateByte =
                memory.readByteUnsigned(pid, manager + 0x180L) ?: -1
            val pendingUnlock =
                memory.readByteUnsigned(pid, manager + 0x0F8L) ?: -1
            val pendingCommit =
                memory.readByteUnsigned(pid, manager + 0x0F9L) ?: -1

            if (managerStateByte !in 0..1) {
                return reject(
                    "MANAGER_STATE_NOT_0_1",
                    score,
                    managerGlobal,
                    manager,
                    managerStateByte = managerStateByte,
                    pendingUnlock = pendingUnlock,
                    pendingCommit = pendingCommit
                )
            }
            score += 2

            if (pendingUnlock !in 0..1 || pendingCommit !in 0..1) {
                return reject(
                    "PENDING_FLAGS_NOT_0_1",
                    score,
                    managerGlobal,
                    manager,
                    managerStateByte = managerStateByte,
                    pendingUnlock = pendingUnlock,
                    pendingCommit = pendingCommit
                )
            }
            score += 4

            val finalSuccess =
                decodeProtectedBool(pid, maps, manager + 0x080L) ?: -1
            val rawCondition =
                decodeProtectedBool(pid, maps, manager + 0x0A8L) ?: -1
            val secondaryState =
                decodeProtectedBool(pid, maps, manager + 0x0D0L) ?: -1

            if (
                finalSuccess !in 0..1 ||
                rawCondition !in 0..1 ||
                secondaryState !in 0..1
            ) {
                return reject(
                    "PROTECTED_BOOL_INVALID",
                    score,
                    managerGlobal,
                    manager,
                    managerStateByte = managerStateByte,
                    pendingUnlock = pendingUnlock,
                    pendingCommit = pendingCommit,
                    finalSuccess = finalSuccess,
                    rawCondition = rawCondition,
                    secondaryState = secondaryState
                )
            }
            score += 9

            val currentFloor =
                decodeProtected32(pid, maps, manager + 0x008L) ?: -1L
            val missionOrder =
                decodeProtected32(pid, maps, manager + 0x030L) ?: -1L
            val bestStage =
                decodeProtected32(pid, maps, manager + 0x058L) ?: -1L

            if (
                currentFloor !in 0L..100L ||
                missionOrder !in 0L..3L ||
                bestStage !in 0L..100L
            ) {
                return reject(
                    "PROTECTED32_RANGE_INVALID",
                    score,
                    managerGlobal,
                    manager,
                    managerStateByte = managerStateByte,
                    pendingUnlock = pendingUnlock,
                    pendingCommit = pendingCommit,
                    finalSuccess = finalSuccess,
                    rawCondition = rawCondition,
                    secondaryState = secondaryState,
                    currentFloor = currentFloor,
                    missionOrder = missionOrder,
                    bestStage = bestStage
                )
            }
            score += 6

            val activeMission =
                memory.readLong(pid, manager + 0x100L) ?: 0L

            if (activeMission == 0L) {
                score += 1
            } else {
                val missionReason =
                    missionValidationReason(pid, maps, activeMission)

                if (missionReason != "OK") {
                    return reject(
                        "ACTIVE_MISSION_$missionReason",
                        score,
                        managerGlobal,
                        manager,
                        activeMission,
                        managerStateByte,
                        pendingUnlock,
                        pendingCommit,
                        finalSuccess,
                        rawCondition,
                        secondaryState,
                        currentFloor,
                        missionOrder,
                        bestStage
                    )
                }
                score += 6
            }

            return BaseCandidate(
                base = base,
                source = source,
                accepted = score >= 20,
                score = score,
                reason = "ACCEPT",
                managerGlobal = managerGlobal,
                manager = manager,
                activeMission = activeMission,
                managerStateByte = managerStateByte,
                pendingUnlock = pendingUnlock,
                pendingCommit = pendingCommit,
                finalSuccess = finalSuccess,
                rawCondition = rawCondition,
                secondaryState = secondaryState,
                currentFloor = currentFloor,
                missionOrder = missionOrder,
                bestStage = bestStage
            )
        }

        private fun missionValidationReason(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            activeMission: Long
        ): String {
            if (!isPointer(activeMission) || !isMapped(maps, activeMission, 0x1F9)) {
                return "PTR_INVALID"
            }

            val conditionType =
                memory.readInt(pid, activeMission + 0x190L) ?: return "CONDITION_TYPE_READ"
            val conditionIndex =
                memory.readInt(pid, activeMission + 0x194L) ?: return "CONDITION_INDEX_READ"
            val comparator =
                memory.readInt(pid, activeMission + 0x1C8L) ?: return "COMPARATOR_READ"
            val completed =
                memory.readByteUnsigned(pid, activeMission + 0x1CDL) ?: return "COMPLETED_READ"
            val stateFlag =
                memory.readByteUnsigned(pid, activeMission + 0x1CEL) ?: return "STATE_FLAG_READ"

            if (conditionType !in 0..16) return "CONDITION_TYPE_RANGE"
            if (conditionIndex !in 0..1_000_000) return "CONDITION_INDEX_RANGE"
            if (comparator !in 0..16) return "COMPARATOR_RANGE"
            if (completed !in 0..1) return "COMPLETED_RANGE"
            if (stateFlag !in 0..1) return "STATE_FLAG_RANGE"

            return "OK"
        }

        private fun buildResolverReport(
            results: List<BaseCandidate>
        ): String = buildString {
            appendLine("candidateCount=${results.size}")

            results.forEachIndexed { index, c ->
                appendLine()
                appendLine("[CANDIDATE ${index + 1}]")
                appendLine("base=${hex(c.base)}")
                appendLine("source=${c.source}")
                appendLine("accepted=${c.accepted}")
                appendLine("score=${c.score}")
                appendLine("reason=${c.reason}")
                appendLine("managerGlobal=${hex(c.managerGlobal)}")
                appendLine("manager=${hex(c.manager)}")
                appendLine("activeMission=${hex(c.activeMission)}")
                appendLine("managerStateByte=${c.managerStateByte}")
                appendLine("pendingUnlock=${c.pendingUnlock}")
                appendLine("pendingCommit=${c.pendingCommit}")
                appendLine("finalSuccess=${c.finalSuccess}")
                appendLine("rawCondition=${c.rawCondition}")
                appendLine("secondaryState=${c.secondaryState}")
                appendLine("currentFloor=${c.currentFloor}")
                appendLine("missionOrder=${c.missionOrder}")
                append("bestStage=${c.bestStage}")
            }
        }

        private fun decodeProtected32(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            field: Long
        ): Long? {
            val pA = memory.readLong(pid, field + 0x08L) ?: return null
            val pB = memory.readLong(pid, field + 0x10L) ?: return null
            if (!isPointer(pA) || !isPointer(pB)) return null
            if (!isMapped(maps, pA, 4) || !isMapped(maps, pB, 4)) return null

            val a = memory.readBytes(pid, pA, 4) ?: return null
            val b = memory.readBytes(pid, pB, 4) ?: return null
            if (a.size < 4 || b.size < 4) return null

            fun ub(x: Byte): Int = x.toInt() and 0xFF
            fun inv(x: Int): Int = (256 - x) and 0xFF

            val av = intArrayOf(
                inv(ub(a[3])) xor 0xC6,
                inv(ub(a[2])) xor 0x3A,
                inv(ub(a[1])) xor 0xC6,
                inv(ub(a[0])) xor 0x3A
            )
            val bv = intArrayOf(
                inv(ub(b[0])) xor 0x95,
                inv(ub(b[1])) xor 0x6B,
                inv(ub(b[2])) xor 0x95,
                inv(ub(b[3])) xor 0x6B
            )

            var va = 0L
            var vb = 0L
            for (i in 0..3) {
                va = va or ((av[i].toLong() and 0xFFL) shl (i * 8))
                vb = vb or ((bv[i].toLong() and 0xFFL) shl (i * 8))
            }

            return if (va == vb) va else null
        }

        private fun decodeProtected64(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            field: Long
        ): Long? {
            val pA = memory.readLong(pid, field + 0x08L) ?: return null
            val pB = memory.readLong(pid, field + 0x10L) ?: return null
            if (!isPointer(pA) || !isPointer(pB)) return null
            if (!isMapped(maps, pA, 8) || !isMapped(maps, pB, 8)) return null

            val a = memory.readBytes(pid, pA, 8) ?: return null
            val b = memory.readBytes(pid, pB, 8) ?: return null
            if (a.size < 8 || b.size < 8) return null

            fun ub(x: Byte): Int = x.toInt() and 0xFF
            fun dec(x: Byte, key: Int): Int =
                (((ub(x) - 1) and 0xFF) xor key) and 0xFF

            val av = IntArray(8)
            av[7] = dec(a[0], 0xC5)
            av[6] = dec(a[1], 0x39)
            av[5] = dec(a[2], 0xC5)
            av[4] = dec(a[3], 0x39)
            av[3] = dec(a[4], 0xC5)
            av[2] = dec(a[5], 0x39)
            av[1] = dec(a[6], 0xC5)
            av[0] = dec(a[7], 0x39)

            val bv = IntArray(8)
            bv[0] = dec(b[0], 0x6A)
            bv[1] = dec(b[1], 0x94)
            bv[2] = dec(b[2], 0x6A)
            bv[3] = dec(b[3], 0x94)
            bv[4] = dec(b[4], 0x6A)
            bv[5] = dec(b[5], 0x94)
            bv[6] = dec(b[6], 0x6A)
            bv[7] = dec(b[7], 0x94)

            if (!av.contentEquals(bv)) return null

            var out = 0L
            for (i in 0..7) {
                out = out or ((av[i].toLong() and 0xFFL) shl (i * 8))
            }
            return out
        }

        private fun decodeProtectedBool(
            pid: Int,
            maps: List<RootProcessMemory.MapEntry>,
            field: Long
        ): Int? {
            val pB = memory.readLong(pid, field + 0x10L) ?: return null
            if (!isPointer(pB) || !isMapped(maps, pB, 1)) return null

            return when (memory.readByteUnsigned(pid, pB)) {
                0x6B -> 0
                0x6C -> 1
                else -> null
            }
        }

        private fun protectedFailure(
            name: String,
            pid: Int,
            base: Long,
            manager: Long,
            activeMission: Long
        ): ReadResult = readFailure(
            stage = "PROTECTED_DECODE_$name",
            rc = "-307",
            detail = buildString {
                appendLine("pid=$pid")
                appendLine("libgameBase=${hex(base)}")
                appendLine("manager=${hex(manager)}")
                append("activeMission=${hex(activeMission)}")
            }
        )

        private fun directFailure(
            name: String,
            pid: Int,
            base: Long,
            manager: Long,
            activeMission: Long
        ): ReadResult = readFailure(
            stage = "DIRECT_READ_$name",
            rc = "-308",
            detail = buildString {
                appendLine("pid=$pid")
                appendLine("libgameBase=${hex(base)}")
                appendLine("manager=${hex(manager)}")
                append("activeMission=${hex(activeMission)}")
            }
        )

        private fun readFailure(
            stage: String,
            rc: String,
            detail: String
        ): ReadResult {
            val report = buildString {
                appendLine("TOWER_LAB")
                appendLine("readBuild=V1_9_MISSION_SOURCE_AUTO_PASS")
                appendLine("readRoute=ROOT_PROCESS_MEMORY")
                appendLine("resolver=STRICT_V2_1_PORT")
                appendLine("RESULT=ERROR")
                appendLine("phase=READ_STATE")
                appendLine("rc=$rc")
                appendLine("errorStage=$stage")
                append(detail)
            }
            return ReadResult(
                ok = false,
                stage = stage,
                rc = rc,
                report = report,
                snapshot = null
            )
        }

        private fun isMapped(
            maps: List<RootProcessMemory.MapEntry>,
            address: Long,
            size: Int
        ): Boolean {
            if (address <= 0L || size <= 0) return false
            val end = address + size.toLong()
            return maps.any { entry ->
                address >= entry.start && end <= entry.end
            }
        }

        private fun isPointer(value: Long): Boolean =
            value >= 0x10000L &&
                value < 0x0001000000000000L &&
                value % 8L == 0L

        private fun hex(value: Long): String =
            if (value == 0L) "0x0"
            else "0x${value.toString(16).uppercase(Locale.US)}"
    }
}
