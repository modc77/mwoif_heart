package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/**
 * AUTO A1 read-only state capture backend.
 *
 * Internal flavor only. This tool never writes target-process memory. It uses
 * the current server-delivered RunRewardProfile to resolve the gameplay state
 * and StageService, then captures a compact snapshot that can be diffed across
 * Lobby / Pre-Run / Run / Result / post-result screens.
 */
internal object AutoStateProbeBackend {
    private const val MAX_LIST_NODES = 4096
    private const val MAX_DIFF_LINES = 180
    private const val MAX_STAGE_DUMP_OFFSET = 0x80L
    private const val STAGE_DUMP_STEP = 0x08L

    // Runtime research checkpoint currently identifies StageService+0x10 as
    // Controller. It is deliberately treated as an observed slot, not a
    // server-profile invariant; the full StageService dump is always captured.
    private const val OBSERVED_CONTROLLER_OFFSET = 0x10L

    private data class Runtime(
        val pid: Int,
        val elfBase: Long,
        val loadBias: Long,
        val stateGlobal: Long,
        val stageServiceGlobal: Long
    )

    private data class FieldSnapshot(
        val key: Int,
        val type: Int?,
        val flag: Int?,
        val decodedInt: Int?,
        val node: Long
    )

    private data class Capture(
        val label: String,
        val pid: Int,
        val elfBase: Long,
        val loadBias: Long,
        val stateGlobal: Long,
        val stageServiceGlobal: Long,
        val state: Long,
        val stageService: Long,
        val character: Long,
        val controllerCandidate: Long,
        val stageSlots: LinkedHashMap<Long, Long?>,
        val fields: LinkedHashMap<Int, FieldSnapshot>,
        val truncated: Boolean,
        val timestampMs: Long
    )

    private val memory = RootProcessMemory()
    private var previous: Capture? = null
    private var latestText: String = "AUTO A1 • no capture yet"

    @JvmStatic
    @Synchronized
    fun capture(context: Context, rawLabel: String): String {
        val label = normalizeLabel(rawLabel)
        val result = try {
            captureInternal(context.applicationContext, label)
        } catch (t: Throwable) {
            "AUTO A1 CAPTURE FAILED\nlabel=$label\n${t.javaClass.simpleName}: ${t.message ?: "unknown"}"
        }

        latestText = result
        result.lineSequence().take(220).forEach { line ->
            if (line.isNotBlank()) DevConsole.log("AUTO-A1", line)
        }
        return result
    }

    @JvmStatic
    @Synchronized
    fun reset(): String {
        previous = null
        latestText = "AUTO A1 • baseline cleared"
        DevConsole.log("AUTO-A1", "baseline cleared")
        return latestText
    }

    @JvmStatic
    @Synchronized
    fun latest(): String = latestText

    private fun captureInternal(context: Context, label: String): String {
        if (!memory.hasRoot() && !memory.requestRoot(context)) {
            return failure(label, "ROOT_NOT_READY", "Root Worker is not ready")
        }

        val profile = SecureProfileManager.getRunReward()
            ?: return failure(label, "PROFILE_NOT_READY", "RunReward Secure Profile is not loaded")

        val runtime = resolveRuntime(profile)
            ?: return failure(label, "RUNTIME_NOT_READY", "Cannot resolve current libgame/runtime globals")

        val state = memory.readLong(runtime.pid, runtime.stateGlobal) ?: 0L
        val service = memory.readLong(runtime.pid, runtime.stageServiceGlobal) ?: 0L

        val stageSlots = LinkedHashMap<Long, Long?>()
        if (isPointer(service)) {
            var offset = 0L
            while (offset <= MAX_STAGE_DUMP_OFFSET) {
                stageSlots[offset] = memory.readLong(runtime.pid, service + offset)
                offset += STAGE_DUMP_STEP
            }
        }

        val character = if (isPointer(service)) {
            resolveCharacter(runtime.pid, service, profile)
        } else 0L

        val controllerCandidate = if (isPointer(service)) {
            memory.readLong(runtime.pid, service + OBSERVED_CONTROLLER_OFFSET) ?: 0L
        } else 0L

        val (fields, truncated) = if (isPointer(state)) {
            captureStateFields(runtime.pid, state, profile)
        } else {
            LinkedHashMap<Int, FieldSnapshot>() to false
        }

        val current = Capture(
            label = label,
            pid = runtime.pid,
            elfBase = runtime.elfBase,
            loadBias = runtime.loadBias,
            stateGlobal = runtime.stateGlobal,
            stageServiceGlobal = runtime.stageServiceGlobal,
            state = state,
            stageService = service,
            character = character,
            controllerCandidate = controllerCandidate,
            stageSlots = stageSlots,
            fields = fields,
            truncated = truncated,
            timestampMs = System.currentTimeMillis()
        )

        val before = previous
        previous = current
        return render(current, before, profile)
    }

    private fun resolveRuntime(profile: RunRewardProfile): Runtime? {
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return null

        val candidates = LinkedHashSet<Long>()
        ranges.forEach { range ->
            candidates += range.start
            if (range.offset > 0L && range.start > range.offset) {
                candidates += range.start - range.offset
            }
        }

        val elfBase = candidates.firstOrNull { validateArm64Elf(pid, it) } ?: return null
        val loadBias = parseLoadBias(pid, elfBase) ?: return null

        val stateGlobal = loadBias + (profile.stateGlobal - profile.imageBase)
        val stageServiceGlobal = loadBias + (profile.stageServiceGlobal - profile.imageBase)
        if (!isAddress(stateGlobal) || !isAddress(stageServiceGlobal)) return null

        return Runtime(
            pid = pid,
            elfBase = elfBase,
            loadBias = loadBias,
            stateGlobal = stateGlobal,
            stageServiceGlobal = stageServiceGlobal
        )
    }

    private fun captureStateFields(
        pid: Int,
        state: Long,
        profile: RunRewardProfile
    ): Pair<LinkedHashMap<Int, FieldSnapshot>, Boolean> {
        val output = LinkedHashMap<Int, FieldSnapshot>()
        val map = state + profile.mapOffset
        var node = memory.readLong(pid, map + profile.listHeadOffset)
        var guard = 0

        while (node != null && isPointer(node) && guard < MAX_LIST_NODES) {
            val key = memory.readInt(pid, node + profile.nodeKeyOffset)
            if (key != null) {
                val field = node + profile.nodeFieldOffset
                val type = memory.readInt(pid, field + profile.fieldTypeOffset)
                val flag = memory.readByteUnsigned(pid, field + profile.fieldFlagOffset)
                val decoded = decodeProtectedInt(pid, field, type, flag, profile)

                output[key] = FieldSnapshot(
                    key = key,
                    type = type,
                    flag = flag,
                    decodedInt = decoded,
                    node = node
                )
            }

            node = memory.readLong(pid, node + profile.nodeNextOffset)
            guard += 1
        }

        return output to (node != null && isPointer(node))
    }

    private fun decodeProtectedInt(
        pid: Int,
        field: Long,
        type: Int?,
        flag: Int?,
        profile: RunRewardProfile
    ): Int? {
        if (type != profile.expectedType || flag != profile.expectedFlag) return null

        val valuePtr = memory.readLong(pid, field + profile.fieldValuePtrOffset) ?: return null
        val keyPtr = memory.readLong(pid, field + profile.fieldKeyPtrOffset) ?: return null
        if (!isPointer(valuePtr) || !isPointer(keyPtr)) return null

        val raw = memory.readInt(pid, valuePtr) ?: return null
        val xorKey = memory.readInt(pid, keyPtr) ?: return null
        return raw xor xorKey
    }

    private fun resolveCharacter(pid: Int, service: Long, profile: RunRewardProfile): Long {
        val direct = memory.readLong(pid, service + profile.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(pid, service + profile.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(pid, jelly + profile.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun render(current: Capture, before: Capture?, profile: RunRewardProfile): String = buildString {
        appendLine("=== AUTO A1 • READ ONLY STATE CAPTURE ===")
        appendLine("label=${current.label}")
        appendLine("pid=${current.pid}")
        appendLine("elfBase=${hex(current.elfBase)} loadBias=${hex(current.loadBias)}")
        appendLine("stateGlobal=${hex(current.stateGlobal)} -> ${hex(current.state)}")
        appendLine("stageServiceGlobal=${hex(current.stageServiceGlobal)} -> ${hex(current.stageService)}")
        appendLine("character=${hex(current.character)}")
        appendLine("controller(+0x10 observed)=${hex(current.controllerCandidate)}")
        appendLine("stateFields=${current.fields.size}${if (current.truncated) " TRUNCATED" else ""}")
        appendLine("profileRevision=${profile.revision}")

        appendLine("--- KNOWN RUN METRICS ---")
        appendMetric(current, "rawCoin", profile.rawCoinKey)
        appendMetric(current, "rawXp", profile.rawXpKey)
        appendMetric(current, "finalCoin", profile.finalCoinKey)
        appendMetric(current, "finalXp", profile.finalXpKey)
        appendMetric(current, "mirrorCoin", profile.mirrorCoinKey)
        appendMetric(current, "mirrorXp", profile.mirrorXpKey)

        appendLine("--- STAGE SERVICE +00..+80 ---")
        current.stageSlots.forEach { (offset, value) ->
            appendLine("+${offset.toString(16).padStart(2, '0').uppercase(Locale.US)} = ${hexNullable(value)}")
        }

        if (before == null) {
            appendLine("--- DIFF ---")
            appendLine("BASELINE CREATED • capture the next screen to compare")
        } else {
            appendLine("--- DIFF ${before.label} -> ${current.label} ---")
            appendDiff(before, current)
        }
    }

    private fun StringBuilder.appendMetric(capture: Capture, name: String, key: Int) {
        val field = capture.fields[key]
        if (field == null) {
            appendLine("$name key=$key : NOT_FOUND")
        } else {
            appendLine(
                "$name key=$key type=${field.type ?: -1} flag=${field.flag ?: -1} value=${field.decodedInt?.toString() ?: "n/a"}"
            )
        }
    }

    private fun StringBuilder.appendDiff(before: Capture, current: Capture) {
        var lines = 0

        fun add(text: String) {
            if (lines >= MAX_DIFF_LINES) return
            appendLine(text)
            lines += 1
        }

        if (before.pid != current.pid) add("PID ${before.pid} -> ${current.pid}")
        if (before.state != current.state) add("STATE_PTR ${hex(before.state)} -> ${hex(current.state)}")
        if (before.stageService != current.stageService) {
            add("STAGE_SERVICE ${hex(before.stageService)} -> ${hex(current.stageService)}")
        }
        if (before.character != current.character) {
            add("CHARACTER ${hex(before.character)} -> ${hex(current.character)}")
        }
        if (before.controllerCandidate != current.controllerCandidate) {
            add("CONTROLLER+10 ${hex(before.controllerCandidate)} -> ${hex(current.controllerCandidate)}")
        }

        val slotOffsets = LinkedHashSet<Long>()
        slotOffsets += before.stageSlots.keys
        slotOffsets += current.stageSlots.keys
        slotOffsets.sorted().forEach { offset ->
            val old = before.stageSlots[offset]
            val now = current.stageSlots[offset]
            if (old != now) {
                add("SERVICE+${offset.toString(16).uppercase(Locale.US)} ${hexNullable(old)} -> ${hexNullable(now)}")
            }
        }

        val allKeys = LinkedHashSet<Int>()
        allKeys += before.fields.keys
        allKeys += current.fields.keys

        allKeys.sorted().forEach { key ->
            if (lines >= MAX_DIFF_LINES) return@forEach
            val old = before.fields[key]
            val now = current.fields[key]
            when {
                old == null && now != null -> add(
                    "KEY $key ADDED type=${now.type ?: -1} flag=${now.flag ?: -1} value=${now.decodedInt?.toString() ?: "n/a"}"
                )
                old != null && now == null -> add(
                    "KEY $key REMOVED type=${old.type ?: -1} flag=${old.flag ?: -1} value=${old.decodedInt?.toString() ?: "n/a"}"
                )
                old != null && now != null && (
                    old.type != now.type || old.flag != now.flag || old.decodedInt != now.decodedInt
                ) -> add(
                    "KEY $key type ${old.type ?: -1}->${now.type ?: -1} flag ${old.flag ?: -1}->${now.flag ?: -1} value ${old.decodedInt?.toString() ?: "n/a"}->${now.decodedInt?.toString() ?: "n/a"}"
                )
            }
        }

        if (lines == 0) {
            appendLine("NO_OBSERVED_CHANGE")
        } else if (lines >= MAX_DIFF_LINES) {
            appendLine("... DIFF TRUNCATED at $MAX_DIFF_LINES lines ...")
        }
    }

    private fun validateArm64Elf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false

        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selectedVaddr: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selectedVaddr = vaddr
                break
            }
            if (selectedVaddr == null) selectedVaddr = vaddr
        }

        return elfBase - (selectedVaddr ?: return null)
    }

    private fun normalizeLabel(value: String): String =
        value.trim().uppercase(Locale.US).replace(' ', '_').take(32).ifBlank { "CURRENT" }

    private fun isAddress(value: Long): Boolean = value >= 0x10000L

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun hex(value: Long): String = if (value == 0L) "0x0" else "0x${value.toString(16).uppercase(Locale.US)}"

    private fun hexNullable(value: Long?): String = value?.let(::hex) ?: "READ_FAIL"

    private fun failure(label: String, code: String, message: String): String = buildString {
        appendLine("=== AUTO A1 • READ ONLY STATE CAPTURE ===")
        appendLine("label=$label")
        appendLine("status=$code")
        append(message)
    }
}
