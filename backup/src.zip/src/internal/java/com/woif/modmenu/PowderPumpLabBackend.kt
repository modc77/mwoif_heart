package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/**
 * Internal/Lab-only Powder Pump one-round verifier/driver.
 *
 * Architecture:
 *   App process (this class) observes server-owned state through the existing
 *   RootProcessMemory read path.
 *
 *   BUY/BREAK themselves are NOT memory writes from the app. They are queued
 *   through InProcessGameControl and executed on CookieRun's hooked game thread
 *   by the ARM64 InProcessNativeBridge using the game's own process/request
 *   constructors.
 *
 * One round only:
 *   snapshot -> BUY Box1 -> wait NEW type-27 Treasure -> BREAK qty=1
 *   -> wait exact key removal -> verify Powder/Shard numeric delta -> stop.
 */
class PowderPumpLabBackend {
    companion object {
        private const val IMAGE_BASE = 0x00100000L
        private const val OUTER_GLOBAL_GH = 0x02259950L
        private const val ITEM_VPTR_GH = 0x020EEDD0L
        private const val PROFILE_INV_OFF = 0x618L
        private const val POWDER_OFF = 0x910L
        private const val SHARD_OFF = 0x938L
        private const val TREASURE_TYPE = 27

        private const val BUY_TIMEOUT_MS = 15_000L
        private const val BURST10_BUY_TIMEOUT_MS = 12_000L
        private const val BREAK_TIMEOUT_MS = 15_000L
        // V6 speed tune after 10/10 verified rounds.
        // Keep request sequencing single-flight; only shorten observation slack.
        private const val POLL_MS = 100L
        private const val STABLE_MS = 150L
        private const val MAX_NODES = 10_000
        private const val LOOP_COOLDOWN_MS = 250L
        private const val MAX_LOOP_ROUNDS = 50

        // Cabinet capacity is read from the live Treasure Shop page.
        // FUN_016828E0 stores it at page+0x258 and the native diagnostics expose
        // it as cabinetCapacity=.  The native batch BREAK path currently accepts
        // at most 20 item pointers (native rc=-131 above that), and BUY x20 is the
        // largest window already verified end-to-end.  Keep BUY and BREAK windows
        // aligned so large cabinets are processed as repeated <=20-item batches.
        private const val TURBO_BURST_TRANSPORT_MAX = 20
        private const val NORMAL_BOX1_PRICE = 5_000L

        // Confirmed by the successful V9.3 server-owned run on 26.8.02:
        // profile+0x1D0 decoded as protected64 changed
        // 210000 -> 205000 for exactly one Normal 5000-Coin purchase.
        //
        // Do not re-calibrate by purchasing one box on every rebuilt Lab app:
        // after a previous pump ends at Coin=0 that calibration cannot start
        // and the UI appears stuck at TURBO RUNNING.
        private const val CONFIRMED_COIN_OFF = 0x1D0L

        private const val TURBO_MAX_BATCHES = 500
        private const val TURBO_BUY_SETTLE_MS = 450L
        private const val TURBO_BUY_TIMEOUT_MS = 8_000L

        // 5.6-side runtime discovery: no Ghidra offset is assumed for Coin.
        // On the first Turbo run in this app process we buy exactly one Normal
        // box, scan protected64 fields in the live profile, and select a field
        // that decreased by exactly 5000. That readable server-owned field is
        // then used only as a preflight cap so we never dispatch unaffordable
        // requests and never intentionally trigger the game's Connection Lost.
        private const val COIN_SCAN_START = 0x000L
        private const val COIN_SCAN_END = 0x1400L
        private const val COIN_SCAN_STEP = 0x08L

        @Volatile
        private var loopStopRequested = false

        @Volatile
        private var discoveredCoinOffset: Long? = null

        /**
         * Immutable live snapshot published by the Turbo worker. The whole object
         * is replaced atomically so FloatingMenuService can poll it without taking
         * the @Synchronized Turbo monitor (which would block until the run ends).
         */
        private data class PumpLiveState(
            val running: Boolean = false,
            val phase: String = "READY",
            val stopRequested: Boolean = false,
            val startedAtMs: Long = 0L,
            val pageLocator: String = "NOT_RUN",
            val page: String = "UNKNOWN",
            val capacity: Int = 0,
            val occupied: Int = 0,
            val freeSlots: Int = 0,
            val capacitySource: String = "UNKNOWN",
            val profile: String = "UNKNOWN",
            val coin: Long? = null,
            val affordable: Int = 0,
            val burstRequested: Int = 0,
            val accepted: Int = 0,
            val totalBought: Int = 0,
            val buyMs: Long = 0L,
            val batchRequested: Int = 0,
            val removed: Int = 0,
            val totalBroken: Int = 0,
            val breakMs: Long = 0L,
            val powderStart: Long? = null,
            val powderCurrent: Long? = null,
            val powderDelta: Long = 0L,
            val totalPowder: Long = 0L,
            val buyResult: String = "NOT_RUN",
            val batchBreakResult: String = "NOT_RUN",
            val cleanupResult: String = "NOT_RUN",
            val finalFlowResult: String = "NOT_RUN",
            val errorStage: String = "NONE",
            val errorRc: String = "0",
            val errorMessage: String = ""
        )

        @Volatile
        private var liveState = PumpLiveState()

        @Volatile
        private var lastFullReport = "NO POWDER PUMP REPORT YET"

        @Volatile
        private var lastFailedReport = "NONE"

        private val memory = RootProcessMemory()

        private data class Protected64(
            val valid: Boolean,
            val value: Long?,
            val aHex: String,
            val bHex: String
        )

        private data class Item(
            val node: Long,
            val key: String,
            val item: Long,
            val vptrGh: Long,
            val stuffSeq: Long?,
            val qty: Long?,
            val groupSeq: Long?,
            val tag: Long?,
            val type: Int?
        )

        private data class Snapshot(
            val pid: Int,
            val elfBase: Long,
            val outer: Long,
            val a: Long,
            val profile: Long,
            val store: Long,
            val declaredCount: Long?,
            val powder: Protected64,
            val shard: Protected64,
            val items: LinkedHashMap<String, Item>
        ) {
            val treasureCount: Int
                get() = items.values.count {
                    it.type == TREASURE_TYPE && it.vptrGh == ITEM_VPTR_GH
                }
        }

        private data class CoinCalibration(
            val ok: Boolean,
            val offset: Long?,
            val coinBefore: Long?,
            val coinAfterBuy: Long?,
            val afterCleanup: Snapshot?,
            val bought: Int,
            val broken: Int,
            val powderDelta: Long,
            val shardDelta: Long,
            val detail: String
        )

        @JvmStatic
        @Synchronized
        fun runOneRound(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "POWDER PUMP LAB • INTERNAL_BUILD_REQUIRED"
            }

            val app = context.applicationContext
            if (!memory.hasRoot() && !memory.requestRoot(app)) {
                return "POWDER PUMP LAB • ROOT_NOT_READY"
            }

            val ping = InProcessGameControl.ping(app, 3500L)
            if (!ping.ok) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP ONE ROUND ===")
                    appendLine("RESULT=BRIDGE_NOT_READY")
                    append("bridge=${ping.message}")
                }
            }

            // V2 safety: locate the real live Treasure Shop page first.
            // BUY then calls the game's exact Box1 UI action on game thread,
            // preserving page-owned callback/request lifecycle context.
            val pageLocate = InProcessGameControl.powderLocateTreasurePage(app, 6500L)
            if (!pageLocate.ok) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP ONE AUTO ROUND ===")
                    appendLine("MODE=INTERNAL_GAME_OWNED_REQUEST")
                    appendLine("PAGE_RESULT=NOT_READY")
                    appendLine("bridge=${pageLocate.message}")
                    appendLine("ACTION=Open Treasure Shop page in CookieRun, then press LAB test again")
                    append("RESULT=BUY_NOT_STARTED_SAFE")
                }
            }

            val start = snapshot()
                ?: return failure(
                    "START_ROUTE_NOT_READY",
                    "${ping.message} • ${pageLocate.message}"
                )

            log("START inv=${start.declaredCount} treasure=${start.treasureCount} powder=${fmt(start.powder)} shard=${fmt(start.shard)}")

            val buyStartedAt = SystemClock.elapsedRealtime()
            val buy = InProcessGameControl.powderBuyBox1(app, 4500L)
            if (!buy.ok) {
                return buildString {
                    appendLine(header(start))
                    appendLine("BUY_RESULT=DISPATCH_FAILED")
                    appendLine("bridge=${buy.message}")
                    append("RESULT=BUY_NOT_STARTED")
                }
            }

            var boughtSnapshot: Snapshot? = null
            var newTreasure: Item? = null
            while (SystemClock.elapsedRealtime() - buyStartedAt <= BUY_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val current = snapshot() ?: continue
                val found = findNewTreasures(start, current)
                if (found.size == 1) {
                    boughtSnapshot = current
                    newTreasure = found.first()
                    break
                }
                if (found.size > 1) {
                    return buildString {
                        appendLine(header(start))
                        appendLine("BUY_RESULT=AMBIGUOUS_NEW_TREASURE")
                        appendLine("newCount=${found.size}")
                        found.forEachIndexed { i, item ->
                            appendLine("  #${i + 1} ${itemLine(item)}")
                        }
                        append("RESULT=NEEDS_REVIEW")
                    }
                }
            }

            if (boughtSnapshot == null || newTreasure == null) {
                return buildString {
                    appendLine(header(start))
                    appendLine("BUY_RESULT=TIMEOUT")
                    appendLine("bridge=${buy.message}")
                    appendLine("waitMs=${SystemClock.elapsedRealtime() - buyStartedAt}")
                    appendLine("NOTE=high-level BUY returned but no new Treasure delta arrived")
                    append("RESULT=BUY_TIMEOUT")
                }
            }

            SystemClock.sleep(STABLE_MS)
            boughtSnapshot = snapshot() ?: boughtSnapshot
            newTreasure = boughtSnapshot.items[newTreasure.key] ?: newTreasure

            val buyWaitMs = SystemClock.elapsedRealtime() - buyStartedAt
            log("BUY OK wait=${buyWaitMs}ms ${itemLine(newTreasure)}")

            // High-level BUY is owned entirely by the game's Treasure Shop page;
            // there is no Lab BUY retain to release.
            val buyCleanup = InProcessGameControl.Result(
                true,
                "not required • game-owned high-level BUY"
            )

            val breakStartedAt = SystemClock.elapsedRealtime()
            val breakResult = InProcessGameControl.powderBreakItem(
                app,
                newTreasure.item,
                4500L
            )
            if (!breakResult.ok) {
                return buildString {
                    appendLine(header(start))
                    appendLine("BUY_DETECTED:")
                    appendLine("  waitMs=$buyWaitMs")
                    appendLine("  ${itemLine(newTreasure)}")
                    appendLine("  cleanup=${buyCleanup.message}")
                    appendLine("BREAK_RESULT=DISPATCH_FAILED")
                    appendLine("bridge=${breakResult.message}")
                    append("RESULT=BREAK_NOT_STARTED")
                }
            }

            var final: Snapshot? = null
            while (SystemClock.elapsedRealtime() - breakStartedAt <= BREAK_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val current = snapshot() ?: continue
                if (!current.items.containsKey(newTreasure.key)) {
                    final = current
                    break
                }
            }

            if (final == null) {
                return buildString {
                    appendLine(header(start))
                    appendLine("BUY_DETECTED:")
                    appendLine("  waitMs=$buyWaitMs")
                    appendLine("  ${itemLine(newTreasure)}")
                    appendLine("BREAK_RESULT=TIMEOUT")
                    appendLine("bridge=${breakResult.message}")
                    appendLine("waitMs=${SystemClock.elapsedRealtime() - breakStartedAt}")
                    appendLine("NOTE=retained native BREAK owner is intentionally NOT released on timeout")
                    append("RESULT=BREAK_TIMEOUT")
                }
            }

            SystemClock.sleep(STABLE_MS)
            final = snapshot() ?: final
            val breakWaitMs = SystemClock.elapsedRealtime() - breakStartedAt

            val powderDelta = delta(boughtSnapshot.powder, final.powder)
            val shardDelta = delta(boughtSnapshot.shard, final.shard)
            val fullPowderDelta = delta(start.powder, final.powder)
            val fullShardDelta = delta(start.shard, final.shard)
            val sameKeyRemoved = !final.items.containsKey(newTreasure.key)

            // Exact key removal + numeric balance transition is enough to open
            // the next single-flight round, but NOT enough to free the process:
            // the game's success popup still keeps callbacks into that object.
            //
            // powderCleanup() is two-phase in V6:
            //   here -> retire current process, clear the in-flight gate, no release
            //   explicit Cleanup button after popup Confirm -> release retired list
            val finalCleanup = InProcessGameControl.powderCleanup(app, 3500L)

            val verified =
                newTreasure.type == TREASURE_TYPE &&
                    newTreasure.vptrGh == ITEM_VPTR_GH &&
                    newTreasure.qty == 1L &&
                    sameKeyRemoved &&
                    powderDelta != null && powderDelta > 0L &&
                    shardDelta != null

            val report = buildString {
                appendLine(header(start))
                appendLine("BRIDGE:")
                appendLine("  ping=${ping.message}")
                appendLine("  page=${pageLocate.message}")
                appendLine()
                appendLine("START:")
                appendLine("  inventoryCount=${start.declaredCount}")
                appendLine("  treasureCount=${start.treasureCount}")
                appendLine("  powder=${fmt(start.powder)}")
                appendLine("  shard=${fmt(start.shard)}")
                appendLine()
                appendLine("BUY_DETECTED:")
                appendLine("  waitMs=$buyWaitMs")
                appendLine("  ${itemLine(newTreasure)}")
                appendLine("  inventoryCount=${boughtSnapshot.declaredCount}")
                appendLine("  treasureCount=${boughtSnapshot.treasureCount}")
                appendLine("  powder=${fmt(boughtSnapshot.powder)}")
                appendLine("  shard=${fmt(boughtSnapshot.shard)}")
                appendLine("  native=${buy.message}")
                appendLine("  retainCleanup=${buyCleanup.message}")
                appendLine()
                appendLine("BREAK_DETECTED:")
                appendLine("  waitMs=$breakWaitMs")
                appendLine("  removedKey=${newTreasure.key}")
                appendLine("  keyStillPresent=${!sameKeyRemoved}")
                appendLine("  inventoryCount=${final.declaredCount}")
                appendLine("  treasureCount=${final.treasureCount}")
                appendLine("  powder=${fmt(final.powder)}")
                appendLine("  shard=${fmt(final.shard)}")
                appendLine("  native=${breakResult.message}")
                appendLine("  retainCleanup=${finalCleanup.message}")
                appendLine()
                appendLine("EXTRACT_DELTA:")
                appendLine("  POWDER_DELTA=${powderDelta ?: "INVALID"}")
                appendLine("  SHARD_DELTA=${shardDelta ?: "INVALID"}")
                appendLine()
                appendLine("FULL_ROUNDTRIP_DELTA:")
                appendLine("  POWDER_START_TO_END=${fullPowderDelta ?: "INVALID"}")
                appendLine("  SHARD_START_TO_END=${fullShardDelta ?: "INVALID"}")
                appendLine()
                appendLine("VERIFY:")
                appendLine("  NEW_TREASURE_TYPE27=${yes(newTreasure.type == TREASURE_TYPE)}")
                appendLine("  NEW_TREASURE_VPTR=${yes(newTreasure.vptrGh == ITEM_VPTR_GH)}")
                appendLine("  NEW_TREASURE_QTY=${newTreasure.qty}")
                appendLine("  SAME_KEY_REMOVED=${yes(sameKeyRemoved)}")
                appendLine("  POWDER_INCREASED=${yes(powderDelta != null && powderDelta > 0L)}")
                appendLine("  SHARD_DELTA_VALID=${yes(shardDelta != null)}")
                appendLine("  RESULT=${if (verified) "ONE_AUTO_ROUND_VERIFIED" else "NEEDS_REVIEW"}")
                appendLine()
                append("RESULT=POWDER_PUMP_LAB_CAPTURE_COMPLETE")
            }

            report.lineSequence().take(180).forEach {
                if (it.isNotBlank()) DevConsole.log("PUMP-LAB", it)
            }
            return report
        }

        /**
         * V7 EXPERIMENT C
         *
         * Fires ten verified high-level Normal Box1 actions back-to-back on the
         * game thread, without waiting for the previous server reply.
         *
         * This is intentionally one-shot. It does NOT loop burst mode.
         * After observing how many real Treasure items arrive, every detected
         * item is BREAKed sequentially with the already-verified safe path.
         *
         * Expected outcomes:
         * - 10/10 accepted -> C is viable for further research.
         * - partial accepted -> server/client serializes or rejects overlap.
         * - process crash -> page-owned request lifecycle cannot tolerate burst.
         */
        @JvmStatic
        @Synchronized
        fun runBurst10Experiment(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "POWDER PUMP LAB BURST10 • INTERNAL_BUILD_REQUIRED"
            }

            val app = context.applicationContext
            if (!memory.hasRoot() && !memory.requestRoot(app)) {
                return "POWDER PUMP LAB BURST10 • ROOT_NOT_READY"
            }

            val ping = InProcessGameControl.ping(app, 3500L)
            if (!ping.ok) {
                return "POWDER PUMP LAB BURST10 • BRIDGE_NOT_READY • ${ping.message}"
            }

            val pageLocate = InProcessGameControl.powderLocateTreasurePage(app, 6500L)
            if (!pageLocate.ok) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP BURST10 EXPERIMENT ===")
                    appendLine("MODE=EXPERIMENT_C_PARALLEL_BUY")
                    appendLine("PAGE_RESULT=NOT_READY")
                    appendLine("bridge=${pageLocate.message}")
                    append("RESULT=BURST10_NOT_STARTED_SAFE")
                }
            }

            val start = snapshot()
                ?: return "POWDER PUMP LAB BURST10 • START_ROUTE_NOT_READY"

            val startedAt = SystemClock.elapsedRealtime()
            val burst = InProcessGameControl.powderBuyBox1Burst10(app, 5000L)
            if (!burst.ok) {
                return buildString {
                    appendLine(header(start))
                    appendLine("MODE=EXPERIMENT_C_PARALLEL_BUY")
                    appendLine("BURST_DISPATCH=FAILED")
                    appendLine("bridge=${burst.message}")
                    append("RESULT=BURST10_NOT_STARTED")
                }
            }

            var observed = emptyList<Item>()
            var buyEnd: Snapshot? = null
            while (SystemClock.elapsedRealtime() - startedAt <= BURST10_BUY_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val current = snapshot() ?: continue
                val found = findNewTreasures(start, current)
                if (found.size > observed.size) {
                    observed = found
                    buyEnd = current
                }
                if (found.size >= 10) {
                    observed = found.take(10)
                    buyEnd = current
                    break
                }
            }

            val dispatchToObserveMs = SystemClock.elapsedRealtime() - startedAt
            if (observed.isEmpty()) {
                return buildString {
                    appendLine(header(start))
                    appendLine("MODE=EXPERIMENT_C_PARALLEL_BUY")
                    appendLine("BURST_DISPATCH=${burst.message}")
                    appendLine("BUY_WAIT_MS=$dispatchToObserveMs")
                    appendLine("NEW_TREASURES=0")
                    appendLine("NOTE=No server-owned Treasure delta observed after BURST10")
                    append("RESULT=BURST10_ZERO_ACCEPTED")
                }
            }

            val toBreak = observed.toList()
            var currentSnapshot = buyEnd ?: snapshot() ?: start
            var breakPass = 0
            var breakFailReason: String? = null
            val breakLines = ArrayList<String>(toBreak.size)

            for ((index, item) in toBreak.withIndex()) {
                if (loopStopRequested) {
                    breakFailReason = "STOP_REQUESTED"
                    break
                }

                val beforeBreak = currentSnapshot
                val breakStartedAt = SystemClock.elapsedRealtime()
                val br = InProcessGameControl.powderBreakItem(app, item.item, 4500L)
                if (!br.ok) {
                    breakFailReason = "BREAK_DISPATCH_${index + 1} • ${br.message}"
                    break
                }

                var afterBreak: Snapshot? = null
                while (SystemClock.elapsedRealtime() - breakStartedAt <= BREAK_TIMEOUT_MS) {
                    SystemClock.sleep(POLL_MS)
                    val now = snapshot() ?: continue
                    if (!now.items.containsKey(item.key)) {
                        afterBreak = now
                        break
                    }
                }

                if (afterBreak == null) {
                    breakFailReason = "BREAK_TIMEOUT_${index + 1}"
                    break
                }

                SystemClock.sleep(STABLE_MS)
                afterBreak = snapshot() ?: afterBreak
                val pd = delta(beforeBreak.powder, afterBreak.powder)
                val sd = delta(beforeBreak.shard, afterBreak.shard)
                val cleanup = InProcessGameControl.powderCleanup(app, 3500L)

                breakPass += 1
                currentSnapshot = afterBreak
                breakLines += buildString {
                    append("#${index + 1}=PASS")
                    append(" key=${item.key}")
                    append(" powderDelta=${pd ?: "INVALID"}")
                    append(" shardDelta=${sd ?: "INVALID"}")
                    append(" cleanup=${cleanup.message}")
                }
            }

            val final = currentSnapshot
            val totalPowder = delta(start.powder, final.powder)
            val totalShard = delta(start.shard, final.shard)
            val accepted = toBreak.size
            val allAccepted = accepted == 10
            val cleanedAllObserved = breakPass == accepted && breakFailReason == null

            val result = when {
                allAccepted && cleanedAllObserved -> "BURST10_ACCEPTED_AND_CLEANED"
                cleanedAllObserved -> "BURST10_PARTIAL_ACCEPT_CLEANED"
                else -> "BURST10_NEEDS_REVIEW"
            }

            return buildString {
                appendLine("=== M WOIF LAB • POWDER PUMP BURST10 EXPERIMENT ===")
                appendLine("MODE=EXPERIMENT_C_PARALLEL_BUY")
                appendLine("policy=ONE_SHOT_ONLY")
                appendLine("pid=${start.pid}")
                appendLine("elfBase=${hex(start.elfBase)}")
                appendLine()
                appendLine("START:")
                appendLine("  inventoryCount=${start.declaredCount}")
                appendLine("  treasureCount=${start.treasureCount}")
                appendLine("  powder=${fmt(start.powder)}")
                appendLine("  shard=${fmt(start.shard)}")
                appendLine()
                appendLine("BURST10:")
                appendLine("  native=${burst.message}")
                appendLine("  observeMs=$dispatchToObserveMs")
                appendLine("  acceptedTreasureKeys=$accepted")
                appendLine("  expected=10")
                appendLine("  all10Accepted=${yes(allAccepted)}")
                toBreak.forEachIndexed { i, item ->
                    appendLine("  BUY#${i + 1} ${itemLine(item)}")
                }
                appendLine()
                appendLine("SEQUENTIAL_BREAK_CLEANUP:")
                appendLine("  pass=$breakPass/$accepted")
                breakLines.forEach { appendLine("  $it") }
                if (breakFailReason != null) {
                    appendLine("  failure=$breakFailReason")
                }
                appendLine()
                appendLine("TOTAL:")
                appendLine("  POWDER_DELTA=${totalPowder ?: "INVALID"}")
                appendLine("  SHARD_DELTA=${totalShard ?: "INVALID"}")
                appendLine("  inventoryCount=${final.declaredCount}")
                appendLine("  treasureCount=${final.treasureCount}")
                appendLine()
                append("RESULT=$result")
            }
        }

        /**
         * Finite Lab loop using the already-verified ONE AUTO ROUND path.
         *
         * Safety policy:
         * - strictly sequential (single-flight)
         * - no retry storm
         * - any failed round stops the loop immediately
         * - Stop request is honored after the current in-flight round finishes
         * - cooldown between successful rounds
         */
        @JvmStatic
        @Synchronized
        fun runLoop(context: Context, requestedRounds: Int): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "POWDER PUMP LAB LOOP • INTERNAL_BUILD_REQUIRED"
            }

            val rounds = requestedRounds.coerceIn(1, MAX_LOOP_ROUNDS)
            loopStopRequested = false

            var completed = 0
            var totalPowder = 0L
            var totalShard = 0L
            var failedRound = 0
            var failedReport: String? = null

            val summaries = ArrayList<String>(rounds)
            val startedAt = SystemClock.elapsedRealtime()

            for (round in 1..rounds) {
                if (loopStopRequested) break

                val roundStartedAt = SystemClock.elapsedRealtime()
                val report = runOneRound(context)
                val ok = report.contains("RESULT=ONE_AUTO_ROUND_VERIFIED")

                val powderDelta = extractLong(report, "POWDER_DELTA")
                val shardDelta = extractLong(report, "SHARD_DELTA")
                val removedKey = extractText(report, "removedKey")
                val elapsed = SystemClock.elapsedRealtime() - roundStartedAt

                if (!ok) {
                    failedRound = round
                    failedReport = report
                    summaries += buildString {
                        append("ROUND $round=FAIL")
                        append(" elapsedMs=$elapsed")
                        if (!removedKey.isNullOrBlank()) append(" key=$removedKey")
                        append(" result=${extractFinalRoundResult(report)}")
                    }
                    break
                }

                completed += 1
                totalPowder += powderDelta ?: 0L
                totalShard += shardDelta ?: 0L

                summaries += buildString {
                    append("ROUND $round=PASS")
                    append(" elapsedMs=$elapsed")
                    append(" powderDelta=${powderDelta ?: "INVALID"}")
                    append(" shardDelta=${shardDelta ?: "INVALID"}")
                    if (!removedKey.isNullOrBlank()) append(" key=$removedKey")
                }

                if (round < rounds && !loopStopRequested) {
                    SystemClock.sleep(LOOP_COOLDOWN_MS)
                }
            }

            val stopped = loopStopRequested
            loopStopRequested = false
            val elapsedTotal = SystemClock.elapsedRealtime() - startedAt

            val result = when {
                failedRound > 0 -> "POWDER_PUMP_LOOP_STOPPED_ON_FAILURE"
                stopped -> "POWDER_PUMP_LOOP_STOPPED_BY_USER"
                completed == rounds -> "POWDER_PUMP_LOOP_COMPLETE"
                else -> "POWDER_PUMP_LOOP_INCOMPLETE"
            }

            return buildString {
                appendLine("=== M WOIF LAB • POWDER PUMP SAFE LOOP ===")
                appendLine("MODE=INTERNAL_GAME_OWNED_REQUEST_LOOP")
                appendLine("targetRounds=$rounds")
                appendLine("completedRounds=$completed")
                appendLine("cooldownMs=$LOOP_COOLDOWN_MS")
                appendLine("elapsedMs=$elapsedTotal")
                appendLine("stopRequested=$stopped")
                appendLine()
                appendLine("TOTAL:")
                appendLine("  POWDER_DELTA=$totalPowder")
                appendLine("  SHARD_DELTA=$totalShard")
                appendLine()
                appendLine("ROUNDS:")
                summaries.forEach { appendLine("  $it") }

                if (failedRound > 0) {
                    appendLine()
                    appendLine("FAILURE:")
                    appendLine("  failedRound=$failedRound")
                    appendLine("  policy=STOP_IMMEDIATELY_NO_AUTO_RETRY")
                    appendLine()
                    appendLine("LAST_FAILED_REPORT:")
                    failedReport
                        ?.lineSequence()
                        ?.take(180)
                        ?.forEach { appendLine("  $it") }
                }

                appendLine()
                append("RESULT=$result")
            }
        }

        /**
         * Safe stop: never aborts an in-flight game request.
         * The loop exits after the current round has completed/failed.
         */
        @JvmStatic
        fun requestLoopStop(): String {
            loopStopRequested = true
            liveState = liveState.copy(
                stopRequested = true,
                phase = if (liveState.running) "STOP_REQUESTED" else liveState.phase
            )
            return "POWDER PUMP LAB LOOP • STOP_REQUESTED • จะหยุดหลังจบรอบที่กำลังทำ"
        }

        /** Lightweight machine-readable state used by the Pump tab. */
        @JvmStatic
        fun getLiveUiState(): String {
            val s = liveState
            val elapsed = if (s.startedAtMs > 0L) {
                (SystemClock.elapsedRealtime() - s.startedAtMs).coerceAtLeast(0L)
            } else {
                0L
            }
            return buildString {
                appendLine("running=${s.running}")
                appendLine("phase=${s.phase}")
                appendLine("stopRequested=${s.stopRequested}")
                appendLine("elapsedMs=$elapsed")
                appendLine("totalBought=${s.totalBought}")
                appendLine("totalBroken=${s.totalBroken}")
                appendLine("totalPowder=${s.totalPowder}")
                appendLine("accepted=${s.accepted}")
                appendLine("removed=${s.removed}")
                appendLine("coin=${s.coin ?: -1L}")
                append("finalFlowResult=${s.finalFlowResult}")
            }
        }

        /** Full DEV diagnostics; intentionally never exposed by Stable. */
        @JvmStatic
        fun getDevDiagnostics(): String {
            val s = liveState
            val elapsed = if (s.startedAtMs > 0L) {
                (SystemClock.elapsedRealtime() - s.startedAtMs).coerceAtLeast(0L)
            } else {
                0L
            }
            return buildString {
                appendLine("STATE")
                appendLine("running=${s.running}")
                appendLine("phase=${s.phase}")
                appendLine("stopRequested=${s.stopRequested}")
                appendLine("elapsedMs=$elapsed")
                appendLine()
                appendLine("CABINET")
                appendLine("page=${s.page}")
                appendLine("capacity=${s.capacity}")
                appendLine("occupied=${s.occupied}")
                appendLine("freeSlots=${s.freeSlots}")
                appendLine("capacitySource=${s.capacitySource}")
                appendLine()
                appendLine("COIN")
                appendLine("profile=${s.profile}")
                appendLine("coinOffset=0x${CONFIRMED_COIN_OFF.toString(16).uppercase(Locale.US)}")
                appendLine("coin=${s.coin ?: "UNKNOWN"}")
                appendLine("affordable=${s.affordable}")
                appendLine()
                appendLine("BUY")
                appendLine("burstRequested=${s.burstRequested}")
                appendLine("accepted=${s.accepted}")
                appendLine("totalBought=${s.totalBought}")
                appendLine("buyMs=${s.buyMs}")
                appendLine()
                appendLine("BREAK")
                appendLine("batchRequested=${s.batchRequested}")
                appendLine("removed=${s.removed}")
                appendLine("totalBroken=${s.totalBroken}")
                appendLine("breakMs=${s.breakMs}")
                appendLine()
                appendLine("POWDER")
                appendLine("start=${s.powderStart ?: "UNKNOWN"}")
                appendLine("current=${s.powderCurrent ?: "UNKNOWN"}")
                appendLine("delta=${s.powderDelta}")
                appendLine("totalDelta=${s.totalPowder}")
                appendLine()
                appendLine("NATIVE")
                appendLine("pageLocator=${s.pageLocator}")
                appendLine("buyResult=${s.buyResult}")
                appendLine("batchBreakResult=${s.batchBreakResult}")
                appendLine("cleanupResult=${s.cleanupResult}")
                appendLine("finalFlowResult=${s.finalFlowResult}")
                appendLine()
                appendLine("LAST ERROR")
                appendLine("stage=${s.errorStage}")
                appendLine("rc=${s.errorRc}")
                appendLine("message=${s.errorMessage.ifBlank { "NONE" }}")
                appendLine()
                appendLine("FULL REPORT")
                appendLine(lastFullReport)
                appendLine()
                appendLine("LAST_FAILED_REPORT")
                append(lastFailedReport)
            }
        }

        @JvmStatic
        fun resetDevReport(): String {
            if (liveState.running) return "POWDER PUMP DEV • RESET_BLOCKED_WHILE_RUNNING"
            loopStopRequested = false
            liveState = PumpLiveState()
            lastFullReport = "NO POWDER PUMP REPORT YET"
            lastFailedReport = "NONE"
            return "POWDER PUMP DEV • RESET_OK"
        }

        @JvmStatic
        fun recordExternalFailure(report: String) {
            lastFullReport = report
            lastFailedReport = report
            liveState = liveState.copy(
                running = false,
                phase = "ERROR",
                errorStage = "UNCAUGHT",
                errorRc = "EXCEPTION",
                errorMessage = report.take(500)
            )
        }

        private fun markLiveError(stage: String, rc: String, message: String) {
            liveState = liveState.copy(
                errorStage = stage,
                errorRc = rc,
                errorMessage = message
            )
        }

        private fun publishTerminalReport(report: String, failed: Boolean): String {
            lastFullReport = report
            if (failed) lastFailedReport = report
            liveState = liveState.copy(running = false)
            return report
        }

        private fun extractDiagnosticToken(text: String, key: String): String? {
            val rx = Regex("(?:^|\\s)" + Regex.escape(key) + "=([^\\s]+)")
            return rx.find(text)?.groupValues?.getOrNull(1)
        }

        private fun extractDiagnosticLong(text: String, key: String): Long? {
            val rx = Regex("(?:^|\\s)" + Regex.escape(key) + "=(\\d+)")
            return rx.find(text)?.groupValues?.getOrNull(1)?.toLongOrNull()
        }

        private fun extractLong(report: String, key: String): Long? {
            val rx = Regex("""(?m)^\s*${Regex.escape(key)}=(-?\d+)\s*$""")
            return rx.find(report)?.groupValues?.getOrNull(1)?.toLongOrNull()
        }

        private fun extractText(report: String, key: String): String? {
            val rx = Regex("""(?m)^\s*${Regex.escape(key)}=([^\r\n]+)\s*$""")
            return rx.find(report)?.groupValues?.getOrNull(1)?.trim()
        }

        private fun extractFinalRoundResult(report: String): String {
            val matches = Regex("""(?m)^\s*RESULT=([A-Z0-9_]+)\s*$""")
                .findAll(report)
                .map { it.groupValues[1] }
                .toList()
            return matches.firstOrNull { it == "ONE_AUTO_ROUND_VERIFIED" }
                ?: matches.firstOrNull { it != "POWDER_PUMP_LAB_CAPTURE_COMPLETE" }
                ?: matches.lastOrNull()
                ?: "UNKNOWN"
        }

        /**
         * V8 experiment: BURST BUY x10, then dispatch a single request-level
         * BATCH BREAK for the exact ten server-owned Treasure items.
         *
         * This is a one-shot proof before building the real Turbo loop:
         *   BUY x10 parallel -> wait 10 new keys -> BATCH BREAK x10 -> verify all keys removed.
         */
        @JvmStatic
        @Synchronized
        fun runBurst10BatchBreakExperiment(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) {
                return "POWDER PUMP LAB BATCH • INTERNAL_BUILD_REQUIRED"
            }

            val app = context.applicationContext
            if (!memory.hasRoot() && !memory.requestRoot(app)) {
                return "POWDER PUMP LAB BATCH • ROOT_NOT_READY"
            }

            val ping = InProcessGameControl.ping(app, 3500L)
            if (!ping.ok) {
                return "POWDER PUMP LAB BATCH • BRIDGE_NOT_READY • ${ping.message}"
            }

            val pageLocate = InProcessGameControl.powderLocateTreasurePage(app, 6500L)
            if (!pageLocate.ok) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP BURST10 + BATCH BREAK ===")
                    appendLine("MODE=EXPERIMENT_V8_BATCH_BREAK")
                    appendLine("PAGE_RESULT=NOT_READY")
                    appendLine("bridge=${pageLocate.message}")
                    append("RESULT=BATCH_NOT_STARTED_SAFE")
                }
            }

            val start = snapshot()
                ?: return "POWDER PUMP LAB BATCH • START_ROUTE_NOT_READY"

            val startedAt = SystemClock.elapsedRealtime()
            val burst = InProcessGameControl.powderBuyBox1Burst10(app, 5000L)
            if (!burst.ok) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP BURST10 + BATCH BREAK ===")
                    appendLine("MODE=EXPERIMENT_V8_BATCH_BREAK")
                    appendLine("BURST_DISPATCH=FAILED")
                    appendLine("bridge=${burst.message}")
                    append("RESULT=BATCH_BUY_NOT_STARTED")
                }
            }

            var observed = emptyList<Item>()
            var buyEnd: Snapshot? = null
            while (SystemClock.elapsedRealtime() - startedAt <= BURST10_BUY_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val current = snapshot() ?: continue
                val found = findNewTreasures(start, current)
                if (found.size > observed.size) {
                    observed = found
                    buyEnd = current
                }
                if (found.size >= 10) {
                    observed = found.take(10)
                    buyEnd = current
                    break
                }
            }

            val buyObserveMs = SystemClock.elapsedRealtime() - startedAt
            if (observed.size < 10) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP BURST10 + BATCH BREAK ===")
                    appendLine("MODE=EXPERIMENT_V8_BATCH_BREAK")
                    appendLine("BUY_ACCEPTED=${observed.size}/10")
                    appendLine("observeMs=$buyObserveMs")
                    appendLine("policy=NO_BATCH_BREAK_ON_PARTIAL_BUY")
                    observed.forEachIndexed { index, item ->
                        appendLine("  BUY#${index + 1} ${itemLine(item)}")
                    }
                    append("RESULT=BATCH_BUY_PARTIAL_NOT_BROKEN")
                }
            }

            val beforeBatch = buyEnd ?: snapshot() ?: start
            val breakStartedAt = SystemClock.elapsedRealtime()
            val itemPtrs = observed.map { it.item }.toLongArray()
            val batch = InProcessGameControl.powderBreakBatch(app, itemPtrs, 6500L)
            if (!batch.ok) {
                return buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP BURST10 + BATCH BREAK ===")
                    appendLine("MODE=EXPERIMENT_V8_BATCH_BREAK")
                    appendLine("BUY_ACCEPTED=10/10")
                    appendLine("BATCH_DISPATCH=FAILED")
                    appendLine("bridge=${batch.message}")
                    observed.forEachIndexed { index, item ->
                        appendLine("  BUY#${index + 1} ${itemLine(item)}")
                    }
                    append("RESULT=BATCH_BREAK_NOT_STARTED")
                }
            }

            val boughtKeys = observed.map { it.key }.toSet()
            var finalSnapshot: Snapshot? = null
            var removedCount = 0
            while (SystemClock.elapsedRealtime() - breakStartedAt <= BREAK_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val now = snapshot() ?: continue
                removedCount = boughtKeys.count { !now.items.containsKey(it) }
                if (removedCount >= boughtKeys.size) {
                    finalSnapshot = now
                    break
                }
            }

            val breakWaitMs = SystemClock.elapsedRealtime() - breakStartedAt
            if (finalSnapshot != null) {
                SystemClock.sleep(STABLE_MS)
                finalSnapshot = snapshot() ?: finalSnapshot
            }

            val final = finalSnapshot ?: snapshot() ?: beforeBatch
            val finalRemovedCount = boughtKeys.count { !final.items.containsKey(it) }
            val powderDelta = delta(beforeBatch.powder, final.powder)
            val shardDelta = delta(beforeBatch.shard, final.shard)
            val fullPowderDelta = delta(start.powder, final.powder)
            val fullShardDelta = delta(start.shard, final.shard)
            val cleanup = InProcessGameControl.powderCleanup(app, 3500L)

            val verified = finalRemovedCount == boughtKeys.size &&
                powderDelta != null && powderDelta > 0L && shardDelta != null
            val result = if (verified) {
                "BURST10_BATCH_BREAK_VERIFIED"
            } else {
                "BURST10_BATCH_BREAK_NEEDS_REVIEW"
            }

            return buildString {
                appendLine("=== M WOIF LAB • POWDER PUMP BURST10 + BATCH BREAK ===")
                appendLine("MODE=EXPERIMENT_V8_BATCH_BREAK")
                appendLine("policy=ONE_SHOT_ONLY")
                appendLine("pid=${start.pid}")
                appendLine("elfBase=${hex(start.elfBase)}")
                appendLine()
                appendLine("START:")
                appendLine("  inventoryCount=${start.declaredCount}")
                appendLine("  treasureCount=${start.treasureCount}")
                appendLine("  powder=${fmt(start.powder)}")
                appendLine("  shard=${fmt(start.shard)}")
                appendLine()
                appendLine("BURST10:")
                appendLine("  native=${burst.message}")
                appendLine("  observeMs=$buyObserveMs")
                appendLine("  acceptedTreasureKeys=${observed.size}")
                appendLine("  expected=10")
                appendLine("  all10Accepted=${yes(observed.size == 10)}")
                observed.forEachIndexed { index, item ->
                    appendLine("  BUY#${index + 1} ${itemLine(item)}")
                }
                appendLine()
                appendLine("BATCH_BREAK:")
                appendLine("  native=${batch.message}")
                appendLine("  waitMs=$breakWaitMs")
                appendLine("  removedKeys=$finalRemovedCount/${boughtKeys.size}")
                appendLine("  cleanup=${cleanup.message}")
                boughtKeys.forEachIndexed { index, key ->
                    appendLine("  KEY#${index + 1} $key removed=${yes(!final.items.containsKey(key))}")
                }
                appendLine()
                appendLine("DELTA_AFTER_BATCH:")
                appendLine("  POWDER_DELTA=${powderDelta ?: "INVALID"}")
                appendLine("  SHARD_DELTA=${shardDelta ?: "INVALID"}")
                appendLine()
                appendLine("FULL_ROUNDTRIP_DELTA:")
                appendLine("  POWDER_START_TO_END=${fullPowderDelta ?: "INVALID"}")
                appendLine("  SHARD_START_TO_END=${fullShardDelta ?: "INVALID"}")
                appendLine()
                appendLine("FINAL:")
                appendLine("  inventoryCount=${final.declaredCount}")
                appendLine("  treasureCount=${final.treasureCount}")
                appendLine("  powder=${fmt(final.powder)}")
                appendLine("  shard=${fmt(final.shard)}")
                appendLine()
                appendLine("VERIFY:")
                appendLine("  BUY_ACCEPTED_10=${yes(observed.size == 10)}")
                appendLine("  BATCH_REMOVED_ALL=${yes(finalRemovedCount == boughtKeys.size)}")
                appendLine("  POWDER_INCREASED=${yes(powderDelta != null && powderDelta > 0L)}")
                appendLine("  SHARD_DELTA_VALID=${yes(shardDelta != null)}")
                appendLine("  RESULT=$result")
                appendLine()
                append("RESULT=$result")
            }
        }

        /**
         * Turbo Lab:
         * live occupied Cabinet count -> burst exactly free slots -> wait real
         * Treasure keys -> one BATCH BREAK -> verify -> repeat until the server
         * stops accepting Normal Box1 purchases (normally Coin < 5000).
         *
         * Existing/pre-run Treasure items are never selected for BREAK.
         */
        @JvmStatic
        @Synchronized
        fun runTurboUntilCoinExhausted(context: Context): String {
            val turboStartedAt = SystemClock.elapsedRealtime()
            liveState = PumpLiveState(
                running = true,
                phase = "STARTING",
                startedAtMs = turboStartedAt
            )

            fun failEarly(stage: String, message: String, report: String): String {
                markLiveError(stage, "N/A", message)
                liveState = liveState.copy(phase = "ERROR")
                return publishTerminalReport(report, failed = true)
            }

            if (!BuildConfig.INTERNAL_BUILD) {
                return failEarly(
                    "BUILD",
                    "INTERNAL_BUILD_REQUIRED",
                    "POWDER PUMP TURBO • INTERNAL_BUILD_REQUIRED"
                )
            }

            val app = context.applicationContext
            if (!memory.hasRoot() && !memory.requestRoot(app)) {
                return failEarly(
                    "ROOT",
                    "ROOT_NOT_READY",
                    "POWDER PUMP TURBO • ROOT_NOT_READY"
                )
            }

            val ping = InProcessGameControl.ping(app, 3500L)
            if (!ping.ok) {
                return failEarly(
                    "BRIDGE",
                    ping.message,
                    "POWDER PUMP TURBO • BRIDGE_NOT_READY • ${ping.message}"
                )
            }

            liveState = liveState.copy(phase = "LOCATING_PAGE")
            val pageLocate = InProcessGameControl.powderLocateTreasurePage(app, 6500L)
            liveState = liveState.copy(
                pageLocator = pageLocate.message,
                page = extractDiagnosticToken(pageLocate.message, "best") ?: "UNKNOWN"
            )
            if (!pageLocate.ok) {
                val report = buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP TURBO ===")
                    appendLine("MODE=DYNAMIC_CABINET_BURST_PLUS_BATCH_BREAK")
                    appendLine("PAGE_RESULT=NOT_READY")
                    appendLine("bridge=${pageLocate.message}")
                    append("RESULT=TURBO_NOT_STARTED_SAFE")
                }
                return failEarly("PAGE_LOCATOR", pageLocate.message, report)
            }

            loopStopRequested = false
            liveState = liveState.copy(stopRequested = false)

            val globalStart = snapshot()
                ?: return failEarly(
                    "START_SNAPSHOT",
                    "START_ROUTE_NOT_READY",
                    "POWDER PUMP TURBO • START_ROUTE_NOT_READY"
                )

            val liveCapacityRaw = extractDiagnosticLong(
                pageLocate.message,
                "cabinetCapacity"
            )

            val liveCapacity: Int
            val capacitySource: String
            if (liveCapacityRaw != null && liveCapacityRaw in 1..10_000L) {
                liveCapacity = liveCapacityRaw.toInt()
                capacitySource = "PAGE_0x258"
            } else if (globalStart.treasureCount <= 20) {
                liveCapacity = 20
                capacitySource = "FALLBACK_20_PAGE_NOT_REFRESHED"
            } else {
                val report = buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP TURBO ===")
                    appendLine("MODE=DYNAMIC_CABINET_BURST_PLUS_BATCH_BREAK")
                    appendLine("treasureCount=${globalStart.treasureCount}")
                    appendLine("PAGE=${pageLocate.message}")
                    append("RESULT=CABINET_CAPACITY_UNKNOWN_SAFE_STOP")
                }
                return failEarly("CABINET", "capacity unknown", report)
            }

            val powderStartValue = globalStart.powder.value
            liveState = liveState.copy(
                phase = "READY_TO_BUY",
                capacity = liveCapacity,
                occupied = globalStart.treasureCount,
                freeSlots = (liveCapacity - globalStart.treasureCount).coerceAtLeast(0),
                capacitySource = capacitySource,
                profile = "0x${globalStart.profile.toString(16).uppercase(Locale.US)}",
                powderStart = powderStartValue,
                powderCurrent = powderStartValue
            )

            var current = globalStart
            var batchNo = 0
            var totalBought = 0
            var totalBroken = 0
            var totalPowder = 0L
            var totalShard = 0L
            var stopReason = "UNKNOWN"
            val lines = ArrayList<String>()

            val coinOffset = CONFIRMED_COIN_OFF
            discoveredCoinOffset = coinOffset

            val initialCoinField = decodeProtected64(
                current.pid,
                current.profile + coinOffset
            )
            val initialCoin = initialCoinField.value
            if (!initialCoinField.valid || initialCoin == null || initialCoin < 0L) {
                val report = buildString {
                    appendLine("=== M WOIF LAB • POWDER PUMP TURBO ===")
                    appendLine("MODE=DYNAMIC_CABINET_BURST_PLUS_BATCH_BREAK")
                    appendLine("coinOffset=0x${coinOffset.toString(16).uppercase(Locale.US)}")
                    appendLine("coin=INVALID")
                    append("RESULT=CONFIRMED_COIN_ROUTE_NOT_READY_SAFE_STOP")
                }
                return failEarly("COIN", "confirmed coin route invalid", report)
            }

            liveState = liveState.copy(
                coin = initialCoin,
                affordable = (initialCoin / NORMAL_BOX1_PRICE)
                    .coerceAtMost(Int.MAX_VALUE.toLong())
                    .toInt()
            )

            lines += buildString {
                append("COIN ROUTE PASS")
                append(" offset=0x${coinOffset.toString(16).uppercase(Locale.US)}")
                append(" coin=$initialCoin")
            }

            while (!loopStopRequested && batchNo < TURBO_MAX_BATCHES) {
                val occupied = current.treasureCount
                val freeSlotsRaw = (liveCapacity - occupied).coerceAtLeast(0)
                val freeSlots = minOf(freeSlotsRaw, TURBO_BURST_TRANSPORT_MAX)

                liveState = liveState.copy(
                    occupied = occupied,
                    freeSlots = freeSlotsRaw,
                    phase = "PRECHECK"
                )

                if (freeSlotsRaw <= 0) {
                    stopReason = "CABINET_FULL"
                    lines += "BATCH#${batchNo + 1} STOP occupied=$occupied capacity=$liveCapacity free=0"
                    break
                }

                val coinField = decodeProtected64(
                    current.pid,
                    current.profile + coinOffset
                )
                val coinNow = coinField.value
                if (!coinField.valid || coinNow == null || coinNow < 0L) {
                    stopReason = "COIN_READ_FAILED_SAFE_STOP"
                    markLiveError("COIN_READ", "INVALID", "protected64 decode failed")
                    lines += "BATCH#${batchNo + 1} STOP coinOffset=0x${coinOffset.toString(16).uppercase(Locale.US)} coin=INVALID"
                    break
                }

                val affordable = (coinNow / NORMAL_BOX1_PRICE)
                    .coerceAtMost(Int.MAX_VALUE.toLong())
                    .toInt()

                liveState = liveState.copy(
                    coin = coinNow,
                    affordable = affordable
                )

                if (affordable <= 0) {
                    stopReason = "COIN_BELOW_5000_NO_REQUEST_SENT"
                    lines += "BATCH#${batchNo + 1} STOP coin=$coinNow affordable=0"
                    break
                }

                val requested = minOf(freeSlots, affordable)
                val beforeBuy = current
                val buyStartedAt = SystemClock.elapsedRealtime()
                val dispatchTimeoutMs = maxOf(5_000L, 2_500L + requested * 120L)
                val buyObserveTimeoutMs = maxOf(
                    TURBO_BUY_TIMEOUT_MS,
                    4_000L + requested * 350L
                )
                val settleMs = maxOf(
                    TURBO_BUY_SETTLE_MS,
                    minOf(1_800L, 400L + requested * 15L)
                )

                liveState = liveState.copy(
                    phase = "BUYING",
                    burstRequested = requested,
                    accepted = 0,
                    buyMs = 0L,
                    batchRequested = 0,
                    removed = 0,
                    breakMs = 0L,
                    buyResult = "DISPATCHING",
                    batchBreakResult = "NOT_RUN"
                )

                val burst = InProcessGameControl.powderBuyBox1Burst(
                    app,
                    requested,
                    dispatchTimeoutMs
                )
                if (!burst.ok) {
                    stopReason = "BURST_DISPATCH_FAILED"
                    markLiveError("BUY_DISPATCH", "BRIDGE", burst.message)
                    liveState = liveState.copy(buyResult = "FAIL • ${burst.message}")
                    lines += "BATCH#${batchNo + 1} FAIL burst=$requested bridge=${burst.message}"
                    break
                }
                liveState = liveState.copy(buyResult = "DISPATCH_OK • ${burst.message}")

                var observed = emptyList<Item>()
                var buySnapshot: Snapshot? = null
                var lastGrowthAt = buyStartedAt

                while (SystemClock.elapsedRealtime() - buyStartedAt <= buyObserveTimeoutMs) {
                    SystemClock.sleep(POLL_MS)
                    val now = snapshot() ?: continue
                    val found = findNewTreasures(beforeBuy, now)

                    if (found.size > observed.size) {
                        observed = found.take(requested)
                        buySnapshot = now
                        lastGrowthAt = SystemClock.elapsedRealtime()
                        liveState = liveState.copy(
                            accepted = observed.size,
                            totalBought = totalBought + observed.size,
                            buyMs = SystemClock.elapsedRealtime() - buyStartedAt
                        )
                    }

                    if (observed.size >= requested) break

                    if (
                        observed.isNotEmpty() &&
                        SystemClock.elapsedRealtime() - lastGrowthAt >= settleMs
                    ) {
                        break
                    }
                }

                val accepted = observed.size
                val buyMs = SystemClock.elapsedRealtime() - buyStartedAt

                if (accepted <= 0) {
                    stopReason = "COIN_EXHAUSTED_OR_SERVER_REJECTED"
                    liveState = liveState.copy(
                        accepted = 0,
                        buyMs = buyMs,
                        buyResult = "SERVER_REJECT_OR_NO_DELTA"
                    )
                    lines += "BATCH#${batchNo + 1} STOP requested=$requested accepted=0 buyMs=$buyMs"
                    current = snapshot() ?: current
                    break
                }

                totalBought += accepted
                liveState = liveState.copy(
                    phase = "BREAKING",
                    accepted = accepted,
                    totalBought = totalBought,
                    buyMs = buyMs,
                    buyResult = "ACCEPTED=$accepted"
                )

                val beforeBreak = buySnapshot ?: snapshot() ?: beforeBuy
                val boughtKeys = observed.map { it.key }.toSet()
                val itemPtrs = observed.map { it.item }.toLongArray()

                val breakStartedAt = SystemClock.elapsedRealtime()
                liveState = liveState.copy(
                    batchRequested = itemPtrs.size,
                    batchBreakResult = "DISPATCHING"
                )
                val batchBreak = InProcessGameControl.powderBreakBatch(app, itemPtrs, 6500L)
                if (!batchBreak.ok) {
                    stopReason = "BATCH_BREAK_DISPATCH_FAILED"
                    markLiveError("BREAK_DISPATCH", "BRIDGE", batchBreak.message)
                    liveState = liveState.copy(
                        batchBreakResult = "FAIL • ${batchBreak.message}"
                    )
                    lines += "BATCH#${batchNo + 1} FAIL requested=$requested accepted=$accepted batchBreak=${batchBreak.message}"
                    current = snapshot() ?: beforeBreak
                    break
                }
                liveState = liveState.copy(
                    batchBreakResult = "DISPATCH_OK • ${batchBreak.message}"
                )

                var afterBreak: Snapshot? = null
                var removed = 0
                while (SystemClock.elapsedRealtime() - breakStartedAt <= BREAK_TIMEOUT_MS) {
                    SystemClock.sleep(POLL_MS)
                    val now = snapshot() ?: continue
                    removed = boughtKeys.count { !now.items.containsKey(it) }
                    liveState = liveState.copy(
                        removed = removed,
                        breakMs = SystemClock.elapsedRealtime() - breakStartedAt
                    )
                    if (removed >= boughtKeys.size) {
                        afterBreak = now
                        break
                    }
                }

                if (afterBreak == null) {
                    stopReason = "BATCH_BREAK_TIMEOUT"
                    markLiveError("BREAK_WAIT", "TIMEOUT", "removed=$removed/$accepted")
                    lines += "BATCH#${batchNo + 1} FAIL accepted=$accepted removed=$removed/$accepted"
                    current = snapshot() ?: beforeBreak
                    break
                }

                liveState = liveState.copy(phase = "VERIFYING")
                SystemClock.sleep(STABLE_MS)
                val final = snapshot() ?: afterBreak
                val finalRemoved = boughtKeys.count { !final.items.containsKey(it) }
                val powderDelta = delta(beforeBreak.powder, final.powder)
                val shardDelta = delta(beforeBreak.shard, final.shard)

                if (
                    finalRemoved != accepted ||
                    powderDelta == null ||
                    powderDelta <= 0L ||
                    shardDelta == null
                ) {
                    stopReason = "BATCH_VERIFY_FAILED"
                    markLiveError(
                        "VERIFY",
                        "MISMATCH",
                        "accepted=$accepted removed=$finalRemoved powder=${powderDelta ?: "INVALID"} shard=${shardDelta ?: "INVALID"}"
                    )
                    lines += "BATCH#${batchNo + 1} FAIL accepted=$accepted removed=$finalRemoved powderDelta=${powderDelta ?: "INVALID"} shardDelta=${shardDelta ?: "INVALID"}"
                    current = final
                    break
                }

                liveState = liveState.copy(phase = "CLEANUP")
                val cleanup = InProcessGameControl.powderCleanup(app, 3500L)

                totalBroken += finalRemoved
                totalPowder += powderDelta
                totalShard += shardDelta
                batchNo += 1
                current = final

                liveState = liveState.copy(
                    phase = "BATCH_COMPLETE",
                    occupied = current.treasureCount,
                    freeSlots = (liveCapacity - current.treasureCount).coerceAtLeast(0),
                    removed = finalRemoved,
                    totalBroken = totalBroken,
                    breakMs = SystemClock.elapsedRealtime() - breakStartedAt,
                    powderCurrent = final.powder.value,
                    powderDelta = powderDelta,
                    totalPowder = totalPowder,
                    cleanupResult = "${if (cleanup.ok) "OK" else "FAIL"} • ${cleanup.message}"
                )

                lines += buildString {
                    append("BATCH#$batchNo PASS")
                    append(" cabinet=$occupied/$liveCapacity")
                    append(" freeRaw=$freeSlotsRaw")
                    append(" burstWindow=$freeSlots")
                    append(" coinBefore=$coinNow")
                    append(" affordable=$affordable")
                    append(" requested=$requested")
                    append(" accepted=$accepted")
                    append(" broken=$finalRemoved")
                    append(" powder=+$powderDelta")
                    append(" shard=+$shardDelta")
                    append(" buyMs=$buyMs")
                    append(" breakMs=${SystemClock.elapsedRealtime() - breakStartedAt}")
                    append(" cleanup=${cleanup.ok}")
                }

                if (!cleanup.ok) {
                    markLiveError("CLEANUP", "BRIDGE", cleanup.message)
                }

                if (accepted < requested) {
                    stopReason = "SERVER_PARTIAL_ACCEPT_SAFE_STOP"
                    break
                }
            }

            if (loopStopRequested) {
                stopReason = "STOPPED_BY_USER"
            } else if (batchNo >= TURBO_MAX_BATCHES) {
                stopReason = "SAFETY_MAX_BATCHES"
            }

            val stoppedByUser = loopStopRequested
            loopStopRequested = false
            liveState = liveState.copy(stopRequested = false)

            val end = snapshot() ?: current
            val elapsed = SystemClock.elapsedRealtime() - turboStartedAt
            val globalPowderDelta = delta(globalStart.powder, end.powder)
            val globalShardDelta = delta(globalStart.shard, end.shard)

            // V12 final behavior: do NOT call FUN_015D899C directly. Ghidra shows
            // the normal Box1 action FUN_0168494C only checks network availability
            // before entering FUN_016856C8, which builds the real server request.
            // The old Pump behavior that the user wants was produced when one
            // request reached the server after Coin was already below 5000. That
            // server failure enters CookieRun's own ConnectionFailPopup/Retry flow.
            // Trigger it only after every accepted Treasure was fully batch-broken
            // and the deferred retain cleanup has completed.
            var finalFlowResult = "NOT_REQUESTED"
            var finalCleanupResult: InProcessGameControl.Result? = null
            if (stopReason == "COIN_BELOW_5000_NO_REQUEST_SENT" && totalBroken > 0) {
                liveState = liveState.copy(phase = "FINAL_CLEANUP")
                finalCleanupResult = InProcessGameControl.powderCleanup(app, 3500L)
                liveState = liveState.copy(
                    cleanupResult = "FINAL ${if (finalCleanupResult.ok) "OK" else "FAIL"} • ${finalCleanupResult.message}"
                )

                liveState = liveState.copy(phase = "WAIT_CONNECTION_RETRY")
                val trigger = InProcessGameControl.powderBuyBox1(app, 4500L)
                finalFlowResult = if (trigger.ok) {
                    "CONNECTION_RETRY_TRIGGER_DISPATCHED • ${trigger.message}"
                } else {
                    "CONNECTION_RETRY_TRIGGER_FAILED • ${trigger.message}"
                }
                liveState = liveState.copy(finalFlowResult = finalFlowResult)
                if (!trigger.ok) {
                    markLiveError("FINAL_CONNECTION_TRIGGER", "BRIDGE", trigger.message)
                }
                lines += "FINAL_CONNECTION_FLOW ${if (trigger.ok) "PASS" else "FAIL"} • ${trigger.message}"
            } else if (stopReason == "COIN_EXHAUSTED_OR_SERVER_REJECTED") {
                finalFlowResult = "SERVER_REJECT_ALREADY_SENT_BY_LAST_BUY"
                liveState = liveState.copy(
                    phase = "WAIT_CONNECTION_RETRY",
                    finalFlowResult = finalFlowResult
                )
                lines += "FINAL_CONNECTION_FLOW PASS • server reject already in flight"
            } else {
                liveState = liveState.copy(finalFlowResult = finalFlowResult)
            }

            val report = buildString {
                appendLine("=== M WOIF LAB • POWDER PUMP TURBO ===")
                appendLine("MODE=DYNAMIC_CABINET_BURST_PLUS_BATCH_BREAK")
                appendLine("cabinetCapacity=$liveCapacity")
                appendLine("capacitySource=$capacitySource")
                appendLine("policy=DIRECT_CONFIRMED_COIN_OFFSET_PLUS_DYNAMIC_FREE_SLOTS_THEN_BATCH_BREAK")
                appendLine("coinOffset=0x${coinOffset.toString(16).uppercase(Locale.US)}")
                appendLine("transportMax=$TURBO_BURST_TRANSPORT_MAX")
                appendLine("elapsedMs=$elapsed")
                appendLine("batches=$batchNo")
                appendLine("stopRequested=$stoppedByUser")
                appendLine("finalFlow=$finalFlowResult")
                appendLine("finalCleanupOk=${finalCleanupResult?.ok ?: true}")
                appendLine()
                appendLine("TOTAL:")
                appendLine("  bought=$totalBought")
                appendLine("  broken=$totalBroken")
                appendLine("  powderDelta=$totalPowder")
                appendLine("  shardDelta=$totalShard")
                appendLine("  verifiedPowderStartToEnd=${globalPowderDelta ?: "INVALID"}")
                appendLine("  verifiedShardStartToEnd=${globalShardDelta ?: "INVALID"}")
                appendLine()
                appendLine("BATCHES:")
                lines.forEach { appendLine("  $it") }
                appendLine()
                appendLine("STOP_REASON=$stopReason")
                append("RESULT=${if (totalBroken > 0) "TURBO_STOPPED_CLEANLY" else "TURBO_NO_COMPLETED_BATCH"}")
            }

            val failedTerminal =
                stopReason.contains("FAILED") ||
                    stopReason.contains("TIMEOUT") ||
                    stopReason == "UNKNOWN" ||
                    stopReason == "SAFETY_MAX_BATCHES" ||
                    (totalBroken <= 0 && stopReason != "STOPPED_BY_USER")

            liveState = liveState.copy(
                running = false,
                phase = when {
                    failedTerminal -> "ERROR"
                    stopReason == "STOPPED_BY_USER" -> "STOPPED"
                    finalFlowResult.startsWith("CONNECTION_RETRY") ||
                        finalFlowResult.startsWith("SERVER_REJECT") -> "WAIT_CONNECTION_RETRY"
                    else -> "COMPLETE"
                },
                occupied = end.treasureCount,
                freeSlots = (liveCapacity - end.treasureCount).coerceAtLeast(0),
                powderCurrent = end.powder.value,
                totalBought = totalBought,
                totalBroken = totalBroken,
                totalPowder = totalPowder,
                finalFlowResult = finalFlowResult
            )

            return publishTerminalReport(report, failed = failedTerminal)
        }

        @JvmStatic
        @Synchronized
        fun triggerConnectionRetry(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) return "POWDER PUMP CONNECTION • INTERNAL_BUILD_REQUIRED"
            if (liveState.running) return "POWDER PUMP CONNECTION • BLOCKED_WHILE_RUNNING"

            val app = context.applicationContext
            if (!memory.hasRoot() && !memory.requestRoot(app)) {
                return "POWDER PUMP CONNECTION • ROOT_NOT_READY"
            }

            val current = snapshot()
                ?: return "POWDER PUMP CONNECTION • SNAPSHOT_NOT_READY"

            val coinOffset = discoveredCoinOffset ?: CONFIRMED_COIN_OFF
            val coinField = decodeProtected64(
                current.pid,
                current.profile + coinOffset
            )
            val coin = coinField.value
                ?: return "POWDER PUMP CONNECTION • COIN_NOT_READABLE"

            liveState = liveState.copy(
                profile = "0x${current.profile.toString(16).uppercase(Locale.US)}",
                coin = coin,
                affordable = (coin / NORMAL_BOX1_PRICE).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            )

            // This button is intentionally guarded. The old Connection Lost /
            // Retry behavior is produced by one real Box1 request only after Coin
            // is already below 5000. With enough Coin the same action would buy a
            // Treasure instead of opening the game's retry popup.
            if (coin >= NORMAL_BOX1_PRICE) {
                val result = "POWDER PUMP CONNECTION • BLOCKED_COIN_NOT_LOW • coin=$coin"
                liveState = liveState.copy(
                    finalFlowResult = result,
                    errorStage = "NONE",
                    errorRc = "0",
                    errorMessage = ""
                )
                return result
            }

            val ping = InProcessGameControl.ping(app, 3000L)
            if (!ping.ok) {
                val result = "POWDER PUMP CONNECTION • BRIDGE_NOT_READY • ${ping.message}"
                liveState = liveState.copy(
                    finalFlowResult = result,
                    errorStage = "FINAL_CONNECTION_TRIGGER",
                    errorRc = "BRIDGE",
                    errorMessage = ping.message
                )
                return result
            }

            liveState = liveState.copy(phase = "FINAL_CLEANUP")
            val cleanup = InProcessGameControl.powderCleanup(app, 3500L)
            liveState = liveState.copy(
                cleanupResult = "CONNECTION ${if (cleanup.ok) "OK" else "FAIL"} • ${cleanup.message}"
            )

            liveState = liveState.copy(phase = "WAIT_CONNECTION_RETRY")
            val trigger = InProcessGameControl.powderBuyBox1(app, 4500L)
            val result = if (trigger.ok) {
                "POWDER PUMP CONNECTION • CONNECTION_RETRY_TRIGGER_DISPATCHED • ${trigger.message}"
            } else {
                "POWDER PUMP CONNECTION • CONNECTION_RETRY_TRIGGER_FAILED • ${trigger.message}"
            }

            liveState = liveState.copy(
                phase = if (trigger.ok) "WAIT_CONNECTION_RETRY" else "ERROR",
                finalFlowResult = result,
                errorStage = if (trigger.ok) "NONE" else "FINAL_CONNECTION_TRIGGER",
                errorRc = if (trigger.ok) "0" else "BRIDGE",
                errorMessage = if (trigger.ok) "" else trigger.message
            )
            return result
        }

        @JvmStatic
        @Synchronized
        fun cleanup(context: Context): String {
            if (!BuildConfig.INTERNAL_BUILD) return "INTERNAL_BUILD_REQUIRED"
            val ping = InProcessGameControl.ping(context.applicationContext, 3000L)
            if (!ping.ok) return "CLEANUP_FAILED • ${ping.message}"
            val result = InProcessGameControl.powderCleanup(context.applicationContext, 3500L)
            liveState = liveState.copy(
                cleanupResult = "MANUAL ${if (result.ok) "OK" else "FAIL"} • ${result.message}"
            )
            if (!result.ok) markLiveError("MANUAL_CLEANUP", "BRIDGE", result.message)
            return "POWDER PUMP LAB CLEANUP AFTER POPUP • ${if (result.ok) "OK" else "FAIL"} • ${result.message}"
        }

        private fun scanProtected64Profile(
            pid: Int,
            profile: Long
        ): LinkedHashMap<Long, Long> {
            val out = LinkedHashMap<Long, Long>()
            var off = COIN_SCAN_START
            while (off <= COIN_SCAN_END) {
                // Known Powder/Shard fields are not Coin candidates.
                if (off != POWDER_OFF && off != SHARD_OFF) {
                    val decoded = decodeProtected64(pid, profile + off)
                    val value = decoded.value
                    if (
                        decoded.valid &&
                        value != null &&
                        value >= 0L &&
                        value <= 10_000_000_000_000L
                    ) {
                        out[off] = value
                    }
                }
                off += COIN_SCAN_STEP
            }
            return out
        }

        /**
         * Discover the live account-Coin protected64 field without any fixed
         * reverse-engineered offset:
         *
         * profile fields BEFORE
         *   -> one real Normal Box1 purchase
         *   -> profile fields AFTER
         *   -> candidate where BEFORE - AFTER == 5000
         *
         * If several mirrors move together, any synchronized readable mirror is
         * sufficient for a conservative affordability cap; prefer the lowest
         * offset deterministically and report every candidate in detail.
         */
        private fun calibrateCoinOffset(
            app: Context,
            start: Snapshot
        ): CoinCalibration {
            val beforeFields = scanProtected64Profile(start.pid, start.profile)

            val buyStartedAt = SystemClock.elapsedRealtime()
            val buy = InProcessGameControl.powderBuyBox1Burst(app, 1, 4500L)
            if (!buy.ok) {
                return CoinCalibration(
                    false, null, null, null, null,
                    0, 0, 0L, 0L,
                    "CALIBRATION_BUY_DISPATCH_FAILED • ${buy.message}"
                )
            }

            var bought: Item? = null
            var afterBuy: Snapshot? = null
            while (SystemClock.elapsedRealtime() - buyStartedAt <= BUY_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val now = snapshot() ?: continue
                val found = findNewTreasures(start, now)
                if (found.isNotEmpty()) {
                    bought = found.first()
                    afterBuy = now
                    break
                }
            }

            if (bought == null || afterBuy == null) {
                return CoinCalibration(
                    false, null, null, null, snapshot(),
                    0, 0, 0L, 0L,
                    "CALIBRATION_BUY_RESULT_TIMEOUT"
                )
            }

            SystemClock.sleep(STABLE_MS)
            val stableAfterBuy = snapshot() ?: afterBuy
            val afterFields = scanProtected64Profile(
                stableAfterBuy.pid,
                stableAfterBuy.profile
            )

            val candidates = beforeFields.entries
                .mapNotNull { (off, before) ->
                    val after = afterFields[off] ?: return@mapNotNull null
                    if (before - after == NORMAL_BOX1_PRICE) {
                        Triple(off, before, after)
                    } else {
                        null
                    }
                }
                .sortedBy { it.first }

            if (candidates.isEmpty()) {
                // The purchased Treasure is real, so clean it up before stopping.
                val br = InProcessGameControl.powderBreakBatch(
                    app,
                    longArrayOf(bought.item),
                    6500L
                )
                if (br.ok) {
                    val t0 = SystemClock.elapsedRealtime()
                    while (SystemClock.elapsedRealtime() - t0 <= BREAK_TIMEOUT_MS) {
                        SystemClock.sleep(POLL_MS)
                        val now = snapshot() ?: continue
                        if (!now.items.containsKey(bought.key)) break
                    }
                    InProcessGameControl.powderCleanup(app, 3500L)
                }

                return CoinCalibration(
                    false, null, null, null, snapshot(),
                    1, 0, 0L, 0L,
                    "COIN_DELTA_5000_FIELD_NOT_FOUND"
                )
            }

            val chosen = candidates.first()
            val chosenOffset = chosen.first
            val beforeCoin = chosen.second
            val afterCoin = chosen.third

            val beforeBreak = stableAfterBuy
            val breakStartedAt = SystemClock.elapsedRealtime()
            val br = InProcessGameControl.powderBreakBatch(
                app,
                longArrayOf(bought.item),
                6500L
            )
            if (!br.ok) {
                return CoinCalibration(
                    false,
                    chosenOffset,
                    beforeCoin,
                    afterCoin,
                    snapshot(),
                    1,
                    0,
                    0L,
                    0L,
                    "CALIBRATION_BREAK_DISPATCH_FAILED • ${br.message}"
                )
            }

            var removedSnapshot: Snapshot? = null
            while (SystemClock.elapsedRealtime() - breakStartedAt <= BREAK_TIMEOUT_MS) {
                SystemClock.sleep(POLL_MS)
                val now = snapshot() ?: continue
                if (!now.items.containsKey(bought.key)) {
                    removedSnapshot = now
                    break
                }
            }

            if (removedSnapshot == null) {
                return CoinCalibration(
                    false,
                    chosenOffset,
                    beforeCoin,
                    afterCoin,
                    snapshot(),
                    1,
                    0,
                    0L,
                    0L,
                    "CALIBRATION_BREAK_TIMEOUT"
                )
            }

            SystemClock.sleep(STABLE_MS)
            val final = snapshot() ?: removedSnapshot
            val pd = delta(beforeBreak.powder, final.powder) ?: 0L
            val sd = delta(beforeBreak.shard, final.shard) ?: 0L
            InProcessGameControl.powderCleanup(app, 3500L)

            val candidateText = candidates.joinToString(",") {
                "0x${it.first.toString(16).uppercase(Locale.US)}:${it.second}->${it.third}"
            }

            return CoinCalibration(
                true,
                chosenOffset,
                beforeCoin,
                afterCoin,
                final,
                1,
                1,
                pd,
                sd,
                "candidates=$candidateText chosen=0x${chosenOffset.toString(16).uppercase(Locale.US)}"
            )
        }

        private fun snapshot(): Snapshot? {
            val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
            val elfBase = findElfBase(pid) ?: return null
            val outerGlobal = elfBase + (OUTER_GLOBAL_GH - IMAGE_BASE)
            val outer = memory.readLong(pid, outerGlobal) ?: return null
            if (!isPointer(outer)) return null
            val a = memory.readLong(pid, outer + 0x08L) ?: return null
            if (!isPointer(a)) return null
            val profile = memory.readLong(pid, a + 0x30L) ?: return null
            if (!isPointer(profile)) return null
            val store = memory.readLong(pid, profile + PROFILE_INV_OFF) ?: return null
            if (!isPointer(store)) return null

            val powder = decodeProtected64(pid, profile + POWDER_OFF)
            val shard = decodeProtected64(pid, profile + SHARD_OFF)
            if (!powder.valid || !shard.valid) return null

            val declaredCount = memory.readLong(pid, store + 0x28L)
            val items = traverseInventory(pid, elfBase, store)

            return Snapshot(
                pid = pid,
                elfBase = elfBase,
                outer = outer,
                a = a,
                profile = profile,
                store = store,
                declaredCount = declaredCount,
                powder = powder,
                shard = shard,
                items = items
            )
        }

        private fun traverseInventory(
            pid: Int,
            elfBase: Long,
            store: Long
        ): LinkedHashMap<String, Item> {
            val output = LinkedHashMap<String, Item>()
            val root = memory.readLong(pid, store + 0x20L) ?: return output
            if (!isPointer(root)) return output

            val stack = ArrayDeque<Long>()
            val seen = HashSet<Long>()
            stack.add(root)

            while (stack.isNotEmpty() && output.size < MAX_NODES) {
                val node = stack.removeLast()
                if (!isPointer(node) || !seen.add(node)) continue

                val left = memory.readLong(pid, node + 0x00L) ?: 0L
                val right = memory.readLong(pid, node + 0x08L) ?: 0L
                val key = readCppString(pid, node + 0x20L, 192)
                val itemPtr = memory.readLong(pid, node + 0x38L) ?: 0L

                if (!key.isNullOrBlank() && isPointer(itemPtr)) {
                    val item = readItem(pid, elfBase, node, key, itemPtr)
                    output[key] = item
                }

                if (isPointer(left)) stack.add(left)
                if (isPointer(right)) stack.add(right)
            }
            return output
        }

        private fun readItem(
            pid: Int,
            elfBase: Long,
            node: Long,
            key: String,
            item: Long
        ): Item {
            val vptr = memory.readLong(pid, item) ?: 0L
            val vptrGh = if (vptr >= elfBase) IMAGE_BASE + (vptr - elfBase) else 0L
            return Item(
                node = node,
                key = key,
                item = item,
                vptrGh = vptrGh,
                stuffSeq = decodeProtected32(pid, item + 0x30L),
                qty = decodeProtected64(pid, item + 0x58L).value,
                groupSeq = decodeProtected32(pid, item + 0x80L),
                tag = decodeProtected32(pid, item + 0xA8L),
                type = memory.readInt(pid, item + 0xD0L)
            )
        }

        private fun findNewTreasures(before: Snapshot, after: Snapshot): List<Item> =
            after.items.values.filter { item ->
                !before.items.containsKey(item.key) &&
                    item.type == TREASURE_TYPE &&
                    item.vptrGh == ITEM_VPTR_GH
            }

        private fun decodeProtected32(pid: Int, field: Long): Long? {
            val pA = memory.readLong(pid, field + 0x08L) ?: return null
            val pB = memory.readLong(pid, field + 0x10L) ?: return null
            if (!isPointer(pA) || !isPointer(pB)) return null
            val a = memory.readBytes(pid, pA, 4) ?: return null
            val b = memory.readBytes(pid, pB, 4) ?: return null
            if (a.size < 4 || b.size < 4) return null

            fun ub(x: Byte): Int = x.toInt() and 0xFF
            fun inv(x: Int): Int = (256 - x) and 0xFF

            val av = intArrayOf(
                inv(ub(a[3])) xor 0xC6,
                inv(ub(a[2])) xor 0x3A,
                inv(ub(a[1])) xor 0xC6,
                inv(ub(a[0])) xor 0x3A
            )
            val bv = intArrayOf(
                inv(ub(b[0])) xor 0x95,
                inv(ub(b[1])) xor 0x6B,
                inv(ub(b[2])) xor 0x95,
                inv(ub(b[3])) xor 0x6B
            )

            var va = 0L
            var vb = 0L
            for (i in 0..3) {
                va = va or ((av[i].toLong() and 0xFFL) shl (i * 8))
                vb = vb or ((bv[i].toLong() and 0xFFL) shl (i * 8))
            }
            return if (va == vb) va else null
        }

        private fun decodeProtected64(pid: Int, field: Long): Protected64 {
            val pA = memory.readLong(pid, field + 0x08L) ?: return invalid64()
            val pB = memory.readLong(pid, field + 0x10L) ?: return invalid64()
            if (!isPointer(pA) || !isPointer(pB)) return invalid64()

            val a = memory.readBytes(pid, pA, 8) ?: return invalid64()
            val b = memory.readBytes(pid, pB, 8) ?: return invalid64()
            if (a.size < 8 || b.size < 8) return invalid64()

            fun ub(x: Byte): Int = x.toInt() and 0xFF
            fun dec(x: Byte, key: Int): Int = (((ub(x) - 1) and 0xFF) xor key) and 0xFF

            val av = IntArray(8)
            av[7] = dec(a[0], 0xC5)
            av[6] = dec(a[1], 0x39)
            av[5] = dec(a[2], 0xC5)
            av[4] = dec(a[3], 0x39)
            av[3] = dec(a[4], 0xC5)
            av[2] = dec(a[5], 0x39)
            av[1] = dec(a[6], 0xC5)
            av[0] = dec(a[7], 0x39)

            val bv = IntArray(8)
            bv[0] = dec(b[0], 0x6A)
            bv[1] = dec(b[1], 0x94)
            bv[2] = dec(b[2], 0x6A)
            bv[3] = dec(b[3], 0x94)
            bv[4] = dec(b[4], 0x6A)
            bv[5] = dec(b[5], 0x94)
            bv[6] = dec(b[6], 0x6A)
            bv[7] = dec(b[7], 0x94)

            if (!av.contentEquals(bv)) {
                return Protected64(false, null, hexBytes(av), hexBytes(bv))
            }

            var value = 0L
            for (i in 0..7) {
                value = value or ((av[i].toLong() and 0xFFL) shl (i * 8))
            }
            return Protected64(true, value, hexBytes(av), hexBytes(bv))
        }

        private fun invalid64() = Protected64(false, null, "INVALID", "INVALID")

        private fun hexBytes(bytes: IntArray): String = buildString {
            for (i in 7 downTo 0) append(String.format(Locale.US, "%02X", bytes[i] and 0xFF))
        }

        private fun readCppString(pid: Int, address: Long, maxLen: Int): String? {
            val b0 = memory.readByteUnsigned(pid, address) ?: return null
            val length: Long
            val ptr: Long
            if ((b0 and 1) == 0) {
                length = (b0 / 2).toLong()
                ptr = address + 1L
            } else {
                length = memory.readLong(pid, address + 0x08L) ?: return null
                ptr = memory.readLong(pid, address + 0x10L) ?: return null
            }
            if (length < 0L || length > maxLen.toLong()) return null
            if (length == 0L) return ""
            if (!isAddress(ptr)) return null
            val bytes = memory.readBytes(pid, ptr, length.toInt()) ?: return null
            return bytes.toString(Charsets.UTF_8)
        }

        private fun findElfBase(pid: Int): Long? {
            val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
            if (ranges.isEmpty()) return null

            val candidates = LinkedHashSet<Long>()
            ranges.forEach { range ->
                candidates += range.start
                if (range.offset > 0L && range.start > range.offset) {
                    candidates += range.start - range.offset
                }
            }
            return candidates.firstOrNull { validateArm64Elf(pid, it) }
        }

        private fun validateArm64Elf(pid: Int, address: Long): Boolean {
            val header = memory.readBytes(pid, address, 0x40) ?: return false
            if (header.size < 0x40) return false
            val machine = ByteBuffer.wrap(header, 0x12, 2)
                .order(ByteOrder.LITTLE_ENDIAN)
                .short.toInt() and 0xFFFF
            return (header[0].toInt() and 0xFF) == 0x7F &&
                (header[1].toInt() and 0xFF) == 0x45 &&
                (header[2].toInt() and 0xFF) == 0x4C &&
                (header[3].toInt() and 0xFF) == 0x46 &&
                (header[4].toInt() and 0xFF) == 2 &&
                machine == 0xB7
        }

        private fun header(s: Snapshot): String = buildString {
            appendLine("=== M WOIF LAB • POWDER PUMP ONE AUTO ROUND ===")
            appendLine("MODE=INTERNAL_GAME_OWNED_REQUEST")
            appendLine("pid=${s.pid}")
            appendLine("elfBase=${hex(s.elfBase)}")
            appendLine("outer=${hex(s.outer)}")
            appendLine("A=${hex(s.a)}")
            appendLine("profile=${hex(s.profile)}")
            appendLine("store=${hex(s.store)}")
        }.trimEnd()

        private fun failure(code: String, bridge: String): String = buildString {
            appendLine("=== M WOIF LAB • POWDER PUMP ONE AUTO ROUND ===")
            appendLine("RESULT=$code")
            append("bridge=$bridge")
        }

        private fun itemLine(item: Item): String =
            "key=${item.key} node=${hex(item.node)} item=${hex(item.item)} " +
                "vptrGH=${hex(item.vptrGh)} stuffSeq=${item.stuffSeq} qty=${item.qty} " +
                "groupSeq=${item.groupSeq} tag=${item.tag} type=${item.type}"

        private fun fmt(value: Protected64): String =
            if (value.valid) value.value?.toString() ?: "INVALID" else "INVALID"

        private fun delta(before: Protected64, after: Protected64): Long? {
            if (!before.valid || !after.valid) return null
            val a = before.value ?: return null
            val b = after.value ?: return null
            return b - a
        }

        private fun yes(value: Boolean): String = if (value) "YES" else "NO"

        private fun isPointer(value: Long): Boolean =
            value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

        private fun isAddress(value: Long): Boolean =
            value >= 0x10000L && value < 0x0001000000000000L

        private fun hex(value: Long): String =
            if (value == 0L) "0x0" else "0x${value.toString(16).uppercase(Locale.US)}"

        private fun log(text: String) {
            DevConsole.log("PUMP-LAB", text)
        }
    }
}
