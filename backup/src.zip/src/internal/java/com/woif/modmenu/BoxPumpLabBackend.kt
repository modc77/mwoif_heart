package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Internal-only EP1 one-box manual-loop Lab.
 *
 * User flow:
 * - Turn Box Pump ON in Lab.
 * - Lab owns Giant only (through FloatingMenuService).
 * - User enters/starts EP1 manually.
 * - When the Cookie is really moving, warp to forward 38390.
 * - Wait 5 seconds so the game naturally picks the Mystery Box.
 * - Force current gameplay HP to 0 through the SAME HpMod instance used by the existing HP/Immortal feature.
 * - User handles Result/reward manually and starts the next run manually.
 * - Backend stays armed and repeats until the user presses Stop.
 *
 * No Result/OpenAll/Confirm callback is used.
 * Tower state is never read or modified.
 */
class BoxPumpLabBackend {
    companion object {
        private const val IMAGE_BASE = 0x00100000L
        private const val STAGE_SERVICE_GLOBAL_GH = 0x02259220L
        private const val STAGE_SERVICE_CHARACTER_OFFSET = 0x08L
        private const val STAGE_SERVICE_JELLY_MANAGER_OFFSET = 0x20L
        private const val JELLY_MANAGER_CHARACTER_OFFSET = 0x788L
        private const val CHARACTER_TRANSFORM_PTR_OFFSET = 0x78L
        private const val TRANSFORM_FORWARD_POSITION_OFFSET = 0x30L

        private const val SAFE_PREBOX_FORWARD = 38390.0f
        private const val PICKUP_DWELL_MS = 5_000L
        private const val GIANT_SETTLE_MS = 700L

        private const val RUN_START_MIN_STEP = 1.0f
        private const val RUN_START_MIN_TOTAL_MOVE = 12.0f
        private const val RUN_START_REQUIRED_MOVING_SAMPLES = 4
        private const val RUN_START_POLL_MS = 50L

        private const val STAGE_END_WAIT_MS = 20_000L
        private const val STAGE_END_POLL_MS = 100L
        private const val HP_PROFILE_WAIT_MS = 12_000L

        private val memory = RootProcessMemory()

        private data class LiveState(
            val running: Boolean = false,
            val phase: String = "READY",
            val round: Int = 0,
            val targetRounds: Int = 0,
            val message: String = "ปั้มปิดอยู่ • เปิดแล้วกดเข้า EP1 เอง",
            val forward: Float = Float.NaN,
            val lastAction: String = "NONE",
            val error: String = "NONE"
        )

        private data class StageRoute(
            val pid: Int,
            val libgameBase: Long,
            val stageService: Long,
            val character: Long,
            val transform: Long,
            val forwardAddress: Long,
            val forward: Float,
            val route: String
        )

        @Volatile
        private var state = LiveState()

        @Volatile
        private var worker: Thread? = null

        @Volatile
        private var stopRequested = false

        @Volatile
        private var lastReport = "ยังไม่มี Box Pump report"

        private val reportLock = Any()
        private val reportLines = ArrayList<String>()

        private fun log(line: String) {
            synchronized(reportLock) {
                reportLines += "+${SystemClock.elapsedRealtime()} $line"
                if (reportLines.size > 700) {
                    repeat(reportLines.size - 700) { reportLines.removeAt(0) }
                }
                lastReport = reportLines.joinToString("\n")
            }
            DevConsole.log("BOX", line)
        }

        private fun publish(
            phase: String,
            round: Int = state.round,
            message: String,
            forward: Float = state.forward,
            lastAction: String = state.lastAction,
            error: String = "NONE",
            running: Boolean = true
        ) {
            state = LiveState(
                running = running,
                phase = phase,
                round = round,
                targetRounds = 0,
                message = message,
                forward = forward,
                lastAction = lastAction,
                error = error
            )
            log("phase=$phase round=$round message=$message")
        }

        @JvmStatic
        fun startManualLoop(context: Context): String {
            if (worker?.isAlive == true || state.running) {
                return "BOX_PUMP_LAB\nRESULT=ALREADY_RUNNING\n${getLiveUiState()}"
            }

            stopRequested = false
            synchronized(reportLock) {
                reportLines.clear()
            }

            publish(
                phase = "ARMED",
                round = 0,
                message = "ปั้มพร้อม • กดเข้า EP1 เอง",
                running = true
            )

            val appContext = context.applicationContext
            val t = Thread({ runManualLoop(appContext) }, "MWOIF-BOX-PUMP-MANUAL-LOOP")
            worker = t
            t.start()

            return buildString {
                appendLine("BOX_PUMP_LAB")
                appendLine("RESULT=STARTED")
                appendLine("mode=MANUAL_ONE_BOX_LOOP")
                appendLine("safePreBoxForward=$SAFE_PREBOX_FORWARD")
                append("pickupDwellMs=$PICKUP_DWELL_MS")
            }
        }

        /** Compatibility alias for older internal UI builds. */
        @JvmStatic
        fun startTwoRoundTest(context: Context): String = startManualLoop(context)

        @JvmStatic
        fun requestStop(): String {
            stopRequested = true
            worker?.interrupt()
            publish(
                phase = "STOP_REQUESTED",
                message = "กำลังหยุด Box Pump Lab",
                running = true
            )
            return "BOX_PUMP_LAB\nRESULT=STOP_REQUESTED"
        }

        @JvmStatic
        fun isRunning(): Boolean = state.running

        @JvmStatic
        fun getLiveUiState(): String {
            val s = state
            return buildString {
                appendLine("running=${s.running}")
                appendLine("phase=${s.phase}")
                appendLine("round=${s.round}")
                appendLine("targetRounds=0")
                appendLine("message=${s.message}")
                appendLine(
                    "forward=${if (s.forward.isFinite()) String.format(Locale.US, "%.3f", s.forward) else "nan"}"
                )
                appendLine("lastAction=${s.lastAction}")
                append("error=${s.error}")
            }
        }

        @JvmStatic
        fun getDevDiagnostics(): String = buildString {
            appendLine("=== M WOIF LAB • EP1 BOX PUMP V2 ===")
            appendLine("MODE=MANUAL_ONE_BOX_LOOP")
            appendLine("TOWER_TOUCH=false")
            appendLine("GIANT=OWNED_BY_FLOATING_MENU_SERVICE")
            appendLine("SIZE=false")
            appendLine("FAST_RUN=false")
            appendLine("RESULT_CALLBACK=false")
            appendLine("OPEN_ALL_CALLBACK=false")
            appendLine("CONFIRM_CALLBACK=false")
            appendLine("SAFE_PREBOX_FORWARD=$SAFE_PREBOX_FORWARD")
            appendLine("PICKUP_DWELL_MS=$PICKUP_DWELL_MS")
            appendLine("FORCE_DEATH=EXISTING_HP_MOD current HP(k1) -> 0")
            appendLine()
            appendLine("[LIVE]")
            appendLine(getLiveUiState())
            appendLine()
            appendLine("[LOG]")
            append(lastReport)
        }

        private fun runManualLoop(context: Context) {
            try {
                if (!memory.requestRoot(context) || !memory.hasRoot()) {
                    fail("ROOT_NOT_READY", "RootProcessMemory ไม่พร้อม")
                    return
                }

                if (!ensureHpProfileReady()) {
                    fail("HP_PROFILE_NOT_READY", "Secure HP Profile ยังไม่พร้อมสำหรับบังคับตาย")
                    return
                }

                var round = 0

                while (!shouldStop()) {
                    publish(
                        phase = "WAIT_MANUAL_RUN",
                        round = round,
                        message = if (round == 0) {
                            "ปั้มเปิดแล้ว • กดเข้า EP1 และกดเล่นเอง"
                        } else {
                            "รับรางวัลเองแล้วกดเล่นรอบใหม่ได้เลย"
                        },
                        lastAction = "WAIT_MANUAL_RUN"
                    )

                    val stage = waitForRunStart(context)
                    if (stage == null) {
                        if (shouldStop()) {
                            stopNow("waiting manual RUN_START")
                            return
                        }
                        continue
                    }

                    round += 1
                    publish(
                        phase = "GIANT_SETTLE",
                        round = round,
                        message = "เริ่มวิ่งแล้ว • รอ Giant ติด",
                        forward = stage.forward,
                        lastAction = "RUN_START"
                    )

                    sleepChecked(GIANT_SETTLE_MS)
                    if (shouldStop()) return stopNow("giant settle")

                    val freshStage = resolveStageRoute(context)
                    if (freshStage == null) {
                        fail("STAGE_LOST_BEFORE_WARP", "Stage หายก่อนวาร์ป")
                        return
                    }

                    publish(
                        phase = "WARP_PREBOX",
                        round = round,
                        message = "วาร์ปไปกล่อง $SAFE_PREBOX_FORWARD",
                        forward = freshStage.forward,
                        lastAction = "WARP_PREBOX"
                    )

                    val wrote = memory.writeFloat(
                        freshStage.pid,
                        freshStage.forwardAddress,
                        SAFE_PREBOX_FORWARD
                    )
                    val verify = memory.readFloat(freshStage.pid, freshStage.forwardAddress)
                    log(
                        "WARP_WRITE round=$round address=${hex(freshStage.forwardAddress)} " +
                            "write=$SAFE_PREBOX_FORWARD verify=$verify route=${freshStage.route}"
                    )

                    if (
                        !wrote ||
                        verify == null ||
                        kotlin.math.abs(verify - SAFE_PREBOX_FORWARD) >= 5.0f
                    ) {
                        fail("WARP_VERIFY_FAILED", "เขียน forward ไม่ผ่าน • verify=$verify")
                        return
                    }

                    publish(
                        phase = "PICKUP_DWELL",
                        round = round,
                        message = "วาร์ปแล้ว • รอเก็บกล่อง 5 วินาที",
                        forward = verify,
                        lastAction = "WAIT_PICKUP_5S"
                    )

                    sleepChecked(PICKUP_DWELL_MS)
                    if (shouldStop()) return stopNow("pickup dwell")

                    publish(
                        phase = "FORCE_DEATH",
                        round = round,
                        message = "ครบ 5 วินาที • บังคับ HP=0",
                        lastAction = "HP_ZERO"
                    )

                    val death = FloatingMenuService.boxPumpWriteCurrentHpForLab(0)
                    log(
                        "FORCE_DEATH round=$round source=EXISTING_HP_MOD value=0 " +
                            "ok=${death.ok} code=${death.errorCode} message=${death.message}"
                    )

                    if (!death.ok) {
                        fail(
                            death.errorCode ?: "FORCE_DEATH_FAILED",
                            death.message
                        )
                        return
                    }

                    publish(
                        phase = "WAIT_DEATH",
                        round = round,
                        message = "HP=0 แล้ว • รอเกมเข้าตาย/Result",
                        lastAction = "HP_ZERO"
                    )

                    if (!waitForStageEnd(context, freshStage.character, STAGE_END_WAIT_MS)) {
                        if (shouldStop()) {
                            stopNow("waiting death")
                            return
                        }
                        fail("DEATH_NOT_OBSERVED", "เขียน HP=0 ผ่านแต่ Stage ยังไม่จบ")
                        return
                    }

                    publish(
                        phase = "WAIT_MANUAL_REWARD",
                        round = round,
                        message = "ตายแล้ว • รับรางวัลเอง แล้วกดเล่นรอบใหม่",
                        lastAction = "MANUAL_REWARD"
                    )

                    // The next loop waits indefinitely for a new moving Stage.
                    // Result/reward UI is intentionally left entirely to the user.
                }
            } catch (_: InterruptedException) {
                stopNow("thread interrupted")
            } catch (t: Throwable) {
                fail("UNCAUGHT", "${t.javaClass.simpleName}: ${t.message ?: "unknown"}")
            } finally {
                worker = null
            }
        }

        private fun ensureHpProfileReady(): Boolean {
            if (SecureProfileManager.getHp() != null) return true

            val latch = CountDownLatch(1)
            SecureProfileManager.preloadHp(forceRefresh = false) {
                latch.countDown()
            }

            runCatching {
                latch.await(HP_PROFILE_WAIT_MS, TimeUnit.MILLISECONDS)
            }

            return SecureProfileManager.getHp() != null
        }

        private fun waitForRunStart(context: Context): StageRoute? {
            var first: Float? = null
            var previous: Float? = null
            var moving = 0

            while (!shouldStop()) {
                val route = resolveStageRoute(context)

                if (route != null) {
                    if (first == null) {
                        first = route.forward
                        previous = route.forward
                    } else {
                        val prev = previous ?: route.forward
                        val step = kotlin.math.abs(route.forward - prev)
                        val total = kotlin.math.abs(route.forward - (first ?: route.forward))

                        if (step >= RUN_START_MIN_STEP) moving++ else moving = 0
                        previous = route.forward

                        if (
                            moving >= RUN_START_REQUIRED_MOVING_SAMPLES &&
                            total >= RUN_START_MIN_TOTAL_MOVE
                        ) {
                            log(
                                "RUN_START_FOUND route=${route.route} character=${hex(route.character)} " +
                                    "transform=${hex(route.transform)} forward=${route.forward}"
                            )
                            return route
                        }
                    }
                } else {
                    first = null
                    previous = null
                    moving = 0
                }

                sleepChecked(RUN_START_POLL_MS)
            }

            return null
        }

        private fun waitForStageEnd(
            context: Context,
            oldCharacter: Long,
            timeoutMs: Long
        ): Boolean {
            val started = SystemClock.elapsedRealtime()

            while (SystemClock.elapsedRealtime() - started < timeoutMs) {
                if (shouldStop()) return false

                val route = resolveStageRoute(context)
                if (route == null || route.character != oldCharacter) {
                    log(
                        "STAGE_END_FOUND oldCharacter=${hex(oldCharacter)} " +
                            "newCharacter=${hex(route?.character ?: 0L)}"
                    )
                    return true
                }

                sleepChecked(STAGE_END_POLL_MS)
            }

            return false
        }

        private fun resolveStageRoute(context: Context): StageRoute? {
            if (!memory.hasRoot() && !memory.requestRoot(context)) return null
            val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
            val maps = memory.maps(pid)
            if (maps.isEmpty()) return null

            val libRanges = maps.filter { it.path.contains("libgame.so") }
            if (libRanges.isEmpty()) return null

            val bases = linkedSetOf<Long>()
            libRanges.forEach { range ->
                bases += range.start
                if (range.offset > 0L && range.start > range.offset) {
                    bases += range.start - range.offset
                }
            }

            for (base in bases) {
                val global = base + (STAGE_SERVICE_GLOBAL_GH - IMAGE_BASE)
                if (!isMapped(maps, global, 8)) continue

                val stageService = memory.readLong(pid, global) ?: 0L
                if (!isPointer(stageService) || !isMapped(maps, stageService, 0x28)) continue

                val direct = memory.readLong(pid, stageService + STAGE_SERVICE_CHARACTER_OFFSET) ?: 0L
                val jelly = memory.readLong(pid, stageService + STAGE_SERVICE_JELLY_MANAGER_OFFSET) ?: 0L
                val fallback = if (
                    isPointer(jelly) &&
                    isMapped(maps, jelly + JELLY_MANAGER_CHARACTER_OFFSET, 8)
                ) {
                    memory.readLong(pid, jelly + JELLY_MANAGER_CHARACTER_OFFSET) ?: 0L
                } else {
                    0L
                }

                val character: Long
                val route: String

                if (
                    isPointer(direct) &&
                    isMapped(maps, direct + CHARACTER_TRANSFORM_PTR_OFFSET, 8)
                ) {
                    character = direct
                    route = "DIRECT"
                } else if (
                    isPointer(fallback) &&
                    isMapped(maps, fallback + CHARACTER_TRANSFORM_PTR_OFFSET, 8)
                ) {
                    character = fallback
                    route = "JELLY_FALLBACK"
                } else {
                    continue
                }

                val transform = memory.readLong(pid, character + CHARACTER_TRANSFORM_PTR_OFFSET) ?: 0L
                if (
                    !isPointer(transform) ||
                    !isMapped(maps, transform + TRANSFORM_FORWARD_POSITION_OFFSET, 4)
                ) {
                    continue
                }

                val forwardAddress = transform + TRANSFORM_FORWARD_POSITION_OFFSET
                val forward = memory.readFloat(pid, forwardAddress) ?: continue

                return StageRoute(
                    pid = pid,
                    libgameBase = base,
                    stageService = stageService,
                    character = character,
                    transform = transform,
                    forwardAddress = forwardAddress,
                    forward = forward,
                    route = route
                )
            }

            return null
        }

        private fun isMapped(
            maps: List<RootProcessMemory.MapEntry>,
            address: Long,
            size: Int
        ): Boolean = maps.any {
            address >= it.start &&
                address + size <= it.end &&
                it.perms.startsWith("r")
        }

        private fun isPointer(value: Long): Boolean =
            value >= 0x10000L && value < 0x0001000000000000L

        private fun sleepChecked(ms: Long) {
            var left = ms
            while (left > 0L) {
                if (shouldStop()) throw InterruptedException("stop requested")
                val step = minOf(100L, left)
                Thread.sleep(step)
                left -= step
            }
        }

        private fun shouldStop(): Boolean =
            stopRequested || Thread.currentThread().isInterrupted

        private fun stopNow(reason: String) {
            publish(
                phase = "STOPPED",
                message = "หยุด Box Pump Lab • $reason",
                error = "NONE",
                running = false
            )
            log("RESULT=STOPPED reason=$reason")
        }

        private fun fail(code: String, message: String) {
            publish(
                phase = "ERROR",
                message = message,
                error = code,
                running = false
            )
            log("RESULT=ERROR code=$code message=$message")
        }

        private fun hex(value: Long): String =
            if (value == 0L) "0x0" else "0x${value.toString(16).uppercase(Locale.US)}"
    }
}
