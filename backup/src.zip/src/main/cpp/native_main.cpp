#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <atomic>
#include <string>
#include <vector>
#include <mutex>
#include <utility>
#include <algorithm>
#include <cerrno>
#include <fcntl.h>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/mman.h>

#define LOG_TAG "WOIF-CRG-IP"

namespace {

bool address_in_libgame(uintptr_t address) {
    if (address < 0x10000u) return false;

    FILE* fp = std::fopen("/proc/self/maps", "r");
    if (!fp) return false;

    char line[1024];
    bool found = false;
    while (std::fgets(line, sizeof(line), fp)) {
        unsigned long long start = 0;
        unsigned long long end = 0;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start,
                &end,
                perms,
                path
        );
        if (parsed >= 3 && address >= start && address < end) {
            if (parsed == 4 && std::strstr(path, "libgame.so") != nullptr) {
                found = true;
            }
            break;
        }
    }

    std::fclose(fp);
    return found;
}

bool address_is_mapped(uintptr_t address) {
    if (address < 0x10000u) return false;

    FILE* fp = std::fopen("/proc/self/maps", "r");
    if (!fp) return false;

    char line[1024];
    bool found = false;
    while (std::fgets(line, sizeof(line), fp)) {
        unsigned long long start = 0;
        unsigned long long end = 0;
        char perms[8] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s",
                &start,
                &end,
                perms
        );
        if (parsed == 3 && address >= start && address < end) {
            found = perms[0] == 'r';
            break;
        }
    }

    std::fclose(fp);
    return found;
}

bool valid_effect_id(jint effect_id) {
    return effect_id == 5 || effect_id == 7;
}

#if defined(MWOIF_INTERNAL_BUILD) && defined(__aarch64__)

constexpr uintptr_t kImageBase = 0x00100000u;
constexpr uintptr_t kEventBusGlobalGh = 0x021C4D10u;
constexpr uintptr_t kResolverGlobalGh = 0x021C5110u;
constexpr uintptr_t kStageServiceGlobalGh = 0x021C49E0u;
constexpr uintptr_t kEventLookupGh = 0x00EC3168u;
constexpr uintptr_t kEventCleanupGh = 0x00EC350Cu;
constexpr uintptr_t kEventDispatchGh = 0x00EC2620u;
constexpr uintptr_t kDynamicCastGh = 0x01FBB458u;

// PRE_RUN screen object signature recovered from the screen object's
// destructor/vtable layout around 013054B0. V5 never patches executable code;
// it locates the live object in writable process memory after Play #1.
constexpr uintptr_t kPreRunVtablePrimaryGh = 0x0208F0B8u;
constexpr uintptr_t kPreRunVtable158Gh = 0x0208F4A8u;
constexpr uintptr_t kPreRunVtable168Gh = 0x0208F4D8u;
constexpr uintptr_t kPreRunVtable170Gh = 0x0208F508u;
constexpr uintptr_t kPreRunVtable178Gh = 0x0208F538u;
constexpr uintptr_t kPreRunVtable180Gh = 0x0208F550u;
// These are runtime slots containing the RTTI/type_info pointers used by the
// game's own __dynamic_cast calls in 01307800 (event 0x6B) and 01307A00
// (event 0x69).  Do not treat the slot addresses themselves as type_info.
constexpr uintptr_t kTypeSourceSlotGh = 0x02183370u;
constexpr uintptr_t kTypeEvent6BSlotGh = 0x021841D0u;
constexpr uintptr_t kTypeEvent69SlotGh = 0x021841D8u;

uintptr_t find_libgame_elf_base() {
    FILE* fp = std::fopen("/proc/self/maps", "r");
    if (!fp) return 0;

    char line[1024];
    uintptr_t base = 0;
    while (std::fgets(line, sizeof(line), fp)) {
        unsigned long long start = 0;
        unsigned long long end = 0;
        unsigned long long offset = 0;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %llx %*s %*s %767[^\n]",
                &start,
                &end,
                perms,
                &offset,
                path
        );
        if (parsed >= 4 && offset == 0 && perms[0] == 'r' &&
            parsed == 5 && std::strstr(path, "libgame.so") != nullptr) {
            const auto candidate = static_cast<uintptr_t>(start);
            if (address_is_mapped(candidate)) {
                const auto* magic = reinterpret_cast<const std::uint8_t*>(candidate);
                if (magic[0] == 0x7f && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') {
                    base = candidate;
                    break;
                }
            }
        }
    }

    std::fclose(fp);
    return base;
}

uintptr_t gh_to_runtime(uintptr_t elf_base, uintptr_t gh) {
    if (elf_base == 0 || gh < kImageBase) return 0;
    return elf_base + (gh - kImageBase);
}

bool mapped_pointer_value(uintptr_t value) {
    return value >= 0x10000u && address_is_mapped(value);
}

// -------------------------------------------------------------------------
// INTERNAL / LAB • EP1 Box Pump action binding profiles
// -------------------------------------------------------------------------
constexpr uintptr_t kBoxBindingSignature = 0x01000000u;
constexpr uintptr_t kBoxFinalStartGh = 0x01428F8Cu;
constexpr uintptr_t kBoxFinalStartTargetVtableGh = 0x02127860u;
constexpr uintptr_t kBoxResultOkGh = 0x010BF268u;
constexpr uintptr_t kBoxResultOkTargetVtableGh = 0x020D7098u;
constexpr uintptr_t kBoxOpenAllGh = 0x010C8138u;
constexpr uintptr_t kBoxConfirmGh = 0x010C8078u;
constexpr uintptr_t kBoxMysteryTargetVtableGh = 0x020D7FA8u;

struct BoxActionProfile {
    int id;
    const char* name;
    uintptr_t callback_gh;
    uintptr_t target_vtable_gh;
};

struct BoxActionCache {
    int action_id = 0;
    uintptr_t binding = 0;
    uintptr_t callback = 0;
    uintptr_t target = 0;
    uintptr_t target_vtable = 0;
    uint64_t valid_matches = 0;
};

std::mutex g_box_action_mutex;
BoxActionCache g_box_action_cache;
std::string g_box_action_report = "BOX_ACTION_LOCATOR\nRESULT=NOT_RUN\n";

const BoxActionProfile* box_action_profile(int action_id) {
    static const BoxActionProfile profiles[] = {
            {1, "FINAL_START", kBoxFinalStartGh, kBoxFinalStartTargetVtableGh},
            {2, "RESULT_OK", kBoxResultOkGh, kBoxResultOkTargetVtableGh},
            {3, "OPEN_ALL", kBoxOpenAllGh, kBoxMysteryTargetVtableGh},
            {4, "CONFIRM", kBoxConfirmGh, kBoxMysteryTargetVtableGh},
    };
    for (const auto& profile : profiles) {
        if (profile.id == action_id) return &profile;
    }
    return nullptr;
}

void reset_box_action_cache_locked() {
    g_box_action_cache = BoxActionCache{};
}

std::atomic<uintptr_t> g_play2_screen_base{0};
std::atomic<uintptr_t> g_play2_context{0};
std::atomic<uint64_t> g_play2_locator_matches{0};
std::atomic<uint64_t> g_play2_locator_primary_hits{0};
std::atomic<uint64_t> g_play2_locator_scanned_bytes{0};
std::atomic<uint64_t> g_play2_locator_scanned_ranges{0};
std::atomic<uintptr_t> g_play2_locator_best_base{0};
std::atomic<uint32_t> g_play2_locator_best_score{0};
std::atomic<int> g_play2_locator_mode{0};  // 0=none, 1=exact6, 2=unique-primary

using EventLookupFn = void* (*)(void*, int);
using DynamicCastFn = void* (*)(void*, void*, void*, intptr_t);

bool resolve_type_info(
        uintptr_t elf_base,
        uintptr_t slot_gh,
        void** out_type_info) {
    if (out_type_info == nullptr) return false;
    *out_type_info = nullptr;

    const uintptr_t slot = gh_to_runtime(elf_base, slot_gh);
    if (!address_is_mapped(slot)) return false;

    const uintptr_t value = *reinterpret_cast<uintptr_t*>(slot);
    if (!mapped_pointer_value(value)) return false;

    *out_type_info = reinterpret_cast<void*>(value);
    return true;
}

void* cast_event_interface(
        uintptr_t elf_base,
        void* raw_listener,
        uintptr_t target_type_slot_gh) {
    if (raw_listener == nullptr ||
        !address_is_mapped(reinterpret_cast<uintptr_t>(raw_listener))) {
        return nullptr;
    }

    const uintptr_t dynamic_cast_addr = gh_to_runtime(elf_base, kDynamicCastGh);
    if (!address_in_libgame(dynamic_cast_addr)) return nullptr;

    void* source_type = nullptr;
    void* target_type = nullptr;
    if (!resolve_type_info(elf_base, kTypeSourceSlotGh, &source_type) ||
        !resolve_type_info(elf_base, target_type_slot_gh, &target_type)) {
        return nullptr;
    }

    auto dynamic_cast_fn = reinterpret_cast<DynamicCastFn>(dynamic_cast_addr);
    void* adjusted = dynamic_cast_fn(
            raw_listener,
            source_type,
            target_type,
            0
    );
    if (adjusted == nullptr ||
        !address_is_mapped(reinterpret_cast<uintptr_t>(adjusted))) {
        return nullptr;
    }
    return adjusted;
}

void reset_play2_locator_state() {
    g_play2_screen_base.store(0, std::memory_order_release);
    g_play2_context.store(0, std::memory_order_release);
    g_play2_locator_matches.store(0, std::memory_order_release);
    g_play2_locator_primary_hits.store(0, std::memory_order_release);
    g_play2_locator_scanned_bytes.store(0, std::memory_order_release);
    g_play2_locator_scanned_ranges.store(0, std::memory_order_release);
    g_play2_locator_best_base.store(0, std::memory_order_release);
    g_play2_locator_best_score.store(0, std::memory_order_release);
    g_play2_locator_mode.store(0, std::memory_order_release);
}

bool locator_mapping_allowed(const char perms[8], const char* path) {
    if (perms == nullptr || perms[0] != 'r' || perms[1] != 'w' || perms[2] == 'x') {
        return false;
    }

    // PRE_RUN is allocated as a native C++ object. Restrict the scan to
    // anonymous/native-allocator arenas so V5 does not walk Java/Dalvik heaps,
    // APK mappings, stacks, graphics buffers, or writable library data.
    if (path == nullptr || path[0] == '\0') return true;
    if (std::strstr(path, "dalvik") != nullptr ||
        std::strstr(path, "jit") != nullptr ||
        std::strstr(path, "stack") != nullptr) {
        return false;
    }
    return std::strstr(path, "[heap]") != nullptr ||
           std::strstr(path, "[anon:") != nullptr ||
           std::strstr(path, "malloc") != nullptr ||
           std::strstr(path, "scudo") != nullptr;
}


// -------------------------------------------------------------------------
// INTERNAL / LAB • initMember3 passive request-object probe
//
// Ghidra 26.8.02:
//   FUN_013B6998() -> "member/initMember3.ds"
//   FUN_01640B40() allocates the common request object and selects either
//   initMember3.ds or episodeDefaultMemberInfo.ds.
//   request vtable = PTR_FUN_020EC238
//
// This probe NEVER calls the request builder and NEVER changes game memory.
// It only scans native writable allocator arenas for live request objects,
// then prints libc++ strings / pointed ASCII strings for payload discovery.
// -------------------------------------------------------------------------
constexpr uintptr_t kInitMember3RequestVtableGh = 0x020EC238u;
constexpr uintptr_t kInitMember3BuilderGh = 0x01640B40u;
constexpr uintptr_t kInitMember3EndpointStringGh = 0x007269E4u;
constexpr const char* kInitMember3Endpoint = "member/initMember3.ds";


// V13.2 Heart SEND legacy-DS passive capture.
// Ghidra 26.8.02:
//   FUN_01464104 -> FUN_013D4D10
//   base constructor FUN_00F17588 first sets 0x02097568, then FUN_013D4D10 overwrites vptr to actual 0x020EC238
//   endpoint literal GH 0x007B24A9 = "game/sendLifeMail2.ds"
// Same common 0xE0 request layout used by the legacy DS transport:
//   +0x48 endpoint string, +0x60 ValueMap/body, +0xC0 resolved URL.
constexpr uintptr_t kHeartSendRequestVtableGh = 0x020EC238u;
constexpr uintptr_t kHeartSendSerializeSlotGh = 0x020EC260u; // actual request vtable + 0x28
constexpr uintptr_t kHeartSendSerializeGh = 0x00F17830u;
constexpr uintptr_t kHeartSendBuilderGh = 0x013D4D10u;
constexpr uintptr_t kHeartSendEndpointStringGh = 0x007B24A9u;
constexpr const char* kHeartSendEndpoint = "game/sendLifeMail2.ds";

// Legacy DS protocol v4 crypto profile, proven through FUN_00F1B108 ->
// FUN_00F3DA48 -> FUN_016AF2D4 -> FUN_016AF4F4.
// key: 32 bytes, base nonce: 12 bytes.
constexpr uintptr_t kHeartDsV4ChaCha20KeyGh = 0x007D2310u;
constexpr uintptr_t kHeartDsV4BaseNonceGh = 0x007D2330u;
constexpr std::size_t kHeartDsV4ChaCha20KeySize = 32u;
constexpr std::size_t kHeartDsV4BaseNonceSize = 12u;

// V13 established-session state path recovered from the native bootstrap
// serializer/parser pair.  Unlike V12.x, V13 does not scan short-lived
// request objects.  It reads the long-lived session object returned by the
// game's own singleton accessor after a normal login/bootstrap.
//
// Ghidra 26.8.02 facts:
//   global singleton slot GH 0x02259950
//   singleton->vtable[0](singleton) -> current session/game-state object
//   state +0x20  -> protected memberSeq (getter FUN_00E1E5A8)
//   state +0x90  -> protected currentLv  (getter FUN_00D654F8)
//   state +0x1F8 -> libc++ string used as session key by FUN_011343B8
constexpr uintptr_t kSessionSingletonSlotGh = 0x02259950u;
constexpr uintptr_t kProtectedInt64ReadGh = 0x00E1E5A8u;
constexpr uintptr_t kProtectedInt32ReadGh = 0x00D654F8u;
constexpr uintptr_t kSessionMemberSeqOffset = 0x20u;
constexpr uintptr_t kSessionCurrentLvOffset = 0x90u;
constexpr uintptr_t kSessionKeyOffset = 0x1F8u;

// V13.1 Friend/gRPC auth export uses the game's own materializer.
// Ghidra 26.8.02:
//   FUN_00EB8EFC(gameOwnedContext)
//     -> game calls authObject vtable +0x60 (gameAccessToken)
//     -> formats "Bearer %s" into context +0x20
//     -> copies authorization std::string to context +0x420
//     -> calls authObject vtable +0x58 (MID/player-id)
//     -> copies player-id std::string to context +0x458
//
// We deliberately call FUN_00EB8EFC itself from the injected GAME process.
// LAB never calls +0x58/+0x60 directly.
constexpr uintptr_t kAuthMaterializerGh = 0x00EB8EFCu;
constexpr uintptr_t kGetFgsIdGh = 0x0179B4ECu;
constexpr uintptr_t kAuthBearerBufferOffset = 0x20u;
constexpr uintptr_t kAuthAuthorizationStringOffset = 0x420u;
constexpr uintptr_t kAuthPlayerIdStringOffset = 0x458u;
constexpr std::size_t kAuthScratchSize = 0x500u;

bool initmember3_ascii_char(unsigned char c) {
    return c >= 0x20u && c <= 0x7eu;
}

std::string initmember3_safe_text(const std::string& value) {
    if (value.empty()) return value;

    // Do not leak long bearer/session/token-like values into the Lab report.
    // Endpoint names, URLs and field names remain visible for protocol mapping.
    const bool structural =
            value.find(".ds") != std::string::npos ||
            value.find("member/") != std::string::npos ||
            value.find("http://") != std::string::npos ||
            value.find("https://") != std::string::npos ||
            value.find("Content-Type") != std::string::npos ||
            value.find("marketType") != std::string::npos ||
            value.find("osType") != std::string::npos ||
            value.find("device") != std::string::npos ||
            value.find("lang") != std::string::npos ||
            value.find("timezone") != std::string::npos;

    if (!structural && value.size() > 64u) {
        return "<REDACTED_LONG_VALUE len=" + std::to_string(value.size()) + ">";
    }

    std::string out;
    out.reserve(value.size());
    for (char ch : value) {
        if (ch == '\n' || ch == '\r' || ch == '\t') {
            out.push_back(' ');
        } else {
            out.push_back(ch);
        }
    }
    return out;
}

bool initmember3_read_ascii(
        uintptr_t address,
        std::size_t max_len,
        std::string* out) {
    if (out == nullptr) return false;
    out->clear();
    if (!mapped_pointer_value(address) || max_len == 0u) return false;

    std::string value;
    value.reserve(max_len);

    for (std::size_t i = 0; i < max_len; ++i) {
        const uintptr_t slot = address + i;
        if (!address_is_mapped(slot)) return false;
        const unsigned char c = *reinterpret_cast<const unsigned char*>(slot);
        if (c == 0u) {
            if (value.size() < 3u) return false;
            *out = initmember3_safe_text(value);
            return true;
        }
        if (!initmember3_ascii_char(c)) return false;
        value.push_back(static_cast<char>(c));
    }

    if (value.size() < 3u) return false;
    *out = initmember3_safe_text(value);
    return true;
}

bool initmember3_read_libcpp_string(
        uintptr_t field,
        std::string* out) {
    if (out == nullptr) return false;
    out->clear();
    if (!address_is_mapped(field) ||
        !address_is_mapped(field + 0x17u)) {
        return false;
    }

    const auto first = *reinterpret_cast<const unsigned char*>(field);

    // libc++ short string layout observed throughout this build:
    //   byte0 = length << 1, bytes begin at +1.
    if ((first & 1u) == 0u) {
        const std::size_t len = static_cast<std::size_t>(first >> 1u);
        if (len > 22u) return false;

        std::string value;
        value.reserve(len);
        for (std::size_t i = 0; i < len; ++i) {
            const unsigned char c =
                    *reinterpret_cast<const unsigned char*>(field + 1u + i);
            if (!initmember3_ascii_char(c)) return false;
            value.push_back(static_cast<char>(c));
        }
        *out = initmember3_safe_text(value);
        return true;
    }

    // libc++ long string layout observed in the decompiler:
    //   +0x08 size
    //   +0x10 data pointer
    const std::size_t len =
            *reinterpret_cast<const std::size_t*>(field + 0x08u);
    const uintptr_t ptr =
            *reinterpret_cast<const uintptr_t*>(field + 0x10u);

    if (len > 512u || !mapped_pointer_value(ptr)) {
        return false;
    }

    std::string value;
    value.reserve(len);
    for (std::size_t i = 0; i < len; ++i) {
        const uintptr_t slot = ptr + i;
        if (!address_is_mapped(slot)) return false;
        const unsigned char c =
                *reinterpret_cast<const unsigned char*>(slot);
        if (!initmember3_ascii_char(c)) return false;
        value.push_back(static_cast<char>(c));
    }

    *out = initmember3_safe_text(value);
    return true;
}

bool session_read_libcpp_string_raw(
        uintptr_t field,
        std::string* out) {
    if (out == nullptr) return false;
    out->clear();
    if (!address_is_mapped(field) ||
        !address_is_mapped(field + 0x17u)) {
        return false;
    }

    const auto first = *reinterpret_cast<const unsigned char*>(field);
    if ((first & 1u) == 0u) {
        const std::size_t len = static_cast<std::size_t>(first >> 1u);
        if (len > 22u) return false;
        out->reserve(len);
        for (std::size_t i = 0; i < len; ++i) {
            const unsigned char c =
                    *reinterpret_cast<const unsigned char*>(field + 1u + i);
            if (!initmember3_ascii_char(c)) return false;
            out->push_back(static_cast<char>(c));
        }
        return true;
    }

    const std::size_t len =
            *reinterpret_cast<const std::size_t*>(field + 0x08u);
    const uintptr_t ptr =
            *reinterpret_cast<const uintptr_t*>(field + 0x10u);
    if (len > 512u || (len != 0u && !mapped_pointer_value(ptr))) {
        return false;
    }
    out->reserve(len);
    for (std::size_t i = 0; i < len; ++i) {
        const uintptr_t slot = ptr + i;
        if (!address_is_mapped(slot)) return false;
        const unsigned char c =
                *reinterpret_cast<const unsigned char*>(slot);
        if (!initmember3_ascii_char(c)) return false;
        out->push_back(static_cast<char>(c));
    }
    return true;
}

std::string session_json_escape(const std::string& value) {
    std::string out;
    out.reserve(value.size() + 16u);
    for (const unsigned char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20u) {
                    char buf[8] = {};
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out.push_back(static_cast<char>(c));
                }
                break;
        }
    }
    return out;
}

std::string session_state_snapshot(bool include_secret) {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0u) {
        return "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=LIBGAME_BASE_NOT_FOUND\n";
    }

    const uintptr_t singleton_slot =
            gh_to_runtime(elf_base, kSessionSingletonSlotGh);
    const uintptr_t read_i64_rt =
            gh_to_runtime(elf_base, kProtectedInt64ReadGh);
    const uintptr_t read_i32_rt =
            gh_to_runtime(elf_base, kProtectedInt32ReadGh);

    if (!address_is_mapped(singleton_slot) ||
        !address_in_libgame(read_i64_rt) ||
        !address_in_libgame(read_i32_rt)) {
        return "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=PROFILE_ADDRESS_INVALID\n";
    }

    uintptr_t singleton = 0u;
    std::memcpy(&singleton, reinterpret_cast<const void*>(singleton_slot), sizeof(singleton));
    if (!mapped_pointer_value(singleton)) {
        return "MWOIF_SESSION_STATE_V13\nRESULT=NOT_READY\nreason=SESSION_SINGLETON_NULL\n";
    }

    uintptr_t vtable = 0u;
    std::memcpy(&vtable, reinterpret_cast<const void*>(singleton), sizeof(vtable));
    if (!address_in_libgame(vtable) || !address_is_mapped(vtable)) {
        return "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=SESSION_SINGLETON_VTABLE_INVALID\n";
    }

    uintptr_t accessor_rt = 0u;
    std::memcpy(&accessor_rt, reinterpret_cast<const void*>(vtable), sizeof(accessor_rt));
    if (!address_in_libgame(accessor_rt)) {
        return "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=SESSION_ACCESSOR_INVALID\n";
    }

    using SessionAccessor = uintptr_t (*)(uintptr_t);
    const auto accessor = reinterpret_cast<SessionAccessor>(accessor_rt);
    const uintptr_t state = accessor(singleton);
    if (!mapped_pointer_value(state) ||
        !address_is_mapped(state + kSessionKeyOffset + 0x17u)) {
        return "MWOIF_SESSION_STATE_V13\nRESULT=NOT_READY\nreason=SESSION_STATE_NULL\n";
    }

    using ProtectedI64Read = long long (*)(uintptr_t, int);
    using ProtectedI32Read = int (*)(uintptr_t, int);
    const auto read_i64 = reinterpret_cast<ProtectedI64Read>(read_i64_rt);
    const auto read_i32 = reinterpret_cast<ProtectedI32Read>(read_i32_rt);

    const long long member_seq =
            read_i64(state + kSessionMemberSeqOffset, 1);
    const int current_lv =
            read_i32(state + kSessionCurrentLvOffset, 1);

    std::string session_value;
    const bool session_read_ok =
            session_read_libcpp_string_raw(
                    state + kSessionKeyOffset,
                    &session_value);
    const bool ready = member_seq > 0 && session_read_ok && !session_value.empty();

    char header[1024] = {};
    std::snprintf(
            header,
            sizeof(header),
            "MWOIF_SESSION_STATE_V13\n"
            "RESULT=%s\n"
            "source=ESTABLISHED_GAME_STATE\n"
            "singletonSlotGH=0x%08llX\n"
            "stateObject=%p\n"
            "memberSeq=%lld\n"
            "currentLv=%d\n"
            "sessionKeyPresent=%s\n"
            "sessionKeyLen=%zu\n",
            ready ? "READY" : "NOT_READY",
            static_cast<unsigned long long>(kSessionSingletonSlotGh),
            reinterpret_cast<void*>(state),
            member_seq,
            current_lv,
            (session_read_ok && !session_value.empty()) ? "true" : "false",
            session_value.size());

    std::string report(header);
    if (!ready) {
        report += "reason=ESTABLISHED_SESSION_NOT_AVAILABLE\n";
        report += "sessionKey=<REDACTED>\n";
        return report;
    }

    if (include_secret) {
        report += "sessionKey=" + session_value + "\n";
        report += "sessionJson={\"schema\":\"mwoif-session-v13\",\"member_seq\":" +
                  std::to_string(member_seq) +
                  ",\"current_lv\":" + std::to_string(current_lv) +
                  ",\"session_key\":\"" + session_json_escape(session_value) +
                  "\",\"source\":\"established_game_state\"}\n";
    } else {
        report += "sessionKey=<REDACTED>\n";
    }
    return report;
}


bool auth_read_local_c_string(
        const unsigned char* base,
        std::size_t offset,
        std::size_t max_len,
        std::string* out) {
    if (base == nullptr || out == nullptr || max_len == 0u) return false;
    out->clear();
    const unsigned char* p = base + offset;
    for (std::size_t i = 0; i < max_len; ++i) {
        const unsigned char c = p[i];
        if (c == 0u) return !out->empty();
        if (!initmember3_ascii_char(c)) return false;
        out->push_back(static_cast<char>(c));
    }
    return false;
}

bool auth_materializer_preflight(
        uintptr_t elf_base,
        std::string* reason) {
    if (reason != nullptr) reason->clear();

    const uintptr_t slot =
            gh_to_runtime(elf_base, kSessionSingletonSlotGh);
    if (!address_is_mapped(slot)) {
        if (reason) *reason = "AUTH_SLOT_INVALID";
        return false;
    }

    uintptr_t manager = 0u;
    std::memcpy(&manager, reinterpret_cast<const void*>(slot), sizeof(manager));
    if (!mapped_pointer_value(manager)) {
        if (reason) *reason = "AUTH_MANAGER_NOT_READY";
        return false;
    }

    uintptr_t manager_vtable = 0u;
    std::memcpy(
            &manager_vtable,
            reinterpret_cast<const void*>(manager),
            sizeof(manager_vtable));
    if (!address_in_libgame(manager_vtable)) {
        if (reason) *reason = "AUTH_MANAGER_VTABLE_INVALID";
        return false;
    }

    uintptr_t holder_getter_rt = 0u;
    std::memcpy(
            &holder_getter_rt,
            reinterpret_cast<const void*>(manager_vtable),
            sizeof(holder_getter_rt));
    if (!address_in_libgame(holder_getter_rt)) {
        if (reason) *reason = "AUTH_HOLDER_GETTER_INVALID";
        return false;
    }

    using HolderGetter = uintptr_t (*)(uintptr_t);
    const auto holder_getter =
            reinterpret_cast<HolderGetter>(holder_getter_rt);
    const uintptr_t holder = holder_getter(manager);
    if (!mapped_pointer_value(holder) ||
        !address_is_mapped(holder + 0x0Fu)) {
        if (reason) *reason = "AUTH_HOLDER_NOT_READY";
        return false;
    }

    uintptr_t auth_object = 0u;
    std::memcpy(
            &auth_object,
            reinterpret_cast<const void*>(holder + 0x08u),
            sizeof(auth_object));
    if (!mapped_pointer_value(auth_object)) {
        if (reason) *reason = "AUTH_OBJECT_NOT_READY";
        return false;
    }

    uintptr_t auth_vtable = 0u;
    std::memcpy(
            &auth_vtable,
            reinterpret_cast<const void*>(auth_object),
            sizeof(auth_vtable));
    if (!address_in_libgame(auth_vtable)) {
        if (reason) *reason = "AUTH_OBJECT_VTABLE_INVALID";
        return false;
    }

    uintptr_t mid_getter = 0u;
    uintptr_t token_getter = 0u;
    std::memcpy(
            &mid_getter,
            reinterpret_cast<const void*>(auth_vtable + 0x58u),
            sizeof(mid_getter));
    std::memcpy(
            &token_getter,
            reinterpret_cast<const void*>(auth_vtable + 0x60u),
            sizeof(token_getter));
    if (!address_in_libgame(mid_getter) ||
        !address_in_libgame(token_getter)) {
        if (reason) *reason = "AUTH_GETTERS_NOT_READY";
        return false;
    }

    return true;
}


std::string game_owned_fgs_id_snapshot() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0u) return {};

    const uintptr_t getter_rt = gh_to_runtime(elf_base, kGetFgsIdGh);
    if (!address_in_libgame(getter_rt)) return {};

    using GetFgsId = std::string (*)();
    const auto getter = reinterpret_cast<GetFgsId>(getter_rt);
    std::string value = getter();

    if (value.empty() || value.size() > 512u) return {};
    for (unsigned char c : value) {
        if (c < 0x20u || c > 0x7eu) return {};
    }
    return value;
}

std::string auth_context_snapshot(bool include_secret) {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0u) {
        return "MWOIF_AUTH_CONTEXT_V13_1\n"
               "RESULT=ERROR\n"
               "reason=LIBGAME_BASE_NOT_FOUND\n";
    }

    const uintptr_t materializer_rt =
            gh_to_runtime(elf_base, kAuthMaterializerGh);
    if (!address_in_libgame(materializer_rt)) {
        return "MWOIF_AUTH_CONTEXT_V13_1\n"
               "RESULT=ERROR\n"
               "reason=AUTH_MATERIALIZER_INVALID\n";
    }

    std::string preflight_reason;
    if (!auth_materializer_preflight(elf_base, &preflight_reason)) {
        return "MWOIF_AUTH_CONTEXT_V13_1\n"
               "RESULT=NOT_READY\n"
               "source=GAME_OWNED_MATERIALIZER\n"
               "reason=" + preflight_reason + "\n";
    }

    // FUN_00EB8EFC expects a context whose relevant layout is:
    //   +0x020 char authorizationBuffer[0x400]
    //   +0x420 libc++ std::string authorization
    //   +0x458 libc++ std::string playerId
    //
    // The recovered libc++ short-string layout represents an empty string as
    // all-zero bytes. Keep the scratch buffer zero-initialized and let the GAME
    // own all std::string assignment/materialization. LAB only reads the raw
    // libc++ layout afterwards; it does not call the account getters or copy
    // through a second std::string ABI.
    alignas(16) unsigned char scratch[kAuthScratchSize] = {};

    using MaterializeAuth = void (*)(void*);
    const auto materialize =
            reinterpret_cast<MaterializeAuth>(materializer_rt);

    materialize(scratch);

    std::string bearer;
    const bool bearer_ok =
            auth_read_local_c_string(
                    scratch,
                    kAuthBearerBufferOffset,
                    0x400u,
                    &bearer);

    std::string authorization;
    std::string player_id;
    const bool authorization_string_ok =
            session_read_libcpp_string_raw(
                    reinterpret_cast<uintptr_t>(
                            scratch + kAuthAuthorizationStringOffset),
                    &authorization);
    const bool player_id_ok =
            session_read_libcpp_string_raw(
                    reinterpret_cast<uintptr_t>(
                            scratch + kAuthPlayerIdStringOffset),
                    &player_id);

    // FUN_00EB8EFC's string helpers allocate through the process libc++
    // allocator. In this build the decompiled cleanup path resolves to free().
    // Release only long-string heap buffers; short-string data is inline.
    const auto cleanup_raw_libcpp_string = [](unsigned char* field) {
        if (field == nullptr) return;
        const unsigned char first = field[0];
        if ((first & 1u) != 0u) {
            uintptr_t ptr = 0u;
            std::memcpy(&ptr, field + 0x10u, sizeof(ptr));
            if (mapped_pointer_value(ptr)) {
                std::free(reinterpret_cast<void*>(ptr));
            }
        }
        std::memset(field, 0, 0x18u);
    };
    cleanup_raw_libcpp_string(
            scratch + kAuthPlayerIdStringOffset);
    cleanup_raw_libcpp_string(
            scratch + kAuthAuthorizationStringOffset);

    const bool prefix_ok =
            bearer_ok &&
            bearer.size() > 7u &&
            bearer.rfind("Bearer ", 0u) == 0u;
    const std::string token =
            prefix_ok ? bearer.substr(7u) : std::string();

    const bool authorization_match =
            authorization_string_ok &&
            !authorization.empty() &&
            authorization == bearer;
    const bool ready =
            prefix_ok &&
            authorization_string_ok &&
            player_id_ok &&
            !token.empty() &&
            !player_id.empty();

    std::string report;
    report += "MWOIF_AUTH_CONTEXT_V13_1\n";
    report += std::string("RESULT=") + (ready ? "READY" : "NOT_READY") + "\n";
    report += "source=GAME_OWNED_MATERIALIZER\n";
    report += "materializerGH=0x00EB8EFC\n";
    report += std::string("authorizationPresent=") +
              (bearer_ok ? "true" : "false") + "\n";
    report += std::string("authorizationCacheMatch=") +
              (authorization_match ? "true" : "false") + "\n";
    report += std::string("gameAccessTokenPresent=") +
              (!token.empty() ? "true" : "false") + "\n";
    report += "gameAccessTokenLen=" + std::to_string(token.size()) + "\n";
    report += "mid=" + player_id + "\n";

    if (!ready) {
        report += "reason=GAME_OWNED_AUTH_NOT_AVAILABLE\n";
        report += "gameAccessToken=<REDACTED>\n";
        return report;
    }

    if (include_secret) {
        report += "authJson={\"schema\":\"mwoif-auth-v13.1\","
                  "\"mid\":\"" + session_json_escape(player_id) + "\","
                  "\"game_access_token\":\"" +
                  session_json_escape(token) + "\","
                  "\"source\":\"game_owned_materializer\"}\n";
    } else {
        report += "gameAccessToken=<REDACTED>\n";
    }

    return report;
}


void initmember3_add_unique(
        std::vector<std::string>* values,
        const std::string& label,
        const std::string& value,
        std::size_t limit) {
    if (values == nullptr || value.empty() || values->size() >= limit) return;
    const std::string line = label + "=" + value;
    for (const auto& existing : *values) {
        if (existing == line) return;
    }
    values->push_back(line);
}

void initmember3_collect_strings(
        uintptr_t object,
        std::size_t object_size,
        const char* prefix,
        std::vector<std::string>* values,
        std::size_t limit) {
    if (values == nullptr || !mapped_pointer_value(object)) return;
    if (!address_is_mapped(object + object_size - 1u)) return;

    for (std::size_t off = 0; off + 0x18u <= object_size; off += 0x08u) {
        if (values->size() >= limit) break;

        std::string s;
        if (initmember3_read_libcpp_string(object + off, &s)) {
            char label[64] = {};
            std::snprintf(
                    label,
                    sizeof(label),
                    "%s.s+0x%02zX",
                    prefix,
                    off
            );
            initmember3_add_unique(values, label, s, limit);
        }

        uintptr_t ptr = 0;
        std::memcpy(
                &ptr,
                reinterpret_cast<const void*>(object + off),
                sizeof(ptr)
        );
        if (!mapped_pointer_value(ptr)) continue;

        if (initmember3_read_ascii(ptr, 192u, &s)) {
            char label[64] = {};
            std::snprintf(
                    label,
                    sizeof(label),
                    "%s.p+0x%02zX",
                    prefix,
                    off
            );
            initmember3_add_unique(values, label, s, limit);
        }
    }
}


bool initmember3_seen_address(
        const std::vector<uintptr_t>& values,
        uintptr_t address) {
    for (const auto v : values) {
        if (v == address) return true;
    }
    return false;
}

std::string initmember3_slot_value_summary(uintptr_t value) {
    if (value == 0) return "0";

    if (value < 0x100000u) {
        return std::to_string(static_cast<unsigned long long>(value));
    }

    std::string s;
    if (mapped_pointer_value(value) &&
        initmember3_read_ascii(value, 160u, &s)) {
        return "ascii:" + s;
    }

    if (address_in_libgame(value)) {
        const uintptr_t elf_base = find_libgame_elf_base();
        if (elf_base != 0 && value >= elf_base) {
            char buf[64] = {};
            std::snprintf(
                    buf,
                    sizeof(buf),
                    "libgame:GH+0x%llX",
                    static_cast<unsigned long long>(value - elf_base + 0x00100000u)
            );
            return buf;
        }
        return "libgame_ptr";
    }

    if (mapped_pointer_value(value)) {
        return "mapped_ptr";
    }

    char buf[64] = {};
    std::snprintf(
            buf,
            sizeof(buf),
            "0x%llX",
            static_cast<unsigned long long>(value)
    );
    return buf;
}

void initmember3_collect_body_graph(
        uintptr_t root,
        std::vector<std::string>* out,
        std::size_t line_limit) {
    if (out == nullptr || !mapped_pointer_value(root)) return;

    struct Work {
        uintptr_t object = 0;
        int depth = 0;
        std::string path;
    };

    std::vector<Work> queue;
    std::vector<uintptr_t> visited;
    queue.push_back({root, 0, "body"});
    visited.push_back(root);

    for (std::size_t qi = 0;
         qi < queue.size() && out->size() < line_limit;
         ++qi) {
        const Work item = queue[qi];

        if (!address_is_mapped(item.object) ||
            !address_is_mapped(item.object + 0x1FFu)) {
            continue;
        }

        uintptr_t vt = 0;
        std::memcpy(
                &vt,
                reinterpret_cast<const void*>(item.object),
                sizeof(vt)
        );

        {
            char line[192] = {};
            if (address_in_libgame(vt)) {
                const uintptr_t elf_base = find_libgame_elf_base();
                const unsigned long long gh =
                        elf_base != 0 && vt >= elf_base
                        ? static_cast<unsigned long long>(
                                vt - elf_base + 0x00100000u)
                        : 0ull;
                std::snprintf(
                        line,
                        sizeof(line),
                        "%s.object=%p depth=%d vtableGH=0x%llX",
                        item.path.c_str(),
                        reinterpret_cast<void*>(item.object),
                        item.depth,
                        gh
                );
            } else {
                std::snprintf(
                        line,
                        sizeof(line),
                        "%s.object=%p depth=%d vtable=NON_LIBGAME",
                        item.path.c_str(),
                        reinterpret_cast<void*>(item.object),
                        item.depth
                );
            }
            out->push_back(line);
        }

        // First collect libc++ strings embedded directly in this object.
        initmember3_collect_strings(
                item.object,
                0x200u,
                item.path.c_str(),
                out,
                line_limit
        );

        for (std::size_t off = 0;
             off + sizeof(uintptr_t) <= 0x200u &&
             out->size() < line_limit;
             off += 0x08u) {
            uintptr_t value = 0;
            std::memcpy(
                    &value,
                    reinterpret_cast<const void*>(item.object + off),
                    sizeof(value)
            );

            if (value == 0) continue;

            const std::string summary =
                    initmember3_slot_value_summary(value);

            // Keep structurally interesting slots only:
            // small integers, strings, libgame pointers, or mapped pointers
            // near likely payload members.
            const bool interesting =
                    value < 0x100000u ||
                    summary.rfind("ascii:", 0) == 0 ||
                    summary.rfind("libgame:", 0) == 0 ||
                    (summary == "mapped_ptr" &&
                     (off <= 0x80u || item.depth < 2));

            if (interesting) {
                char label[96] = {};
                std::snprintf(
                        label,
                        sizeof(label),
                        "%s.q+0x%02zX",
                        item.path.c_str(),
                        off
                );
                initmember3_add_unique(
                        out,
                        label,
                        summary,
                        line_limit
                );
            }

            if (item.depth >= 2 ||
                !mapped_pointer_value(value) ||
                initmember3_seen_address(visited, value) ||
                !address_is_mapped(value + 0x7Fu)) {
                continue;
            }

            uintptr_t child_vt = 0;
            std::memcpy(
                    &child_vt,
                    reinterpret_cast<const void*>(value),
                    sizeof(child_vt)
            );

            if (!address_in_libgame(child_vt)) continue;

            char child_path[96] = {};
            std::snprintf(
                    child_path,
                    sizeof(child_path),
                    "%s@%02zX",
                    item.path.c_str(),
                    off
            );

            visited.push_back(value);
            queue.push_back({
                    value,
                    item.depth + 1,
                    child_path
            });

            if (queue.size() >= 24u) break;
        }
    }
}



constexpr uintptr_t kInitMember3JsonStringVtableGh = 0x021FFBA8u;
constexpr uintptr_t kInitMember3JsonInt64VtableGh = 0x020949E0u;
constexpr uintptr_t kInitMember3JsonInt32VtableGh = 0x02094A38u;

std::string initmember3_read_fixed_ascii(
        uintptr_t address,
        std::size_t length) {
    if (length == 0u || length > 256u ||
        !address_is_mapped(address) ||
        !address_is_mapped(address + length - 1u)) {
        return {};
    }

    std::string value;
    value.reserve(length);
    for (std::size_t i = 0; i < length; ++i) {
        const unsigned char c =
                *reinterpret_cast<const unsigned char*>(address + i);
        if (!initmember3_ascii_char(c)) return {};
        value.push_back(static_cast<char>(c));
    }
    return value;
}

bool initmember3_key_is_secret(const std::string& key) {
    return key == "accessToken" ||
           key == "sessionKey" ||
           key == "session_key" ||
           key == "token" ||
           key == "authorization" ||
           key == "Authorization";
}

std::string initmember3_decode_json_value(
        const std::string& key,
        uintptr_t value_object,
        uintptr_t elf_base) {
    if (!mapped_pointer_value(value_object) ||
        !address_is_mapped(value_object + 0x2Fu)) {
        return "UNMAPPED";
    }

    uintptr_t vt = 0;
    std::memcpy(
            &vt,
            reinterpret_cast<const void*>(value_object),
            sizeof(vt)
    );

    uintptr_t gh = 0;
    if (elf_base != 0 && vt >= elf_base && address_in_libgame(vt)) {
        gh = vt - elf_base + kImageBase;
    }

    if (gh == kInitMember3JsonStringVtableGh) {
        std::string value;
        if (!initmember3_read_libcpp_string(value_object + 0x18u, &value)) {
            return "STRING_DECODE_FAIL";
        }

        // V12.2: keep pushToken available to the Kotlin bridge for a
        // one-time COPY PUSH TOKEN action.  The UI/report layer redacts it
        // before display/export.  accessToken/sessionKey remain redacted here.
        if (key == "pushToken") {
            std::string out;
            out.reserve(value.size());
            for (char ch : value) {
                if (ch == '\n' || ch == '\r' || ch == '\t') {
                    out.push_back(' ');
                } else {
                    out.push_back(ch);
                }
            }
            return "string:" + out;
        }

        if (initmember3_key_is_secret(key)) {
            return "<REDACTED_STRING len=" +
                   std::to_string(value.size()) + ">";
        }
        return "string:" + initmember3_safe_text(value);
    }

    if (gh == kInitMember3JsonInt64VtableGh) {
        long long value = 0;
        std::memcpy(
                &value,
                reinterpret_cast<const void*>(value_object + 0x18u),
                sizeof(value)
        );
        return "int64:" + std::to_string(value);
    }

    if (gh == kInitMember3JsonInt32VtableGh) {
        int value = 0;
        std::memcpy(
                &value,
                reinterpret_cast<const void*>(value_object + 0x18u),
                sizeof(value)
        );
        return "int32:" + std::to_string(value);
    }

    char buf[192] = {};
    unsigned long long raw18 = 0;
    if (address_is_mapped(value_object + 0x1Fu)) {
        std::memcpy(
                &raw18,
                reinterpret_cast<const void*>(value_object + 0x18u),
                sizeof(raw18)
        );
    }

    std::snprintf(
            buf,
            sizeof(buf),
            "typeVtableGH=%s raw+0x18=0x%llX",
            gh != 0 ? "KNOWN_MODULE" : "NON_MODULE",
            raw18
    );

    if (gh != 0) {
        char ghbuf[64] = {};
        std::snprintf(
                ghbuf,
                sizeof(ghbuf),
                "0x%llX",
                static_cast<unsigned long long>(gh)
        );
        return std::string("typeVtableGH=") + ghbuf +
               " raw+0x18=0x" + [&]() {
                   char rawbuf[32] = {};
                   std::snprintf(
                           rawbuf,
                           sizeof(rawbuf),
                           "%llX",
                           raw18
                   );
                   return std::string(rawbuf);
               }();
    }

    return buf;
}

void initmember3_enumerate_json_map(
        uintptr_t json_object,
        std::vector<std::string>* out,
        std::size_t line_limit) {
    if (out == nullptr || out->size() >= line_limit) return;

    // V8 / fast native intrusive-list snapshot.
    //
    // Confirmed from FUN_01E734E8 / FUN_01E739F0:
    //   JSON +0x18        = first entry BASE (not node)
    //   entry+0x118      = previous entry BASE
    //   entry+0x120      = next entry BASE
    //   entry+0x110      = embedded hash node / table back-pointer
    //   table+0x18       = tail NODE (tail entry + nodeBias)
    //   table+0x20       = nodeBias (0x110)
    //
    // V6 walked the bucket array. That proved the table metadata but the
    // final buckets could race while the short-lived bootstrap request was
    // being consumed. V8 caches readable mappings once and snapshots the insertion-order list first,
    // which avoids touching mutable bucket-head state during enumeration.

    auto read_u64 = [](uintptr_t address) -> uint64_t {
        uint64_t value = 0;
        std::memcpy(&value, reinterpret_cast<const void*>(address), sizeof(value));
        return value;
    };
    auto read_u32 = [](uintptr_t address) -> uint32_t {
        uint32_t value = 0;
        std::memcpy(&value, reinterpret_cast<const void*>(address), sizeof(value));
        return value;
    };
    auto hex_u64 = [](uint64_t value) -> std::string {
        char b[32] = {};
        std::snprintf(b, sizeof(b), "0x%016llX",
                      static_cast<unsigned long long>(value));
        return std::string(b);
    };
    auto hex_ptr = [](uintptr_t value) -> std::string {
        char b[32] = {};
        std::snprintf(b, sizeof(b), "0x%llX",
                      static_cast<unsigned long long>(value));
        return std::string(b);
    };

    struct FastRange { uintptr_t start = 0u; uintptr_t end = 0u; };
    std::vector<FastRange> fast_ranges;
    if (FILE* maps = std::fopen("/proc/self/maps", "r")) {
        char map_line[1024];
        while (std::fgets(map_line, sizeof(map_line), maps)) {
            unsigned long long rs = 0, re = 0;
            char perms[8] = {};
            if (std::sscanf(map_line, "%llx-%llx %7s", &rs, &re, perms) == 3 &&
                perms[0] == 'r' && re > rs) {
                fast_ranges.push_back({static_cast<uintptr_t>(rs), static_cast<uintptr_t>(re)});
            }
        }
        std::fclose(maps);
    }
    auto fast_mapped = [&fast_ranges](uintptr_t address, std::size_t size = 1u) -> bool {
        if (address < 0x10000u || size == 0u) return false;
        const uintptr_t last = address + size - 1u;
        if (last < address) return false;
        for (const auto& r : fast_ranges) {
            if (address >= r.start && last < r.end) return true;
        }
        return false;
    };

    // The V8 fast range cache must exist before the first fast_mapped() call.
    // Keeping this check here avoids the previous compile error where the lambda
    // was referenced before its declaration.
    if (!fast_mapped(json_object, 0x28u)) {
        out->push_back("map.status=JSON_OBJECT_UNMAPPED");
        return;
    }

    uintptr_t first_entry = 0;
    uint32_t initialized = 0;
    std::memcpy(
            &first_entry,
            reinterpret_cast<const void*>(json_object + 0x18u),
            sizeof(first_entry)
    );
    std::memcpy(
            &initialized,
            reinterpret_cast<const void*>(json_object + 0x20u),
            sizeof(initialized)
    );

    out->push_back("map.initialized=" + std::to_string(initialized));
    out->push_back("map.firstEntry=" + hex_ptr(first_entry));

    if (initialized == 0u || first_entry == 0u) {
        out->push_back("map.count=0");
        out->push_back("list.enumerated=0");
        out->push_back("map.enumerated=0");
        out->push_back("map.status=EMPTY");
        return;
    }

    if (initialized != 1u ||
        !fast_mapped(first_entry, 0x148u)) {
        out->push_back("map.status=INVALID_FIRST_ENTRY");
        return;
    }

    uintptr_t table = 0;
    std::memcpy(
            &table,
            reinterpret_cast<const void*>(first_entry + 0x110u),
            sizeof(table)
    );

    if (!fast_mapped(table, 0x40u)) {
        out->push_back("map.status=INVALID_HASH_TABLE");
        return;
    }

    // Keep the V6 raw metadata dump because it independently proved the
    // native field widths and is useful for cross-run validation.
    out->push_back("map.table=" + hex_ptr(table));
    for (uintptr_t off = 0u; off <= 0x38u; off += 0x08u) {
        if (!fast_mapped(table + off, 0x08u)) {
            char offbuf[8] = {};
            std::snprintf(offbuf, sizeof(offbuf), "%02llX",
                          static_cast<unsigned long long>(off));
            out->push_back(std::string("table.raw+0x") + offbuf + "=UNMAPPED");
            continue;
        }

        const uint64_t q = read_u64(table + off);
        const uint32_t lo = static_cast<uint32_t>(q & 0xffffffffULL);
        const uint32_t hi = static_cast<uint32_t>((q >> 32u) & 0xffffffffULL);

        char line[160] = {};
        std::snprintf(
                line,
                sizeof(line),
                "table.raw+0x%02llX qword=%s lo32=%u hi32=%u",
                static_cast<unsigned long long>(off),
                hex_u64(q).c_str(),
                static_cast<unsigned int>(lo),
                static_cast<unsigned int>(hi)
        );
        out->push_back(line);
        if (out->size() >= line_limit) return;
    }

    const uintptr_t bucket_array =
            static_cast<uintptr_t>(read_u64(table + 0x00u));
    const uint32_t bucket_count = read_u32(table + 0x08u);
    const uint32_t generation = read_u32(table + 0x0Cu);
    const uint32_t entry_count = read_u32(table + 0x10u);
    const uint32_t table_aux_14 = read_u32(table + 0x14u);
    const uintptr_t tail_node =
            static_cast<uintptr_t>(read_u64(table + 0x18u));
    const uintptr_t node_bias =
            static_cast<uintptr_t>(read_u64(table + 0x20u));
    const uint32_t meta_28 = read_u32(table + 0x28u);
    const uint32_t meta_2c = read_u32(table + 0x2Cu);
    const uint32_t meta_30 = read_u32(table + 0x30u);
    const uint32_t meta_34 = read_u32(table + 0x34u);
    const uint32_t meta_38 = read_u32(table + 0x38u);
    const uint32_t meta_3c = read_u32(table + 0x3Cu);

    uintptr_t tail_entry = 0u;
    if (tail_node >= node_bias && node_bias != 0u) {
        tail_entry = tail_node - node_bias;
    }

    out->push_back("map.bucketArray=" + hex_ptr(bucket_array));
    out->push_back("map.bucketCount=" + std::to_string(bucket_count));
    out->push_back("map.generation=" + std::to_string(generation));
    out->push_back("map.count=" + std::to_string(entry_count));
    out->push_back("map.aux14=" + std::to_string(table_aux_14));
    out->push_back("map.tailNode=" + hex_ptr(tail_node));
    out->push_back("map.tailEntry=" + hex_ptr(tail_entry));
    out->push_back("map.nodeBias=" + hex_ptr(node_bias));
    out->push_back("map.meta28=" + std::to_string(meta_28));
    out->push_back("map.meta2C=" + std::to_string(meta_2c));
    out->push_back("map.meta30=" + std::to_string(meta_30));
    out->push_back("map.meta34=" + std::to_string(meta_34));
    out->push_back("map.meta38=" + hex_u64(meta_38));
    out->push_back("map.meta3C=" + std::to_string(meta_3c));
    out->push_back("map.traversal=INTRUSIVE_LIST");

    const bool bucket_count_is_pow2 =
            bucket_count != 0u && (bucket_count & (bucket_count - 1u)) == 0u;

    if (entry_count == 0u || entry_count > 256u ||
        node_bias != 0x110u ||
        bucket_count == 0u || bucket_count > 4096u ||
        !bucket_count_is_pow2 ||
        !fast_mapped(bucket_array, 0x10u) ||
        !fast_mapped(tail_node, 0x08u) ||
        !fast_mapped(tail_entry, 0x148u)) {
        out->push_back("map.status=INVALID_TABLE_METADATA");
        return;
    }

    struct ListSnapshotEntry {
        uintptr_t entry = 0u;
        uintptr_t prev = 0u;
        uintptr_t next = 0u;
        uintptr_t value_object = 0u;
        uint32_t key_hash = 0u;
        uint32_t bucket_index = 0u;
        std::string key;
        std::string value;
    };

    const uintptr_t elf_base = find_libgame_elf_base();
    std::vector<uintptr_t> seen_entries;
    seen_entries.reserve(entry_count + 8u);
    std::vector<ListSnapshotEntry> snapshot;
    snapshot.reserve(entry_count + 4u);

    uintptr_t entry = first_entry;
    uintptr_t expected_prev = 0u;
    bool traversal_error = false;
    uint32_t prev_link_mismatch = 0u;
    uint32_t table_backref_mismatch = 0u;
    uint32_t key_decode_fail = 0u;

    // Snapshot first, format later. This minimizes time spent touching the
    // live bootstrap object before the game releases it.
    while (entry != 0u && snapshot.size() < entry_count + 8u) {
        if (!fast_mapped(entry, 0x148u) ||
            initmember3_seen_address(seen_entries, entry)) {
            traversal_error = true;
            break;
        }

        seen_entries.push_back(entry);

        const uintptr_t value_object =
                static_cast<uintptr_t>(read_u64(entry + 0x108u));
        const uintptr_t table_back =
                static_cast<uintptr_t>(read_u64(entry + 0x110u));
        const uintptr_t prev_entry =
                static_cast<uintptr_t>(read_u64(entry + 0x118u));
        const uintptr_t next_entry =
                static_cast<uintptr_t>(read_u64(entry + 0x120u));
        const uintptr_t key_ptr =
                static_cast<uintptr_t>(read_u64(entry + 0x138u));
        const uint32_t key_len = read_u32(entry + 0x140u);
        const uint32_t key_hash = read_u32(entry + 0x144u);

        if (table_back != table) {
            ++table_backref_mismatch;
            traversal_error = true;
            break;
        }

        if (prev_entry != expected_prev) {
            ++prev_link_mismatch;
        }

        std::string key;
        if (key_ptr != 0u && key_len <= 256u) {
            key = initmember3_read_fixed_ascii(key_ptr, key_len);
        }
        if (key.empty() && key_len > 0u && key_len <= 256u) {
            // Insert stores the key bytes inline at entry+0x00 as well.
            key = initmember3_read_fixed_ascii(entry, key_len);
        }
        if (key.empty()) {
            ++key_decode_fail;
            key = "<UNKNOWN_KEY_" + std::to_string(snapshot.size()) + ">";
        }

        ListSnapshotEntry item;
        item.entry = entry;
        item.prev = prev_entry;
        item.next = next_entry;
        item.value_object = value_object;
        item.key_hash = key_hash;
        item.bucket_index = key_hash & (bucket_count - 1u);
        item.key = key;
        // V8: do NOT decode the value while walking live links.  Copy the
        // structural metadata first; value decoding happens only after the
        // entire intrusive list is locally captured.
        snapshot.push_back(std::move(item));

        expected_prev = entry;
        entry = next_entry;
    }

    if (entry != 0u) {
        traversal_error = true;
    }

    // V8 phase 2: the list topology is already local. Decode values only now.
    for (auto& item : snapshot) {
        item.value = initmember3_decode_json_value(
                item.key, item.value_object, elf_base);
    }

    const uintptr_t last_entry =
            snapshot.empty() ? 0u : snapshot.back().entry;
    const bool tail_match = last_entry != 0u && last_entry == tail_entry;
    const bool first_prev_zero =
            snapshot.empty() || snapshot.front().prev == 0u;
    const bool last_next_zero =
            snapshot.empty() || snapshot.back().next == 0u;

    for (std::size_t i = 0u;
         i < snapshot.size() && out->size() < line_limit;
         ++i) {
        const auto& item = snapshot[i];
        char line[1200] = {};
        std::snprintf(
                line,
                sizeof(line),
                "entry[%zu].list=%zu bucket=%u key=%s hash=0x%08X value=%s prev=%p next=%p",
                i,
                i,
                static_cast<unsigned int>(item.bucket_index),
                item.key.c_str(),
                static_cast<unsigned int>(item.key_hash),
                item.value.c_str(),
                reinterpret_cast<void*>(item.prev),
                reinterpret_cast<void*>(item.next)
        );
        out->push_back(line);
        if (item.key.rfind("<UNKNOWN_KEY_", 0) != 0) {
            out->push_back("field." + item.key + "=" + item.value);
        }
    }

    const uint32_t enumerated = static_cast<uint32_t>(snapshot.size());
    out->push_back("list.enumerated=" + std::to_string(enumerated));
    out->push_back("map.enumerated=" + std::to_string(enumerated));
    out->push_back("list.prevLinkMismatch=" + std::to_string(prev_link_mismatch));
    out->push_back("list.tableBackrefMismatch=" + std::to_string(table_backref_mismatch));
    out->push_back("list.keyDecodeFail=" + std::to_string(key_decode_fail));
    out->push_back(std::string("list.firstPrevZero=") + (first_prev_zero ? "true" : "false"));
    out->push_back(std::string("list.lastNextZero=") + (last_next_zero ? "true" : "false"));
    out->push_back(std::string("list.tailMatch=") + (tail_match ? "true" : "false"));

    if (!traversal_error &&
        enumerated == entry_count &&
        prev_link_mismatch == 0u &&
        table_backref_mismatch == 0u &&
        key_decode_fail == 0u &&
        first_prev_zero &&
        last_next_zero &&
        tail_match) {
        out->push_back("map.status=COMPLETE");
    } else if (!traversal_error && enumerated == entry_count) {
        out->push_back("map.status=COMPLETE_WITH_LIST_WARNINGS");
    } else {
        out->push_back("map.status=PARTIAL");
    }
}

bool initmember3_strings_match(
        const std::vector<std::string>& values) {
    for (const auto& line : values) {
        if (line.find("member/initMember3.ds") != std::string::npos ||
            line.find("initMember3") != std::string::npos) {
            return true;
        }
    }
    return false;
}

ssize_t initmember3_read_some(
        int mem_fd,
        uintptr_t address,
        void* out,
        std::size_t size) {
    if (out == nullptr || size == 0u || address < 0x10000u) {
        errno = EINVAL;
        return -1;
    }

    if (mem_fd >= 0) {
        return ::pread(
                mem_fd,
                out,
                size,
                static_cast<off_t>(address)
        );
    }

    struct iovec local {};
    local.iov_base = out;
    local.iov_len = size;

    struct iovec remote {};
    remote.iov_base = reinterpret_cast<void*>(address);
    remote.iov_len = size;

    return ::process_vm_readv(
            ::getpid(),
            &local,
            1,
            &remote,
            1,
            0
    );
}

bool initmember3_read_exact(
        int mem_fd,
        uintptr_t address,
        void* out,
        std::size_t size) {
    if (out == nullptr || size == 0u || address < 0x10000u) {
        return false;
    }

    auto* dst = static_cast<unsigned char*>(out);
    std::size_t done = 0u;
    while (done < size) {
        const ssize_t n = initmember3_read_some(
                mem_fd,
                address + done,
                dst + done,
                size - done
        );
        if (n <= 0) return false;
        done += static_cast<std::size_t>(n);
    }
    return true;
}

bool initmember3_decode_snapshot_string(
        int mem_fd,
        const unsigned char* object,
        std::size_t object_size,
        std::size_t field_offset,
        std::string* out,
        bool preserve_raw = false) {
    if (out == nullptr || object == nullptr ||
        field_offset + 0x18u > object_size) {
        return false;
    }
    out->clear();

    const unsigned char first = object[field_offset];
    if ((first & 1u) == 0u) {
        const std::size_t len = static_cast<std::size_t>(first >> 1u);
        if (len > 22u || field_offset + 1u + len > object_size) return false;

        std::string value;
        value.reserve(len);
        for (std::size_t i = 0; i < len; ++i) {
            const unsigned char c = object[field_offset + 1u + i];
            if (!initmember3_ascii_char(c)) return false;
            value.push_back(static_cast<char>(c));
        }
        *out = preserve_raw ? value : initmember3_safe_text(value);
        return true;
    }

    std::size_t len = 0u;
    uintptr_t ptr = 0u;
    std::memcpy(&len, object + field_offset + 0x08u, sizeof(len));
    std::memcpy(&ptr, object + field_offset + 0x10u, sizeof(ptr));
    if (len == 0u || len > 512u || ptr < 0x10000u) return false;

    std::vector<unsigned char> bytes(len);
    if (!initmember3_read_exact(mem_fd, ptr, bytes.data(), bytes.size())) {
        return false;
    }

    std::string value;
    value.reserve(len);
    for (const unsigned char c : bytes) {
        if (!initmember3_ascii_char(c)) return false;
        value.push_back(static_cast<char>(c));
    }
    *out = preserve_raw ? value : initmember3_safe_text(value);
    return true;
}


struct InitMember3SafeEntrySnapshot {
    uintptr_t entry = 0u;
    uintptr_t prev = 0u;
    uintptr_t next = 0u;
    uintptr_t value_object = 0u;
    uintptr_t table_back = 0u;
    uint32_t key_hash = 0u;
    std::string key;
    std::string value;
};

bool initmember3_read_ascii_safe(
        int mem_fd,
        uintptr_t address,
        std::size_t length,
        std::string* out) {
    if (out == nullptr || length > 256u) return false;
    out->clear();
    if (length == 0u) return true;
    if (address < 0x10000u) return false;

    std::vector<unsigned char> bytes(length);
    if (!initmember3_read_exact(mem_fd, address, bytes.data(), bytes.size())) {
        return false;
    }
    std::string value;
    value.reserve(length);
    for (unsigned char c : bytes) {
        if (!initmember3_ascii_char(c)) return false;
        value.push_back(static_cast<char>(c));
    }
    *out = initmember3_safe_text(value);
    return true;
}

std::string initmember3_decode_json_value_safe_snapshot(
        int mem_fd,
        const std::string& key,
        uintptr_t value_object,
        uintptr_t elf_base) {
    if (value_object < 0x10000u) return "UNMAPPED";

    unsigned char object[0x30u] = {};
    if (!initmember3_read_exact(
                mem_fd,
                value_object,
                object,
                sizeof(object))) {
        return "VALUE_READ_FAIL";
    }

    uintptr_t vt = 0u;
    std::memcpy(&vt, object, sizeof(vt));
    uintptr_t gh = 0u;
    if (elf_base != 0u && vt >= elf_base && address_in_libgame(vt)) {
        gh = vt - elf_base + kImageBase;
    }

    if (gh == kInitMember3JsonStringVtableGh) {
        std::string value;
        if (!initmember3_decode_snapshot_string(
                    mem_fd,
                    object,
                    sizeof(object),
                    0x18u,
                    &value,
                    true)) {
            return "string:DECODE_FAIL";
        }
        // V12.3 FIX:
        // The V12 locator uses this safe-snapshot decoder, not only the
        // older direct decoder above. Preserve pushToken in the raw
        // in-memory report so the explicit COPY PUSH TOKEN button can
        // retrieve it. Kotlin redacts it before display/report/JSON export.
        if (key == "pushToken") {
            std::string out;
            out.reserve(value.size());
            for (char ch : value) {
                if (ch == '\n' || ch == '\r' || ch == '\t') {
                    out.push_back(' ');
                } else {
                    out.push_back(ch);
                }
            }
            return "string:" + out;
        }

        if (initmember3_key_is_secret(key)) {
            return "string:<REDACTED len=" + std::to_string(value.size()) + ">";
        }
        return "string:" + initmember3_safe_text(value);
    }

    if (gh == kInitMember3JsonInt64VtableGh) {
        long long value = 0;
        std::memcpy(&value, object + 0x18u, sizeof(value));
        return "int64:" + std::to_string(value);
    }

    if (gh == kInitMember3JsonInt32VtableGh) {
        int value = 0;
        std::memcpy(&value, object + 0x18u, sizeof(value));
        return "int32:" + std::to_string(value);
    }

    char type_line[96] = {};
    if (gh != 0u) {
        std::snprintf(
                type_line,
                sizeof(type_line),
                "typeVtableGH=0x%llX",
                static_cast<unsigned long long>(gh));
    } else {
        std::snprintf(
                type_line,
                sizeof(type_line),
                "typeVtableRuntime=%p",
                reinterpret_cast<void*>(vt));
    }
    return type_line;
}

void initmember3_enumerate_json_map_safe_snapshot(
        int mem_fd,
        uintptr_t json_object,
        uintptr_t elf_base,
        std::vector<std::string>* out,
        std::size_t line_limit) {
    if (out == nullptr || out->size() >= line_limit) return;
    out->push_back("map.mode=SAFE_ONE_SHOT_INTRUSIVE_LIST");

    unsigned char json_header[0x28u] = {};
    if (!initmember3_read_exact(
                mem_fd,
                json_object,
                json_header,
                sizeof(json_header))) {
        out->push_back("map.status=JSON_HEADER_READ_FAIL");
        return;
    }

    uintptr_t first_entry = 0u;
    uint32_t initialized = 0u;
    std::memcpy(&first_entry, json_header + 0x18u, sizeof(first_entry));
    std::memcpy(&initialized, json_header + 0x20u, sizeof(initialized));

    char first_line[128] = {};
    std::snprintf(
            first_line,
            sizeof(first_line),
            "map.initialized=%u map.firstEntry=%p",
            static_cast<unsigned int>(initialized),
            reinterpret_cast<void*>(first_entry));
    out->push_back(first_line);

    if (initialized == 0u || first_entry == 0u) {
        out->push_back("map.count=0");
        out->push_back("map.status=EMPTY");
        return;
    }
    if (initialized != 1u || first_entry < 0x10000u) {
        out->push_back("map.status=INVALID_FIRST_ENTRY");
        return;
    }

    unsigned char first_blob[0x148u] = {};
    if (!initmember3_read_exact(
                mem_fd,
                first_entry,
                first_blob,
                sizeof(first_blob))) {
        out->push_back("map.status=FIRST_ENTRY_READ_FAIL");
        return;
    }

    uintptr_t table = 0u;
    std::memcpy(&table, first_blob + 0x110u, sizeof(table));
    if (table < 0x10000u) {
        out->push_back("map.status=INVALID_HASH_TABLE");
        return;
    }

    unsigned char table_blob[0x40u] = {};
    if (!initmember3_read_exact(
                mem_fd,
                table,
                table_blob,
                sizeof(table_blob))) {
        out->push_back("map.status=HASH_TABLE_READ_FAIL");
        return;
    }

    auto load_u32 = [](const unsigned char* p) -> uint32_t {
        uint32_t v = 0u;
        std::memcpy(&v, p, sizeof(v));
        return v;
    };
    auto load_ptr = [](const unsigned char* p) -> uintptr_t {
        uintptr_t v = 0u;
        std::memcpy(&v, p, sizeof(v));
        return v;
    };

    const uintptr_t bucket_array = load_ptr(table_blob + 0x00u);
    const uint32_t bucket_count = load_u32(table_blob + 0x08u);
    const uint32_t generation = load_u32(table_blob + 0x0Cu);
    const uint32_t entry_count = load_u32(table_blob + 0x10u);
    const uintptr_t tail_node = load_ptr(table_blob + 0x18u);
    const uintptr_t node_bias = load_ptr(table_blob + 0x20u);
    const uintptr_t tail_entry =
            node_bias != 0u && tail_node >= node_bias
                    ? tail_node - node_bias
                    : 0u;

    char meta[512] = {};
    std::snprintf(
            meta,
            sizeof(meta),
            "map.table=%p\nmap.bucketArray=%p\nmap.bucketCount=%u\n"
            "map.generation=%u\nmap.count=%u\nmap.tailEntry=%p\n"
            "map.nodeBias=0x%llX\nmap.traversal=INTRUSIVE_LIST_SAFE_COPY",
            reinterpret_cast<void*>(table),
            reinterpret_cast<void*>(bucket_array),
            static_cast<unsigned int>(bucket_count),
            static_cast<unsigned int>(generation),
            static_cast<unsigned int>(entry_count),
            reinterpret_cast<void*>(tail_entry),
            static_cast<unsigned long long>(node_bias));
    std::string meta_text(meta);
    std::size_t start = 0u;
    while (start <= meta_text.size()) {
        const std::size_t nl = meta_text.find('\n', start);
        out->push_back(meta_text.substr(start, nl == std::string::npos ? std::string::npos : nl - start));
        if (nl == std::string::npos) break;
        start = nl + 1u;
    }

    const bool bucket_count_pow2 =
            bucket_count != 0u && (bucket_count & (bucket_count - 1u)) == 0u;
    if (entry_count == 0u || entry_count > 256u ||
        node_bias != 0x110u ||
        bucket_count == 0u || bucket_count > 4096u ||
        !bucket_count_pow2) {
        out->push_back("map.status=INVALID_TABLE_METADATA");
        return;
    }

    std::vector<InitMember3SafeEntrySnapshot> snapshot;
    snapshot.reserve(entry_count + 2u);
    std::vector<uintptr_t> seen;
    seen.reserve(entry_count + 2u);

    uintptr_t entry = first_entry;
    uintptr_t expected_prev = 0u;
    uint32_t prev_mismatch = 0u;
    uint32_t table_mismatch = 0u;
    uint32_t key_fail = 0u;
    bool traversal_error = false;

    while (entry != 0u && snapshot.size() < entry_count + 2u) {
        if (entry < 0x10000u || initmember3_seen_address(seen, entry)) {
            traversal_error = true;
            break;
        }
        seen.push_back(entry);

        unsigned char blob[0x148u] = {};
        if (!initmember3_read_exact(mem_fd, entry, blob, sizeof(blob))) {
            traversal_error = true;
            break;
        }

        InitMember3SafeEntrySnapshot item;
        item.entry = entry;
        std::memcpy(&item.value_object, blob + 0x108u, sizeof(item.value_object));
        std::memcpy(&item.table_back, blob + 0x110u, sizeof(item.table_back));
        std::memcpy(&item.prev, blob + 0x118u, sizeof(item.prev));
        std::memcpy(&item.next, blob + 0x120u, sizeof(item.next));
        uintptr_t key_ptr = 0u;
        uint32_t key_len = 0u;
        std::memcpy(&key_ptr, blob + 0x138u, sizeof(key_ptr));
        std::memcpy(&key_len, blob + 0x140u, sizeof(key_len));
        std::memcpy(&item.key_hash, blob + 0x144u, sizeof(item.key_hash));

        if (item.table_back != table) {
            ++table_mismatch;
            traversal_error = true;
            break;
        }
        if (item.prev != expected_prev) ++prev_mismatch;

        if (key_len <= 256u && key_ptr >= 0x10000u) {
            initmember3_read_ascii_safe(mem_fd, key_ptr, key_len, &item.key);
        }
        if (item.key.empty() && key_len <= 0x100u && key_len <= sizeof(blob)) {
            bool ok = true;
            std::string inline_key;
            inline_key.reserve(key_len);
            for (uint32_t i = 0u; i < key_len; ++i) {
                const unsigned char c = blob[i];
                if (!initmember3_ascii_char(c)) { ok = false; break; }
                inline_key.push_back(static_cast<char>(c));
            }
            if (ok) item.key = initmember3_safe_text(inline_key);
        }
        if (item.key.empty()) {
            ++key_fail;
            item.key = "<UNKNOWN_KEY_" + std::to_string(snapshot.size()) + ">";
        }

        // Read the value immediately through the safe-copy backend. Read failures
        // are reported as data, never dereferenced directly.
        item.value = initmember3_decode_json_value_safe_snapshot(
                mem_fd,
                item.key,
                item.value_object,
                elf_base);

        snapshot.push_back(std::move(item));
        expected_prev = entry;
        entry = snapshot.back().next;
    }

    if (entry != 0u) traversal_error = true;

    for (std::size_t i = 0u; i < snapshot.size() && out->size() < line_limit; ++i) {
        const auto& item = snapshot[i];
        char line[1400] = {};
        std::snprintf(
                line,
                sizeof(line),
                "entry[%zu] key=%s hash=0x%08X value=%s prev=%p next=%p",
                i,
                item.key.c_str(),
                static_cast<unsigned int>(item.key_hash),
                item.value.c_str(),
                reinterpret_cast<void*>(item.prev),
                reinterpret_cast<void*>(item.next));
        out->push_back(line);
        if (item.key.rfind("<UNKNOWN_KEY_", 0u) != 0u) {
            out->push_back("field." + item.key + "=" + item.value);
        }
    }

    const uintptr_t last_entry = snapshot.empty() ? 0u : snapshot.back().entry;
    const bool first_prev_zero = snapshot.empty() || snapshot.front().prev == 0u;
    const bool last_next_zero = snapshot.empty() || snapshot.back().next == 0u;
    const bool tail_match = last_entry != 0u && last_entry == tail_entry;

    out->push_back("payload.schema.count=" + std::to_string(snapshot.size()));
    out->push_back("list.prevLinkMismatch=" + std::to_string(prev_mismatch));
    out->push_back("list.tableBackrefMismatch=" + std::to_string(table_mismatch));
    out->push_back("list.keyDecodeFail=" + std::to_string(key_fail));
    out->push_back(std::string("list.firstPrevZero=") + (first_prev_zero ? "true" : "false"));
    out->push_back(std::string("list.lastNextZero=") + (last_next_zero ? "true" : "false"));
    out->push_back(std::string("list.tailMatch=") + (tail_match ? "true" : "false"));

    if (!traversal_error &&
        snapshot.size() == entry_count &&
        prev_mismatch == 0u &&
        table_mismatch == 0u &&
        key_fail == 0u &&
        first_prev_zero &&
        last_next_zero &&
        tail_match) {
        out->push_back("map.status=COMPLETE_SAFE_SNAPSHOT");
    } else if (!snapshot.empty()) {
        out->push_back("map.status=PARTIAL_SAFE_SNAPSHOT");
    } else {
        out->push_back("map.status=SNAPSHOT_FAILED");
    }
}


std::string initmember3_redact_wire_value(
        const std::string& input,
        const std::string& key) {
    std::string out = input;

    // form style: key=value&...
    {
        const std::string needle = key + "=";
        std::size_t pos = 0u;
        while ((pos = out.find(needle, pos)) != std::string::npos) {
            const std::size_t value_begin = pos + needle.size();
            std::size_t value_end = out.find('&', value_begin);
            if (value_end == std::string::npos) value_end = out.size();
            out.replace(
                    value_begin,
                    value_end - value_begin,
                    "<REDACTED>"
            );
            pos = value_begin + 10u;
        }
    }

    // JSON style: "key":"value"
    {
        const std::string needle = "\"" + key + "\"";
        std::size_t pos = 0u;
        while ((pos = out.find(needle, pos)) != std::string::npos) {
            std::size_t colon = out.find(':', pos + needle.size());
            if (colon == std::string::npos) break;
            std::size_t quote = out.find('"', colon + 1u);
            if (quote == std::string::npos) break;
            const std::size_t value_begin = quote + 1u;
            std::size_t value_end = out.find('"', value_begin);
            if (value_end == std::string::npos) break;
            out.replace(
                    value_begin,
                    value_end - value_begin,
                    "<REDACTED>"
            );
            pos = value_begin + 10u;
        }
    }

    return out;
}

std::string initmember3_sanitize_wire_text(const std::string& input) {
    std::string out = input;
    static const char* const keys[] = {
            "pushToken",
            "accessToken",
            "sessionKey",
            "session_key",
            "Authorization",
            "authorization",
            "refresh_token",
            "oven_access_token",
            "game_access_token"
    };
    for (const char* key : keys) {
        out = initmember3_redact_wire_value(out, key);
    }
    if (out.size() > 4096u) {
        out.resize(4096u);
        out += "<TRUNCATED>";
    }
    return out;
}

std::size_t initmember3_count_wire_keys(const std::string& value) {
    static const char* const keys[] = {
            "mid",
            "playerId",
            "agreementSeq",
            "pushToken",
            "accessToken",
            "agreement",
            "mobclixSignature",
            "macAddress",
            "pid",
            "currentLv",
            "socialUidCommon",
            "ver",
            "buildVer",
            "cc",
            "ms",
            "osType",
            "osVersion",
            "timeZone",
            "timeZoneDistance",
            "marketType",
            "carrier",
            "fgsId",
            "locale",
            "deviceId",
            "deviceName",
            "deviceModel",
            "cable"
    };

    std::size_t count = 0u;
    for (const char* key : keys) {
        if (value.find(key) != std::string::npos) {
            ++count;
        }
    }
    return count;
}

std::string initmember3_classify_wire_text(const std::string& value) {
    if (value.find("mid=") != std::string::npos &&
        value.find("playerId=") != std::string::npos &&
        value.find('&') != std::string::npos) {
        return "FORM_URLENCODED";
    }

    if (value.find("\"mid\"") != std::string::npos &&
        value.find("\"playerId\"") != std::string::npos &&
        value.find(':') != std::string::npos) {
        return "JSON_TEXT";
    }

    if (value.find("%22mid%22") != std::string::npos ||
        value.find("%22playerId%22") != std::string::npos) {
        return "URLENCODED_JSON";
    }

    return "ASCII_MULTI_FIELD";
}

struct InitMember3WireCandidate {
    uintptr_t address = 0u;
    std::string encoding;
    std::string text;
    std::size_t key_count = 0u;
};

std::vector<InitMember3WireCandidate> initmember3_find_wire_candidates(
        int mem_fd,
        std::size_t limit) {
    std::vector<InitMember3WireCandidate> out;
    if (limit == 0u) return out;

    FILE* maps = std::fopen("/proc/self/maps", "r");
    if (!maps) return out;

    constexpr std::size_t kChunkSize = 256u * 1024u;
    constexpr std::size_t kWindow = 8192u;
    constexpr const char* kAnchor = "pushToken";
    constexpr std::size_t kAnchorLen = 9u;

    std::vector<unsigned char> chunk(kChunkSize);
    char line[1024];

    while (out.size() < limit && std::fgets(line, sizeof(line), maps)) {
        unsigned long long start_raw = 0u;
        unsigned long long end_raw = 0u;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path
        );
        if (parsed < 3) continue;

        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < 64u) continue;

        for (uintptr_t pos = start; pos < end && out.size() < limit;) {
            const std::size_t want = static_cast<std::size_t>(
                    std::min<uintptr_t>(kChunkSize, end - pos)
            );
            if (want == 0u) break;

            const ssize_t got = initmember3_read_some(
                    mem_fd,
                    pos,
                    chunk.data(),
                    want
            );
            if (got <= 0) break;

            const std::size_t size = static_cast<std::size_t>(got);

            for (std::size_t i = 0u;
                 i + kAnchorLen <= size && out.size() < limit;
                 ++i) {
                if (std::memcmp(
                            chunk.data() + i,
                            kAnchor,
                            kAnchorLen) != 0) {
                    continue;
                }

                const uintptr_t hit = pos + i;
                const uintptr_t window_start =
                        hit > start + kWindow / 2u
                        ? hit - kWindow / 2u
                        : start;
                const uintptr_t window_end =
                        std::min<uintptr_t>(end, window_start + kWindow);
                if (window_end <= window_start) continue;

                std::vector<unsigned char> window(
                        static_cast<std::size_t>(window_end - window_start)
                );
                if (!initmember3_read_exact(
                            mem_fd,
                            window_start,
                            window.data(),
                            window.size())) {
                    continue;
                }

                const std::size_t hit_off =
                        static_cast<std::size_t>(hit - window_start);

                std::size_t left = hit_off;
                while (left > 0u) {
                    const unsigned char c = window[left - 1u];
                    if (c == 0u || !initmember3_ascii_char(c)) break;
                    --left;
                }

                std::size_t right = hit_off;
                while (right < window.size()) {
                    const unsigned char c = window[right];
                    if (c == 0u || !initmember3_ascii_char(c)) break;
                    ++right;
                }

                if (right <= left || right - left < 64u) continue;

                std::string candidate(
                        reinterpret_cast<const char*>(window.data() + left),
                        right - left
                );

                const std::size_t key_count =
                        initmember3_count_wire_keys(candidate);

                // This rejects isolated JSON-map key strings and static literals.
                if (key_count < 8u) continue;

                bool duplicate = false;
                for (const auto& existing : out) {
                    if (existing.text == candidate) {
                        duplicate = true;
                        break;
                    }
                }
                if (duplicate) continue;

                InitMember3WireCandidate item;
                item.address = window_start + left;
                item.encoding = initmember3_classify_wire_text(candidate);
                item.key_count = key_count;
                item.text = initmember3_sanitize_wire_text(candidate);
                out.push_back(std::move(item));
            }

            pos += size;
        }
    }

    std::fclose(maps);
    return out;
}


struct InitMember3EnvelopeCandidate {
    uintptr_t address = 0u;
    std::string version;
    std::string data_shape;
    std::string data; // kept in native memory; normal initMember3 report still redacts it
    std::size_t observed_body_len = 0u;
    std::size_t observed_data_len = 0u;
};

bool initmember3_base64ish_char(unsigned char c) {
    return (c >= 'A' && c <= 'Z') ||
           (c >= 'a' && c <= 'z') ||
           (c >= '0' && c <= '9') ||
           c == '+' || c == '/' || c == '=' || c == '-' || c == '_';
}

std::string initmember3_envelope_data_shape(const std::string& data) {
    if (data.empty()) return "EMPTY";

    bool base64ish = true;
    bool has_percent = false;
    for (unsigned char c : data) {
        if (c == '%') {
            has_percent = true;
            continue;
        }
        if (!initmember3_base64ish_char(c)) {
            base64ish = false;
        }
    }
    if (has_percent) return "URLENCODED_OR_ESCAPED_ASCII";
    if (base64ish) return "BASE64_OR_BASE64URL_ASCII";
    return "ASCII_OTHER";
}

std::vector<InitMember3EnvelopeCandidate> initmember3_find_final_envelope_candidates(
        int mem_fd,
        std::size_t limit) {
    std::vector<InitMember3EnvelopeCandidate> out;
    if (limit == 0u) return out;

    FILE* maps = std::fopen("/proc/self/maps", "r");
    if (!maps) return out;

    constexpr std::size_t kChunkSize = 256u * 1024u;
    constexpr std::size_t kCarry = 256u;
    constexpr std::size_t kMaxObservedBody = 16384u;
    constexpr const char* kAnchor = "isEncryptedData=";
    constexpr std::size_t kAnchorLen = 16u;
    constexpr const char* kDataNeedle = "&data=";

    std::vector<unsigned char> chunk(kChunkSize + kCarry);
    char line[1024];

    while (out.size() < limit && std::fgets(line, sizeof(line), maps)) {
        unsigned long long start_raw = 0u;
        unsigned long long end_raw = 0u;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path
        );
        if (parsed < 3) continue;

        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < 32u) continue;

        for (uintptr_t pos = start; pos < end && out.size() < limit;) {
            const std::size_t want = static_cast<std::size_t>(
                    std::min<uintptr_t>(kChunkSize, end - pos)
            );
            if (want == 0u) break;

            const ssize_t got = initmember3_read_some(
                    mem_fd,
                    pos,
                    chunk.data(),
                    want
            );
            if (got <= 0) break;
            const std::size_t size = static_cast<std::size_t>(got);

            for (std::size_t i = 0u;
                 i + kAnchorLen <= size && out.size() < limit;
                 ++i) {
                if (std::memcmp(chunk.data() + i, kAnchor, kAnchorLen) != 0) {
                    continue;
                }

                const uintptr_t hit = pos + i;
                const std::size_t max_read = static_cast<std::size_t>(
                        std::min<uintptr_t>(kMaxObservedBody, end - hit)
                );
                if (max_read < kAnchorLen + 8u) continue;

                std::vector<unsigned char> body(max_read);
                const ssize_t body_got = initmember3_read_some(
                        mem_fd,
                        hit,
                        body.data(),
                        body.size()
                );
                if (body_got <= 0) continue;

                std::size_t observed = 0u;
                const std::size_t body_size = static_cast<std::size_t>(body_got);
                while (observed < body_size) {
                    const unsigned char c = body[observed];
                    if (c == 0u || !initmember3_ascii_char(c)) break;
                    ++observed;
                }
                if (observed < kAnchorLen + 8u) continue;

                std::string text(
                        reinterpret_cast<const char*>(body.data()),
                        observed
                );
                const std::size_t data_pos = text.find(kDataNeedle);
                if (data_pos == std::string::npos || data_pos <= kAnchorLen) {
                    continue;
                }

                std::string version = text.substr(
                        kAnchorLen,
                        data_pos - kAnchorLen
                );
                if (version.empty() || version.size() > 16u) continue;

                bool version_ascii = true;
                for (unsigned char c : version) {
                    if (!(c == '-' || c == '_' || c == '.' ||
                          (c >= '0' && c <= '9') ||
                          (c >= 'A' && c <= 'Z') ||
                          (c >= 'a' && c <= 'z'))) {
                        version_ascii = false;
                        break;
                    }
                }
                if (!version_ascii) continue;

                const std::size_t data_begin = data_pos + 6u;
                if (data_begin > text.size()) continue;
                const std::string data = text.substr(data_begin);

                bool duplicate = false;
                for (const auto& existing : out) {
                    if (existing.version == version &&
                        existing.observed_body_len == text.size() &&
                        existing.observed_data_len == data.size()) {
                        duplicate = true;
                        break;
                    }
                }
                if (duplicate) continue;

                InitMember3EnvelopeCandidate item;
                item.address = hit;
                item.version = version;
                item.data_shape = initmember3_envelope_data_shape(data);
                item.data = data;
                item.observed_body_len = text.size();
                item.observed_data_len = data.size();
                out.push_back(std::move(item));
            }

            pos += size;
        }
    }

    std::fclose(maps);
    return out;
}

std::vector<std::string> initmember3_request_meta_snapshot(
        int mem_fd,
        const unsigned char* object,
        std::size_t object_size,
        uintptr_t elf_base) {
    std::vector<std::string> out;
    if (object == nullptr || object_size < 0xE0u) return out;

    out.push_back("req.meta.objectSize=0xE0");
    out.push_back("req.flag+0x08=" + std::to_string(static_cast<unsigned int>(object[0x08])));
    out.push_back("req.flag+0xD8=" + std::to_string(static_cast<unsigned int>(object[0xD8])));

    for (std::size_t off = 0u;
         off + sizeof(uintptr_t) <= object_size;
         off += 0x08u) {
        uintptr_t value = 0u;
        std::memcpy(&value, object + off, sizeof(value));

        std::string summary;
        if (value == 0u) {
            summary = "0";
        } else if (value < 0x100000u) {
            summary = std::to_string(
                    static_cast<unsigned long long>(value)
            );
        } else if (address_in_libgame(value) &&
                   elf_base != 0u &&
                   value >= elf_base) {
            char tmp[64] = {};
            std::snprintf(
                    tmp,
                    sizeof(tmp),
                    "libgame:GH+0x%llX",
                    static_cast<unsigned long long>(
                            value - elf_base + kImageBase)
            );
            summary = tmp;
        } else {
            // Do not emit raw heap addresses in normal report. We only need
            // the shape of the object and which slots are pointer-like.
            unsigned char probe[8] = {};
            summary = initmember3_read_exact(
                    mem_fd,
                    value,
                    probe,
                    sizeof(probe))
                    ? "mapped_ptr"
                    : "scalar64";
        }

        char line[128] = {};
        std::snprintf(
                line,
                sizeof(line),
                "req.q+0x%02zX=%s",
                off,
                summary.c_str()
        );
        out.push_back(line);
    }

    // Probe each 8-byte aligned position as a libc++ string. False positives
    // are naturally rejected by the string-layout/ASCII checks.
    for (std::size_t off = 0u;
         off + 0x18u <= object_size;
         off += 0x08u) {
        std::string s;
        if (!initmember3_decode_snapshot_string(
                    mem_fd,
                    object,
                    object_size,
                    off,
                    &s,
                    false)) {
            continue;
        }
        if (s.size() < 3u) continue;

        char label[64] = {};
        std::snprintf(
                label,
                sizeof(label),
                "req.str+0x%02zX=",
                off
        );
        out.push_back(std::string(label) + initmember3_sanitize_wire_text(s));
    }

    return out;
}


std::string initmember3_probe_snapshot() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) {
        return "INITMEMBER3_PROBE\nRESULT=ERROR\nreason=LIBGAME_BASE_NOT_FOUND\n";
    }

    const uintptr_t request_vtable =
            gh_to_runtime(elf_base, kInitMember3RequestVtableGh);
    const uintptr_t builder =
            gh_to_runtime(elf_base, kInitMember3BuilderGh);
    const uintptr_t endpoint_const =
            gh_to_runtime(elf_base, kInitMember3EndpointStringGh);

    if (!address_in_libgame(request_vtable) ||
        !address_in_libgame(builder) ||
        !address_in_libgame(endpoint_const)) {
        return "INITMEMBER3_PROBE\nRESULT=ERROR\nreason=PROFILE_ADDRESS_INVALID\n";
    }

    FILE* maps = std::fopen("/proc/self/maps", "r");
    if (!maps) {
        return "INITMEMBER3_PROBE\nRESULT=ERROR\nreason=MAPS_OPEN_FAILED\n";
    }

    const int mem_fd = ::open("/proc/self/mem", O_RDONLY | O_CLOEXEC);
    const int self_mem_errno = mem_fd < 0 ? errno : 0;
    const char* read_mode =
            mem_fd >= 0
                    ? "PREAD_SELF_MEM"
                    : "PROCESS_VM_READV_SELF";

    // Android/SELinux can deny /proc/self/mem with EACCES even for a process
    // reading its own address space. V11.1 keeps the probe read-only and
    // falls back to process_vm_readv(getpid()) instead of failing the capture.
    if (mem_fd < 0) {
        unsigned char probe_byte = 0u;
        const uintptr_t probe_address =
                reinterpret_cast<uintptr_t>(&probe_byte);
        const ssize_t probe_read = initmember3_read_some(
                -1,
                probe_address,
                &probe_byte,
                sizeof(probe_byte)
        );
        if (probe_read != static_cast<ssize_t>(sizeof(probe_byte))) {
            const int vm_errno = errno;
            std::fclose(maps);
            char error_line[256] = {};
            std::snprintf(
                    error_line,
                    sizeof(error_line),
                    "INITMEMBER3_PROBE\nRESULT=ERROR\n"
                    "reason=SELF_MEMORY_READ_UNAVAILABLE\n"
                    "selfMemErrno=%d\nprocessVmErrno=%d\n",
                    self_mem_errno,
                    vm_errno
            );
            return error_line;
        }
    }

    struct Candidate {
        uintptr_t object = 0u;
        uintptr_t body = 0u;
        std::string endpoint;
        std::string url;
        bool endpoint_match = false;
        std::vector<std::string> body_snapshot;
        std::vector<std::string> request_meta_snapshot;
    };

    std::vector<Candidate> candidates;
    candidates.reserve(8u);

    constexpr std::size_t kObjectSize = 0xE0u;
    constexpr std::size_t kChunkSize = 256u * 1024u;
    std::vector<unsigned char> chunk(kChunkSize);
    const unsigned char low =
            static_cast<unsigned char>(request_vtable & 0xffu);

    uint64_t scanned_ranges = 0u;
    uint64_t scanned_bytes = 0u;
    bool exact_found = false;

    // V12.6: request objects are very short-lived on some boots. A full scan can
    // take a few hundred milliseconds, long enough to miss initMember3 between
    // polling attempts. Keep small "hot" windows around allocator regions where
    // any request object with this vtable was observed, scan those windows first,
    // and only refresh the full maps scan periodically.
    struct HotRange {
        uintptr_t start = 0u;
        uintptr_t end = 0u;
    };
    static std::mutex hot_mutex;
    static std::vector<HotRange> hot_ranges;
    static std::atomic<uint32_t> probe_sequence{0u};

    auto snapshot_hot_ranges = [&]() {
        std::lock_guard<std::mutex> lock(hot_mutex);
        return hot_ranges;
    };

    auto remember_hot_window = [&](uintptr_t hit, uintptr_t map_start, uintptr_t map_end) {
        constexpr uintptr_t kRadius = 8u * 1024u * 1024u;
        uintptr_t hot_start = hit > kRadius ? hit - kRadius : map_start;
        uintptr_t hot_end = hit + kRadius;
        if (hot_start < map_start) hot_start = map_start;
        if (hot_end > map_end || hot_end < hit) hot_end = map_end;
        if (hot_end <= hot_start) return;

        std::lock_guard<std::mutex> lock(hot_mutex);
        for (const auto& r : hot_ranges) {
            if (hit >= r.start && hit < r.end) return;
        }
        if (hot_ranges.size() >= 6u) hot_ranges.erase(hot_ranges.begin());
        hot_ranges.push_back({hot_start, hot_end});
    };

    auto candidate_already_seen = [&](uintptr_t object) {
        for (const auto& c : candidates) {
            if (c.object == object) return true;
        }
        return false;
    };

    auto scan_range = [&](uintptr_t start, uintptr_t end, bool remember_range) {
        if (end <= start || end - start < kObjectSize) return;
        ++scanned_ranges;

        for (uintptr_t pos = start;
             pos < end && !exact_found && candidates.size() < 8u;) {
            const std::size_t want = static_cast<std::size_t>(
                    std::min<uintptr_t>(kChunkSize, end - pos)
            );
            if (want == 0u) break;

            const ssize_t got = initmember3_read_some(
                    mem_fd,
                    pos,
                    chunk.data(),
                    want
            );
            if (got <= 0) break;

            const std::size_t size = static_cast<std::size_t>(got);
            scanned_bytes += static_cast<uint64_t>(size);

            const unsigned char* cursor = chunk.data();
            const unsigned char* limit = chunk.data() + size;
            while (cursor < limit && !exact_found && candidates.size() < 8u) {
                const void* raw_hit = std::memchr(
                        cursor,
                        low,
                        static_cast<std::size_t>(limit - cursor)
                );
                if (raw_hit == nullptr) break;

                const auto* local_hit =
                        static_cast<const unsigned char*>(raw_hit);
                const std::size_t local_off =
                        static_cast<std::size_t>(local_hit - chunk.data());
                const uintptr_t candidate = pos + local_off;
                cursor = local_hit + 1u;

                if ((candidate & (alignof(uintptr_t) - 1u)) != 0u) continue;
                if (candidate + kObjectSize > end) continue;
                if (candidate_already_seen(candidate)) continue;

                uintptr_t first = 0u;
                if (local_off + sizeof(first) <= size) {
                    std::memcpy(&first, chunk.data() + local_off, sizeof(first));
                } else if (!initmember3_read_exact(
                                   mem_fd, candidate, &first, sizeof(first))) {
                    continue;
                }
                if (first != request_vtable) continue;

                if (remember_range) {
                    remember_hot_window(candidate, start, end);
                }

                unsigned char object[kObjectSize] = {};
                if (!initmember3_read_exact(
                            mem_fd, candidate, object, sizeof(object))) {
                    continue;
                }

                Candidate item;
                item.object = candidate;
                initmember3_decode_snapshot_string(
                        mem_fd, object, sizeof(object), 0x48u, &item.endpoint);
                initmember3_decode_snapshot_string(
                        mem_fd, object, sizeof(object), 0xC0u, &item.url);
                std::memcpy(
                        &item.body,
                        object + 0x60u,
                        sizeof(item.body)
                );

                item.endpoint_match =
                        item.endpoint == kInitMember3Endpoint ||
                        item.url.find(kInitMember3Endpoint) != std::string::npos;

                if (item.endpoint_match) {
                    item.request_meta_snapshot =
                            initmember3_request_meta_snapshot(
                                    mem_fd,
                                    object,
                                    sizeof(object),
                                    elf_base);
                }

                if (item.endpoint_match && item.body >= 0x10000u) {
                    item.body_snapshot.reserve(96u);
                    initmember3_enumerate_json_map_safe_snapshot(
                            mem_fd,
                            item.body,
                            elf_base,
                            &item.body_snapshot,
                            96u);
                }

                candidates.push_back(std::move(item));
                if (candidates.back().endpoint_match) {
                    exact_found = true;
                    break;
                }
            }

            pos += size;
        }
    };

    const uint32_t sequence = probe_sequence.fetch_add(1u) + 1u;
    const auto cached_ranges = snapshot_hot_ranges();

    // Fast path: once any request object has been seen, poll only small nearby
    // allocator windows most of the time. This is what prevents a short-lived
    // initMember3 object from disappearing during a 300-500 MiB full scan.
    for (const auto& r : cached_ranges) {
        if (exact_found || candidates.size() >= 8u) break;
        scan_range(r.start, r.end, false);
    }

    // Refresh the global allocator map on first run, whenever no hot window is
    // known, and periodically so allocator movement cannot permanently hide the
    // target. Hot-only passes between refreshes are intentionally much faster.
    const bool refresh_full =
            cached_ranges.empty() ||
            exact_found ||
            (sequence % 8u) == 1u;

    char line[1024];
    if (!exact_found && (cached_ranges.empty() || refresh_full)) {
        std::rewind(maps);
        while (!exact_found && std::fgets(line, sizeof(line), maps)) {
            unsigned long long start_raw = 0u;
            unsigned long long end_raw = 0u;
            char perms[8] = {};
            char path[768] = {};
            const int parsed = std::sscanf(
                    line,
                    "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                    &start_raw,
                    &end_raw,
                    perms,
                    path
            );
            if (parsed < 3) continue;

            const char* map_path = parsed == 4 ? path : "";
            if (!locator_mapping_allowed(perms, map_path)) continue;

            const uintptr_t start = static_cast<uintptr_t>(start_raw);
            const uintptr_t end = static_cast<uintptr_t>(end_raw);
            scan_range(start, end, true);
        }
    }

    const auto wire_candidates =
            exact_found
            ? initmember3_find_wire_candidates(mem_fd, 3u)
            : std::vector<InitMember3WireCandidate>{};

    const auto final_envelope_candidates =
            exact_found
            ? initmember3_find_final_envelope_candidates(mem_fd, 4u)
            : std::vector<InitMember3EnvelopeCandidate>{};

    if (mem_fd >= 0) ::close(mem_fd);
    std::fclose(maps);

    std::size_t matched_count = 0u;
    for (const auto& c : candidates) {
        if (c.endpoint_match) ++matched_count;
    }

    std::string report;
    report.reserve(4096u);
    report += "INITMEMBER3_PROBE\n";
    report += "probeVersion=V12.6-FAST-HOT-RANGE-CAPTURE\n";
    report += std::string("captureMode=STREAM_MAPS_SAFE_COPY_") + read_mode + "\n";
    if (self_mem_errno != 0) {
        char io_note[96] = {};
        std::snprintf(io_note, sizeof(io_note), "selfMemOpenErrno=%d\n", self_mem_errno);
        report += io_note;
    }
    report += "READ_ONLY=true\n";
    report += matched_count > 0u
            ? "RESULT=FOUND_INITMEMBER3\n"
            : (!candidates.empty()
               ? "RESULT=REQUEST_OBJECTS_FOUND\n"
               : "RESULT=WAITING\n");

    char header[768] = {};
    std::snprintf(
            header,
            sizeof(header),
            "endpoint=%s\nendpointStringGH=0x%08llX\nbuilderGH=0x%08llX\n"
            "requestVtableGH=0x%08llX\nrequestObjects=%zu\nmatched=%zu\n"
            "scannedRanges=%llu\nscannedMiB=%.1f\n",
            kInitMember3Endpoint,
            static_cast<unsigned long long>(kInitMember3EndpointStringGh),
            static_cast<unsigned long long>(kInitMember3BuilderGh),
            static_cast<unsigned long long>(kInitMember3RequestVtableGh),
            candidates.size(),
            matched_count,
            static_cast<unsigned long long>(scanned_ranges),
            static_cast<double>(scanned_bytes) / (1024.0 * 1024.0)
    );
    report += header;

    std::size_t shown = 0u;
    for (const auto& c : candidates) {
        if (matched_count > 0u && !c.endpoint_match) continue;
        if (shown >= 4u) break;

        char candidate_header[256] = {};
        std::snprintf(
                candidate_header,
                sizeof(candidate_header),
                "\n[CANDIDATE %zu]\nobject=%p\nendpointMatch=%s\nbody=%p\n",
                shown + 1u,
                reinterpret_cast<void*>(c.object),
                c.endpoint_match ? "true" : "false",
                reinterpret_cast<void*>(c.body)
        );
        report += candidate_header;

        if (!c.endpoint.empty()) {
            report += "req.s+0x48=" + c.endpoint + "\n";
        }
        if (!c.url.empty()) {
            report += "req.s+0xC0=" + c.url + "\n";
        }
        if (c.endpoint_match) {
            if (!c.request_meta_snapshot.empty()) {
                report += "--- REQUEST META SNAPSHOT ---\n";
                for (const auto& line : c.request_meta_snapshot) {
                    report += line + "\n";
                }
            }

            if (c.body_snapshot.empty()) {
                report += "map.status=BODY_SNAPSHOT_EMPTY\n";
            } else {
                report += "--- BODY SNAPSHOT ---\n";
                for (const auto& line : c.body_snapshot) {
                    report += line + "\n";
                }
            }
        }
        ++shown;
    }

    if (matched_count > 0u) {
        report += "\n--- WIRE BODY SEARCH ---\n";
        report += "wire.candidates=" +
                  std::to_string(wire_candidates.size()) + "\n";
        std::size_t wire_index = 0u;
        for (const auto& wire : wire_candidates) {
            char wire_header[192] = {};
            std::snprintf(
                    wire_header,
                    sizeof(wire_header),
                    "[WIRE %zu] encoding=%s nativeKeyCount=%zu\n",
                    ++wire_index,
                    wire.encoding.c_str(),
                    wire.key_count
            );
            report += wire_header;
            report += "wire.text=" + wire.text + "\n";
        }
        if (wire_candidates.empty()) {
            report += "wire.status=NO_ASCII_MULTI_FIELD_BODY_FOUND\n";
        } else {
            report += "wire.status=ASCII_MULTI_FIELD_BODY_FOUND\n";
        }
    }

    if (matched_count > 0u) {
        report += "\n--- FINAL PROTOCOL ENVELOPE META ---\n";
        report += "envelope.candidates=" +
                  std::to_string(final_envelope_candidates.size()) + "\n";
        std::size_t envelope_index = 0u;
        for (const auto& envelope : final_envelope_candidates) {
            char header[256] = {};
            std::snprintf(
                    header,
                    sizeof(header),
                    "[ENVELOPE %zu] isEncryptedData=%s dataShape=%s bodyLenObserved=%zu dataLenObserved=%zu\n",
                    ++envelope_index,
                    envelope.version.c_str(),
                    envelope.data_shape.c_str(),
                    envelope.observed_body_len,
                    envelope.observed_data_len
            );
            report += header;
            report += "envelope.body=isEncryptedData=" +
                      envelope.version + "&data=<REDACTED>\n";
        }
        if (final_envelope_candidates.empty()) {
            report += "envelope.status=FINAL_WRAPPER_NOT_FOUND\n";
        } else {
            report += "envelope.status=FINAL_WRAPPER_FOUND\n";
        }
    }

    if (matched_count == 0u) {
        report += "\nNOTE=Arm capture before the natural bootstrap. V10 intentionally does not inspect the JSON body.\n";
    } else {
        report += "\nNEXT=V12.6 fast capture keeps short-lived initMember3 request objects in polling range; use FINAL PROTOCOL ENVELOPE META if found. Secrets and data payload remain redacted.\n";
    }
    return report;
}


std::vector<InitMember3WireCandidate> heart_send_find_wire_candidates(
        int mem_fd,
        std::size_t limit) {
    std::vector<InitMember3WireCandidate> out;
    if (limit == 0u) return out;

    FILE* maps = std::fopen("/proc/self/maps", "r");
    if (!maps) return out;

    constexpr std::size_t kChunkSize = 256u * 1024u;
    constexpr std::size_t kBefore = 2048u;
    constexpr std::size_t kAfter = 8192u;
    constexpr const char* kAnchor = "fromMemberSeq";
    constexpr std::size_t kAnchorLen = 13u;

    std::vector<unsigned char> chunk(kChunkSize);
    char line[1024] = {};

    while (out.size() < limit && std::fgets(line, sizeof(line), maps)) {
        unsigned long long start_raw = 0u;
        unsigned long long end_raw = 0u;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path
        );
        if (parsed < 3) continue;
        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < 64u) continue;

        for (uintptr_t pos = start; pos < end && out.size() < limit;) {
            const std::size_t want = static_cast<std::size_t>(
                    std::min<uintptr_t>(kChunkSize, end - pos));
            if (want == 0u) break;
            const ssize_t got = initmember3_read_some(mem_fd, pos, chunk.data(), want);
            if (got <= 0) break;
            const std::size_t size = static_cast<std::size_t>(got);

            for (std::size_t i = 0u;
                 i + kAnchorLen <= size && out.size() < limit;
                 ++i) {
                if (std::memcmp(chunk.data() + i, kAnchor, kAnchorLen) != 0) continue;

                const uintptr_t hit = pos + i;
                const uintptr_t window_start = hit > kBefore ? std::max(start, hit - kBefore) : start;
                const uintptr_t window_end = std::min(end, hit + kAfter);
                if (window_end <= window_start) continue;

                std::vector<unsigned char> window(
                        static_cast<std::size_t>(window_end - window_start));
                const ssize_t window_got = initmember3_read_some(
                        mem_fd, window_start, window.data(), window.size());
                if (window_got <= 0) continue;
                const std::size_t window_size = static_cast<std::size_t>(window_got);
                const std::size_t anchor_off = static_cast<std::size_t>(hit - window_start);
                if (anchor_off >= window_size) continue;

                std::size_t left = anchor_off;
                while (left > 0u) {
                    const unsigned char c = window[left - 1u];
                    if (c == 0u || !initmember3_ascii_char(c)) break;
                    --left;
                }
                std::size_t right = anchor_off + kAnchorLen;
                while (right < window_size) {
                    const unsigned char c = window[right];
                    if (c == 0u || !initmember3_ascii_char(c)) break;
                    ++right;
                }
                if (right <= left || right - left < 64u) continue;

                std::string candidate(
                        reinterpret_cast<const char*>(window.data() + left),
                        right - left);
                if (candidate.find("toMemberSeq") == std::string::npos ||
                    candidate.find("requestId") == std::string::npos) {
                    continue;
                }

                bool duplicate = false;
                for (const auto& existing : out) {
                    if (existing.text == initmember3_sanitize_wire_text(candidate)) {
                        duplicate = true;
                        break;
                    }
                }
                if (duplicate) continue;

                InitMember3WireCandidate item;
                item.address = window_start + left;
                item.encoding = initmember3_classify_wire_text(candidate);
                item.key_count = 3u;
                item.text = initmember3_sanitize_wire_text(candidate);
                out.push_back(std::move(item));
            }
            pos += size;
        }
    }

    std::fclose(maps);
    return out;
}



std::string heart_ds_hex_bytes(const unsigned char* data, std::size_t size) {
    static constexpr char kHex[] = "0123456789ABCDEF";
    std::string out;
    out.resize(size * 2u);
    for (std::size_t i = 0; i < size; ++i) {
        out[i * 2u] = kHex[(data[i] >> 4u) & 0x0Fu];
        out[i * 2u + 1u] = kHex[data[i] & 0x0Fu];
    }
    return out;
}

std::string heart_ds_crypto_profile_snapshot() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0u) {
        return
                "HEART_DS_CRYPTO_PROFILE\n"
                "profileVersion=V13.5-HEART-DS-V4-CRYPTO\n"
                "RESULT=ERROR\n"
                "reason=LIBGAME_BASE_NOT_FOUND\n";
    }

    const uintptr_t key_rt =
            gh_to_runtime(elf_base, kHeartDsV4ChaCha20KeyGh);
    const uintptr_t nonce_rt =
            gh_to_runtime(elf_base, kHeartDsV4BaseNonceGh);

    if (!address_in_libgame(key_rt) ||
        !address_in_libgame(key_rt + kHeartDsV4ChaCha20KeySize - 1u) ||
        !address_in_libgame(nonce_rt) ||
        !address_in_libgame(nonce_rt + kHeartDsV4BaseNonceSize - 1u)) {
        return
                "HEART_DS_CRYPTO_PROFILE\n"
                "profileVersion=V13.5-HEART-DS-V4-CRYPTO\n"
                "RESULT=ERROR\n"
                "reason=PROFILE_ADDRESS_INVALID\n";
    }

    unsigned char key[kHeartDsV4ChaCha20KeySize] = {};
    unsigned char nonce[kHeartDsV4BaseNonceSize] = {};
    std::memcpy(key, reinterpret_cast<const void*>(key_rt), sizeof(key));
    std::memcpy(nonce, reinterpret_cast<const void*>(nonce_rt), sizeof(nonce));

    std::string report;
    report.reserve(1024u);
    report += "HEART_DS_CRYPTO_PROFILE\n";
    report += "profileVersion=V13.5-HEART-DS-V4-CRYPTO\n";
    report += "READ_ONLY=true\n";
    report += "RESULT=FOUND\n";
    report += "protocolEncryptionVersion=4\n";
    report += "transportEnvelope=isEncryptedData=4&data=<URL_SAFE_BASE64>\n";
    report += "pipeline=FASTLZ_FRAME->CHACHA20->URL_SAFE_BASE64\n";
    report += "compressorGH=0x016AAB7C\n";
    report += "cryptoGH=0x016AF2D4\n";
    report += "cryptoInitGH=0x016AF4F4\n";
    report += "keyGH=0x007D2310\n";
    report += "keyLength=32\n";
    report += "keyHex=" + heart_ds_hex_bytes(key, sizeof(key)) + "\n";
    report += "baseNonceGH=0x007D2330\n";
    report += "baseNonceLength=12\n";
    report += "baseNonceHex=" + heart_ds_hex_bytes(nonce, sizeof(nonce)) + "\n";
    report += "nonceRule=EACH_BASE_NONCE_BYTE_PLUS_PRE_ENCRYPT_INPUT_LENGTH_LOW8\n";
    report += "nonceRuleProof=FUN_00F3DA48(param3=1)_ADDS_INPUT_LENGTH_TO_ALL_12_BYTES\n";
    report += "sessionKey=NOT_READ_BY_THIS_TOOL\n";
    report += "NEXT=Copy this report to Python side; no heart send is required.\n";
    return report;
}

// -------------------------------------------------------------------------
// V13.3 Heart SEND event-time capture.
//
// V13.2 tried to find a short-lived 0xE0 request object by rescanning hundreds
// of MiB of allocator memory. The request can be created, serialized and freed
// between scans, so a successful natural send could still produce NOT_FOUND.
//
// V13.3 arms only the serializer vtable slot used by this request class:
//   actual request vtable GH 0x020EC238
//   serializer slot GH 0x020EC260 (= +0x28)
//   original serializer GH 0x00F17830
//
// The hook calls the game's original serializer unchanged, copies the returned
// final form body only when request.endpoint == game/sendLifeMail2.ds, then
// restores the original vtable slot. No game request fields are modified.
// -------------------------------------------------------------------------

enum class HeartSendCaptureState : int {
    IDLE = 0,
    ARMED = 1,
    FOUND = 2,
    ERROR = 3,
};

using HeartSendSerializeFn = std::string (*)(void*, uint32_t*);

std::mutex g_heart_send_event_mutex;
std::atomic<int> g_heart_send_event_state{
        static_cast<int>(HeartSendCaptureState::IDLE)};
std::atomic<uintptr_t> g_heart_send_original_serializer{0u};
std::atomic<uintptr_t> g_heart_send_serializer_slot{0u};
std::string g_heart_send_event_report;

bool heart_send_write_ro_pointer(
        uintptr_t address,
        uintptr_t value,
        std::string* error) {
    if (address < 0x10000u) {
        if (error) *error = "invalid slot address";
        return false;
    }

    const long page_size_raw = ::sysconf(_SC_PAGESIZE);
    const uintptr_t page_size =
            page_size_raw > 0 ? static_cast<uintptr_t>(page_size_raw) : 4096u;
    const uintptr_t page = address & ~(page_size - 1u);

    if (::mprotect(
                reinterpret_cast<void*>(page),
                static_cast<std::size_t>(page_size),
                PROT_READ | PROT_WRITE) != 0) {
        if (error) {
            *error = "mprotect RW failed errno=" + std::to_string(errno);
        }
        return false;
    }

    *reinterpret_cast<volatile uintptr_t*>(address) = value;
    __sync_synchronize();

    if (::mprotect(
                reinterpret_cast<void*>(page),
                static_cast<std::size_t>(page_size),
                PROT_READ) != 0) {
        if (error) {
            *error = "restore R failed errno=" + std::to_string(errno);
        }
        return false;
    }

    return true;
}

bool heart_send_read_local_libcpp_string(
        const void* field,
        std::string* out) {
    if (field == nullptr || out == nullptr) return false;
    out->clear();

    unsigned char raw[0x18] = {};
    std::memcpy(raw, field, sizeof(raw));

    if ((raw[0] & 1u) == 0u) {
        const std::size_t len = static_cast<std::size_t>(raw[0] >> 1u);
        if (len > 22u) return false;
        out->assign(reinterpret_cast<const char*>(raw + 1u), len);
        return true;
    }

    std::size_t len = 0u;
    uintptr_t ptr = 0u;
    std::memcpy(&len, raw + 0x08u, sizeof(len));
    std::memcpy(&ptr, raw + 0x10u, sizeof(ptr));
    if (len == 0u || len > 512u || ptr < 0x10000u) return false;

    std::vector<char> bytes(len);
    if (!initmember3_read_exact(
                -1, ptr, bytes.data(), bytes.size())) {
        return false;
    }
    out->assign(bytes.data(), bytes.size());
    return true;
}

bool heart_send_restore_event_hook(std::string* note) {
    const uintptr_t slot = g_heart_send_serializer_slot.load();
    const uintptr_t original = g_heart_send_original_serializer.load();

    if (slot == 0u || original == 0u) return true;

    std::string error;
    const bool ok = heart_send_write_ro_pointer(slot, original, &error);
    if (!ok && note) *note = error;
    if (ok) {
        g_heart_send_serializer_slot.store(0u);
        g_heart_send_original_serializer.store(0u);
    }
    return ok;
}

std::string heart_send_build_event_report(
        const std::string& endpoint,
        const std::string& final_form,
        uint32_t reported_length,
        bool restore_ok,
        const std::string& restore_note) {
    std::string encrypted_flag;
    std::string data_value;

    constexpr const char* kFlagPrefix = "isEncryptedData=";
    constexpr const char* kDataSep = "&data=";

    const std::size_t flag_pos = final_form.find(kFlagPrefix);
    const std::size_t data_pos = final_form.find(kDataSep);
    if (flag_pos != std::string::npos &&
        data_pos != std::string::npos &&
        data_pos >= flag_pos + std::strlen(kFlagPrefix)) {
        encrypted_flag = final_form.substr(
                flag_pos + std::strlen(kFlagPrefix),
                data_pos - (flag_pos + std::strlen(kFlagPrefix)));
        data_value = final_form.substr(data_pos + std::strlen(kDataSep));
    }

    std::string report;
    report.reserve(final_form.size() + 1024u);
    report += "HEART_SEND_DS_PROBE\n";
    report += "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n";
    report += "CAPTURE_ONLY=true\n";
    report += "RESULT=FOUND_HEART_SEND\n";
    report += "captureRoute=EVENT_TIME_SERIALIZER_VTABLE\n";
    report += "endpoint=" + endpoint + "\n";
    report += "requestVtableGH=0x020EC238\n";
    report += "serializerSlotGH=0x020EC260\n";
    report += "serializerGH=0x00F17830\n";
    report += "builderGH=0x013D4D10\n";
    report += "vtableProof=FUN_013D4D10@013D4FE4->0x020EC238\n";
    report += "reportedLength=" + std::to_string(reported_length) + "\n";
    report += "finalFormLength=" + std::to_string(final_form.size()) + "\n";

    if (!encrypted_flag.empty()) {
        report += "envelope.isEncryptedData=" + encrypted_flag + "\n";
    } else {
        report += "envelope.isEncryptedData=<NOT_PARSED>\n";
    }

    if (!data_value.empty()) {
        report += "envelope.data=" + data_value + "\n";
        report += "envelope.dataLength=" + std::to_string(data_value.size()) + "\n";
    } else {
        report += "envelope.data=<NOT_PARSED>\n";
        report += "finalForm=" + final_form + "\n";
    }

    report += std::string("hookRestored=") + (restore_ok ? "true" : "false") + "\n";
    if (!restore_note.empty()) {
        report += "hookRestoreNote=" + restore_note + "\n";
    }
    report += "sessionKeyPlaintext=REDACTED_NOT_CAPTURED\n";
    return report;
}

std::string heart_send_serialize_event_hook(
        void* request,
        uint32_t* reported_length) {
    const uintptr_t original_ptr = g_heart_send_original_serializer.load();
    if (original_ptr == 0u) {
        return {};
    }

    const auto original =
            reinterpret_cast<HeartSendSerializeFn>(original_ptr);
    std::string final_form = original(request, reported_length);

    if (g_heart_send_event_state.load() !=
        static_cast<int>(HeartSendCaptureState::ARMED)) {
        return final_form;
    }

    std::string endpoint;
    bool endpoint_ok = false;
    if (request != nullptr) {
        endpoint_ok = heart_send_read_local_libcpp_string(
                reinterpret_cast<const unsigned char*>(request) + 0x48u,
                &endpoint);
    }
    if (!endpoint_ok || endpoint != kHeartSendEndpoint) {
        return final_form;
    }

    const uint32_t length_value =
            reported_length != nullptr ? *reported_length : 0u;

    std::string restore_note;
    const bool restored = heart_send_restore_event_hook(&restore_note);

    {
        std::lock_guard<std::mutex> lock(g_heart_send_event_mutex);
        g_heart_send_event_report = heart_send_build_event_report(
                endpoint,
                final_form,
                length_value,
                restored,
                restore_note);
        g_heart_send_event_state.store(
                static_cast<int>(HeartSendCaptureState::FOUND));
    }

    return final_form;
}

std::string heart_send_arm_or_status_event_capture() {
    std::lock_guard<std::mutex> lock(g_heart_send_event_mutex);

    const int state = g_heart_send_event_state.load();
    if (state == static_cast<int>(HeartSendCaptureState::FOUND) ||
        state == static_cast<int>(HeartSendCaptureState::ERROR)) {
        return g_heart_send_event_report;
    }

    if (state == static_cast<int>(HeartSendCaptureState::ARMED)) {
        return
                "HEART_SEND_DS_PROBE\n"
                "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
                "CAPTURE_ONLY=true\n"
                "RESULT=WAITING\n"
                "captureRoute=EVENT_TIME_SERIALIZER_VTABLE\n"
                "endpoint=game/sendLifeMail2.ds\n"
                "requestVtableGH=0x020EC238\n"
                "serializerSlotGH=0x020EC260\n"
                "serializerGH=0x00F17830\n"
                "vtableProof=FUN_013D4D10@013D4FE4->0x020EC238\n"
                "hookInstalled=true\n"
                "NEXT=Send one natural heart while ARMED.\n";
    }

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0u) {
        g_heart_send_event_state.store(
                static_cast<int>(HeartSendCaptureState::ERROR));
        g_heart_send_event_report =
                "HEART_SEND_DS_PROBE\n"
                "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
                "RESULT=ERROR\nreason=LIBGAME_BASE_NOT_FOUND\n";
        return g_heart_send_event_report;
    }

    const uintptr_t slot =
            gh_to_runtime(elf_base, kHeartSendSerializeSlotGh);
    const uintptr_t expected_original =
            gh_to_runtime(elf_base, kHeartSendSerializeGh);

    if (!address_in_libgame(slot) ||
        !address_in_libgame(expected_original)) {
        g_heart_send_event_state.store(
                static_cast<int>(HeartSendCaptureState::ERROR));
        g_heart_send_event_report =
                "HEART_SEND_DS_PROBE\n"
                "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
                "RESULT=ERROR\nreason=PROFILE_ADDRESS_INVALID\n";
        return g_heart_send_event_report;
    }

    const uintptr_t current =
            *reinterpret_cast<const uintptr_t*>(slot);
    if (current != expected_original) {
        g_heart_send_event_state.store(
                static_cast<int>(HeartSendCaptureState::ERROR));
        char buf[512] = {};
        std::snprintf(
                buf, sizeof(buf),
                "HEART_SEND_DS_PROBE\n"
                "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
                "RESULT=ERROR\nreason=SERIALIZER_SLOT_MISMATCH\n"
                "slotGH=0x%08llX\nexpectedGH=0x%08llX\n"
                "currentRT=0x%llX\nexpectedRT=0x%llX\n",
                static_cast<unsigned long long>(kHeartSendSerializeSlotGh),
                static_cast<unsigned long long>(kHeartSendSerializeGh),
                static_cast<unsigned long long>(current),
                static_cast<unsigned long long>(expected_original));
        g_heart_send_event_report = buf;
        return g_heart_send_event_report;
    }

    g_heart_send_original_serializer.store(expected_original);
    g_heart_send_serializer_slot.store(slot);

    std::string error;
    if (!heart_send_write_ro_pointer(
                slot,
                reinterpret_cast<uintptr_t>(&heart_send_serialize_event_hook),
                &error)) {
        g_heart_send_serializer_slot.store(0u);
        g_heart_send_original_serializer.store(0u);
        g_heart_send_event_state.store(
                static_cast<int>(HeartSendCaptureState::ERROR));
        g_heart_send_event_report =
                "HEART_SEND_DS_PROBE\n"
                "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
                "RESULT=ERROR\nreason=VTABLE_HOOK_INSTALL_FAILED\n"
                "detail=" + error + "\n";
        return g_heart_send_event_report;
    }

    g_heart_send_event_state.store(
            static_cast<int>(HeartSendCaptureState::ARMED));
    g_heart_send_event_report.clear();

    return
            "HEART_SEND_DS_PROBE\n"
            "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
            "CAPTURE_ONLY=true\n"
            "RESULT=WAITING\n"
            "captureRoute=EVENT_TIME_SERIALIZER_VTABLE\n"
            "endpoint=game/sendLifeMail2.ds\n"
            "requestVtableGH=0x020EC238\n"
            "serializerSlotGH=0x020EC260\n"
            "serializerGH=0x00F17830\n"
            "vtableProof=FUN_013D4D10@013D4FE4->0x020EC238\n"
            "hookInstalled=true\n"
            "NEXT=Send one natural heart while ARMED.\n";
}

std::string heart_send_reset_event_capture() {
    std::lock_guard<std::mutex> lock(g_heart_send_event_mutex);

    std::string restore_note;
    const bool restored = heart_send_restore_event_hook(&restore_note);

    g_heart_send_event_state.store(
            static_cast<int>(HeartSendCaptureState::IDLE));
    g_heart_send_event_report.clear();

    std::string report =
            "HEART_SEND_DS_PROBE\n"
            "probeVersion=V13.4-HEART-SEND-ACTUAL-VTABLE-CAPTURE\n"
            "RESULT=RESET\n";
    report += std::string("hookRestored=") + (restored ? "true" : "false") + "\n";
    if (!restore_note.empty()) {
        report += "hookRestoreNote=" + restore_note + "\n";
    }
    return report;
}

std::string heart_send_ds_probe_snapshot() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0u) {
        return "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=LIBGAME_BASE_NOT_FOUND\n";
    }

    const uintptr_t request_vtable =
            gh_to_runtime(elf_base, kHeartSendRequestVtableGh);
    const uintptr_t builder =
            gh_to_runtime(elf_base, kHeartSendBuilderGh);
    const uintptr_t endpoint_const =
            gh_to_runtime(elf_base, kHeartSendEndpointStringGh);

    if (!address_in_libgame(request_vtable) ||
        !address_in_libgame(builder) ||
        !address_in_libgame(endpoint_const)) {
        return "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=PROFILE_ADDRESS_INVALID\n";
    }

    FILE* maps = std::fopen("/proc/self/maps", "r");
    if (!maps) {
        return "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=MAPS_OPEN_FAILED\n";
    }

    const int mem_fd = ::open("/proc/self/mem", O_RDONLY | O_CLOEXEC);
    const int self_mem_errno = mem_fd < 0 ? errno : 0;
    if (mem_fd < 0) {
        unsigned char probe_byte = 0u;
        const ssize_t probe_read = initmember3_read_some(
                -1,
                reinterpret_cast<uintptr_t>(&probe_byte),
                &probe_byte,
                sizeof(probe_byte));
        if (probe_read != static_cast<ssize_t>(sizeof(probe_byte))) {
            const int vm_errno = errno;
            std::fclose(maps);
            char err[256] = {};
            std::snprintf(
                    err, sizeof(err),
                    "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=SELF_MEMORY_READ_UNAVAILABLE\n"
                    "selfMemErrno=%d\nprocessVmErrno=%d\n",
                    self_mem_errno, vm_errno);
            return err;
        }
    }

    struct Candidate {
        uintptr_t object = 0u;
        uintptr_t body = 0u;
        std::string endpoint;
        std::string url;
        std::vector<std::string> body_snapshot;
        std::vector<std::string> request_meta_snapshot;
    };

    std::vector<Candidate> candidates;
    constexpr std::size_t kObjectSize = 0xE0u;
    constexpr std::size_t kChunkSize = 256u * 1024u;
    std::vector<unsigned char> chunk(kChunkSize);
    const unsigned char low = static_cast<unsigned char>(request_vtable & 0xffu);
    uint64_t scanned_ranges = 0u;
    uint64_t scanned_bytes = 0u;
    bool found = false;

    char line[1024] = {};
    while (!found && std::fgets(line, sizeof(line), maps)) {
        unsigned long long start_raw = 0u;
        unsigned long long end_raw = 0u;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path);
        if (parsed < 3) continue;
        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < kObjectSize) continue;
        ++scanned_ranges;

        for (uintptr_t pos = start; pos < end && !found;) {
            const std::size_t want = static_cast<std::size_t>(
                    std::min<uintptr_t>(kChunkSize, end - pos));
            if (want == 0u) break;
            const ssize_t got = initmember3_read_some(mem_fd, pos, chunk.data(), want);
            if (got <= 0) break;
            const std::size_t size = static_cast<std::size_t>(got);
            scanned_bytes += size;

            const unsigned char* cursor = chunk.data();
            const unsigned char* limit = chunk.data() + size;
            while (cursor < limit && !found) {
                const void* raw_hit = std::memchr(
                        cursor, low, static_cast<std::size_t>(limit - cursor));
                if (!raw_hit) break;
                const auto* local_hit = static_cast<const unsigned char*>(raw_hit);
                const std::size_t local_off = static_cast<std::size_t>(local_hit - chunk.data());
                const uintptr_t candidate = pos + local_off;
                cursor = local_hit + 1u;

                if ((candidate & (alignof(uintptr_t) - 1u)) != 0u) continue;
                if (candidate + kObjectSize > end) continue;

                uintptr_t first = 0u;
                if (local_off + sizeof(first) <= size) {
                    std::memcpy(&first, chunk.data() + local_off, sizeof(first));
                } else if (!initmember3_read_exact(mem_fd, candidate, &first, sizeof(first))) {
                    continue;
                }
                if (first != request_vtable) continue;

                unsigned char object[kObjectSize] = {};
                if (!initmember3_read_exact(mem_fd, candidate, object, sizeof(object))) continue;

                Candidate item;
                item.object = candidate;
                initmember3_decode_snapshot_string(
                        mem_fd, object, sizeof(object), 0x48u, &item.endpoint);
                initmember3_decode_snapshot_string(
                        mem_fd, object, sizeof(object), 0xC0u, &item.url);
                std::memcpy(&item.body, object + 0x60u, sizeof(item.body));

                const bool endpoint_match =
                        item.endpoint == kHeartSendEndpoint ||
                        item.url.find(kHeartSendEndpoint) != std::string::npos;
                if (!endpoint_match) continue;

                item.request_meta_snapshot = initmember3_request_meta_snapshot(
                        mem_fd, object, sizeof(object), elf_base);
                if (item.body >= 0x10000u) {
                    initmember3_enumerate_json_map_safe_snapshot(
                            mem_fd, item.body, elf_base,
                            &item.body_snapshot, 96u);
                }
                candidates.push_back(std::move(item));
                found = true;
            }
            pos += size;
        }
    }

    const auto wire_candidates = found
            ? heart_send_find_wire_candidates(mem_fd, 4u)
            : std::vector<InitMember3WireCandidate>{};
    const auto envelopes = found
            ? initmember3_find_final_envelope_candidates(mem_fd, 8u)
            : std::vector<InitMember3EnvelopeCandidate>{};

    if (mem_fd >= 0) ::close(mem_fd);
    std::fclose(maps);

    std::string report;
    report.reserve(8192u);
    report += "HEART_SEND_DS_PROBE\n";
    report += "probeVersion=V13.2-HEART-SEND-DS-CAPTURE\n";
    report += "READ_ONLY=true\n";
    report += found ? "RESULT=FOUND_HEART_SEND\n" : "RESULT=WAITING\n";
    char header[512] = {};
    std::snprintf(
            header, sizeof(header),
            "endpoint=%s\nendpointStringGH=0x%08llX\nbuilderGH=0x%08llX\n"
            "requestVtableGH=0x%08llX\nscannedRanges=%llu\nscannedMiB=%.1f\n",
            kHeartSendEndpoint,
            static_cast<unsigned long long>(kHeartSendEndpointStringGh),
            static_cast<unsigned long long>(kHeartSendBuilderGh),
            static_cast<unsigned long long>(kHeartSendRequestVtableGh),
            static_cast<unsigned long long>(scanned_ranges),
            static_cast<double>(scanned_bytes) / (1024.0 * 1024.0));
    report += header;

    if (found && !candidates.empty()) {
        const auto& c = candidates.front();
        report += "\n--- REQUEST OBJECT ---\n";
        report += "endpoint=" + c.endpoint + "\n";
        if (!c.url.empty()) report += "url=" + c.url + "\n";
        for (const auto& meta : c.request_meta_snapshot) report += meta + "\n";

        report += "\n--- VALUE MAP SNAPSHOT ---\n";
        if (c.body_snapshot.empty()) {
            report += "map.status=BODY_SNAPSHOT_EMPTY\n";
        } else {
            for (const auto& v : c.body_snapshot) report += v + "\n";
        }

        report += "\n--- PLAINTEXT WIRE SEARCH ---\n";
        report += "wire.candidates=" + std::to_string(wire_candidates.size()) + "\n";
        std::size_t wi = 0u;
        for (const auto& w : wire_candidates) {
            report += "[WIRE " + std::to_string(++wi) + "] encoding=" + w.encoding + "\n";
            report += "wire.text=" + w.text + "\n";
        }
        if (wire_candidates.empty()) report += "wire.status=NOT_FOUND\n";

        report += "\n--- FINAL PROTOCOL ENVELOPE ---\n";
        report += "envelope.candidates=" + std::to_string(envelopes.size()) + "\n";
        std::size_t ei = 0u;
        for (const auto& e : envelopes) {
            report += "[ENVELOPE " + std::to_string(++ei) + "] isEncryptedData=" +
                      e.version + " dataShape=" + e.data_shape +
                      " bodyLenObserved=" + std::to_string(e.observed_body_len) +
                      " dataLenObserved=" + std::to_string(e.observed_data_len) + "\n";
            report += "envelope.body=isEncryptedData=" + e.version + "&data=<CAPTURED>\n";
            report += "envelope.data=" + e.data + "\n";
        }
        if (envelopes.empty()) report += "envelope.status=NOT_FOUND\n";
    }

    report += "\nNEXT=Copy this report after one natural in-game heart send. "
              "sessionKey remains redacted in plaintext snapshots; envelope.data is encrypted transport material.\n";
    return report;
}

int locate_box_action_binding(int action_id) {
    const BoxActionProfile* profile = box_action_profile(action_id);
    if (profile == nullptr) return -200;

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t callback = gh_to_runtime(elf_base, profile->callback_gh);
    const uintptr_t expected_target_vtable =
            gh_to_runtime(elf_base, profile->target_vtable_gh);

    if (!address_in_libgame(callback) || !address_in_libgame(expected_target_vtable)) {
        return -205;
    }

    FILE* fp = std::fopen("/proc/self/maps", "r");
    if (!fp) return -206;

    uintptr_t found_binding = 0;
    uintptr_t found_target = 0;
    uint64_t valid_matches = 0;
    uint64_t scanned_ranges = 0;
    uint64_t scanned_bytes = 0;
    const unsigned char callback_low = static_cast<unsigned char>(callback & 0xffu);

    char line[1024];
    while (std::fgets(line, sizeof(line), fp)) {
        unsigned long long start_raw = 0;
        unsigned long long end_raw = 0;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path
        );
        if (parsed < 3) continue;
        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < 0x40u) continue;

        ++scanned_ranges;
        scanned_bytes += static_cast<uint64_t>(end - start);

        const unsigned char* cursor = reinterpret_cast<const unsigned char*>(start);
        const unsigned char* limit = reinterpret_cast<const unsigned char*>(end);

        while (cursor + sizeof(uintptr_t) <= limit) {
            const std::size_t remaining = static_cast<std::size_t>(limit - cursor);
            const void* raw_hit = std::memchr(cursor, callback_low, remaining);
            if (raw_hit == nullptr) break;

            const uintptr_t selector_slot = reinterpret_cast<uintptr_t>(raw_hit);
            cursor = reinterpret_cast<const unsigned char*>(selector_slot + 1u);

            if ((selector_slot & (alignof(uintptr_t) - 1u)) != 0) continue;
            if (selector_slot < start + 0x20u || selector_slot + sizeof(uintptr_t) > end) continue;

            uintptr_t selector = 0;
            std::memcpy(&selector, reinterpret_cast<const void*>(selector_slot), sizeof(selector));
            if (selector != callback) continue;

            const uintptr_t binding = selector_slot - 0x20u;
            if (binding < start || binding + 0x28u > end) continue;

            uintptr_t binding_vtable = 0;
            uintptr_t minus_one = 0;
            uintptr_t signature = 0;
            uintptr_t target = 0;
            uintptr_t selector_again = 0;

            std::memcpy(&binding_vtable, reinterpret_cast<const void*>(binding + 0x00u), sizeof(binding_vtable));
            std::memcpy(&minus_one, reinterpret_cast<const void*>(binding + 0x08u), sizeof(minus_one));
            std::memcpy(&signature, reinterpret_cast<const void*>(binding + 0x10u), sizeof(signature));
            std::memcpy(&target, reinterpret_cast<const void*>(binding + 0x18u), sizeof(target));
            std::memcpy(&selector_again, reinterpret_cast<const void*>(binding + 0x20u), sizeof(selector_again));

            if (!address_in_libgame(binding_vtable)) continue;
            if (minus_one != static_cast<uintptr_t>(-1)) continue;
            if (signature != kBoxBindingSignature) continue;
            if (selector_again != callback) continue;
            if (!mapped_pointer_value(target)) continue;

            uintptr_t target_vtable = 0;
            std::memcpy(&target_vtable, reinterpret_cast<const void*>(target), sizeof(target_vtable));
            if (target_vtable != expected_target_vtable) continue;

            ++valid_matches;
            if (found_binding == 0) {
                found_binding = binding;
                found_target = target;
            }
        }
    }
    std::fclose(fp);

    char report[768] = {};
    if (valid_matches == 1 && found_binding != 0 && found_target != 0) {
        {
            std::lock_guard<std::mutex> lock(g_box_action_mutex);
            g_box_action_cache.action_id = action_id;
            g_box_action_cache.binding = found_binding;
            g_box_action_cache.callback = callback;
            g_box_action_cache.target = found_target;
            g_box_action_cache.target_vtable = expected_target_vtable;
            g_box_action_cache.valid_matches = valid_matches;
        }
        std::snprintf(
                report,
                sizeof(report),
                "BOX_ACTION_LOCATOR\nRESULT=FOUND\naction=%s\nactionId=%d\ncallbackGH=0x%08llX\n"
                "targetVtableGH=0x%08llX\nbinding=%p\ntarget=%p\nvalidMatches=%llu\n"
                "scannedRanges=%llu\nscannedMiB=%.1f\n",
                profile->name,
                action_id,
                static_cast<unsigned long long>(profile->callback_gh),
                static_cast<unsigned long long>(profile->target_vtable_gh),
                reinterpret_cast<void*>(found_binding),
                reinterpret_cast<void*>(found_target),
                static_cast<unsigned long long>(valid_matches),
                static_cast<unsigned long long>(scanned_ranges),
                static_cast<double>(scanned_bytes) / (1024.0 * 1024.0)
        );
        std::lock_guard<std::mutex> lock(g_box_action_mutex);
        g_box_action_report = report;
        return 0;
    }

    {
        std::lock_guard<std::mutex> lock(g_box_action_mutex);
        reset_box_action_cache_locked();
    }

    std::snprintf(
            report,
            sizeof(report),
            "BOX_ACTION_LOCATOR\nRESULT=%s\naction=%s\nactionId=%d\ncallbackGH=0x%08llX\n"
            "targetVtableGH=0x%08llX\nvalidMatches=%llu\nscannedRanges=%llu\nscannedMiB=%.1f\n",
            valid_matches == 0 ? "WAITING" : "AMBIGUOUS",
            profile->name,
            action_id,
            static_cast<unsigned long long>(profile->callback_gh),
            static_cast<unsigned long long>(profile->target_vtable_gh),
            static_cast<unsigned long long>(valid_matches),
            static_cast<unsigned long long>(scanned_ranges),
            static_cast<double>(scanned_bytes) / (1024.0 * 1024.0)
    );
    {
        std::lock_guard<std::mutex> lock(g_box_action_mutex);
        g_box_action_report = report;
    }
    return valid_matches == 0 ? -201 : -202;
}

int call_cached_box_action(int action_id) {
    const BoxActionProfile* profile = box_action_profile(action_id);
    if (profile == nullptr) return -200;

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    BoxActionCache cache;
    {
        std::lock_guard<std::mutex> lock(g_box_action_mutex);
        cache = g_box_action_cache;
    }

    if (cache.action_id != action_id ||
        cache.binding == 0 ||
        cache.callback == 0 ||
        cache.target == 0) {
        return -203;
    }

    const uintptr_t expected_callback = gh_to_runtime(elf_base, profile->callback_gh);
    const uintptr_t expected_target_vtable = gh_to_runtime(elf_base, profile->target_vtable_gh);
    if (cache.callback != expected_callback || !address_in_libgame(expected_callback)) return -205;

    if (!address_is_mapped(cache.binding) || !address_is_mapped(cache.target)) return -203;

    const uintptr_t binding_vtable = *reinterpret_cast<const uintptr_t*>(cache.binding + 0x00u);
    const uintptr_t minus_one = *reinterpret_cast<const uintptr_t*>(cache.binding + 0x08u);
    const uintptr_t signature = *reinterpret_cast<const uintptr_t*>(cache.binding + 0x10u);
    const uintptr_t target = *reinterpret_cast<const uintptr_t*>(cache.binding + 0x18u);
    const uintptr_t selector = *reinterpret_cast<const uintptr_t*>(cache.binding + 0x20u);

    if (!address_in_libgame(binding_vtable) ||
        minus_one != static_cast<uintptr_t>(-1) ||
        signature != kBoxBindingSignature ||
        target != cache.target ||
        selector != expected_callback) {
        return -203;
    }

    const uintptr_t live_target_vtable = *reinterpret_cast<const uintptr_t*>(cache.target);
    if (live_target_vtable != expected_target_vtable) return -204;

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "BOX_ACTION CALL action=%s id=%d binding=%p target=%p callback=%p",
            profile->name,
            action_id,
            reinterpret_cast<void*>(cache.binding),
            reinterpret_cast<void*>(cache.target),
            reinterpret_cast<void*>(cache.callback)
    );

    using ActionFn = void (*)(void*);
    auto fn = reinterpret_cast<ActionFn>(cache.callback);
    fn(reinterpret_cast<void*>(cache.target));

    {
        std::lock_guard<std::mutex> lock(g_box_action_mutex);
        reset_box_action_cache_locked();
    }
    return 0;
}

uint32_t pre_run_signature_score(
        uintptr_t base,
        uintptr_t end,
        uintptr_t primary,
        uintptr_t v158,
        uintptr_t v168,
        uintptr_t v170,
        uintptr_t v178,
        uintptr_t v180) {
    constexpr uintptr_t kLastRequired = 0x180u + sizeof(uintptr_t);
    if (base > end || end - base < kLastRequired) return 0;

    uint32_t score = 0;
    if (*reinterpret_cast<const uintptr_t*>(base + 0x000u) == primary) ++score;
    if (*reinterpret_cast<const uintptr_t*>(base + 0x158u) == v158) ++score;
    if (*reinterpret_cast<const uintptr_t*>(base + 0x168u) == v168) ++score;
    if (*reinterpret_cast<const uintptr_t*>(base + 0x170u) == v170) ++score;
    if (*reinterpret_cast<const uintptr_t*>(base + 0x178u) == v178) ++score;
    if (*reinterpret_cast<const uintptr_t*>(base + 0x180u) == v180) ++score;
    return score;
}

int prepare_play2_locator() {
    reset_play2_locator_state();

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t profile[] = {
            gh_to_runtime(elf_base, kPreRunVtablePrimaryGh),
            gh_to_runtime(elf_base, kPreRunVtable158Gh),
            gh_to_runtime(elf_base, kPreRunVtable168Gh),
            gh_to_runtime(elf_base, kPreRunVtable170Gh),
            gh_to_runtime(elf_base, kPreRunVtable178Gh),
            gh_to_runtime(elf_base, kPreRunVtable180Gh)
    };
    for (uintptr_t address : profile) {
        if (!address_in_libgame(address)) return -45;
    }

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "PLAY2_LOCATOR V5 READY base=%p primary=%p",
            reinterpret_cast<void*>(elf_base),
            reinterpret_cast<void*>(profile[0])
    );
    return 0;
}

int locate_pre_run_screen() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t primary = gh_to_runtime(elf_base, kPreRunVtablePrimaryGh);
    const uintptr_t v158 = gh_to_runtime(elf_base, kPreRunVtable158Gh);
    const uintptr_t v168 = gh_to_runtime(elf_base, kPreRunVtable168Gh);
    const uintptr_t v170 = gh_to_runtime(elf_base, kPreRunVtable170Gh);
    const uintptr_t v178 = gh_to_runtime(elf_base, kPreRunVtable178Gh);
    const uintptr_t v180 = gh_to_runtime(elf_base, kPreRunVtable180Gh);

    if (!address_in_libgame(primary) || !address_in_libgame(v158) ||
        !address_in_libgame(v168) || !address_in_libgame(v170) ||
        !address_in_libgame(v178) || !address_in_libgame(v180)) {
        return -45;
    }

    g_play2_screen_base.store(0, std::memory_order_release);
    g_play2_context.store(0, std::memory_order_release);
    g_play2_locator_matches.store(0, std::memory_order_release);
    g_play2_locator_primary_hits.store(0, std::memory_order_release);
    g_play2_locator_scanned_bytes.store(0, std::memory_order_release);
    g_play2_locator_scanned_ranges.store(0, std::memory_order_release);
    g_play2_locator_best_base.store(0, std::memory_order_release);
    g_play2_locator_best_score.store(0, std::memory_order_release);
    g_play2_locator_mode.store(0, std::memory_order_release);

    FILE* fp = std::fopen("/proc/self/maps", "r");
    if (!fp) return -46;

    uintptr_t unique_base = 0;
    uint64_t exact_matches = 0;
    uint64_t primary_hits = 0;
    uint64_t scanned_bytes = 0;
    uint64_t scanned_ranges = 0;
    uintptr_t best_base = 0;
    uint32_t best_score = 0;
    const unsigned char primary_low_byte = static_cast<unsigned char>(primary & 0xffu);

    char line[1024];
    while (std::fgets(line, sizeof(line), fp)) {
        unsigned long long start_raw = 0;
        unsigned long long end_raw = 0;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path
        );
        if (parsed < 3) continue;
        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < 0x188u + sizeof(uintptr_t)) continue;

        ++scanned_ranges;
        scanned_bytes += static_cast<uint64_t>(end - start);

        const unsigned char* cursor = reinterpret_cast<const unsigned char*>(start);
        const unsigned char* limit = reinterpret_cast<const unsigned char*>(end);
        while (cursor + 0x188u + sizeof(uintptr_t) <= limit) {
            const std::size_t remaining = static_cast<std::size_t>(limit - cursor);
            const void* raw_hit = std::memchr(cursor, primary_low_byte, remaining);
            if (raw_hit == nullptr) break;

            const uintptr_t candidate = reinterpret_cast<uintptr_t>(raw_hit);
            cursor = reinterpret_cast<const unsigned char*>(candidate + 1u);
            if ((candidate & (alignof(uintptr_t) - 1u)) != 0) continue;
            if (candidate + 0x188u + sizeof(uintptr_t) > end) continue;

            uintptr_t first = 0;
            std::memcpy(&first, reinterpret_cast<const void*>(candidate), sizeof(first));
            if (first != primary) continue;

            ++primary_hits;
            const uint32_t score = pre_run_signature_score(
                    candidate,
                    end,
                    primary,
                    v158,
                    v168,
                    v170,
                    v178,
                    v180
            );
            if (score > best_score) {
                best_score = score;
                best_base = candidate;
            }

            if (score == 6u) {
                ++exact_matches;
                if (unique_base == 0) unique_base = candidate;
            }
        }
    }
    std::fclose(fp);

    g_play2_locator_matches.store(exact_matches, std::memory_order_release);
    g_play2_locator_primary_hits.store(primary_hits, std::memory_order_release);
    g_play2_locator_scanned_bytes.store(scanned_bytes, std::memory_order_release);
    g_play2_locator_scanned_ranges.store(scanned_ranges, std::memory_order_release);
    g_play2_locator_best_base.store(best_base, std::memory_order_release);
    g_play2_locator_best_score.store(best_score, std::memory_order_release);

    uintptr_t selected_base = 0;
    int selected_mode = 0;
    if (exact_matches == 1 && unique_base != 0) {
        selected_base = unique_base;
        selected_mode = 1;
    } else if (exact_matches == 0 && primary_hits == 1 && best_base != 0) {
        // V6: the five secondary vptrs observed in 013054B0 are written by the
        // destructor. A live most-derived PRE_RUN object is therefore allowed
        // to have different secondary interface vptrs. A UNIQUE primary vptr
        // across all writable native arenas is a strong locator candidate.
        // We do not dispatch Play #2 based on this alone: nativePlay2CodeTrigger
        // semantically validates base+0x188 through the game's own resolver+0x60
        // and refuses before Event69 if no valid snapshot is returned.
        selected_base = best_base;
        selected_mode = 2;
    }

    if (selected_base != 0) {
        const uintptr_t play_context = selected_base + 0x188u;
        if (!address_is_mapped(selected_base) || !address_is_mapped(play_context)) {
            return -24;
        }
        g_play2_screen_base.store(selected_base, std::memory_order_release);
        g_play2_context.store(selected_base + 0x180u, std::memory_order_release);
        g_play2_locator_mode.store(selected_mode, std::memory_order_release);
        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "PLAY2_LOCATOR V6 SELECT screen=%p mode=%s exact=%llu primaryHits=%llu best=%u/6 scanned=%llu",
                reinterpret_cast<void*>(selected_base),
                selected_mode == 1 ? "EXACT6" : "PRIMARY_UNIQUE",
                static_cast<unsigned long long>(exact_matches),
                static_cast<unsigned long long>(primary_hits),
                best_score,
                static_cast<unsigned long long>(scanned_bytes)
        );
        return 0;
    }

    __android_log_print(
            ANDROID_LOG_WARN,
            LOG_TAG,
            "PLAY2_LOCATOR V6 MISS matches=%llu primaryHits=%llu best=%u/6 bestBase=%p ranges=%llu bytes=%llu",
            static_cast<unsigned long long>(exact_matches),
            static_cast<unsigned long long>(primary_hits),
            best_score,
            reinterpret_cast<void*>(best_base),
            static_cast<unsigned long long>(scanned_ranges),
            static_cast<unsigned long long>(scanned_bytes)
    );
    if (exact_matches > 1) return -44;
    if (primary_hits > 1) return -47;
    return -43;
}


// -------------------------------------------------------------------------
// INTERNAL / LAB • Powder Pump one-round native bridge
// -------------------------------------------------------------------------
// BUY deliberately uses the game's real Treasure Shop page action instead of
// reconstructing its process/request graph. FUN_016856C8 requires page-owned
// callback/context fields (notably page+0x220); rebuilding it headlessly caused
// the game process to die before IPC could return.
//
// The page locator is READ ONLY and runs off the render/game thread. Once a
// unique live page is cached, the short BUY call runs on the hooked game thread.
constexpr uintptr_t kPowderItemVptrGh = 0x020EEDD0u;
constexpr uintptr_t kPowderDecode32Gh = 0x00D654F8u;
constexpr uintptr_t kPowderAllocGh = 0x02060408u;
constexpr uintptr_t kPowderAutoReleaseGh = 0x01E75B68u;
constexpr uintptr_t kPowderRetainGh = 0x01E75B58u;
constexpr uintptr_t kPowderReleaseGh = 0x01E75B38u;
constexpr uintptr_t kPowderExtractProcessCtorGh = 0x01371660u;
constexpr uintptr_t kPowderExtractProcessInitGh = 0x0137176Cu;
constexpr uintptr_t kPowderBreakDispatchGh = 0x01371998u;

// Direct request-level batch BREAK experiment. This deliberately avoids the
// selected-item UI tree used by FUN_01372200 and builds the same request
// object that FUN_01371998 creates, but with multiple FUN_01374BE0 entries.
constexpr uintptr_t kPowderBreakRequestCtorGh = 0x01374848u;
constexpr uintptr_t kPowderBreakRequestAddItemGh = 0x01374BE0u;
constexpr uintptr_t kPowderConfigGlobalGh = 0x022625F8u;
constexpr uintptr_t kPowderLookupPowderGh = 0x011983F8u;
constexpr uintptr_t kPowderLookupShardGh = 0x01198DDCu;

// CRXTreasure main/shop page constructor FUN_016822DC.
// These vptrs are written directly by the constructor and form an exact live
// object signature for the page that owns +0x230 TreasureBox entry vector.
constexpr uintptr_t kPowderPageVptrPrimaryGh = 0x02195098u;
constexpr uintptr_t kPowderPageVptr158Gh = 0x021955A0u;
constexpr uintptr_t kPowderPageVptr160Gh = 0x02195600u;
constexpr uintptr_t kPowderPageVptr168Gh = 0x02195618u;
constexpr uintptr_t kPowderPageVptr180Gh = 0x02195638u;
constexpr uintptr_t kPowderPageVptr210Gh = 0x02195668u;
constexpr uintptr_t kPowderPageVptr218Gh = 0x02195698u;
constexpr uintptr_t kPowderPageVptr220Gh = 0x021956C8u;

// Exact Box1 UI action. It performs the game's own availability/network gate,
// then calls FUN_016856C8(page, 0, 0) with all page-owned lifecycle context.
constexpr uintptr_t kPowderBuyBox1ActionGh = 0x0168494Cu;

// Game-owned network-failure/title reload flow. FUN_015D87D4 reaches this
// no-argument routine after the common network error handler selects the
// go-title/reload path. Calling it on the CookieRun game thread lets Pump exit
// the Treasure result scene cleanly without deliberately sending a bad request.
constexpr uintptr_t kPowderForceGoTitleReloadGh = 0x015D899Cu;

std::atomic<uintptr_t> g_powder_treasure_page{0};
std::atomic<uint64_t> g_powder_page_exact_matches{0};
std::atomic<uint64_t> g_powder_page_primary_hits{0};
std::atomic<uintptr_t> g_powder_page_best_base{0};
std::atomic<uint32_t> g_powder_page_best_score{0};
std::atomic<uint64_t> g_powder_page_scanned_bytes{0};
std::atomic<uint64_t> g_powder_page_scanned_ranges{0};
std::atomic<uintptr_t> g_powder_break_owner{0};

// BREAK success popup still owns callbacks into its process after the
// inventory/powder delta has already landed. Releasing the Lab retain at that
// moment causes a use-after-free when the user presses Confirm.
//
// Per-round cleanup therefore *retires* the current process here without
// releasing it. A later explicit Lab cleanup, after the result popup has been
// confirmed/closed, releases every retired retain safely.
std::mutex g_powder_retired_mutex;
std::vector<uintptr_t> g_powder_retired_break_processes;
std::atomic<int> g_powder_page_ready_stage{0};
std::atomic<uintptr_t> g_powder_diag_begin{0};
std::atomic<uintptr_t> g_powder_diag_end{0};
std::atomic<uintptr_t> g_powder_diag_cap{0};
std::atomic<uintptr_t> g_powder_diag_entry{0};
std::atomic<uintptr_t> g_powder_diag_stuff_a{0};
std::atomic<uintptr_t> g_powder_diag_stuff_b{0};
std::atomic<uintptr_t> g_powder_diag_price_a{0};
std::atomic<uintptr_t> g_powder_diag_price_b{0};
std::atomic<uint32_t> g_powder_diag_buy_type{0};
std::atomic<uint64_t> g_powder_diag_count{0};

uintptr_t powder_fn(uintptr_t elf_base, uintptr_t gh) {
    const uintptr_t address = gh_to_runtime(elf_base, gh);
    return address_in_libgame(address) ? address : 0;
}

void reset_powder_page_locator() {
    g_powder_treasure_page.store(0, std::memory_order_release);
    g_powder_page_exact_matches.store(0, std::memory_order_release);
    g_powder_page_primary_hits.store(0, std::memory_order_release);
    g_powder_page_best_base.store(0, std::memory_order_release);
    g_powder_page_best_score.store(0, std::memory_order_release);
    g_powder_page_scanned_bytes.store(0, std::memory_order_release);
    g_powder_page_scanned_ranges.store(0, std::memory_order_release);
    g_powder_page_ready_stage.store(0, std::memory_order_release);
    g_powder_diag_begin.store(0, std::memory_order_release);
    g_powder_diag_end.store(0, std::memory_order_release);
    g_powder_diag_cap.store(0, std::memory_order_release);
    g_powder_diag_entry.store(0, std::memory_order_release);
    g_powder_diag_stuff_a.store(0, std::memory_order_release);
    g_powder_diag_stuff_b.store(0, std::memory_order_release);
    g_powder_diag_price_a.store(0, std::memory_order_release);
    g_powder_diag_price_b.store(0, std::memory_order_release);
    g_powder_diag_buy_type.store(0, std::memory_order_release);
    g_powder_diag_count.store(0, std::memory_order_release);
}

uint32_t powder_page_signature_score(
        uintptr_t candidate,
        uintptr_t map_end,
        const uintptr_t profile[8]) {
    // Need all secondary vptrs plus the TreasureBox vector/capacity.
    if (candidate > map_end || map_end - candidate < 0x248u) return 0;

    uint32_t score = 0;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x000u) == profile[0]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x158u) == profile[1]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x160u) == profile[2]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x168u) == profile[3]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x180u) == profile[4]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x210u) == profile[5]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x218u) == profile[6]) ++score;
    if (*reinterpret_cast<const uintptr_t*>(candidate + 0x220u) == profile[7]) ++score;
    return score;
}

int powder_page_readiness_stage(uintptr_t page, bool record_diag) {
    // V4 diagnostic-safe readiness. Return 100 only when every field consumed
    // by FUN_016856C8(page,0,0) is structurally available.
    // Stages intentionally never call game code and never mutate game memory.
    auto rec = [record_diag](std::atomic<int>& slot, int value) {
        if (record_diag) slot.store(value, std::memory_order_release);
    };

    if (!mapped_pointer_value(page) || !address_is_mapped(page + 0x240u)) {
        if (record_diag) g_powder_page_ready_stage.store(1, std::memory_order_release);
        return 1; // PAGE_UNMAPPED
    }
    if (!address_is_mapped(page + 0x220u)) {
        if (record_diag) g_powder_page_ready_stage.store(2, std::memory_order_release);
        return 2; // OWNER_UNMAPPED
    }

    const uintptr_t begin = *reinterpret_cast<const uintptr_t*>(page + 0x230u);
    const uintptr_t end = *reinterpret_cast<const uintptr_t*>(page + 0x238u);
    const uintptr_t cap = *reinterpret_cast<const uintptr_t*>(page + 0x240u);
    if (record_diag) {
        g_powder_diag_begin.store(begin, std::memory_order_release);
        g_powder_diag_end.store(end, std::memory_order_release);
        g_powder_diag_cap.store(cap, std::memory_order_release);
    }

    if (begin == 0 || end == 0 || cap == 0) {
        if (record_diag) g_powder_page_ready_stage.store(3, std::memory_order_release);
        return 3; // VECTOR_NULL
    }
    if (!mapped_pointer_value(begin) || end < begin || cap < end) {
        if (record_diag) g_powder_page_ready_stage.store(4, std::memory_order_release);
        return 4; // VECTOR_INVALID
    }
    if (((end - begin) % sizeof(uintptr_t)) != 0) {
        if (record_diag) g_powder_page_ready_stage.store(5, std::memory_order_release);
        return 5; // VECTOR_MISALIGNED
    }

    const std::size_t count = (end - begin) / sizeof(uintptr_t);
    if (record_diag) g_powder_diag_count.store(count, std::memory_order_release);
    if (count == 0u) {
        if (record_diag) g_powder_page_ready_stage.store(6, std::memory_order_release);
        return 6; // VECTOR_EMPTY
    }
    if (count > 16u || !address_is_mapped(begin)) {
        if (record_diag) g_powder_page_ready_stage.store(7, std::memory_order_release);
        return 7; // VECTOR_RANGE
    }

    const uintptr_t entry = *reinterpret_cast<const uintptr_t*>(begin);
    if (record_diag) g_powder_diag_entry.store(entry, std::memory_order_release);
    if (!mapped_pointer_value(entry) || !address_is_mapped(entry + 0x58u)) {
        if (record_diag) g_powder_page_ready_stage.store(8, std::memory_order_release);
        return 8; // ENTRY0_INVALID
    }

    const uintptr_t stuff_a = *reinterpret_cast<const uintptr_t*>(entry + 0x20u);
    const uintptr_t stuff_b = *reinterpret_cast<const uintptr_t*>(entry + 0x28u);
    const uintptr_t price_a = *reinterpret_cast<const uintptr_t*>(entry + 0x50u);
    const uintptr_t price_b = *reinterpret_cast<const uintptr_t*>(entry + 0x58u);
    const std::uint32_t buy_type = *reinterpret_cast<const std::uint32_t*>(entry + 0x44u);
    if (record_diag) {
        g_powder_diag_stuff_a.store(stuff_a, std::memory_order_release);
        g_powder_diag_stuff_b.store(stuff_b, std::memory_order_release);
        g_powder_diag_price_a.store(price_a, std::memory_order_release);
        g_powder_diag_price_b.store(price_b, std::memory_order_release);
        g_powder_diag_buy_type.store(buy_type, std::memory_order_release);
    }

    if (!mapped_pointer_value(stuff_a) || !mapped_pointer_value(stuff_b)) {
        if (record_diag) g_powder_page_ready_stage.store(9, std::memory_order_release);
        return 9; // STUFF_PROTECTED_PTR
    }
    if (!mapped_pointer_value(price_a) || !mapped_pointer_value(price_b)) {
        if (record_diag) g_powder_page_ready_stage.store(10, std::memory_order_release);
        return 10; // PRICE_PROTECTED_PTR
    }
    if (buy_type > 0x20u) {
        if (record_diag) g_powder_page_ready_stage.store(11, std::memory_order_release);
        return 11; // BUYTYPE_INVALID
    }

    if (record_diag) g_powder_page_ready_stage.store(100, std::memory_order_release);
    return 100;
}

bool powder_page_vector_ready(uintptr_t page) {
    return powder_page_readiness_stage(page, false) == 100;
}

int locate_powder_treasure_page() {
    reset_powder_page_locator();

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t profile[8] = {
            gh_to_runtime(elf_base, kPowderPageVptrPrimaryGh),
            gh_to_runtime(elf_base, kPowderPageVptr158Gh),
            gh_to_runtime(elf_base, kPowderPageVptr160Gh),
            gh_to_runtime(elf_base, kPowderPageVptr168Gh),
            gh_to_runtime(elf_base, kPowderPageVptr180Gh),
            gh_to_runtime(elf_base, kPowderPageVptr210Gh),
            gh_to_runtime(elf_base, kPowderPageVptr218Gh),
            gh_to_runtime(elf_base, kPowderPageVptr220Gh)
    };
    for (uintptr_t address : profile) {
        if (!address_in_libgame(address)) return -120;
    }

    FILE* fp = std::fopen("/proc/self/maps", "r");
    if (!fp) return -121;

    uintptr_t unique_base = 0;
    uintptr_t best_base = 0;
    uint32_t best_score = 0;
    uint64_t exact_matches = 0;
    uint64_t primary_hits = 0;
    uint64_t scanned_bytes = 0;
    uint64_t scanned_ranges = 0;
    const unsigned char primary_low = static_cast<unsigned char>(profile[0] & 0xffu);

    char line[1024];
    while (std::fgets(line, sizeof(line), fp)) {
        unsigned long long start_raw = 0;
        unsigned long long end_raw = 0;
        char perms[8] = {};
        char path[768] = {};
        const int parsed = std::sscanf(
                line,
                "%llx-%llx %7s %*s %*s %*s %767[^\n]",
                &start_raw,
                &end_raw,
                perms,
                path
        );
        if (parsed < 3) continue;
        const char* map_path = parsed == 4 ? path : "";
        if (!locator_mapping_allowed(perms, map_path)) continue;

        const uintptr_t start = static_cast<uintptr_t>(start_raw);
        const uintptr_t end = static_cast<uintptr_t>(end_raw);
        if (end <= start || end - start < 0x320u) continue;

        ++scanned_ranges;
        scanned_bytes += static_cast<uint64_t>(end - start);

        const unsigned char* cursor = reinterpret_cast<const unsigned char*>(start);
        const unsigned char* limit = reinterpret_cast<const unsigned char*>(end);

        while (cursor + 0x320u <= limit) {
            const std::size_t remaining = static_cast<std::size_t>(limit - cursor);
            const void* raw_hit = std::memchr(cursor, primary_low, remaining);
            if (raw_hit == nullptr) break;

            const uintptr_t candidate = reinterpret_cast<uintptr_t>(raw_hit);
            cursor = reinterpret_cast<const unsigned char*>(candidate + 1u);

            if ((candidate & (alignof(uintptr_t) - 1u)) != 0) continue;
            if (candidate + 0x320u > end) continue;

            uintptr_t first = 0;
            std::memcpy(&first, reinterpret_cast<const void*>(candidate), sizeof(first));
            if (first != profile[0]) continue;

            ++primary_hits;
            const uint32_t score =
                    powder_page_signature_score(candidate, end, profile);

            if (score > best_score) {
                best_score = score;
                best_base = candidate;
            }

            if (score == 8u) {
                const int ready_stage = powder_page_readiness_stage(candidate, true);
                if (ready_stage == 100) {
                    ++exact_matches;
                    if (unique_base == 0) unique_base = candidate;
                }
            }
        }
    }
    std::fclose(fp);

    g_powder_page_exact_matches.store(exact_matches, std::memory_order_release);
    g_powder_page_primary_hits.store(primary_hits, std::memory_order_release);
    g_powder_page_best_base.store(best_base, std::memory_order_release);
    g_powder_page_best_score.store(best_score, std::memory_order_release);
    g_powder_page_scanned_bytes.store(scanned_bytes, std::memory_order_release);
    g_powder_page_scanned_ranges.store(scanned_ranges, std::memory_order_release);

    if (exact_matches == 1u && unique_base != 0) {
        g_powder_treasure_page.store(unique_base, std::memory_order_release);
        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "POWDER_LAB PAGE FOUND page=%p exact=%llu primaryHits=%llu best=%u/8 scannedMiB=%.1f",
                reinterpret_cast<void*>(unique_base),
                static_cast<unsigned long long>(exact_matches),
                static_cast<unsigned long long>(primary_hits),
                best_score,
                static_cast<double>(scanned_bytes) / (1024.0 * 1024.0)
        );
        return 0;
    }

    __android_log_print(
            ANDROID_LOG_WARN,
            LOG_TAG,
            "POWDER_LAB PAGE MISS exact=%llu primaryHits=%llu best=%u/8 bestBase=%p",
            static_cast<unsigned long long>(exact_matches),
            static_cast<unsigned long long>(primary_hits),
            best_score,
            reinterpret_cast<void*>(best_base)
    );

    if (exact_matches > 1u) return -123;
    if (primary_hits > 0u) return -124;  // page exists but not fully ready/bound
    return -122;                         // Treasure Shop page is not live
}


const char* powder_ready_stage_name(int stage) {
    switch (stage) {
        case 1: return "PAGE_UNMAPPED";
        case 2: return "OWNER_UNMAPPED";
        case 3: return "VECTOR_NULL";
        case 4: return "VECTOR_INVALID";
        case 5: return "VECTOR_MISALIGNED";
        case 6: return "VECTOR_EMPTY";
        case 7: return "VECTOR_RANGE";
        case 8: return "ENTRY0_INVALID";
        case 9: return "STUFF_PROTECTED_PTR";
        case 10: return "PRICE_PROTECTED_PTR";
        case 11: return "BUYTYPE_INVALID";
        case 100: return "READY";
        default: return "NOT_CHECKED";
    }
}

std::string powder_page_diagnostics() {
    char buf[1024];
    const int stage = g_powder_page_ready_stage.load(std::memory_order_acquire);
    const auto best = g_powder_page_best_base.load(std::memory_order_acquire);
    const auto score = g_powder_page_best_score.load(std::memory_order_acquire);
    const auto primary = g_powder_page_primary_hits.load(std::memory_order_acquire);
    const auto exact = g_powder_page_exact_matches.load(std::memory_order_acquire);
    const auto begin = g_powder_diag_begin.load(std::memory_order_acquire);
    const auto end = g_powder_diag_end.load(std::memory_order_acquire);
    const auto cap = g_powder_diag_cap.load(std::memory_order_acquire);
    const auto count = g_powder_diag_count.load(std::memory_order_acquire);
    const auto entry = g_powder_diag_entry.load(std::memory_order_acquire);
    const auto stuff_a = g_powder_diag_stuff_a.load(std::memory_order_acquire);
    const auto stuff_b = g_powder_diag_stuff_b.load(std::memory_order_acquire);
    const auto price_a = g_powder_diag_price_a.load(std::memory_order_acquire);
    const auto price_b = g_powder_diag_price_b.load(std::memory_order_acquire);
    const auto buy_type = g_powder_diag_buy_type.load(std::memory_order_acquire);

    // FUN_016828E0 is the game's own Treasure-count refresh:
    //   page+0x258 = Cabinet capacity
    //   page+0x260 = occupied Treasure slots
    //   page+0x250 = full flag
    // Read these only after the exact live page has been located.
    std::uint64_t cabinet_capacity = 0;
    std::uint64_t cabinet_occupied = 0;
    std::uint32_t cabinet_full = 0;
    if (stage == 100 && mapped_pointer_value(best) &&
        address_is_mapped(best + 0x268u)) {
        cabinet_capacity = *reinterpret_cast<const std::uint64_t*>(best + 0x258u);
        cabinet_occupied = *reinterpret_cast<const std::uint64_t*>(best + 0x260u);
        cabinet_full = *reinterpret_cast<const std::uint8_t*>(best + 0x250u) ? 1u : 0u;
    }

    std::snprintf(
            buf, sizeof(buf),
            "stage=%s(%d) best=%p score=%u/8 primary=%llu exact=%llu "
            "vec=%p..%p cap=%p count=%llu entry0=%p "
            "stuffA=%p stuffB=%p priceA=%p priceB=%p buyType=%u "
            "cabinetCapacity=%llu cabinetOccupied=%llu cabinetFull=%u",
            powder_ready_stage_name(stage), stage,
            reinterpret_cast<void*>(best), score,
            static_cast<unsigned long long>(primary),
            static_cast<unsigned long long>(exact),
            reinterpret_cast<void*>(begin),
            reinterpret_cast<void*>(end),
            reinterpret_cast<void*>(cap),
            static_cast<unsigned long long>(count),
            reinterpret_cast<void*>(entry),
            reinterpret_cast<void*>(stuff_a),
            reinterpret_cast<void*>(stuff_b),
            reinterpret_cast<void*>(price_a),
            reinterpret_cast<void*>(price_b),
            buy_type,
            static_cast<unsigned long long>(cabinet_capacity),
            static_cast<unsigned long long>(cabinet_occupied),
            cabinet_full
    );
    return std::string(buf);
}

int powder_cleanup_retained() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;
    const uintptr_t release_addr = powder_fn(elf_base, kPowderReleaseGh);
    if (release_addr == 0) return -114;

    using ReleaseFn = void (*)(void*);
    auto release_fn = reinterpret_cast<ReleaseFn>(release_addr);

    // Phase 1 (called automatically after each verified BREAK):
    // clear the single-flight gate, but DO NOT release the process yet.
    // The game's "Extraction successful!" popup can still call back into it.
    const uintptr_t active =
            g_powder_break_owner.exchange(0, std::memory_order_acq_rel);
    if (mapped_pointer_value(active)) {
        std::size_t retained_count = 0;
        {
            std::lock_guard<std::mutex> lock(g_powder_retired_mutex);
            g_powder_retired_break_processes.push_back(active);
            retained_count = g_powder_retired_break_processes.size();
        }
        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "POWDER_LAB BREAK retired for popup callback safety process=%p retained=%zu",
                reinterpret_cast<void*>(active),
                retained_count
        );
        // 1 = current process safely retired; caller may start the next round.
        return 1;
    }

    // Phase 2 (explicit Lab Cleanup button, after Confirm/closing popup):
    // no request is in flight, so release all deferred retains.
    std::vector<uintptr_t> retired;
    {
        std::lock_guard<std::mutex> lock(g_powder_retired_mutex);
        retired.swap(g_powder_retired_break_processes);
    }

    std::size_t released = 0;
    for (const uintptr_t process : retired) {
        if (!mapped_pointer_value(process)) continue;
        release_fn(reinterpret_cast<void*>(process));
        ++released;
    }

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB deferred retain cleanup released=%zu",
            released
    );
    // 0 = deferred retain list released (or already empty).
    return 0;
}

int powder_buy_box1() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t page = g_powder_treasure_page.load(std::memory_order_acquire);
    if (!mapped_pointer_value(page)) return -122;

    const uintptr_t expected_vptr =
            gh_to_runtime(elf_base, kPowderPageVptrPrimaryGh);
    if (*reinterpret_cast<const uintptr_t*>(page) != expected_vptr ||
        !powder_page_vector_ready(page)) {
        g_powder_treasure_page.store(0, std::memory_order_release);
        return -125;
    }

    const uintptr_t action_addr = powder_fn(elf_base, kPowderBuyBox1ActionGh);
    if (action_addr == 0) return -126;

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB BUY high-level page=%p action=%p",
            reinterpret_cast<void*>(page),
            reinterpret_cast<void*>(action_addr)
    );

    using BuyActionFn = void (*)(void*);
    reinterpret_cast<BuyActionFn>(action_addr)(reinterpret_cast<void*>(page));

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB BUY high-level returned page=%p",
            reinterpret_cast<void*>(page)
    );
    return 0;
}


int powder_buy_box1_burst(int count) {
    if (count <= 0 || count > 128) return -127;

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t page = g_powder_treasure_page.load(std::memory_order_acquire);
    if (!mapped_pointer_value(page)) return -122;

    const uintptr_t expected_vptr =
            gh_to_runtime(elf_base, kPowderPageVptrPrimaryGh);
    if (*reinterpret_cast<const uintptr_t*>(page) != expected_vptr ||
        !powder_page_vector_ready(page)) {
        g_powder_treasure_page.store(0, std::memory_order_release);
        return -125;
    }

    const uintptr_t action_addr = powder_fn(elf_base, kPowderBuyBox1ActionGh);
    if (action_addr == 0) return -126;

    using BuyActionFn = void (*)(void*);
    auto action_fn = reinterpret_cast<BuyActionFn>(action_addr);

    // Turbo Lab:
    // Dispatch exactly `count` Normal Box1 high-level actions back-to-back on
    // the CookieRun game thread. The server remains authoritative for every
    // purchase/result; this only removes the client-side wait between actions.
    for (int i = 0; i < count; ++i) {
        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "POWDER_LAB BURST BUY dispatch %d/%d page=%p currentSeq=%p",
                i + 1,
                count,
                reinterpret_cast<void*>(page),
                reinterpret_cast<void*>(
                        *reinterpret_cast<uintptr_t*>(page + 0x268u)
                )
        );
        action_fn(reinterpret_cast<void*>(page));
    }

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB BURST BUY all actions returned count=%d page=%p currentSeq=%p",
            count,
            reinterpret_cast<void*>(page),
            reinterpret_cast<void*>(
                    *reinterpret_cast<uintptr_t*>(page + 0x268u)
            )
    );
    return count;
}


int powder_force_go_title_reload() {
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t reload_addr =
            powder_fn(elf_base, kPowderForceGoTitleReloadGh);
    if (reload_addr == 0) return -141;

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB FORCE_RELOAD game-owned addr=%p",
            reinterpret_cast<void*>(reload_addr)
    );

    // The cached Treasure page becomes invalid as soon as the scene changes.
    reset_powder_page_locator();

    using ReloadFn = void (*)();
    reinterpret_cast<ReloadFn>(reload_addr)();

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB FORCE_RELOAD returned"
    );
    return 0;
}


struct PowderBatchEntry {
    uintptr_t item;
    std::uint32_t group_seq;
    std::uint32_t tag;
    std::int32_t powder_per_item;
    std::int32_t shard_per_item;
};

int powder_compute_item_values(
        uintptr_t elf_base,
        uintptr_t item,
        PowderBatchEntry* out_entry) {
    if (!out_entry) return -1321;
    if (!mapped_pointer_value(item) || !address_is_mapped(item + 0xD0u)) {
        return -1322;
    }

    const uintptr_t expected_vptr = gh_to_runtime(elf_base, kPowderItemVptrGh);
    const uintptr_t actual_vptr = *reinterpret_cast<uintptr_t*>(item);
    const std::uint32_t type = *reinterpret_cast<std::uint32_t*>(item + 0xD0u);
    if (actual_vptr != expected_vptr || type != 27u) {
        return -1323;
    }

    const uintptr_t decode32_addr = powder_fn(elf_base, kPowderDecode32Gh);
    const uintptr_t alloc_addr = powder_fn(elf_base, kPowderAllocGh);
    const uintptr_t autorelease_addr = powder_fn(elf_base, kPowderAutoReleaseGh);
    const uintptr_t process_ctor_addr =
            powder_fn(elf_base, kPowderExtractProcessCtorGh);
    const uintptr_t process_init_addr =
            powder_fn(elf_base, kPowderExtractProcessInitGh);

    if (decode32_addr == 0 || alloc_addr == 0 || autorelease_addr == 0 ||
        process_ctor_addr == 0 || process_init_addr == 0) {
        return -1324;
    }

    using Decode32Fn = std::uint32_t (*)(void*, std::uint64_t);
    using AllocFn = void* (*)(std::size_t);
    using ObjectFn = void (*)(void*);
    using InitFn = void (*)(void*, void*);

    auto decode32 = reinterpret_cast<Decode32Fn>(decode32_addr);
    auto alloc_fn = reinterpret_cast<AllocFn>(alloc_addr);
    auto autorelease_fn = reinterpret_cast<ObjectFn>(autorelease_addr);
    auto process_ctor = reinterpret_cast<ObjectFn>(process_ctor_addr);
    auto process_init = reinterpret_cast<InitFn>(process_init_addr);

    const std::uint32_t group_seq =
            decode32(reinterpret_cast<void*>(item + 0x80u), 1);
    const std::uint32_t tag =
            decode32(reinterpret_cast<void*>(item + 0xA8u), 1);

    // Resolver A:
    // Reuse the exact game-owned initializer used by the already verified
    // single BREAK path. Initialize first, read synchronously, then put the
    // probe in the autorelease pool. V9/V9.1 autoreleased before init.
    std::int32_t powder_per_item = 0;
    std::int32_t shard_per_item = 0;
    bool resolved = false;

    void* probe = alloc_fn(0x80u);
    if (probe != nullptr) {
        process_ctor(probe);
        process_init(probe, reinterpret_cast<void*>(item));

        const uintptr_t probe_addr = reinterpret_cast<uintptr_t>(probe);
        const std::int32_t p =
                *reinterpret_cast<std::int32_t*>(probe_addr + 0x60u);
        const std::int32_t s =
                *reinterpret_cast<std::int32_t*>(probe_addr + 0x64u);

        // Match observed server semantics: Powder-only items may have no shard.
        if (p > 0) {
            powder_per_item = p;
            shard_per_item = s < 0 ? 0 : s;
            resolved = true;
        }

        autorelease_fn(probe);

        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "POWDER_LAB BATCH resolverA item=%p group=%u tag=%u p=%d s=%d resolved=%d",
                reinterpret_cast<void*>(item),
                group_seq,
                tag,
                p,
                s,
                resolved ? 1 : 0
        );
    }

    // Resolver B fallback:
    // Use the game's powder/shard config manager by groupSeq+tag. This is the
    // same config family previously verified against real +3/+15 server deltas.
    if (!resolved) {
        const uintptr_t powder_lookup_addr =
                powder_fn(elf_base, kPowderLookupPowderGh);
        const uintptr_t shard_lookup_addr =
                powder_fn(elf_base, kPowderLookupShardGh);
        const uintptr_t config_global_addr =
                powder_fn(elf_base, kPowderConfigGlobalGh);

        if (powder_lookup_addr == 0 || shard_lookup_addr == 0 ||
            config_global_addr == 0) {
            return -1325;
        }

        const uintptr_t config =
                *reinterpret_cast<uintptr_t*>(config_global_addr);
        if (!mapped_pointer_value(config)) {
            return -1326;
        }

        using LookupFn =
                uintptr_t (*)(void*, std::uint32_t, std::uint32_t);
        auto powder_lookup =
                reinterpret_cast<LookupFn>(powder_lookup_addr);
        auto shard_lookup =
                reinterpret_cast<LookupFn>(shard_lookup_addr);

        const uintptr_t powder_data =
                powder_lookup(reinterpret_cast<void*>(config), group_seq, tag);

        if (!mapped_pointer_value(powder_data) ||
            !address_is_mapped(powder_data + 0x88u)) {
            return -1327;
        }

        const std::int32_t p = static_cast<std::int32_t>(
                decode32(reinterpret_cast<void*>(powder_data + 0x80u), 1));

        std::int32_t s = 0;
        const uintptr_t shard_data =
                shard_lookup(reinterpret_cast<void*>(config), group_seq, tag);
        if (mapped_pointer_value(shard_data) &&
            address_is_mapped(shard_data + 0x60u)) {
            s = static_cast<std::int32_t>(
                    decode32(reinterpret_cast<void*>(shard_data + 0x58u), 1));
            if (s < 0) s = 0;
        }

        if (p <= 0) {
            return -1328;
        }

        powder_per_item = p;
        shard_per_item = s;
        resolved = true;

        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "POWDER_LAB BATCH resolverB item=%p group=%u tag=%u p=%d s=%d",
                reinterpret_cast<void*>(item),
                group_seq,
                tag,
                powder_per_item,
                shard_per_item
        );
    }

    if (!resolved || powder_per_item <= 0) {
        return -1329;
    }

    out_entry->item = item;
    out_entry->group_seq = group_seq;
    out_entry->tag = tag;
    out_entry->powder_per_item = powder_per_item;
    out_entry->shard_per_item = shard_per_item;
    return 0;
}


int powder_break_items_batch(const std::vector<uintptr_t>& items) {
    if (g_powder_break_owner.load(std::memory_order_acquire) != 0) return -113;
    if (items.empty()) return -130;
    if (items.size() > 20u) return -131;

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t alloc_addr = powder_fn(elf_base, kPowderAllocGh);
    const uintptr_t autorelease_addr = powder_fn(elf_base, kPowderAutoReleaseGh);
    const uintptr_t retain_addr = powder_fn(elf_base, kPowderRetainGh);
    const uintptr_t process_ctor_addr = powder_fn(elf_base, kPowderExtractProcessCtorGh);
    const uintptr_t process_init_addr = powder_fn(elf_base, kPowderExtractProcessInitGh);
    const uintptr_t request_ctor_addr = powder_fn(elf_base, kPowderBreakRequestCtorGh);
    const uintptr_t request_add_item_addr = powder_fn(elf_base, kPowderBreakRequestAddItemGh);
    if (alloc_addr == 0 || autorelease_addr == 0 || retain_addr == 0 ||
        process_ctor_addr == 0 || process_init_addr == 0 ||
        request_ctor_addr == 0 || request_add_item_addr == 0) {
        return -112;
    }

    std::vector<PowderBatchEntry> entries;
    entries.reserve(items.size());
    std::uint64_t total_powder = 0;
    std::uint64_t total_shard = 0;
    for (std::size_t i = 0; i < items.size(); ++i) {
        const uintptr_t item = items[i];
        PowderBatchEntry entry{};
        const int resolve_rc =
                powder_compute_item_values(elf_base, item, &entry);
        if (resolve_rc != 0) {
            __android_log_print(
                    ANDROID_LOG_ERROR,
                    LOG_TAG,
                    "POWDER_LAB BATCH preflight failed index=%zu item=%p rc=%d",
                    i,
                    reinterpret_cast<void*>(item),
                    resolve_rc
            );
            return resolve_rc;
        }
        entries.push_back(entry);
        total_powder += static_cast<std::uint64_t>(entry.powder_per_item);
        total_shard += static_cast<std::uint64_t>(entry.shard_per_item);
    }
    if (entries.empty() || total_powder == 0u) return -133;

    using AllocFn = void* (*)(std::size_t);
    using ObjectFn = void (*)(void*);
    using InitFn = void (*)(void*, void*);
    using RequestAddItemFn = void (*)(void*, void*, std::uint64_t);
    using StartFn = void (*)(void*);

    auto alloc_fn = reinterpret_cast<AllocFn>(alloc_addr);
    auto autorelease_fn = reinterpret_cast<ObjectFn>(autorelease_addr);
    auto retain_fn = reinterpret_cast<ObjectFn>(retain_addr);
    auto process_ctor = reinterpret_cast<ObjectFn>(process_ctor_addr);
    auto process_init = reinterpret_cast<InitFn>(process_init_addr);
    auto request_ctor = reinterpret_cast<ObjectFn>(request_ctor_addr);
    auto request_add_item = reinterpret_cast<RequestAddItemFn>(request_add_item_addr);

    // Use the already verified single-extract process as a safe callback owner.
    // The request itself carries the complete multi-item payload and total qty.
    void* process = alloc_fn(0x80u);
    if (!process) return -115;
    process_ctor(process);
    autorelease_fn(process);
    process_init(process, reinterpret_cast<void*>(entries.front().item));
    *reinterpret_cast<std::uint64_t*>(reinterpret_cast<uintptr_t>(process) + 0x68u) = 1u;

    void* request = alloc_fn(0xA0u);
    if (!request) return -134;
    request_ctor(request);
    autorelease_fn(request);

    for (const PowderBatchEntry& entry : entries) {
        request_add_item(request, reinterpret_cast<void*>(entry.item), 1u);
    }

    const uintptr_t request_addr = reinterpret_cast<uintptr_t>(request);
    const uintptr_t process_addr = reinterpret_cast<uintptr_t>(process);
    *reinterpret_cast<std::uint64_t*>(request_addr + 0x80u) = total_powder;
    *reinterpret_cast<std::uint64_t*>(request_addr + 0x88u) = total_shard;
    *reinterpret_cast<uintptr_t*>(request_addr + 0x18u) = process_addr + 0x50u;

    retain_fn(process);
    g_powder_break_owner.store(process_addr, std::memory_order_release);
    retain_fn(request);

    auto start_fn = reinterpret_cast<StartFn>(*reinterpret_cast<uintptr_t*>(
            *reinterpret_cast<uintptr_t*>(request_addr) + 0x30u));

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB BATCH_BREAK dispatch count=%zu powder=%llu shard=%llu process=%p request=%p first=%p",
            entries.size(),
            static_cast<unsigned long long>(total_powder),
            static_cast<unsigned long long>(total_shard),
            process,
            request,
            reinterpret_cast<void*>(entries.front().item)
    );

    start_fn(request);
    return static_cast<int>(entries.size());
}

int powder_break_item(uintptr_t item) {
    if (g_powder_break_owner.load(std::memory_order_acquire) != 0) return -113;
    if (!mapped_pointer_value(item) || !address_is_mapped(item + 0xD0u)) return -110;

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t expected_vptr = gh_to_runtime(elf_base, kPowderItemVptrGh);
    const uintptr_t actual_vptr = *reinterpret_cast<uintptr_t*>(item);
    const std::uint32_t type = *reinterpret_cast<std::uint32_t*>(item + 0xD0u);
    if (actual_vptr != expected_vptr || type != 27u) return -111;

    const uintptr_t alloc_addr = powder_fn(elf_base, kPowderAllocGh);
    const uintptr_t autorelease_addr = powder_fn(elf_base, kPowderAutoReleaseGh);
    const uintptr_t retain_addr = powder_fn(elf_base, kPowderRetainGh);
    const uintptr_t release_addr = powder_fn(elf_base, kPowderReleaseGh);
    const uintptr_t process_ctor_addr = powder_fn(elf_base, kPowderExtractProcessCtorGh);
    const uintptr_t process_init_addr = powder_fn(elf_base, kPowderExtractProcessInitGh);
    const uintptr_t break_dispatch_addr = powder_fn(elf_base, kPowderBreakDispatchGh);
    const uintptr_t decode32_addr = powder_fn(elf_base, kPowderDecode32Gh);

    if (alloc_addr == 0 || autorelease_addr == 0 || retain_addr == 0 ||
        release_addr == 0 || process_ctor_addr == 0 || process_init_addr == 0 ||
        break_dispatch_addr == 0 || decode32_addr == 0) {
        return -112;
    }

    using AllocFn = void* (*)(std::size_t);
    using ObjectFn = void (*)(void*);
    using InitFn = void (*)(void*, void*);
    using Decode32Fn = std::uint32_t (*)(void*, std::uint64_t);

    auto alloc_fn = reinterpret_cast<AllocFn>(alloc_addr);
    auto autorelease_fn = reinterpret_cast<ObjectFn>(autorelease_addr);
    auto retain_fn = reinterpret_cast<ObjectFn>(retain_addr);
    auto release_fn = reinterpret_cast<ObjectFn>(release_addr);
    auto process_ctor = reinterpret_cast<ObjectFn>(process_ctor_addr);
    auto process_init = reinterpret_cast<InitFn>(process_init_addr);
    auto break_dispatch = reinterpret_cast<ObjectFn>(break_dispatch_addr);
    auto decode32 = reinterpret_cast<Decode32Fn>(decode32_addr);

    void* process = alloc_fn(0x80u);
    if (!process) return -115;
    process_ctor(process);
    autorelease_fn(process);
    process_init(process, reinterpret_cast<void*>(item));

    const uintptr_t process_addr = reinterpret_cast<uintptr_t>(process);
    const std::int32_t powder_per_item =
            *reinterpret_cast<std::int32_t*>(process_addr + 0x60u);
    const std::int32_t shard_per_item =
            *reinterpret_cast<std::int32_t*>(process_addr + 0x64u);
    if (powder_per_item <= 0) return -116;

    *reinterpret_cast<std::uint64_t*>(process_addr + 0x68u) = 1u;

    retain_fn(process);
    g_powder_break_owner.store(process_addr, std::memory_order_release);
    break_dispatch(process);

    const std::uint32_t group_seq = decode32(reinterpret_cast<void*>(item + 0x80u), 1);
    const std::uint32_t tag = decode32(reinterpret_cast<void*>(item + 0xA8u), 1);
    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWDER_LAB BREAK item=%p groupSeq=%u tag=%u qty=1 powderPer=%d shardPer=%d process=%p",
            reinterpret_cast<void*>(item),
            group_seq,
            tag,
            powder_per_item,
            shard_per_item,
            process
    );
    (void)release_fn; // retained process is released by nativePowderCleanup.
    return 0;
}

// -----------------------------------------------------------------------------
// INTERNAL / LAB • Tower of Frozen Waves controlled verifier
//
// This deliberately does NOT write total stars, bestStage, or quest-completed
// flags directly. The controlled test only uses game-owned functions to:
//   1) set the current mission statistic to its required value,
//   2) set the secondary/end-condition state, and
//   3) ask the Tower manager to evaluate the mission again.
//
// Result/AfterPlay/mission commit are still left to the normal game lifecycle.
// V1.5 supports mission conditionType 0, 1, and 2. After Mission Success,
// the user can use the game's normal Exit button or death route to reach Result.
// -----------------------------------------------------------------------------
constexpr uintptr_t kTowerManagerGlobalGh = 0x0225C918u;
constexpr uintptr_t kTowerGameStatsGlobalGh = 0x02259800u;
constexpr uintptr_t kTowerDecode32Gh = 0x00D654F8u;
constexpr uintptr_t kTowerDecodeRequiredGh = 0x00E97D8Cu;
constexpr uintptr_t kTowerReadRawConditionGh = 0x01138D28u;
constexpr uintptr_t kTowerReadSecondaryGh = 0x01138E10u;
constexpr uintptr_t kTowerReadFinalSuccessGh = 0x01138EE8u;
constexpr uintptr_t kTowerSetSecondaryGh = 0x01138FD0u;
constexpr uintptr_t kTowerEvaluateGh = 0x01138940u;
constexpr uintptr_t kTowerStatsGetGh = 0x01320B68u;
constexpr uintptr_t kTowerStatsSetGh = 0x01320FE4u;
constexpr uintptr_t kTowerTypedStatGetOrCreateGh = 0x01320CE0u;
constexpr uintptr_t kTowerTypedStatReadGetCountGh = 0x01324C1Cu;
constexpr uintptr_t kTowerTypedStatAddGetCountGh = 0x01324CBCu;

struct TowerLabSnapshot {
    int rc = 0;
    uintptr_t elf_base = 0;
    uintptr_t manager_global = 0;
    uintptr_t manager = 0;
    uintptr_t active_mission = 0;
    uintptr_t stats_manager = 0;
    std::uint32_t current_floor = 0;
    std::uint32_t mission_order = 0;
    std::uint32_t best_stage = 0;
    std::uint32_t mission_floor = 0;
    std::uint64_t required_value = 0;
    std::int32_t condition_type = 0;
    std::int32_t condition_index = 0;
    std::int32_t comparator = 0;
    std::uint8_t raw_condition = 0;
    std::uint8_t secondary_state = 0;
    std::uint8_t final_success = 0;
    std::uint8_t pending_unlock = 0;
    std::uint8_t pending_commit = 0;
    std::uint8_t completed_flag = 0;
    std::uint8_t mission_state_flag = 0;
    std::uint8_t manager_state_byte = 0;
};

int tower_lab_snapshot(TowerLabSnapshot* out) {
    if (out == nullptr) return -200;
    *out = TowerLabSnapshot{};

    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -201;

    const uintptr_t manager_global =
            gh_to_runtime(elf_base, kTowerManagerGlobalGh);
    const uintptr_t stats_global =
            gh_to_runtime(elf_base, kTowerGameStatsGlobalGh);
    if (!address_is_mapped(manager_global) ||
        !address_is_mapped(stats_global)) {
        return -202;
    }

    const uintptr_t manager =
            *reinterpret_cast<uintptr_t*>(manager_global);
    if (!mapped_pointer_value(manager) ||
        !address_is_mapped(manager + 0x180u)) {
        return -203;
    }

    const uintptr_t active_mission =
            *reinterpret_cast<uintptr_t*>(manager + 0x100u);
    if (!mapped_pointer_value(active_mission) ||
        !address_is_mapped(active_mission + 0x1F8u)) {
        return -204;
    }

    const uintptr_t decode32_addr =
            gh_to_runtime(elf_base, kTowerDecode32Gh);
    const uintptr_t decode_required_addr =
            gh_to_runtime(elf_base, kTowerDecodeRequiredGh);
    const uintptr_t read_raw_addr =
            gh_to_runtime(elf_base, kTowerReadRawConditionGh);
    const uintptr_t read_secondary_addr =
            gh_to_runtime(elf_base, kTowerReadSecondaryGh);
    const uintptr_t read_final_addr =
            gh_to_runtime(elf_base, kTowerReadFinalSuccessGh);

    if (!address_in_libgame(decode32_addr) ||
        !address_in_libgame(decode_required_addr) ||
        !address_in_libgame(read_raw_addr) ||
        !address_in_libgame(read_secondary_addr) ||
        !address_in_libgame(read_final_addr)) {
        return -205;
    }

    using Decode32Fn = std::uint32_t (*)(void*, std::uint64_t);
    using DecodeRequiredFn = std::uint64_t (*)(void*, std::uint64_t);
    using ReadBoolFn = std::uint8_t (*)(void*);

    auto decode32 = reinterpret_cast<Decode32Fn>(decode32_addr);
    auto decode_required =
            reinterpret_cast<DecodeRequiredFn>(decode_required_addr);
    auto read_raw = reinterpret_cast<ReadBoolFn>(read_raw_addr);
    auto read_secondary = reinterpret_cast<ReadBoolFn>(read_secondary_addr);
    auto read_final = reinterpret_cast<ReadBoolFn>(read_final_addr);

    out->elf_base = elf_base;
    out->manager_global = manager_global;
    out->manager = manager;
    out->active_mission = active_mission;
    out->stats_manager = *reinterpret_cast<uintptr_t*>(stats_global);
    out->current_floor =
            decode32(reinterpret_cast<void*>(manager + 0x008u), 1);
    out->mission_order =
            decode32(reinterpret_cast<void*>(manager + 0x030u), 1);
    out->best_stage =
            decode32(reinterpret_cast<void*>(manager + 0x058u), 1);
    out->mission_floor =
            decode32(reinterpret_cast<void*>(active_mission + 0x140u), 1);
    out->required_value =
            decode_required(reinterpret_cast<void*>(active_mission + 0x1F8u), 1);
    out->condition_type =
            *reinterpret_cast<std::int32_t*>(active_mission + 0x190u);
    out->condition_index =
            *reinterpret_cast<std::int32_t*>(active_mission + 0x194u);
    out->comparator =
            *reinterpret_cast<std::int32_t*>(active_mission + 0x1C8u);
    out->completed_flag =
            *reinterpret_cast<std::uint8_t*>(active_mission + 0x1CDu) & 1u;
    out->mission_state_flag =
            *reinterpret_cast<std::uint8_t*>(active_mission + 0x1CEu) & 1u;
    out->pending_unlock =
            *reinterpret_cast<std::uint8_t*>(manager + 0x0F8u) & 1u;
    out->pending_commit =
            *reinterpret_cast<std::uint8_t*>(manager + 0x0F9u) & 1u;
    out->manager_state_byte =
            *reinterpret_cast<std::uint8_t*>(manager + 0x180u);
    out->raw_condition = read_raw(reinterpret_cast<void*>(manager)) & 1u;
    out->secondary_state = read_secondary(reinterpret_cast<void*>(manager)) & 1u;
    out->final_success = read_final(reinterpret_cast<void*>(manager)) & 1u;
    out->rc = 0;
    return 0;
}

std::string tower_lab_snapshot_text(
        const char* result,
        const char* phase,
        int rc) {
    TowerLabSnapshot s{};
    const int snap_rc = tower_lab_snapshot(&s);
    const int effective_rc = rc != 0 ? rc : snap_rc;

    char buffer[4096];
    if (snap_rc != 0) {
        std::snprintf(
                buffer,
                sizeof(buffer),
                "TOWER_LAB\nRESULT=ERROR\nphase=%s\nrc=%d\n"
                "snapshotRc=%d\n",
                phase,
                effective_rc,
                snap_rc
        );
        return std::string(buffer);
    }

    std::snprintf(
            buffer,
            sizeof(buffer),
            "TOWER_LAB\nRESULT=%s\nphase=%s\nrc=%d\n"
            "elfBase=0x%llX\nmanagerGlobal=0x%llX\nmanager=0x%llX\n"
            "activeMission=0x%llX\nstatsManager=0x%llX\n"
            "currentFloor=%u\nmissionOrder=%u\nbestStage=%u\nmissionFloor=%u\n"
            "conditionType=%d\nconditionIndex=%d\ncomparator=%d\nrequiredValue=%llu\n"
            "rawCondition=%u\nsecondaryState=%u\nfinalSuccess=%u\n"
            "pendingUnlock=%u\npendingCommit=%u\ncompletedFlag=%u\n"
            "missionStateFlag=%u\nmanagerStateByte=%u\n",
            result,
            phase,
            effective_rc,
            static_cast<unsigned long long>(s.elf_base),
            static_cast<unsigned long long>(s.manager_global),
            static_cast<unsigned long long>(s.manager),
            static_cast<unsigned long long>(s.active_mission),
            static_cast<unsigned long long>(s.stats_manager),
            s.current_floor,
            s.mission_order,
            s.best_stage,
            s.mission_floor,
            s.condition_type,
            s.condition_index,
            s.comparator,
            static_cast<unsigned long long>(s.required_value),
            static_cast<unsigned int>(s.raw_condition),
            static_cast<unsigned int>(s.secondary_state),
            static_cast<unsigned int>(s.final_success),
            static_cast<unsigned int>(s.pending_unlock),
            static_cast<unsigned int>(s.pending_commit),
            static_cast<unsigned int>(s.completed_flag),
            static_cast<unsigned int>(s.mission_state_flag),
            static_cast<unsigned int>(s.manager_state_byte)
    );
    return std::string(buffer);
}

std::string tower_lab_read_state() {
    return tower_lab_snapshot_text("OK", "READ_STATE", 0);
}

std::string tower_lab_test_mission_success() {
    TowerLabSnapshot before{};
    int rc = tower_lab_snapshot(&before);
    if (rc != 0) {
        return tower_lab_snapshot_text("ERROR", "PRECHECK", rc);
    }

    // Safety gate: this controlled test is only for a fresh, uncommitted Tower
    // mission inside a run. Do not mutate an already completed mission.
    if (before.completed_flag != 0u) {
        return tower_lab_snapshot_text("ERROR", "MISSION_ALREADY_COMPLETED", -206);
    }
    if (before.mission_order < 1u || before.mission_order > 3u ||
        before.current_floor == 0u || before.mission_floor == 0u) {
        return tower_lab_snapshot_text("ERROR", "TOWER_STAGE_NOT_READY", -207);
    }
    if (before.condition_type < 0 || before.condition_type > 2) {
        return tower_lab_snapshot_text("ERROR", "UNSUPPORTED_CONDITION_TYPE", -208);
    }
    if (before.required_value > 0x7FFFFFFFu || before.condition_index < 0) {
        return tower_lab_snapshot_text("ERROR", "MISSION_VALUE_INVALID", -209);
    }
    if (!mapped_pointer_value(before.stats_manager)) {
        return tower_lab_snapshot_text("ERROR", "GAME_STATS_NOT_READY", -210);
    }

    const uintptr_t stats_get_addr =
            gh_to_runtime(before.elf_base, kTowerStatsGetGh);
    const uintptr_t stats_set_addr =
            gh_to_runtime(before.elf_base, kTowerStatsSetGh);
    const uintptr_t typed_get_or_create_addr =
            gh_to_runtime(before.elf_base, kTowerTypedStatGetOrCreateGh);
    const uintptr_t typed_read_get_count_addr =
            gh_to_runtime(before.elf_base, kTowerTypedStatReadGetCountGh);
    const uintptr_t typed_add_get_count_addr =
            gh_to_runtime(before.elf_base, kTowerTypedStatAddGetCountGh);
    const uintptr_t set_secondary_addr =
            gh_to_runtime(before.elf_base, kTowerSetSecondaryGh);
    const uintptr_t evaluate_addr =
            gh_to_runtime(before.elf_base, kTowerEvaluateGh);

    if (!address_in_libgame(stats_get_addr) ||
        !address_in_libgame(stats_set_addr) ||
        !address_in_libgame(typed_get_or_create_addr) ||
        !address_in_libgame(typed_read_get_count_addr) ||
        !address_in_libgame(typed_add_get_count_addr) ||
        !address_in_libgame(set_secondary_addr) ||
        !address_in_libgame(evaluate_addr)) {
        return tower_lab_snapshot_text("ERROR", "FUNCTION_ROUTE_INVALID", -211);
    }

    using StatsGetFn = int (*)(void*, std::uint32_t, std::uint64_t);
    using StatsSetFn = void (*)(void*, std::uint64_t, int, std::uint32_t);
    using TypedGetOrCreateFn = void* (*)(void*, std::uint32_t, int);
    using TypedReadGetCountFn = std::uint32_t (*)(void*);
    using TypedAddGetCountFn = void (*)(void*, int);
    using SetSecondaryFn = void (*)(void*, std::uint32_t);
    using EvaluateFn = void (*)(void*);

    auto stats_get = reinterpret_cast<StatsGetFn>(stats_get_addr);
    auto stats_set = reinterpret_cast<StatsSetFn>(stats_set_addr);
    auto typed_get_or_create =
            reinterpret_cast<TypedGetOrCreateFn>(typed_get_or_create_addr);
    auto typed_read_get_count =
            reinterpret_cast<TypedReadGetCountFn>(typed_read_get_count_addr);
    auto typed_add_get_count =
            reinterpret_cast<TypedAddGetCountFn>(typed_add_get_count_addr);
    auto set_secondary = reinterpret_cast<SetSecondaryFn>(set_secondary_addr);
    auto evaluate = reinterpret_cast<EvaluateFn>(evaluate_addr);

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "TOWER_LAB TEST floor=%u mission=%u condType=%d condIndex=%d required=%llu before raw=%u secondary=%u final=%u",
            before.current_floor,
            before.mission_order,
            before.condition_type,
            before.condition_index,
            static_cast<unsigned long long>(before.required_value),
            static_cast<unsigned int>(before.raw_condition),
            static_cast<unsigned int>(before.secondary_state),
            static_cast<unsigned int>(before.final_success)
    );

    // conditionType=0:
    //   GameStatsManager direct statistic -> exact setter FUN_01320FE4.
    //
    // conditionType=1/2:
    //   FUN_01320B08 reads both through:
    //     FUN_01320CE0(statsManager, type, conditionIndex)
    //       -> typed statistic object
    //     FUN_01324C1C(object)
    //       -> protected GetCount at object+0x50.
    //   The matching mutator is FUN_01324CBC(object, delta).
    uintptr_t typed_stat_object = 0;
    int typed_current_before = 0;
    int typed_delta_applied = 0;
    int typed_current_after = 0;

    int type0_current_after = 0;
    bool type0_index5_source_only = false;

    if (before.condition_type == 0) {
        // param4=0 => mission/display units. FUN_01320FE4 applies the game's
        // own per-stat scaling and, critically, creates the Type0 tree node
        // when the key does not exist yet.
        //
        // For conditionIndex=5 ("Slide for N seconds") the direct-memory Lua
        // test proved that the node is absent at 0/N and appears only after the
        // first real Slide sample. Calling the game-owned setter here avoids
        // requiring any manual Slide input.
        stats_set(
                reinterpret_cast<void*>(before.stats_manager),
                static_cast<std::uint64_t>(before.condition_index),
                static_cast<int>(before.required_value),
                0u
        );

        // Read back in mission/display units. flag=0 mirrors evaluator units.
        type0_current_after = stats_get(
                reinterpret_cast<void*>(before.stats_manager),
                static_cast<std::uint32_t>(before.condition_index),
                0u
        );

        if (before.condition_index == 5) {
            const int required = static_cast<int>(before.required_value);
            const bool source_reached =
                    before.comparator == 3
                            ? type0_current_after <= required
                            : type0_current_after >= required;

            if (!source_reached) {
                char extra[768];
                std::snprintf(
                        extra,
                        sizeof(extra),
                        "TOWER_LAB\nRESULT=ERROR\n"
                        "phase=TYPE0_INDEX5_SOURCE_NOT_REACHED\n"
                        "rc=-214\n"
                        "nativeBuild=V2_0_5_TYPE0_INDEX5_PRESEED\n"
                        "conditionType=%d\nconditionIndex=%d\n"
                        "requiredValue=%llu\n"
                        "type0CurrentAfter=%d\n"
                        "policy=CREATE_MISSING_NODE_AND_SET_SOURCE_BEFORE_WARP\n",
                        before.condition_type,
                        before.condition_index,
                        static_cast<unsigned long long>(before.required_value),
                        type0_current_after
                );
                return std::string(extra);
            }

            // Source-only success. Do NOT force secondary/final booleans here.
            // The normal Tower gate/result lifecycle evaluates them after Warp.
            type0_index5_source_only = true;
        }
    } else {
        void* typed_object = typed_get_or_create(
                reinterpret_cast<void*>(before.stats_manager),
                static_cast<std::uint32_t>(before.condition_type),
                before.condition_index
        );
        typed_stat_object = reinterpret_cast<uintptr_t>(typed_object);

        if (!mapped_pointer_value(typed_stat_object) ||
            !address_is_mapped(typed_stat_object + 0x78u)) {
            return tower_lab_snapshot_text(
                    "ERROR",
                    "TYPED_STAT_OBJECT_INVALID",
                    -213
            );
        }

        typed_current_before =
                static_cast<int>(typed_read_get_count(typed_object));
        const int target = static_cast<int>(before.required_value);

        // Tower evaluator uses:
        // comparator == 3 -> current <= required
        // otherwise       -> current >= required
        if (before.comparator == 3) {
            if (typed_current_before > target) {
                typed_delta_applied = target - typed_current_before;
                typed_add_get_count(typed_object, typed_delta_applied);
            }
        } else {
            if (typed_current_before < target) {
                typed_delta_applied = target - typed_current_before;
                typed_add_get_count(typed_object, typed_delta_applied);
            }
        }

        typed_current_after =
                static_cast<int>(typed_read_get_count(typed_object));
    }

    if (type0_index5_source_only) {
        TowerLabSnapshot source_after{};
        rc = tower_lab_snapshot(&source_after);
        if (rc != 0) {
            return tower_lab_snapshot_text("ERROR", "TYPE0_INDEX5_POSTCHECK", rc);
        }

        char source_report[1400];
        std::snprintf(
                source_report,
                sizeof(source_report),
                "TOWER_LAB\n"
                "RESULT=TYPE0_SOURCE_SET\n"
                "phase=WAIT_NORMAL_GATE_EVALUATION\n"
                "rc=0\n"
                "nativeBuild=V2_0_5_TYPE0_INDEX5_PRESEED\n"
                "conditionType=%d\n"
                "conditionIndex=%d\n"
                "requiredValue=%llu\n"
                "type0CurrentAfter=%d\n"
                "rawCondition=%u\n"
                "secondaryState=%u\n"
                "finalSuccess=%u\n"
                "sourceCreatePolicy=GAME_OWNED_SETTER_CREATES_MISSING_NODE\n"
                "manualSlideRequired=false\n"
                "derivedBoolWrite=false\n",
                source_after.condition_type,
                source_after.condition_index,
                static_cast<unsigned long long>(source_after.required_value),
                type0_current_after,
                static_cast<unsigned int>(source_after.raw_condition),
                static_cast<unsigned int>(source_after.secondary_state),
                static_cast<unsigned int>(source_after.final_success)
        );
        return std::string(source_report);
    }

    set_secondary(reinterpret_cast<void*>(before.manager), 1u);
    evaluate(reinterpret_cast<void*>(before.manager));

    TowerLabSnapshot after{};
    rc = tower_lab_snapshot(&after);
    if (rc != 0) {
        return tower_lab_snapshot_text("ERROR", "POSTCHECK", rc);
    }

    if (after.raw_condition != 1u ||
        after.secondary_state != 1u ||
        after.final_success != 1u) {
        return tower_lab_snapshot_text("ERROR", "SUCCESS_STATE_NOT_REACHED", -212);
    }

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "TOWER_LAB SUCCESS_STATE_SET floor=%u mission=%u raw=%u secondary=%u final=%u",
            after.current_floor,
            after.mission_order,
            static_cast<unsigned int>(after.raw_condition),
            static_cast<unsigned int>(after.secondary_state),
            static_cast<unsigned int>(after.final_success)
    );

    std::string report = tower_lab_snapshot_text(
            "SUCCESS_STATE_SET",
            "WAIT_USER_EXIT_OR_DEATH",
            0
    );

    char route_buffer[1024];
    std::snprintf(
            route_buffer,
            sizeof(route_buffer),
            "nativeBuild=V2_0_5_TYPE0_INDEX5_PRESEED\n"
            "supportedConditionTypes=0,1,2\n"
            "conditionRoute=%s\n"
            "typedStatObject=0x%llX\n"
            "typedCurrentBefore=%d\n"
            "typedDeltaApplied=%d\n"
            "typedCurrentAfter=%d\n"
            "resultPolicy=MISSION_SUCCESS_THEN_USER_EXIT_OR_DEATH\n",
            before.condition_type == 0
                    ? "TYPE0_GAME_UNIT_SET_FLAG0"
                    : "TYPE1_2_GETCOUNT_DELTA",
            static_cast<unsigned long long>(typed_stat_object),
            typed_current_before,
            typed_delta_applied,
            typed_current_after
    );
    report.append(route_buffer);
    return report;
}

#endif

}  // namespace

// V13.1 Auth Context reuses the same proven libgame GH -> runtime route
// already used by the V13 Session State Export.  This keeps the new auth
// reader on the exact same module/bias mapping instead of introducing a
// second scanner/resolver.
extern "C" uintptr_t mwoif_v13_resolve_gh(uintptr_t gh) {
#if defined(MWOIF_INTERNAL_BUILD) && defined(__aarch64__)
    const uintptr_t elf_base = find_libgame_elf_base();
    return gh_to_runtime(elf_base, gh);
#else
    (void)gh;
    return 0;
#endif
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeArchitecture(
        JNIEnv* env,
        jclass /*clazz*/) {
#if defined(__aarch64__)
    return env->NewStringUTF("arm64-v8a");
#elif defined(__x86_64__)
    return env->NewStringUTF("x86_64");
#elif defined(__arm__)
    return env->NewStringUTF("armeabi-v7a");
#elif defined(__i386__)
    return env->NewStringUTF("x86");
#else
    return env->NewStringUTF("unknown");
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeApply(
        JNIEnv* /*env*/,
        jclass /*clazz*/,
        jlong dispatcher,
        jlong character,
        jint effect_id) {
#if !defined(__aarch64__)
    return -2;
#else
    if (dispatcher <= 0 || character <= 0 || !valid_effect_id(effect_id)) {
        return -3;
    }

    const auto dispatcher_addr = static_cast<uintptr_t>(dispatcher);
    if (!address_in_libgame(dispatcher_addr)) {
        return -4;
    }

    alignas(16) std::uint8_t event[0x18] = {};
    std::uint32_t id = static_cast<std::uint32_t>(effect_id);
    std::memcpy(event + 0x08, &id, sizeof(id));

    using DispatcherFn = void (*)(void*, void*);
    auto fn = reinterpret_cast<DispatcherFn>(dispatcher_addr);

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "APPLY dispatcher=%p character=%p id=%d",
            reinterpret_cast<void*>(dispatcher_addr),
            reinterpret_cast<void*>(static_cast<uintptr_t>(character)),
            effect_id
    );

    fn(reinterpret_cast<void*>(static_cast<uintptr_t>(character)), event);
    return 0;
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeRemove(
        JNIEnv* /*env*/,
        jclass /*clazz*/,
        jlong remover,
        jlong character,
        jint effect_id) {
#if !defined(__aarch64__)
    return -2;
#else
    if (remover <= 0 || character <= 0 || !valid_effect_id(effect_id)) {
        return -3;
    }

    const auto remover_addr = static_cast<uintptr_t>(remover);
    if (!address_in_libgame(remover_addr)) {
        return -4;
    }

    using RemoverFn = void (*)(void*, int);
    auto fn = reinterpret_cast<RemoverFn>(remover_addr);
    const auto owner = static_cast<uintptr_t>(character) + 0x148u;

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "REMOVE remover=%p owner=%p id=%d",
            reinterpret_cast<void*>(remover_addr),
            reinterpret_cast<void*>(owner),
            effect_id
    );

    fn(reinterpret_cast<void*>(owner), effect_id);
    return 0;
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowerFamily(
        JNIEnv* env,
        jclass /*clazz*/,
        jlong manager_global,
        jlong native_add,
        jlong native_has,
        jlong native_refresh,
        jintArray episode_keys,
        jint param3) {
#if !defined(__aarch64__)
    return -2;
#else
    if (manager_global <= 0 || native_add <= 0 || native_has <= 0 || native_refresh <= 0 || episode_keys == nullptr) {
        return -3;
    }

    const auto manager_global_addr = static_cast<uintptr_t>(manager_global);
    const auto native_add_addr = static_cast<uintptr_t>(native_add);
    const auto native_has_addr = static_cast<uintptr_t>(native_has);
    const auto native_refresh_addr = static_cast<uintptr_t>(native_refresh);

    // The manager global lives in libgame's writable BSS, which MuMu may map
    // anonymously. Function entry points remain strictly file-backed libgame.
    if (!address_is_mapped(manager_global_addr)) {
        return -8;
    }
    if (!address_in_libgame(native_add_addr) ||
        !address_in_libgame(native_has_addr) ||
        !address_in_libgame(native_refresh_addr)) {
        return -4;
    }

    const jsize key_count = env->GetArrayLength(episode_keys);
    if (key_count <= 0 || key_count > 16) {
        return -6;
    }

    jint keys[16] = {};
    env->GetIntArrayRegion(episode_keys, 0, key_count, keys);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return -6;
    }
    for (jsize i = 0; i < key_count; ++i) {
        if (keys[i] <= 0) return -6;
    }

    auto manager = *reinterpret_cast<void**>(manager_global_addr);
    if (manager == nullptr) {
        return -5;
    }
    if (!address_is_mapped(reinterpret_cast<uintptr_t>(manager))) {
        return -7;
    }

    using HasFn = std::uint64_t (*)(void*, int);
    using AddFn = void (*)(void*, int, std::uint32_t);
    using RefreshFn = void (*)(void*);

    auto has_fn = reinterpret_cast<HasFn>(native_has_addr);
    auto add_fn = reinterpret_cast<AddFn>(native_add_addr);
    auto refresh_fn = reinterpret_cast<RefreshFn>(native_refresh_addr);

    // V17.2: do NOT add the whole EP1..EP7 family. The game naturally creates
    // exactly the MysteryBox object that belongs to the current episode when
    // that episode supports/enables it. Use that live key as the episode
    // detector, then add only a boosted instance for that exact key.
    int target_key = 0;
    int live_family_count = 0;
    for (jsize i = 0; i < key_count; ++i) {
        const int key = keys[i];
        const std::uint64_t present = has_fn(manager, key);
        if ((present & 1u) == 0u) continue;
        target_key = key;
        ++live_family_count;
    }

    if (live_family_count == 0) {
        // Called immediately at Stage start. The natural passive may not have
        // been created yet, or this episode may not expose Power+. Kotlin does
        // a short fast-probe window and then treats it as normal gameplay.
        return 0;
    }
    if (live_family_count != 1) {
        // Refuse ambiguous/stale state rather than forcing the wrong episode.
        return -9;
    }

    // Intentionally call nativeAdd even though one natural object with this key
    // already exists. This creates the boosted instance (param3) for the exact
    // current episode instead of skipping it and boosting six wrong EP keys.
    add_fn(
            manager,
            target_key,
            static_cast<std::uint32_t>(param3)
    );

    // Rebuild threshold vectors through the game's own gate. This preserves
    // normal episode/availability checks and leaves unsupported episodes alone.
    refresh_fn(manager);

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWER_EXACT manager=%p key=%d familyLive=%d add=%p refresh=%p param3=%u",
            manager,
            target_key,
            live_family_count,
            reinterpret_cast<void*>(native_add_addr),
            reinterpret_cast<void*>(native_refresh_addr),
            static_cast<unsigned int>(param3)
    );

    return target_key;
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowerImmediate(
        JNIEnv* env,
        jclass /*clazz*/,
        jlong manager_global,
        jlong native_has,
        jlong native_refresh,
        jlong character,
        jintArray episode_keys,
        jlongArray layout) {
#if !defined(__aarch64__)
    return -2;
#else
    if (manager_global <= 0 || native_has <= 0 || native_refresh <= 0 || character <= 0 ||
        episode_keys == nullptr || layout == nullptr) {
        return -3;
    }

    const auto manager_global_addr = static_cast<uintptr_t>(manager_global);
    const auto native_has_addr = static_cast<uintptr_t>(native_has);
    const auto native_refresh_addr = static_cast<uintptr_t>(native_refresh);
    const auto character_addr = static_cast<uintptr_t>(character);

    if (!address_is_mapped(manager_global_addr)) return -8;
    if (!address_in_libgame(native_has_addr) || !address_in_libgame(native_refresh_addr)) return -4;
    if (!address_is_mapped(character_addr)) return -12;

    const jsize key_count = env->GetArrayLength(episode_keys);
    if (key_count <= 0 || key_count > 16) return -6;

    jint keys[16] = {};
    env->GetIntArrayRegion(episode_keys, 0, key_count, keys);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return -6;
    }
    for (jsize i = 0; i < key_count; ++i) {
        if (keys[i] <= 0) return -6;
    }

    constexpr jsize kLayoutCount = 15;
    if (env->GetArrayLength(layout) != kLayoutCount) return -10;
    jlong offsets[kLayoutCount] = {};
    env->GetLongArrayRegion(layout, 0, kLayoutCount, offsets);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return -10;
    }

    const auto char_backref_offset = static_cast<uintptr_t>(offsets[0]);
    const auto game_event_backref_subtract = static_cast<uintptr_t>(offsets[1]);
    const auto consumer_slot_offset = static_cast<uintptr_t>(offsets[2]);
    const auto list_sentinel_offset = static_cast<uintptr_t>(offsets[3]);
    const auto list_start_offset = static_cast<uintptr_t>(offsets[4]);
    const auto node_prev_offset = static_cast<uintptr_t>(offsets[5]);
    const auto node_object_offset = static_cast<uintptr_t>(offsets[6]);
    const auto object_config_offset = static_cast<uintptr_t>(offsets[7]);
    const auto config_key_offset = static_cast<uintptr_t>(offsets[8]);
    const auto expected_game_event_vtable = static_cast<uintptr_t>(offsets[9]);
    const auto expected_power_vtable = static_cast<uintptr_t>(offsets[10]);
    const auto game_event_state_index_offset = static_cast<uintptr_t>(offsets[11]);
    const auto game_event_state_array_offset = static_cast<uintptr_t>(offsets[12]);
    const auto game_event_state_value_offset = static_cast<uintptr_t>(offsets[13]);
    const int game_event_ready_state = static_cast<int>(offsets[14]);

    if (char_backref_offset == 0 || game_event_backref_subtract == 0 ||
        consumer_slot_offset == 0 || list_sentinel_offset == 0 ||
        list_start_offset == 0 || node_prev_offset == 0 ||
        node_object_offset == 0 || object_config_offset == 0 ||
        expected_game_event_vtable == 0 || expected_power_vtable == 0 ||
        game_event_state_index_offset == 0 || game_event_state_array_offset == 0 ||
        game_event_ready_state <= 0) {
        return -10;
    }

    auto manager = *reinterpret_cast<void**>(manager_global_addr);
    if (manager == nullptr) return -5;
    const auto manager_addr = reinterpret_cast<uintptr_t>(manager);
    if (!address_is_mapped(manager_addr)) return -7;

    using HasFn = std::uint64_t (*)(void*, int);
    using RefreshFn = void (*)(void*);
    auto has_fn = reinterpret_cast<HasFn>(native_has_addr);
    auto refresh_fn = reinterpret_cast<RefreshFn>(native_refresh_addr);

    int target_key = 0;
    int live_family_count = 0;
    for (jsize i = 0; i < key_count; ++i) {
        const int key = keys[i];
        const std::uint64_t present = has_fn(manager, key);
        if ((present & 1u) == 0u) continue;
        target_key = key;
        ++live_family_count;
    }

    if (live_family_count == 0) return 0;
    if (live_family_count != 1) return -9;

    // Keep the natural object state synchronized through the game's own
    // threshold refresh before bypassing only the delayed selector.
    refresh_fn(manager);

    // Reproduce the manager traversal used by the game's key-presence helper,
    // but keep the actual matching passive object so it can be handed directly
    // to the game-owned consumer.
    const auto sentinel = manager_addr + list_sentinel_offset;
    const auto list_start_addr = manager_addr + list_start_offset;
    if (!address_is_mapped(list_start_addr)) return -11;

    auto node = *reinterpret_cast<uintptr_t*>(list_start_addr);
    void* power_object = nullptr;
    int guard = 0;
    while (node != sentinel && guard++ < 256) {
        if (!address_is_mapped(node)) return -11;

        const auto object_slot = node + node_object_offset;
        if (!address_is_mapped(object_slot)) return -11;
        const auto object_addr = *reinterpret_cast<uintptr_t*>(object_slot);
        if (object_addr != 0 && address_is_mapped(object_addr)) {
            const auto config_slot = object_addr + object_config_offset;
            if (address_is_mapped(config_slot)) {
                const auto config_addr = *reinterpret_cast<uintptr_t*>(config_slot);
                if (config_addr != 0 && address_is_mapped(config_addr + config_key_offset)) {
                    const int object_key = *reinterpret_cast<int*>(config_addr + config_key_offset);
                    if (object_key == target_key) {
                        power_object = reinterpret_cast<void*>(object_addr);
                        break;
                    }
                }
            }
        }

        const auto prev_slot = node + node_prev_offset;
        if (!address_is_mapped(prev_slot)) return -11;
        node = *reinterpret_cast<uintptr_t*>(prev_slot);
    }

    if (power_object == nullptr) return -11;

    const auto power_object_addr = reinterpret_cast<uintptr_t>(power_object);
    if (!address_is_mapped(power_object_addr)) return -11;
    const auto power_vtable_addr = *reinterpret_cast<uintptr_t*>(power_object_addr);
    if (power_vtable_addr != expected_power_vtable) {
        __android_log_print(
                ANDROID_LOG_WARN,
                LOG_TAG,
                "POWER_IMMEDIATE_SAFE reject powerVtable=%p expected=%p key=%d",
                reinterpret_cast<void*>(power_vtable_addr),
                reinterpret_cast<void*>(expected_power_vtable),
                target_key
        );
        return -15;
    }

    const auto backref_slot = character_addr + char_backref_offset;
    if (!address_is_mapped(backref_slot)) return -12;
    const auto backref = *reinterpret_cast<uintptr_t*>(backref_slot);
    if (backref <= game_event_backref_subtract) return -12;

    const auto game_event_addr = backref - game_event_backref_subtract;
    if (!address_is_mapped(game_event_addr)) return -12;

    const auto vtable_addr = *reinterpret_cast<uintptr_t*>(game_event_addr);
    if (!address_is_mapped(vtable_addr)) return -13;
    if (vtable_addr != expected_game_event_vtable) {
        __android_log_print(
                ANDROID_LOG_WARN,
                LOG_TAG,
                "POWER_IMMEDIATE_SAFE reject gameEventVtable=%p expected=%p gameEvent=%p",
                reinterpret_cast<void*>(vtable_addr),
                reinterpret_cast<void*>(expected_game_event_vtable),
                reinterpret_cast<void*>(game_event_addr)
        );
        return -14;
    }

    // Match the natural 0108D9B8..0108D9CC gate before calling +0x6C8.
    // Character can exist before GameEvent reaches this runnable state; calling
    // the consumer earlier can enter partially initialized gameplay state.
    const auto state_index_addr = game_event_addr + game_event_state_index_offset;
    if (!address_is_mapped(state_index_addr)) return -17;
    const int state_index = *reinterpret_cast<int*>(state_index_addr);
    if (state_index < 0 || state_index > 64) return -17;

    const auto state_object_slot = game_event_addr + game_event_state_array_offset +
                                   static_cast<uintptr_t>(state_index) * sizeof(uintptr_t);
    if (!address_is_mapped(state_object_slot)) return -17;
    const auto state_object = *reinterpret_cast<uintptr_t*>(state_object_slot);
    if (state_object == 0 || !address_is_mapped(state_object + game_event_state_value_offset)) {
        return -17;
    }
    const int state_value = *reinterpret_cast<int*>(state_object + game_event_state_value_offset);
    if (state_value != game_event_ready_state) {
        __android_log_print(
                ANDROID_LOG_INFO,
                LOG_TAG,
                "POWER_IMMEDIATE_SAFE wait key=%d gameEvent=%p stateIndex=%d state=%d expected=%d",
                target_key,
                reinterpret_cast<void*>(game_event_addr),
                state_index,
                state_value,
                game_event_ready_state
        );
        return -16;
    }

    const auto consumer_slot_addr = vtable_addr + consumer_slot_offset;
    if (!address_is_mapped(consumer_slot_addr)) return -13;
    const auto consumer_addr = *reinterpret_cast<uintptr_t*>(consumer_slot_addr);
    if (!address_in_libgame(consumer_addr)) return -13;

    using ConsumerFn = void (*)(void*, void*);
    auto consumer_fn = reinterpret_cast<ConsumerFn>(consumer_addr);

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "POWER_IMMEDIATE_SAFE CALL manager=%p key=%d object=%p powerVtable=%p character=%p gameEvent=%p gameEventVtable=%p state=%d consumer=%p",
            manager,
            target_key,
            power_object,
            reinterpret_cast<void*>(power_vtable_addr),
            reinterpret_cast<void*>(character_addr),
            reinterpret_cast<void*>(game_event_addr),
            reinterpret_cast<void*>(vtable_addr),
            state_value,
            reinterpret_cast<void*>(consumer_addr)
    );

    consumer_fn(reinterpret_cast<void*>(game_event_addr), power_object);
    return target_key;
#endif
}


extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePreparePlay2Locator(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return prepare_play2_locator();
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeLocatePreRunScreen(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return locate_pre_run_screen();
#endif
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2CachedScreenBase(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jlong>(g_play2_screen_base.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorMatches(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jlong>(g_play2_locator_matches.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorPrimaryHits(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jlong>(g_play2_locator_primary_hits.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorBestScore(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jint>(g_play2_locator_best_score.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorBestBase(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jlong>(g_play2_locator_best_base.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorFingerprint(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return env->NewStringUTF("mode=UNAVAILABLE");
#else
    const uintptr_t elf_base = find_libgame_elf_base();
    const uintptr_t base = g_play2_screen_base.load(std::memory_order_acquire);
    const int mode = g_play2_locator_mode.load(std::memory_order_acquire);
    if (elf_base == 0 || base == 0 || !address_is_mapped(base)) {
        return env->NewStringUTF("mode=NONE");
    }
    const uintptr_t offsets[] = {0x000u, 0x158u, 0x168u, 0x170u, 0x178u, 0x180u};
    uintptr_t gh[6] = {};
    for (int i = 0; i < 6; ++i) {
        const uintptr_t slot = base + offsets[i];
        if (!address_is_mapped(slot)) continue;
        const uintptr_t value = *reinterpret_cast<const uintptr_t*>(slot);
        if (value >= elf_base && address_in_libgame(value)) {
            gh[i] = kImageBase + (value - elf_base);
        }
    }
    char buf[256] = {};
    std::snprintf(
            buf,
            sizeof(buf),
            "mode=%s liveVptrGh=%08llX,%08llX,%08llX,%08llX,%08llX,%08llX",
            mode == 1 ? "EXACT6" : (mode == 2 ? "PRIMARY_UNIQUE" : "NONE"),
            static_cast<unsigned long long>(gh[0]),
            static_cast<unsigned long long>(gh[1]),
            static_cast<unsigned long long>(gh[2]),
            static_cast<unsigned long long>(gh[3]),
            static_cast<unsigned long long>(gh[4]),
            static_cast<unsigned long long>(gh[5])
    );
    return env->NewStringUTF(buf);
#endif
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorScannedBytes(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jlong>(g_play2_locator_scanned_bytes.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2LocatorScannedRanges(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return 0;
#else
    return static_cast<jlong>(g_play2_locator_scanned_ranges.load(std::memory_order_acquire));
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePlay2CodeTrigger(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    const uintptr_t elf_base = find_libgame_elf_base();
    if (elf_base == 0) return -20;

    const uintptr_t event_bus_global = gh_to_runtime(elf_base, kEventBusGlobalGh);
    const uintptr_t resolver_global = gh_to_runtime(elf_base, kResolverGlobalGh);
    const uintptr_t stage_service_global = gh_to_runtime(elf_base, kStageServiceGlobalGh);
    const uintptr_t event_lookup_addr = gh_to_runtime(elf_base, kEventLookupGh);
    const uintptr_t event_cleanup_addr = gh_to_runtime(elf_base, kEventCleanupGh);
    const uintptr_t event_dispatch_addr = gh_to_runtime(elf_base, kEventDispatchGh);
    const uintptr_t dynamic_cast_addr = gh_to_runtime(elf_base, kDynamicCastGh);

    if (!address_is_mapped(event_bus_global) ||
        !address_is_mapped(resolver_global) ||
        !address_in_libgame(event_lookup_addr)) {
        return -21;
    }
    if (!address_in_libgame(dynamic_cast_addr)) return -36;

    // Refuse a duplicate start if the normal runtime already owns a live run.
    if (address_is_mapped(stage_service_global)) {
        const auto stage_service = *reinterpret_cast<uintptr_t*>(stage_service_global);
        if (mapped_pointer_value(stage_service)) {
            const auto character_slot = stage_service + 0x08u;
            const auto controller_slot = stage_service + 0x10u;
            if (address_is_mapped(character_slot) && address_is_mapped(controller_slot)) {
                const auto character = *reinterpret_cast<uintptr_t*>(character_slot);
                const auto controller = *reinterpret_cast<uintptr_t*>(controller_slot);
                if (mapped_pointer_value(character) && mapped_pointer_value(controller)) {
                    return -31;
                }
            }
        }
    }

    auto screen_base = g_play2_screen_base.load(std::memory_order_acquire);
    if (screen_base == 0) {
        const int locator_rc = locate_pre_run_screen();
        if (locator_rc != 0) return locator_rc;
        screen_base = g_play2_screen_base.load(std::memory_order_acquire);
    }
    const auto locator_matches = g_play2_locator_matches.load(std::memory_order_acquire);
    const auto locator_mode = g_play2_locator_mode.load(std::memory_order_acquire);
    if (screen_base == 0 || locator_mode == 0) return -23;

    const auto play_context = screen_base + 0x188u;
    if (!address_is_mapped(screen_base) || !address_is_mapped(play_context)) {
        return -24;
    }

    const auto event_bus = *reinterpret_cast<uintptr_t*>(event_bus_global);
    if (!mapped_pointer_value(event_bus)) return -21;

    using EventLookupFn = void* (*)(void*, int);
    auto event_lookup = reinterpret_cast<EventLookupFn>(event_lookup_addr);

    // 01307A00 does not call the raw EventBus payload directly.  It first
    // applies the same RTTI/interface adjustment used by Play #1.  Mirror that
    // exact pattern here before reading +0x4D8.
    void* raw_listener_69 = event_lookup(
            reinterpret_cast<void*>(event_bus + 0x10u),
            0x69
    );
    if (raw_listener_69 == nullptr ||
        !address_is_mapped(reinterpret_cast<uintptr_t>(raw_listener_69))) {
        return -25;
    }

    void* listener_69 = cast_event_interface(
            elf_base,
            raw_listener_69,
            kTypeEvent69SlotGh
    );
    if (listener_69 == nullptr) return -38;

    const auto listener_69_addr = reinterpret_cast<uintptr_t>(listener_69);
    const auto listener_69_vtable = *reinterpret_cast<uintptr_t*>(listener_69_addr);
    if (!mapped_pointer_value(listener_69_vtable)) return -38;

    const auto resolver = *reinterpret_cast<uintptr_t*>(resolver_global);
    if (!mapped_pointer_value(resolver)) return -26;
    const auto resolver_vtable = *reinterpret_cast<uintptr_t*>(resolver);
    if (!mapped_pointer_value(resolver_vtable)) return -26;

    const auto resolver_slot = resolver_vtable + 0x60u;
    if (!address_is_mapped(resolver_slot)) return -27;
    const auto resolver_fn_addr = *reinterpret_cast<uintptr_t*>(resolver_slot);
    if (!address_in_libgame(resolver_fn_addr)) return -27;

    using ResolverFn = void* (*)(void*, void*);
    auto resolver_fn = reinterpret_cast<ResolverFn>(resolver_fn_addr);
    void* snapshot = resolver_fn(
            reinterpret_cast<void*>(resolver),
            reinterpret_cast<void*>(play_context)
    );
    if (snapshot == nullptr || !address_is_mapped(reinterpret_cast<uintptr_t>(snapshot))) {
        return -28;
    }

    const auto play2_slot = listener_69_vtable + 0x4d8u;
    if (!address_is_mapped(play2_slot)) return -29;
    const auto play2_addr = *reinterpret_cast<uintptr_t*>(play2_slot);
    if (!address_in_libgame(play2_addr)) return -29;

    if (!address_in_libgame(event_cleanup_addr) || !address_in_libgame(event_dispatch_addr)) {
        return -30;
    }

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "PLAY2_CODE V6 CALL base=%p screen=%p mode=%d matches=%llu raw69=%p iface69=%p resolver=%p snapshot=%p play2=%p",
            reinterpret_cast<void*>(elf_base),
            reinterpret_cast<void*>(screen_base),
            locator_mode,
            static_cast<unsigned long long>(locator_matches),
            raw_listener_69,
            listener_69,
            reinterpret_cast<void*>(resolver),
            snapshot,
            reinterpret_cast<void*>(play2_addr)
    );

    using Play2Fn = void (*)(void*, void*, int, int);
    auto play2_fn = reinterpret_cast<Play2Fn>(play2_addr);
    play2_fn(listener_69, snapshot, 1, 0);

    // Mirror the exact tail of 01307A00 after listener69 +0x4D8.
    using EventCleanupFn = void (*)(void*, int);
    using EventDispatchFn = void (*)(void*, int);
    auto cleanup_fn = reinterpret_cast<EventCleanupFn>(event_cleanup_addr);
    auto dispatch_fn = reinterpret_cast<EventDispatchFn>(event_dispatch_addr);
    cleanup_fn(reinterpret_cast<void*>(event_bus + 0x10u), 0x69);
    dispatch_fn(reinterpret_cast<void*>(event_bus + 0x10u), 0);

    __android_log_print(
            ANDROID_LOG_INFO,
            LOG_TAG,
            "PLAY2_CODE V6 RETURN event69 dispatched screen=%p mode=%d matches=%llu",
            reinterpret_cast<void*>(screen_base),
            locator_mode,
            static_cast<unsigned long long>(locator_matches)
    );
    return 0;
#endif
}


extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderLocateTreasurePage(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return locate_powder_treasure_page();
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderPageDiagnostics(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF("internal build required");
#elif !defined(__aarch64__)
    return env->NewStringUTF("arm64-v8a required");
#else
    const std::string diag = powder_page_diagnostics();
    return env->NewStringUTF(diag.c_str());
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderBuyBox1(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return powder_buy_box1();
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderBuyBox1Burst(
        JNIEnv* /*env*/,
        jclass /*clazz*/,
        jint count) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return powder_buy_box1_burst(static_cast<int>(count));
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderBreakItem(
        JNIEnv* /*env*/,
        jclass /*clazz*/,
        jlong item) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    if (item <= 0) return -110;
    return powder_break_item(static_cast<uintptr_t>(item));
#endif
}


extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderBreakBatch(
        JNIEnv* env,
        jclass /*clazz*/,
        jlongArray items,
        jint count) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    if (items == nullptr || count <= 0) return -130;
    const jsize len = env->GetArrayLength(items);
    if (len <= 0) return -130;
    jint use_count = count;
    if (use_count > len) use_count = len;
    if (use_count > 128) use_count = 128;

    std::vector<jlong> buffer(static_cast<std::size_t>(use_count));
    env->GetLongArrayRegion(items, 0, use_count, buffer.data());
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return -135;
    }

    std::vector<uintptr_t> native_items;
    native_items.reserve(static_cast<std::size_t>(use_count));
    for (jint i = 0; i < use_count; ++i) {
        if (buffer[static_cast<std::size_t>(i)] <= 0) return -110;
        native_items.push_back(static_cast<uintptr_t>(buffer[static_cast<std::size_t>(i)]));
    }
    return powder_break_items_batch(native_items);
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderForceReload(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return powder_force_go_title_reload();
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativePowderCleanup(
        JNIEnv* /*env*/,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return powder_cleanup_retained();
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeBoxLocateAction(
        JNIEnv* env,
        jclass /*clazz*/,
        jint action_id) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF("BOX_ACTION_LOCATOR\nRESULT=ERROR\nrc=-90\n");
#elif !defined(__aarch64__)
    return env->NewStringUTF("BOX_ACTION_LOCATOR\nRESULT=ERROR\nrc=-2\n");
#else
    const int rc = locate_box_action_binding(static_cast<int>(action_id));
    std::string report;
    {
        std::lock_guard<std::mutex> lock(g_box_action_mutex);
        report = g_box_action_report;
    }
    if (rc != 0 && report.find("rc=") == std::string::npos) {
        report += "rc=" + std::to_string(rc) + "\n";
    }
    return env->NewStringUTF(report.c_str());
#endif
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeBoxCallAction(
        JNIEnv* /*env*/,
        jclass /*clazz*/,
        jint action_id) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return -90;
#elif !defined(__aarch64__)
    return -2;
#else
    return call_cached_box_action(static_cast<int>(action_id));
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeSessionStateSnapshot(
        JNIEnv* env,
        jclass /*clazz*/,
        jboolean include_secret) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF(
            "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=INTERNAL_BUILD_REQUIRED\n"
    );
#elif !defined(__aarch64__)
    return env->NewStringUTF(
            "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=ARM64_REQUIRED\n"
    );
#else
    const std::string report =
            session_state_snapshot(include_secret == JNI_TRUE);
    return env->NewStringUTF(report.c_str());
#endif
}



extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeFgsIdSnapshot(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD) || !defined(__aarch64__)
    return env->NewStringUTF("");
#else
    const std::string value = game_owned_fgs_id_snapshot();
    return env->NewStringUTF(value.c_str());
#endif
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeAuthContextSnapshot(
        JNIEnv* env,
        jclass /*clazz*/,
        jboolean include_secret) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF(
            "MWOIF_AUTH_CONTEXT_V13_1\nRESULT=ERROR\nreason=INTERNAL_BUILD_REQUIRED\n"
    );
#elif !defined(__aarch64__)
    return env->NewStringUTF(
            "MWOIF_AUTH_CONTEXT_V13_1\nRESULT=ERROR\nreason=ARM64_REQUIRED\n"
    );
#else
    const std::string report =
            auth_context_snapshot(include_secret == JNI_TRUE);
    return env->NewStringUTF(report.c_str());
#endif
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeInitMember3ProbeSnapshot(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF(
            "INITMEMBER3_PROBE\nRESULT=ERROR\nreason=INTERNAL_BUILD_REQUIRED\n"
    );
#elif !defined(__aarch64__)
    return env->NewStringUTF(
            "INITMEMBER3_PROBE\nRESULT=ERROR\nreason=ARM64_REQUIRED\n"
    );
#else
    const std::string report = initmember3_probe_snapshot();
    return env->NewStringUTF(report.c_str());
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeHeartDsCryptoProfileSnapshot(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF(
            "HEART_DS_CRYPTO_PROFILE\nRESULT=ERROR\nreason=INTERNAL_BUILD_REQUIRED\n"
    );
#elif !defined(__aarch64__)
    return env->NewStringUTF(
            "HEART_DS_CRYPTO_PROFILE\nRESULT=ERROR\nreason=ARM64_REQUIRED\n"
    );
#else
    const std::string report = heart_ds_crypto_profile_snapshot();
    return env->NewStringUTF(report.c_str());
#endif
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeHeartSendDsProbeSnapshot(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF(
            "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=INTERNAL_BUILD_REQUIRED\n"
    );
#elif !defined(__aarch64__)
    return env->NewStringUTF(
            "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=ARM64_REQUIRED\n"
    );
#else
    const std::string report = heart_send_arm_or_status_event_capture();
    return env->NewStringUTF(report.c_str());
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeHeartSendDsProbeReset(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF(
            "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=INTERNAL_BUILD_REQUIRED\n"
    );
#elif !defined(__aarch64__)
    return env->NewStringUTF(
            "HEART_SEND_DS_PROBE\nRESULT=ERROR\nreason=ARM64_REQUIRED\n"
    );
#else
    const std::string report = heart_send_reset_event_capture();
    return env->NewStringUTF(report.c_str());
#endif
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeTowerState(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF("TOWER_LAB\nRESULT=ERROR\nphase=INTERNAL_BUILD_REQUIRED\nrc=-90\n");
#elif !defined(__aarch64__)
    return env->NewStringUTF("TOWER_LAB\nRESULT=ERROR\nphase=ARM64_REQUIRED\nrc=-2\n");
#else
    const std::string report = tower_lab_read_state();
    return env->NewStringUTF(report.c_str());
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_woif_modmenu_InProcessNativeBridge_nativeTowerTestMissionSuccess(
        JNIEnv* env,
        jclass /*clazz*/) {
#if !defined(MWOIF_INTERNAL_BUILD)
    return env->NewStringUTF("TOWER_LAB\nRESULT=ERROR\nphase=INTERNAL_BUILD_REQUIRED\nrc=-90\n");
#elif !defined(__aarch64__)
    return env->NewStringUTF("TOWER_LAB\nRESULT=ERROR\nphase=ARM64_REQUIRED\nrc=-2\n");
#else
    const std::string report = tower_lab_test_mission_success();
    return env->NewStringUTF(report.c_str());
#endif
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* /*vm*/, void* /*reserved*/) {
#if defined(__aarch64__)
    const char* abi = "arm64-v8a";
#elif defined(__x86_64__)
    const char* abi = "x86_64";
#else
    const char* abi = "other";
#endif
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "WOIF in-process native loaded abi=%s", abi);
    return JNI_VERSION_1_6;
}
