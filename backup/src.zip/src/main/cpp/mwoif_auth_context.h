#pragma once

// V13.1 legacy placeholder.
// Direct +0x58/+0x60 auth getter code was retired.
// See native_main.cpp auth_context_snapshot().
