// V13.1 legacy placeholder.
//
// The old direct account-getter implementation was intentionally retired.
// The live Auth Context route is implemented in native_main.cpp and is called
// only through InProcessNativeBridge inside the injected CookieRun process:
//
//   FloatingMenuService
//     -> InProcessGameControl OP_AUTH_CONTEXT
//     -> InProcessNativeBridge.nativeAuthContextSnapshot()
//     -> FUN_00EB8EFC game-owned materializer
//
// This file is intentionally NOT part of the CMake target.
