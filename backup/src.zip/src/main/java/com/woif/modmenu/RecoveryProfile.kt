package com.woif.modmenu

/**
 * Secure resolver profile for the shared Pit Lift / Revive recovery family.
 *
 * CookieRun uses one native recovery family for both events. The client keeps
 * the two user-facing MODs separate by classifying the event context before a
 * consumed usage record is refunded.
 */
data class RecoveryProfile(
    val imageBase: Long,
    val stageServiceGlobal: Long,
    val gameplayStateGlobal: Long,

    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,

    val characterYOffset: Long,
    val characterYPreviousOffset: Long,
    val characterReferenceOffset: Long,

    val recoveryListSentinelOffset: Long,
    val recoveryListCountOffset: Long,
    val listNodeNextOffset: Long,
    val listNodePreviousOffset: Long,
    val listNodeValueObjectOffset: Long,
    val protectedValuePtrOffset: Long,

    val recoverySubtype: Int,
    val pitArmY: Float,
    val pitRecentWindowMs: Long,
    val refundDelayMs: Long,
    val maximumUsageDelta: Int,

    val revision: String,
    val ttlSeconds: Int
)
