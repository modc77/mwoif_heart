package com.woif.modmenu

/**
 * Minimal client-visible Control Plane state.
 *
 * No Stable/Canary/Internal or entitlement meaning is stored here.
 * Android only knows whether memory writes are currently allowed and which
 * feature IDs are unavailable for this session.
 */
object ControlPlaneState {

    data class Snapshot(
        val writeAllowed: Boolean,
        val gameVersionStatus: String,
        val message: String?,
        val disabledFeatures: Set<String>
    )

    @Volatile
    private var snapshot =
        Snapshot(
            writeAllowed = true,
            gameVersionStatus = "supported",
            message = null,
            disabledFeatures = emptySet()
        )

    fun update(control: ControlSnapshot) {
        snapshot =
            Snapshot(
                writeAllowed = control.writeAllowed,
                gameVersionStatus = control.gameVersionStatus,
                message = control.message,
                disabledFeatures =
                    control.disabledFeatures
                        .asSequence()
                        .map { it.trim() }
                        .filter { FeatureCatalog.isKnownFeatureId(it) }
                        .toSet()
            )
    }

    fun reset() {
        snapshot =
            Snapshot(
                writeAllowed = true,
                gameVersionStatus = "supported",
                message = null,
                disabledFeatures = emptySet()
            )
    }

    fun snapshot(): Snapshot = snapshot.copy(
        disabledFeatures = snapshot.disabledFeatures.toSet()
    )

    fun canWrite(): Boolean = snapshot.writeAllowed

    fun isFeatureAllowed(featureId: String): Boolean {
        if (!FeatureCatalog.isKnownFeatureId(featureId)) {
            return false
        }

        val current = snapshot
        return current.writeAllowed &&
            !current.disabledFeatures.contains(featureId)
    }

    fun isControlAllowed(controlKey: String): Boolean {
        val featureId =
            FeatureCatalog.featureIdForControl(controlKey)
                ?: return false

        return isFeatureAllowed(featureId)
    }
}
