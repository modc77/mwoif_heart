package com.woif.modmenu

/**
 * Decrypted in-memory HP profile.
 *
 * Compact names deliberately avoid documenting the server profile in the APK.
 */
data class HpProfile(
    val a0: Long,
    val a1: Long,

    val b0: Long,
    val b1: Long,
    val b2: Long,
    val b3: Long,

    val b4: Long,
    val b5: Long,
    val b6: Long,
    val b7: Long,

    val b8: Long,
    val b9: Long,
    val ba: Long,
    val bb: Long,

    val k0: Int,
    val k1: Int,
    val k2: Int,
    val k3: Int,

    val v0: Int,
    val v1: Int,

    val revision: String,
    val ttlSeconds: Int
)
