package com.woif.modmenu

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import org.json.JSONObject

class FloatingMenuService : Service() {

    companion object {
        private const val TAG = "WOIF_FLOAT"
        private const val GAME_PACKAGE = "com.devsisters.crg"
        private const val CHANNEL_ID = "woif_floating_channel"
        private const val NOTIFICATION_ID = 1001
        private const val CHECK_INTERVAL = 400L
        private const val BOT_LAB_ENABLED = true

        private const val PREFS = "woif_app_preferences"
        private const val P_LANG = "language"
        private const val P_MENU_SIZE = "menu_size"
        private const val P_W_SIZE = "w_size"
        private const val P_REMEMBER = "remember_key"
        private const val P_SHOW_TIME = "show_countdown"
        private const val P_SHOW_ONLINE = "show_online"
        private const val P_W_X = "w_x"
        private const val P_W_Y = "w_y"
        private const val P_QUICK_X = "quick_mod_x"
        private const val P_QUICK_Y = "quick_mod_y"
        private const val P_QUICK_ENABLED = "quick_mod_enabled"
        private const val P_M_X = "menu_x"
        private const val P_M_Y = "menu_y"
        private const val P_WARNING_ACK_REVISION = "user_warning_ack_revision"

        // Internal HEART handoff: sanitized locator reports only.
        private const val P_HEART_HANDOFF_SENDER_REPORT = "heart_handoff_sender_report"
        private const val P_HEART_HANDOFF_SENDER_AT = "heart_handoff_sender_at"
        private const val P_HEART_HANDOFF_RECEIVER_REPORT = "heart_handoff_receiver_report"
        private const val P_HEART_HANDOFF_RECEIVER_AT = "heart_handoff_receiver_at"

        // V12.5 final-envelope-meta account export.
        // Capture/export one account immediately before switching/login reset.
        private const val P_HEART_CURRENT_REPORT = "heart_current_report"
        private const val P_HEART_CURRENT_AT = "heart_current_at"

        private const val TH = "TH"
        private const val EN = "EN"
        private const val SMALL = "SMALL"
        private const val MEDIUM = "MEDIUM"
        private const val LARGE = "LARGE"


        @Volatile
        private var activeServiceForBoxPump: FloatingMenuService? = null

        /**
         * Internal Box Lab bridge. Uses the SAME HpMod instance that backs the
         * existing HP/Immortal feature; no second HpMod is created.
         */
        @JvmStatic
        fun boxPumpWriteCurrentHpForLab(value: Int): HpMod.ActionResult {
            val service =
                activeServiceForBoxPump
                    ?: return HpMod.ActionResult(
                        false,
                        "FLOATING_SERVICE_NOT_READY",
                        "FloatingMenuService ยังไม่พร้อม"
                    )

            if (!service::hpMod.isInitialized) {
                return HpMod.ActionResult(
                    false,
                    "HP_MOD_NOT_READY",
                    "HP Mod เดิมยังไม่พร้อม"
                )
            }

            return service.hpMod.writeCurrentHpForLab(value)
        }
    }

    enum class Tab { HOME, PLAY, AUTO, FARM, PUMP, SETTINGS, DEV }

    private enum class AutoA2LabPhase { IDLE, PREPARING, READY_FOR_PLAY1, LOCATING, TRIGGERING, PASS, FAILED }

    private fun brandName(): String =
        if (BuildConfig.INTERNAL_BUILD) "M Woif Lab" else "M Woif"

    private fun brandModTitle(): String =
        if (BuildConfig.INTERNAL_BUILD) "M Woif Lab" else "M Woif MOD"

    private fun brandVersion(): String =
        if (BuildConfig.INTERNAL_BUILD) {
            "M Woif Lab v${BuildConfig.VERSION_NAME}"
        } else {
            "M Woif v${BuildConfig.VERSION_NAME}"
        }

    private fun brandMenuName(): String =
        if (BuildConfig.INTERNAL_BUILD) "M Woif Lab" else "M Woif Mod Menu"

    /**
     * Stable/User UI is intentionally compact and never exposes runtime
     * resolver/profile diagnostics. M Woif Lab keeps the full diagnostic
     * text so failures remain debuggable.
     */
    private fun audienceText(
        userTh: String,
        userEn: String,
        labTh: String = userTh,
        labEn: String = userEn
    ): String =
        if (BuildConfig.INTERNAL_BUILD) tr(labTh, labEn) else tr(userTh, userEn)

    private fun addDiagnosticStatus(
        root: LinearLayout,
        text: String,
        color: String = "#8F9AAC"
    ) {
        if (!BuildConfig.INTERNAL_BUILD) return

        root.addView(
            txt(text, 10f, color).apply {
                setPadding(dp(4), dp(10), dp(4), dp(2))
            },
            subLp()
        )
    }

    private lateinit var wm: WindowManager
    private lateinit var usage: UsageStatsManager
    private lateinit var prefs: SharedPreferences
    private lateinit var modSettingsStore: ModSettingsStore
    private val handler = Handler(Looper.getMainLooper())

    private val licenseExecutor =
        Executors.newSingleThreadExecutor()

    private val heartbeatInFlight =
        AtomicBoolean(false)

    private var licenseInvalidated = false

    private var foregroundPackage: String? = null
    private var lastEventTime = 0L

    private var wView: TextView? = null
    private var wLp: WindowManager.LayoutParams? = null
    private var wVisible = false

    // V18.6.1 Quick MOD floating control.
    // Red OFF / Green ON. Uses the 14-item AUTO selection as its preset.
    private var quickModView: TextView? = null
    private var quickModLp: WindowManager.LayoutParams? = null
    private var quickModVisible = false
    private var quickModRenderedState: Boolean? = null
    private var quickModEnabled = true

    // V18.6.2 hidden/recording mode. Runtime-only by design: never persisted.
    private var overlayHiddenMode = false
    private var hiddenWZone: View? = null
    private var hiddenQuickZone: View? = null
    private var hiddenWZoneVisible = false
    private var hiddenQuickZoneVisible = false

    // Live UI reference so floating AUTO ON/OFF always mirrors the AUTO MODE card.
    private var autoMasterToggleView: TextView? = null

    private var menuView: LinearLayout? = null
    private var menuLp: WindowManager.LayoutParams? = null
    private var menuVisible = false
    private var contentScroll: ScrollView? = null
    private var content: LinearLayout? = null

    private val tabText = mutableMapOf<Tab, TextView>()
    private val tabLine = mutableMapOf<Tab, View>()
    private var activeTab = Tab.HOME

    private var licenseChip: TextView? = null
    private var countdownChip: TextView? = null
    private var onlineChip: TextView? = null
    private var expiryLabel: TextView? = null

    private var language = TH
    private var menuSize = MEDIUM
    private var wSize = MEDIUM
    private var rememberKey = false
    private var showCountdown = true
    private var showOnline = true

    // Gameplay feature states.
    private var hpOn = false
    private var hpAutoOwned = false
    private var hpMode = "INFINITE"

    private lateinit var hpMod: HpMod

    private var hpStatusText =
        "ยังไม่ได้เปิด HP"

    private var nextHpPrepareAt =
        0L
    private var speedOn = false
    private var speed = 20

    private lateinit var gameSpeedMod: GameSpeedMod

    private var speedApplyRunnable: Runnable? = null

    private var gameSpeedStatusText =
        "ยังไม่ได้เปิด Game Speed"

    private var nextGameSpeedPrepareAt =
        0L
    private var giantOn = false
    private var giantAutoOwned = false
    private var giantSizeAutoOwned = false
    private var giantStatusText = "ยังไม่ได้เปิด Giant"

    // Giant Size Fast Lock. Manual and AUTO ownership are intentionally separate.
    private var giantSizeOn = false
    private var giantSizePercent = 30
    private var giantSizeStatusText = "เปิด Giant ก่อน แล้วค่อยเปิด Giant Size"

    private var superOn = false
    private var superAutoOwned = false
    private var superStatusText = "ยังไม่ได้เปิด Super"

    private lateinit var nativeEffectMod: NativeEffectMod

    // Internal/Lab-only READ-ONLY finder for Giant/Super after game updates.
    // This never replaces NativeEffectMod and never writes CookieRun memory.
    private lateinit var giantSuperDev: GiantSuperDevTemplate
    private var giantSuperDevView: TextView? = null
    private var superDevView: TextView? = null
    private var giantSuperRegressionView: TextView? = null
    private var giantSizeDevView: TextView? = null

    // Internal/Lab reusable build-update finder for f05/f07/f08/f09/f10.
    // READ ONLY: it only observes natural runtime state and reports new GH values.
    private lateinit var buildUpdateDev: BuildUpdateDevFinder
    private var buildUpdateDevView: TextView? = null
    private val buildUpdateDevSectionViews = HashMap<String, TextView>()
    private var buildUpdateDevActiveSection = "00"

    // Internal/Lab-only passive initMember3 request-object probe.
    // READ ONLY: scans game-process native request objects; never sends or mutates requests.
    private var initMember3ProbeRunning = false
    private var initMember3ProbeText =
        "READY • กด ARM CAPTURE แล้วให้เกมทำ DevPlay / initMember3 ตามธรรมชาติ"
    private var initMember3ProbeLastReport =
        "INITMEMBER3_PROBE\nRESULT=NOT_RUN\n"
    private var initMember3ProbeView: TextView? = null

    // Internal/Lab-only passive capture for the legacy DS heart-send request.
    // READ ONLY: user arms it, then performs one normal in-game Send Heart action.
    private var heartSendDsProbeRunning = false
    private var heartSendDsProbeText =
        "READY • กด ARM แล้วส่งใจในเกมตามธรรมชาติ 1 ครั้ง"
    private var heartSendDsProbeLastReport =
        "HEART_SEND_DS_PROBE\nRESULT=NOT_RUN\n"
    private var heartSendDsProbeView: TextView? = null

    // V13 established-session state export.  Unlike V12.x this reads the
    // long-lived game state after a normal bootstrap and does not scan the
    // short-lived request object.  Secret material is fetched only when the
    // user explicitly presses COPY SESSION JSON and is never rendered.
    private var sessionV13StatusText =
        "READY • เข้าเกมให้ถึง Lobby แล้วกด READ SESSION"
    private var sessionV13LastReport =
        "MWOIF_SESSION_STATE_V13\nRESULT=NOT_RUN\n"
    private var sessionV13View: TextView? = null

    // V13.1 established account auth-context export.
    // The real gameAccessToken is never rendered; it is requested only by
    // the explicit COPY AUTH CONTEXT JSON action.
    private var authV13StatusText =
        "READY • เข้าเกมให้ถึง Lobby แล้วกด READ AUTH CONTEXT"
    private var authV13View: TextView? = null

    private var nativeEffectLabLogView: TextView? = null
    private var nativePlay2ProbeView: TextView? = null
    private var nativePlay2ProbeText = "ยังไม่มีผล Code Play #2"
    private var autoA2EasyStatusView: TextView? = null
    private var autoA2TechnicalView: TextView? = null
    private var autoA2LabPhase = AutoA2LabPhase.IDLE
    private var autoA2TechLogVisible = false
    private var autoA2TechnicalText = "Bridge / PRE_RUN Locator ยังไม่ได้ตรวจ"
    private var autoA2EasyStatusText =
        "READY\nกด AUTO A2 • NEXT เพื่อเตรียม PRE_RUN Locator"

    // Internal/Lab-only Powder Pump one-round integration. The implementation
    // lives under src/internal and is reached via reflection so Stable never
    // compiles or packages the Lab backend class.
    private var powderPumpLabRunning = false
    private var powderPumpLabStatusText =
        "READY • TURBO LAB"
    private var powderPumpSimpleStatus = "พร้อมใช้งาน"
    private var powderPumpTotalDraws = 0
    private var powderPumpTotalBroken = 0
    private var powderPumpTotalPowder = 0L
    private var powderPumpStatusView: TextView? = null
    private var powderPumpDrawsView: TextView? = null
    private var powderPumpBrokenView: TextView? = null
    private var powderPumpPowderView: TextView? = null
    private var powderPumpDevDiagnosticsView: TextView? = null
    private var powderPumpDevDiagnosticsText = "ยังไม่มี Powder Pump diagnostics"
    private var powderPumpLiveRefreshRunnable: Runnable? = null

    // Internal/Lab-only Tower Warp Pump V2.0. The backend lives under src/internal
    // and is reached via reflection so Stable never packages the Lab backend.
    private var towerPumpLabRunning = false
    private var towerPumpSimpleStatus = "ปั้มปิดอยู่ • เปิดปั้มแล้วกดเข้า Tower Stage เอง"
    private var towerPumpFloor = 0
    private var towerPumpMissionOrder = 0
    private var towerPumpBestStage = 0
    private var towerPumpRawCondition = 0
    private var towerPumpSecondaryState = 0
    private var towerPumpFinalSuccess = 0
    private var towerPumpPendingCommit = 0
    private var towerPumpCompletedFlag = 0
    private var towerPumpStatusView: TextView? = null
    private var towerPumpFloorView: TextView? = null
    private var towerPumpMissionView: TextView? = null
    private var towerPumpStateView: TextView? = null
    private var towerPumpCommitView: TextView? = null
    private var towerPumpDevDiagnosticsView: TextView? = null
    private var towerPumpDevDiagnosticsText = "ยังไม่มี Tower Pump diagnostics"
    private var towerPumpLiveRefreshRunnable: Runnable? = null

    // Legacy Tower 3-MOD assist state is retained only so V2.0 can restore
    // anything left active by an older Lab run. Warp mode never enables it.
    private var towerThreeModAssistActive = false
    private var towerThreeModAssistStatus = "IDLE"
    private var towerThreeModOwnsBaseSpeed = false
    private var towerThreeModOwnsGiant = false
    private var towerThreeModOwnsSuper = false

    // Internal/Lab-only EP1 one-box manual-loop pump.
    // Giant ownership is isolated from manual Giant state and Tower V2.0.6.
    private var boxPumpLabRunning = false
    private var boxPumpOwnsGiant = false
    private var boxPumpRound = 0
    private var boxPumpPhase = "READY"
    private var boxPumpSimpleStatus = "ปั้มปิดอยู่ • เปิดปั้มแล้วกดเข้า EP1 เอง"
    private var boxPumpStatusView: TextView? = null
    private var boxPumpRoundView: TextView? = null
    private var boxPumpPhaseView: TextView? = null
    private var boxPumpLiveRefreshRunnable: Runnable? = null

    private var nextNativeEffectPrepareAt = 0L

    private var powerOn = false
    private var powerAutoOwned = false
    private var powerStatusText = "ยังไม่ได้เปิด Power+"
    private var nextPowerPlusPrepareAt = 0L
    private lateinit var powerPlusMod: PowerPlusMod

    private var xpOn = false
    private var xpAutoOwned = false
    private var xp = 10000
    private var xpStatusText = "ยังไม่ได้เปิด XP"
    private var coinOn = false
    private var coinAutoOwned = false
    private var coin = 350000
    private var coinStatusText = "ยังไม่ได้เปิด Coin"
    private var nextRunRewardPrepareAt = 0L
    private lateinit var runRewardMod: RunRewardMod
    private var potatoCoinOn = false
    private var potatoCoinMode = "FIXED"
    private var potatoCoin = 100
    private var potatoCoinInterval = 1.0
    private var potatoCoinStatusText = "Potato เหรียญ • ยังไม่ได้เปิด"
    private lateinit var potatoCoinMod: PotatoCoinMod
    private var potatoRapidOn = false
    private var potatoRapid = 1.0
    private var potatoRapidStatusText = "Potato ยิงเร็ว • ยังไม่ได้เปิด"
    private var nextPotatoPrepareAt = 0L
    private lateinit var potatoRapidMod: PotatoRapidMod
    private var potatoUltimateOn = false
    private var potatoUltimateAutoOwned = false
    private var potatoUltimateInfinite = false
    private var potatoUltimateSeconds = 300
    private var potatoUltimateStatusText = "Potato อัลติเมต • ยังไม่ได้เปิด"
    private lateinit var potatoUltimateMod: PotatoUltimateMod

    private var baseSpeedOn = false
    private var baseSpeedMultiplier = 1.0
    private var baseSpeedStatusText = "ความเร็วพื้นฐาน • ยังไม่ได้เปิด"
    private var nextBaseSpeedPrepareAt = 0L
    private lateinit var baseSpeedMod: BaseSpeedMod

    private var pitLiftOn = false
    private var pitLiftStatusText = "Pit Lift • ยังไม่ได้เปิด"
    private var reviveOn = false
    private var reviveStatusText = "Revive • ยังไม่ได้เปิด"
    private var nextRecoveryPrepareAt = 0L
    private lateinit var recoveryMod: RecoveryMod

    private var unlimitedJumpOn = false
    private var unlimitedJumpStatusText = "Unlimited Jump • ยังไม่ได้เปิด"
    private var nextUnlimitedJumpPrepareAt = 0L
    private lateinit var jumpMod: JumpMod

    // app9 BOT LAB V5. Kept outside the payload path on purpose.
    private lateinit var botLab: BotLabController

    private var autoMaster = false
    private var playExtrasExpanded = false

    private var speedAutoOwned = false
    private var potatoCoinAutoOwned = false
    private var potatoRapidAutoOwned = false
    private var baseSpeedAutoOwned = false
    private var pitLiftAutoOwned = false
    private var reviveAutoOwned = false
    private var unlimitedJumpAutoOwned = false

    /*
     * AUTO preset.
     * Giant and Giant Size are separate selections.
     * Giant Size still requires Giant at runtime.
     */
    private val autoSelected = linkedMapOf(
        "SPEED" to false,
        "HP" to false,
        "GIANT" to false,
        "GIANT_SIZE" to false,
        "SUPER" to false,
        "POWER" to false,
        "XP" to false,
        "COIN" to false,
        "BASE_SPEED" to false,
        "PIT_LIFT" to false,
        "REVIVE" to false,
        "UNLIMITED_JUMP" to false,
        "POTATO_COIN" to false,
        "POTATO_RAPID" to false,
        "ULTIMATE" to false
    )


    private fun loadSavedModSettings() {
        val saved = modSettingsStore.load()

        speed = saved.gameSpeed
        giantSizePercent = saved.giantSizePercent
        xp = saved.xp
        coin = saved.coin
        potatoCoinMode = saved.potatoCoinMode
        potatoCoin = saved.potatoCoin
        potatoCoinInterval = saved.potatoCoinInterval
        potatoRapid = saved.potatoRapid
        potatoUltimateInfinite = saved.potatoUltimateInfinite
        potatoUltimateSeconds = saved.potatoUltimateSeconds
        baseSpeedMultiplier = saved.baseSpeedMultiplier

        autoSelected.keys.forEach { key ->
            autoSelected[key] = saved.autoSelected.contains(key)
        }

        // Runtime state is intentionally NOT restored.
        // Every service/app start begins with all MOD engines OFF.
        hpOn = false
        hpAutoOwned = false
        speedOn = false
        giantOn = false
        giantAutoOwned = false
        giantSizeAutoOwned = false
        giantSizeOn = false
        superOn = false
        superAutoOwned = false
        powerOn = false
        powerAutoOwned = false
        xpOn = false
        xpAutoOwned = false
        coinOn = false
        coinAutoOwned = false
        potatoCoinOn = false
        potatoRapidOn = false
        potatoUltimateOn = false
        potatoUltimateAutoOwned = false
        baseSpeedOn = false
        pitLiftOn = false
        reviveOn = false
        unlimitedJumpOn = false

        speedAutoOwned = false
        potatoCoinAutoOwned = false
        potatoRapidAutoOwned = false
        baseSpeedAutoOwned = false
        pitLiftAutoOwned = false
        reviveAutoOwned = false
        unlimitedJumpAutoOwned = false
        playExtrasExpanded = false

        autoMaster = false
    }

    private fun saveAutoSelection() {
        modSettingsStore.saveAutoSelected(
            autoSelected
                .filterValues { it }
                .keys
                .toSet()
        )
    }


    override fun onCreate() {
        super.onCreate()

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        language = prefs.getString(P_LANG, TH) ?: TH
        menuSize = prefs.getString(P_MENU_SIZE, MEDIUM) ?: MEDIUM
        wSize = prefs.getString(P_W_SIZE, MEDIUM) ?: MEDIUM
        rememberKey = prefs.getBoolean(P_REMEMBER, false)
        showCountdown = prefs.getBoolean(P_SHOW_TIME, true)
        showOnline = prefs.getBoolean(P_SHOW_ONLINE, true)
        quickModEnabled = prefs.getBoolean(P_QUICK_ENABLED, true)

        modSettingsStore = ModSettingsStore(this)
        loadSavedModSettings()

        if (BuildConfig.INTERNAL_BUILD) {
            DevConsole.log("APP", "FloatingMenuService created pid=${Process.myPid()}")
        }

        createNotificationChannel()
        startForegroundCompat()

        /*
         * Local session gate.
         *
         * If Android or another code path tries to create the overlay service
         * without a LOGIN in this process, the service immediately exits.
         */
        if (!SessionManager.isAuthenticated()) {

            Log.w(
                TAG,
                "Floating menu rejected: no authenticated M Woif session"
            )

            stopSelf()

            return
        }

        if (!Settings.canDrawOverlays(this) || !hasUsageAccess()) {
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        usage = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        gameSpeedMod =
            GameSpeedMod()

        hpMod =
            HpMod()

        activeServiceForBoxPump = this

        nativeEffectMod =
            NativeEffectMod(
                this
            )

        if (BuildConfig.INTERNAL_BUILD) {
            giantSuperDev =
                GiantSuperDevTemplate(
                    this
                )
            buildUpdateDev =
                BuildUpdateDevFinder(
                    this
                )
        }

        powerPlusMod =
            PowerPlusMod(
                this
            )

        runRewardMod =
            RunRewardMod(
                this
            )

        potatoCoinMod =
            PotatoCoinMod(
                this
            )

        potatoRapidMod =
            PotatoRapidMod(
                this
            )

        potatoUltimateMod =
            PotatoUltimateMod(
                this
            )

        baseSpeedMod =
            BaseSpeedMod(
                this
            )

        recoveryMod =
            RecoveryMod(
                this
            )

        jumpMod =
            JumpMod(
                this
            )

        if (BOT_LAB_ENABLED) {
            botLab =
                BotLabController(
                    context = this,
                    windowManager = wm,
                    mainHandler = handler
                ) {
                    handler.post {
                        if (activeTab == Tab.AUTO && menuVisible) {
                            renderTab(resetScroll = false)
                        }
                    }
                }
        }

        Thread(
            {
                RootMemoryClient
                    .ensureStarted(
                        this
                    )
            },
            "mw-root-warm"
        )
            .apply {
                isDaemon =
                    true
                start()
            }

        preloadCatalogProfiles()

        createW()
        createQuickModButton()
        createMenu()
        handler.post(watcher)
        handler.post(countdownTicker)
        handler.postDelayed(heartbeatTicker, 5_000L)

        Log.d(TAG, "Wide UI v0.3 created")
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        /*
         * Do not allow Android to resurrect the menu by itself after the
         * process/service has been killed. User must return to M Woif and
         * authenticate again.
         */
        return START_NOT_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun tr(th: String, en: String) = if (language == EN) en else th

    /**
     * 4.2/4.3 Catalog binding.
     *
     * Preserve the existing preload behavior, but the list of eager profile
     * families now comes from FeatureCatalog instead of being duplicated in
     * FloatingMenuService. Giant/Super remain ON_DEMAND.
     */
    private fun preloadCatalogProfiles() {
        FeatureCatalog.eagerFeatures().forEach { feature ->
            if (!ControlPlaneState.isFeatureAllowed(feature.featureId)) {
                return@forEach
            }

            SecureProfileManager.preloadFeature(feature.featureId) { result ->
                if (result is SecureProfileManager.Result.Success) {
                    cacheCatalogProfile(feature.featureId)
                }
            }
        }
    }

    private fun cacheCatalogProfile(featureId: String) {
        when (featureId) {
            CrgProfile.FEATURE_POTATO ->
                SecureProfileManager.getPotato()?.let { profile ->
                    potatoRapidMod.cacheProfile(profile)
                    potatoUltimateMod.cacheProfile(profile)
                    potatoCoinMod.cacheProfile(profile)
                }

            CrgProfile.FEATURE_BASE_SPEED ->
                SecureProfileManager.getBaseSpeed()?.let { profile ->
                    baseSpeedMod.cacheProfile(profile)
                }

            CrgProfile.FEATURE_RECOVERY ->
                SecureProfileManager.getRecovery()?.let { profile ->
                    recoveryMod.cacheProfile(profile)
                }

            CrgProfile.FEATURE_UNLIMITED_JUMP ->
                SecureProfileManager.getJump()?.let { profile ->
                    jumpMod.cacheProfile(profile)
                }
        }
    }

    // ---------------------------------------------------------------------
    // Foreground watcher
    // ---------------------------------------------------------------------

    private val watcher = object : Runnable {
        override fun run() {
            try {
                updateForegroundPackage()

                if (foregroundPackage == GAME_PACKAGE) {

                    prewarmGameSpeedIfNeeded()
                    prewarmHpIfNeeded()
                    prewarmNativeEffectsIfNeeded()
                    prewarmPowerPlusIfNeeded()
                    prewarmRunRewardIfNeeded()
                    prewarmPotatoIfNeeded()
                    prewarmBaseSpeedIfNeeded()
                    prewarmRecoveryIfNeeded()
                    prewarmUnlimitedJumpIfNeeded()

                    if (BuildConfig.INTERNAL_BUILD && activeTab == Tab.DEV && menuVisible) {
                        updateDevViews()
                    }

                    // BOT V5 does not own/intercept game touch. Keep the normal
                    // M Woif menu button and Quick MOD ON/OFF visible while BOT runs.
                    if (overlayHiddenMode) {
                        hideMenu(false)
                        hideW()
                        hideQuickModButton()
                        ensureHiddenOverlayZones()
                    } else {
                        hideHiddenOverlayZones()
                        if (!menuVisible) showW()
                        if (quickModEnabled) {
                            showQuickModButton()
                            updateQuickModButtonState()
                        } else {
                            hideQuickModButton()
                        }
                    }

                } else {
                    // Hidden mode is intentionally session/runtime only. Leaving the
                    // game restores normal visibility the next time the game is opened.
                    if (overlayHiddenMode) {
                        exitHiddenOverlayMode(restoreVisible = false)
                    }
                    hideMenu(false)
                    hideW()
                    hideQuickModButton()
                    hideHiddenOverlayZones()
                }
            } catch (e: Exception) {
                Log.e(TAG, "watcher", e)
            }

            handler.postDelayed(this, CHECK_INTERVAL)
        }
    }

    private fun prewarmGameSpeedIfNeeded() {

        if (
            !::gameSpeedMod.isInitialized ||
            gameSpeedMod.isPrepared() ||
            speedOn
        ) {
            return
        }

        val now =
            System.currentTimeMillis()

        if (
            now <
            nextGameSpeedPrepareAt
        ) {
            return
        }

        nextGameSpeedPrepareAt =
            now +
                    1200L

        if (
            !SecureProfileManager
                .hasGameSpeed()
        ) {

            gameSpeedStatusText =
                tr(
                    "กำลังโหลด Secure Profile...",
                    "Loading Secure Profile..."
                )

            SecureProfileManager
                .preloadGameSpeed {
                    handler.post {
                        prewarmGameSpeedIfNeeded()
                    }
                }

            return
        }

        gameSpeedMod.prepareAsync { result ->

            handler.post {

                gameSpeedStatusText =
                    if (
                        result.ok
                    ) {

                        tr(
                            "Game Speed พร้อม • กด ON ได้ทันที",
                            "Game Speed ready"
                        )

                    } else {

                        when (
                            result.errorCode
                        ) {

                            "ROOT_REQUIRED" ->
                                tr(
                                    "กำลังรอสิทธิ์ Root",
                                    "Waiting for Root"
                                )

                            "PROFILE_NOT_READY" ->
                                tr(
                                    "กำลังโหลด Secure Profile...",
                                    "Loading Secure Profile..."
                                )

                            else ->
                                tr(
                                    "กำลังเตรียม Game Speed...",
                                    "Preparing Game Speed..."
                                )
                        }
                    }

                if (
                    activeTab ==
                    Tab.PLAY &&
                    menuVisible
                ) {
                    renderTab()
                }
            }
        }
    }

    private fun prewarmHpIfNeeded() {

        if (
            !::hpMod.isInitialized ||
            hpMod.isPrepared() ||
            hpOn ||
            hpAutoOwned
        ) {
            return
        }

        val now =
            System.currentTimeMillis()

        if (
            now <
            nextHpPrepareAt
        ) {
            return
        }

        nextHpPrepareAt =
            now +
                    1200L

        if (
            !SecureProfileManager
                .hasHp()
        ) {

            hpStatusText =
                tr(
                    "กำลังโหลด Secure HP Profile...",
                    "Loading Secure HP Profile..."
                )

            SecureProfileManager
                .preloadHp {
                    handler.post {
                        prewarmHpIfNeeded()
                    }
                }

            return
        }

        hpMod.prepareAsync { result ->

            handler.post {

                hpStatusText =
                    if (
                        result.ok
                    ) {
                        tr(
                            "HP พร้อม • รอเข้า Stage",
                            "HP ready • Waiting for stage"
                        )
                    } else {
                        hpErrorText(
                            result
                        )
                    }

                if (
                    activeTab ==
                    Tab.PLAY &&
                    menuVisible
                ) {
                    renderTab()
                }
            }
        }
    }

    private fun prewarmNativeEffectsIfNeeded() {

        if (!::nativeEffectMod.isInitialized) {
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextNativeEffectPrepareAt) {
            return
        }

        nextNativeEffectPrepareAt = now + 5000L

        if (
            ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GIANT)
        ) {
            val profile = SecureProfileManager.getGiant()

            if (profile != null) {
                val cached = nativeEffectMod.cacheProfile(profile)
                giantStatusText = if (cached.ok) {
                    tr("Giant พร้อม • กด ON ได้", "Giant ready")
                } else {
                    cached.message
                }
            } else {
                giantStatusText = tr(
                    "กำลังโหลด Secure Giant Profile...",
                    "Loading Secure Giant Profile..."
                )

                SecureProfileManager.preloadGiant { result ->
                    handler.post {
                        giantStatusText = secureNativeProfileStatus(
                            result,
                            tr("Giant พร้อม • กด ON ได้", "Giant ready")
                        )

                        SecureProfileManager.getGiant()?.let {
                            nativeEffectMod.cacheProfile(it)
                        }

                        if (activeTab == Tab.PLAY && menuVisible) {
                            renderTab()
                        }
                    }
                }
            }
        } else {
            giantStatusText = controlBlockedText(CrgProfile.FEATURE_GIANT)
        }

        if (
            ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_SUPER)
        ) {
            val profile = SecureProfileManager.getSuper()

            if (profile != null) {
                val cached = nativeEffectMod.cacheProfile(profile)
                superStatusText = if (cached.ok) {
                    tr("Super พร้อม • กด ON ได้", "Super ready")
                } else {
                    cached.message
                }
            } else {
                superStatusText = tr(
                    "กำลังโหลด Secure Super Profile...",
                    "Loading Secure Super Profile..."
                )

                SecureProfileManager.preloadSuper { result ->
                    handler.post {
                        superStatusText = secureNativeProfileStatus(
                            result,
                            tr("Super พร้อม • กด ON ได้", "Super ready")
                        )

                        SecureProfileManager.getSuper()?.let {
                            nativeEffectMod.cacheProfile(it)
                        }

                        if (activeTab == Tab.PLAY && menuVisible) {
                            renderTab()
                        }
                    }
                }
            }
        } else {
            superStatusText = controlBlockedText(CrgProfile.FEATURE_SUPER)
        }
    }

    private fun prewarmPowerPlusIfNeeded() {
        if (!::powerPlusMod.isInitialized || powerOn || powerAutoOwned) {
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POWER_PLUS)) {
            powerStatusText = controlBlockedText(CrgProfile.FEATURE_POWER_PLUS)
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextPowerPlusPrepareAt) return
        nextPowerPlusPrepareAt = now + 5000L

        val current = SecureProfileManager.getPowerPlus()
        if (current != null) {
            val cached = powerPlusMod.cacheProfile(current)
            powerStatusText = if (cached.ok) {
                tr("Power+ พร้อม • กด ON ได้", "Power+ ready")
            } else {
                cached.message
            }
            return
        }

        powerStatusText = tr(
            "กำลังโหลด Secure Power+ Profile...",
            "Loading Secure Power+ Profile..."
        )

        SecureProfileManager.preloadPowerPlus { result ->
            handler.post {
                powerStatusText = secureNativeProfileStatus(
                    result,
                    tr("Power+ พร้อม • กด ON ได้", "Power+ ready")
                )

                SecureProfileManager.getPowerPlus()?.let {
                    val cached = powerPlusMod.cacheProfile(it)
                    if (!cached.ok) powerStatusText = cached.message
                }

                if (activeTab == Tab.PLAY && menuVisible) {
                    renderTab()
                }
            }
        }
    }

    private fun prewarmRunRewardIfNeeded() {
        if (!::runRewardMod.isInitialized || xpOn || coinOn || xpAutoOwned || coinAutoOwned) {
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            xpStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            coinStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextRunRewardPrepareAt) return
        nextRunRewardPrepareAt = now + 5000L

        val current = SecureProfileManager.getRunReward()
        if (current != null) {
            val cached = runRewardMod.cacheProfile(current)
            if (cached.ok) {
                xpStatusText = tr("XP พร้อม • กด ON ได้", "XP ready")
                coinStatusText = tr("Coin พร้อม • กด ON ได้", "Coin ready")
            } else {
                xpStatusText = cached.message
                coinStatusText = cached.message
            }
            return
        }

        xpStatusText = tr("กำลังโหลด Secure XP/Coin Profile...", "Loading Secure XP/Coin Profile...")
        coinStatusText = xpStatusText

        SecureProfileManager.preloadRunReward { result ->
            handler.post {
                val text = secureNativeProfileStatus(
                    result,
                    tr("XP/Coin พร้อม • กด ON ได้", "XP/Coin ready")
                )
                xpStatusText = text
                coinStatusText = text

                SecureProfileManager.getRunReward()?.let {
                    val cached = runRewardMod.cacheProfile(it)
                    if (!cached.ok) {
                        xpStatusText = cached.message
                        coinStatusText = cached.message
                    }
                }

                if (activeTab == Tab.PLAY && menuVisible) renderTab()
            }
        }
    }

    private fun prewarmPotatoIfNeeded() {
        if (
            !::potatoCoinMod.isInitialized ||
            !::potatoRapidMod.isInitialized ||
            !::potatoUltimateMod.isInitialized ||
            potatoCoinOn ||
            potatoRapidOn ||
            potatoUltimateOn ||
            potatoUltimateAutoOwned
        ) {
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            potatoCoinStatusText = controlBlockedText(CrgProfile.FEATURE_POTATO)
            potatoRapidStatusText = potatoCoinStatusText
            potatoUltimateStatusText = potatoCoinStatusText
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextPotatoPrepareAt) return
        nextPotatoPrepareAt = now + 5000L

        val current = SecureProfileManager.getPotato()
        if (current != null) {
            val coinCached = potatoCoinMod.cacheProfile(current)
            val rapidCached = potatoRapidMod.cacheProfile(current)
            val ultimateCached = potatoUltimateMod.cacheProfile(current)

            potatoCoinStatusText = if (coinCached.ok) {
                tr("Potato เหรียญ พร้อม • กด ON ได้", "Potato Coin ready")
            } else {
                coinCached.message
            }

            potatoRapidStatusText = if (rapidCached.ok) {
                tr("Potato ยิงเร็ว พร้อม • กด ON ได้", "Potato Rapid ready")
            } else {
                rapidCached.message
            }

            potatoUltimateStatusText = if (ultimateCached.ok) {
                tr("Potato อัลติเมต พร้อม • กด ON ได้", "Potato Ultimate ready")
            } else {
                ultimateCached.message
            }
            return
        }

        potatoCoinStatusText = tr(
            "กำลังโหลด Secure Potato Profile...",
            "Loading Secure Potato Profile..."
        )
        potatoRapidStatusText = potatoCoinStatusText
        potatoUltimateStatusText = potatoCoinStatusText

        SecureProfileManager.preloadPotato { result ->
            handler.post {
                val baseStatus = secureNativeProfileStatus(
                    result,
                    tr("Potato พร้อม • กด ON ได้", "Potato ready")
                )
                potatoCoinStatusText = baseStatus
                potatoRapidStatusText = baseStatus
                potatoUltimateStatusText = baseStatus

                SecureProfileManager.getPotato()?.let { profile ->
                    val coinCached = potatoCoinMod.cacheProfile(profile)
                    val rapidCached = potatoRapidMod.cacheProfile(profile)
                    val ultimateCached = potatoUltimateMod.cacheProfile(profile)
                    if (!coinCached.ok) potatoCoinStatusText = coinCached.message
                    if (!rapidCached.ok) potatoRapidStatusText = rapidCached.message
                    if (!ultimateCached.ok) potatoUltimateStatusText = ultimateCached.message
                }

                if (activeTab == Tab.FARM && menuVisible) renderTab()
                if (activeTab == Tab.PLAY && menuVisible) renderTab()
            }
        }
    }

    private fun prewarmBaseSpeedIfNeeded() {
        if (
            !::baseSpeedMod.isInitialized ||
            baseSpeedOn
        ) {
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_BASE_SPEED)) {
            baseSpeedStatusText = controlBlockedText(CrgProfile.FEATURE_BASE_SPEED)
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextBaseSpeedPrepareAt) return
        nextBaseSpeedPrepareAt = now + 5000L

        val current = SecureProfileManager.getBaseSpeed()
        if (current != null) {
            val cached = baseSpeedMod.cacheProfile(current)
            baseSpeedStatusText = if (cached.ok) {
                tr("ความเร็วพื้นฐานพร้อม • กด ON ได้", "Base Speed ready")
            } else {
                cached.message
            }
            return
        }

        baseSpeedStatusText = tr(
            "กำลังโหลด Secure Base Speed Profile...",
            "Loading Secure Base Speed Profile..."
        )

        SecureProfileManager.preloadBaseSpeed { result ->
            handler.post {
                baseSpeedStatusText = secureNativeProfileStatus(
                    result,
                    tr("ความเร็วพื้นฐานพร้อม • กด ON ได้", "Base Speed ready")
                )

                SecureProfileManager.getBaseSpeed()?.let { profile ->
                    val cached = baseSpeedMod.cacheProfile(profile)
                    if (!cached.ok) baseSpeedStatusText = cached.message
                }

                if (activeTab == Tab.PLAY && menuVisible) renderTab()
            }
        }
    }

    private fun prewarmRecoveryIfNeeded() {
        if (
            !::recoveryMod.isInitialized ||
            pitLiftOn ||
            reviveOn
        ) {
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)) {
            val blocked = controlBlockedText(CrgProfile.FEATURE_RECOVERY)
            pitLiftStatusText = blocked
            reviveStatusText = blocked
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextRecoveryPrepareAt) return
        nextRecoveryPrepareAt = now + 5000L

        val current = SecureProfileManager.getRecovery()
        if (current != null) {
            val cached = recoveryMod.cacheProfile(current)
            val ready = if (cached.ok) {
                tr("Recovery พร้อม • กด ON ได้", "Recovery ready")
            } else {
                cached.message
            }
            pitLiftStatusText = ready
            reviveStatusText = ready
            return
        }

        val loading = tr(
            "กำลังโหลด Secure Recovery Profile...",
            "Loading Secure Recovery Profile..."
        )
        pitLiftStatusText = loading
        reviveStatusText = loading

        SecureProfileManager.preloadRecovery { result ->
            handler.post {
                val baseStatus = secureNativeProfileStatus(
                    result,
                    tr("Recovery พร้อม • กด ON ได้", "Recovery ready")
                )
                pitLiftStatusText = baseStatus
                reviveStatusText = baseStatus

                SecureProfileManager.getRecovery()?.let { profile ->
                    val cached = recoveryMod.cacheProfile(profile)
                    if (!cached.ok) {
                        pitLiftStatusText = cached.message
                        reviveStatusText = cached.message
                    }
                }

                if (activeTab == Tab.PLAY && menuVisible) renderTab()
            }
        }
    }

    private fun prewarmUnlimitedJumpIfNeeded() {
        if (!::jumpMod.isInitialized || unlimitedJumpOn) {
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_UNLIMITED_JUMP)) {
            unlimitedJumpStatusText = controlBlockedText(CrgProfile.FEATURE_UNLIMITED_JUMP)
            return
        }

        val now = System.currentTimeMillis()
        if (now < nextUnlimitedJumpPrepareAt) return
        nextUnlimitedJumpPrepareAt = now + 5000L

        val current = SecureProfileManager.getJump()
        if (current != null) {
            val cached = jumpMod.cacheProfile(current)
            unlimitedJumpStatusText = if (cached.ok) {
                tr("Unlimited Jump พร้อม • กด ON ได้", "Unlimited Jump ready")
            } else {
                cached.message
            }
            return
        }

        unlimitedJumpStatusText = tr(
            "กำลังโหลด Secure Unlimited Jump Profile...",
            "Loading Secure Unlimited Jump Profile..."
        )

        SecureProfileManager.preloadJump { result ->
            handler.post {
                unlimitedJumpStatusText = secureNativeProfileStatus(
                    result,
                    tr("Unlimited Jump พร้อม • กด ON ได้", "Unlimited Jump ready")
                )

                SecureProfileManager.getJump()?.let { profile ->
                    val cached = jumpMod.cacheProfile(profile)
                    if (!cached.ok) unlimitedJumpStatusText = cached.message
                }

                if (activeTab == Tab.PLAY && menuVisible) renderTab()
            }
        }
    }

    private fun secureNativeProfileStatus(
        result: SecureProfileManager.Result,
        readyText: String
    ): String {
        return when (result) {
            is SecureProfileManager.Result.Success -> readyText
            is SecureProfileManager.Result.Failure -> when (result.code) {
                "FEATURE_DISABLED" -> tr(
                    "ฟีเจอร์กำลังอัปเดต • ใช้งานชั่วคราวไม่ได้",
                    "Feature is being updated • Temporarily unavailable"
                )

                "GAME_VERSION_BLOCKED" -> tr(
                    "เวอร์ชันเกมนี้กำลังอัปเดต",
                    "This game version is being updated"
                )

                "PROFILE_KEY_MISMATCH" -> tr(
                    "Secure Profile key ไม่ตรง installation",
                    "Secure Profile key does not match this installation"
                )

                else -> "Secure Profile ไม่พร้อม: ${result.code}"
            }
        }
    }

    private fun updateForegroundPackage() {
        val now = System.currentTimeMillis()
        val begin = (lastEventTime - 1000L).coerceAtLeast(0L)
        val events = usage.queryEvents(begin, now)
        val event = UsageEvents.Event()
        var newest = lastEventTime
        var pkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)

            val resumed = event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            @Suppress("DEPRECATION")
            val fg = event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND

            if ((resumed || fg) && event.timeStamp > newest) {
                newest = event.timeStamp
                pkg = event.packageName
            }
        }

        if (pkg != null) {
            foregroundPackage = pkg
            lastEventTime = newest
        }
    }

    // ---------------------------------------------------------------------
    // Countdown
    // ---------------------------------------------------------------------

    private val countdownTicker = object : Runnable {

        override fun run() {

            updateCountdown()

            if (
                !licenseInvalidated
            ) {

                handler.postDelayed(
                    this,
                    1000L
                )
            }
        }
    }

    private val heartbeatTicker = object : Runnable {

        override fun run() {

            if (
                licenseInvalidated
            ) {
                return
            }

            performHeartbeat()

            val delay =
                SessionManager
                    .heartbeatSeconds()
                    .coerceIn(
                        10,
                        600
                    ) *
                        1000L

            handler.postDelayed(
                this,
                delay
            )
        }
    }

    private fun performHeartbeat() {

        if (
            !heartbeatInFlight.compareAndSet(
                false,
                true
            )
        ) {
            return
        }

        val session =
            SessionManager.snapshot()

        if (
            session == null
        ) {

            heartbeatInFlight.set(
                false
            )

            forceLicenseLogout(
                "NO_SESSION"
            )

            return
        }

        licenseExecutor.execute {

            val result =
                LicenseApi.check(
                    sessionToken =
                    session.sessionToken,

                    deviceId =
                    session.deviceId,

                    gameId =
                    session.gameId,

                    gameVersion =
                    session.gameVersion,

                    appVersion =
                    session.appVersion,

                    appContentRevision =
                    SessionManager.appContentRevision()
                )

            handler.post {

                heartbeatInFlight.set(
                    false
                )

                if (
                    licenseInvalidated
                ) {
                    return@post
                }

                when (
                    result
                ) {

                    is ApiResult.Success -> {

                        try {

                            val oldContentRevision =
                                SessionManager.appContentRevision()

                            SessionManager.update(
                                result.value
                            )

                            val contentChanged =
                                SessionManager.appContentRevision() !=
                                    oldContentRevision

                            ControlPlaneState.update(
                                result.value.control
                            )

                            applyControlPlaneState()

                            // Refresh resident secure profiles before their short
                            // RAM cache expires. Every fetch receives a fresh
                            // server-generated AES-256-GCM key.
                            SecureProfileManager.refreshDueProfiles()

                            updateCountdown()

                            if (
                                contentChanged &&
                                !BuildConfig.INTERNAL_BUILD &&
                                activeTab == Tab.HOME &&
                                menuVisible
                            ) {
                                renderTab(resetScroll = false)
                            }

                        } catch (
                            e: Exception
                        ) {

                            Log.e(
                                TAG,
                                "Invalid heartbeat payload",
                                e
                            )

                            /*
                             * Keep the current short server session.
                             * If it reaches session_expires_at, countdown
                             * handling below fails closed.
                             */
                        }
                    }

                    is ApiResult.Failure -> {

                        Log.w(
                            TAG,
                            "License heartbeat rejected: ${result.error}"
                        )

                        if (
                            shouldInvalidateImmediately(
                                result.error
                            )
                        ) {

                            forceLicenseLogout(
                                result.error
                            )

                        } else if (
                            SessionManager.sessionRemainingMillis() <=
                            0L
                        ) {

                            forceLicenseLogout(
                                "SESSION_TIMEOUT"
                            )
                        }
                    }

                    is ApiResult.NetworkFailure -> {

                        Log.w(
                            TAG,
                            "Heartbeat network failure: ${result.message}"
                        )

                        /*
                         * A temporary network outage does not instantly kill
                         * the menu. It may survive only until the last
                         * server-issued short session expires.
                         */
                        if (
                            SessionManager.sessionRemainingMillis() <=
                            0L
                        ) {

                            forceLicenseLogout(
                                "NETWORK_SESSION_TIMEOUT"
                            )
                        }
                    }
                }
            }
        }
    }

    private fun shouldInvalidateImmediately(
        error: String
    ): Boolean {

        return when (
            error
        ) {

            "INVALID_SESSION",
            "SESSION_REVOKED",
            "SESSION_EXPIRED",
            "KEY_DISABLED",
            "KEY_REVOKED",
            "KEY_EXPIRED",
            "DEVICE_MISMATCH",
            "GAME_MISMATCH",
            "GAME_VERSION_MISMATCH",
            "GAME_DISABLED",
            "GAME_NOT_ALLOWED",
            "APP_UPDATE_REQUIRED",
            "MAINTENANCE",
            "SERVICE_DISABLED" ->
                true

            else ->
                false
        }
    }

    private fun controlBlockedText(featureId: String): String {
        return if (!ControlPlaneState.canWrite()) {
            tr(
                "เวอร์ชันเกมนี้กำลังอัปเดต • MOD ถูกปิดชั่วคราว",
                "This game version is being updated • MOD writes are temporarily disabled"
            )
        } else {
            when (featureId) {
                CrgProfile.FEATURE_GAME_SPEED ->
                    tr(
                        "กำลังอัปเดต Game Speed • ใช้งานชั่วคราวไม่ได้",
                        "Game Speed is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_HP ->
                    tr(
                        "กำลังอัปเดต HP • ใช้งานชั่วคราวไม่ได้",
                        "HP is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_GIANT ->
                    tr(
                        "กำลังอัปเดต Giant • ใช้งานชั่วคราวไม่ได้",
                        "Giant is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_SUPER ->
                    tr(
                        "กำลังอัปเดต Super • ใช้งานชั่วคราวไม่ได้",
                        "Super is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_POWER_PLUS ->
                    tr(
                        "กำลังอัปเดต Power+ • ใช้งานชั่วคราวไม่ได้",
                        "Power+ is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_RUN_REWARD ->
                    tr(
                        "กำลังอัปเดต XP/Coin • ใช้งานชั่วคราวไม่ได้",
                        "XP/Coin is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_POTATO ->
                    tr(
                        "กำลังอัปเดต Potato • ใช้งานชั่วคราวไม่ได้",
                        "Potato is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_BASE_SPEED ->
                    tr(
                        "กำลังอัปเดตความเร็วพื้นฐาน • ใช้งานชั่วคราวไม่ได้",
                        "Base Speed is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_RECOVERY ->
                    tr(
                        "กำลังอัปเดต Pit Lift / Revive • ใช้งานชั่วคราวไม่ได้",
                        "Pit Lift / Revive is being updated • Temporarily unavailable"
                    )

                CrgProfile.FEATURE_UNLIMITED_JUMP ->
                    tr(
                        "กำลังอัปเดต Unlimited Jump • ใช้งานชั่วคราวไม่ได้",
                        "Unlimited Jump is being updated • Temporarily unavailable"
                    )

                else ->
                    tr(
                        "ฟีเจอร์นี้กำลังอัปเดต • ใช้งานชั่วคราวไม่ได้",
                        "This feature is being updated • Temporarily unavailable"
                    )
            }
        }
    }

    private fun applyControlPlaneState() {
        val control = ControlPlaneState.snapshot()

        val speedAllowed =
            ControlPlaneState.isControlAllowed("GAME_SPEED")

        val hpAllowed =
            ControlPlaneState.isControlAllowed("HP")

        val giantAllowed =
            ControlPlaneState.isControlAllowed("GIANT")

        val superAllowed =
            ControlPlaneState.isControlAllowed("SUPER")

        val powerAllowed =
            ControlPlaneState.isControlAllowed("POWER")

        val rewardAllowed =
            ControlPlaneState.isControlAllowed("XP")

        val potatoAllowed =
            ControlPlaneState.isControlAllowed("POTATO_COIN")

        val baseSpeedAllowed =
            ControlPlaneState.isControlAllowed("BASE_SPEED")

        val recoveryAllowed =
            ControlPlaneState.isControlAllowed("PIT_LIFT")

        val jumpAllowed =
            ControlPlaneState.isControlAllowed("UNLIMITED_JUMP")

        val restoreSpeed =
            speedOn &&
                !speedAllowed &&
                ::gameSpeedMod.isInitialized

        val restoreHp =
            (hpOn || hpAutoOwned) &&
                !hpAllowed &&
                ::hpMod.isInitialized

        val restoreGiant =
            (giantOn || giantAutoOwned) &&
                !giantAllowed &&
                ::nativeEffectMod.isInitialized

        val restoreSuper =
            (superOn || superAutoOwned) &&
                !superAllowed &&
                ::nativeEffectMod.isInitialized

        val restorePower =
            (powerOn || powerAutoOwned) &&
                !powerAllowed &&
                ::powerPlusMod.isInitialized

        val restoreReward =
            (xpOn || xpAutoOwned || coinOn || coinAutoOwned) &&
                !rewardAllowed &&
                ::runRewardMod.isInitialized

        val restorePotatoCoin =
            potatoCoinOn &&
                !potatoAllowed &&
                ::potatoCoinMod.isInitialized

        val restorePotatoRapid =
            potatoRapidOn &&
                !potatoAllowed &&
                ::potatoRapidMod.isInitialized

        val restorePotatoUltimate =
            (potatoUltimateOn || potatoUltimateAutoOwned) &&
                !potatoAllowed &&
                ::potatoUltimateMod.isInitialized

        val restoreBaseSpeed =
            baseSpeedOn &&
                !baseSpeedAllowed &&
                ::baseSpeedMod.isInitialized

        val stopRecovery =
            !recoveryAllowed &&
                ::recoveryMod.isInitialized &&
                (
                    pitLiftOn ||
                        reviveOn ||
                        recoveryMod.isPitLiftEnabled() ||
                        recoveryMod.isReviveEnabled()
                )

        val stopJump =
            !jumpAllowed &&
                ::jumpMod.isInitialized &&
                (unlimitedJumpOn || jumpMod.isEnabled())

        if (!speedAllowed) {
            speedOn = false
            speedApplyRunnable?.let {
                handler.removeCallbacks(it)
            }
            speedApplyRunnable = null
            SecureProfileManager.clearFeature(
                CrgProfile.FEATURE_GAME_SPEED
            )
            gameSpeedStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_GAME_SPEED
                )
        }

        if (!hpAllowed) {
            hpOn = false
            hpAutoOwned = false
            autoSelected["HP"] = false
            SecureProfileManager.clearFeature(
                CrgProfile.FEATURE_HP
            )
            hpStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_HP
                )
        }

        if (!giantAllowed) {
            giantOn = false
            giantAutoOwned = false
            autoSelected["GIANT"] = false
            giantStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_GIANT
                )
        }

        if (!superAllowed) {
            superOn = false
            superAutoOwned = false
            autoSelected["SUPER"] = false
            superStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_SUPER
                )
        }

        if (!powerAllowed) {
            powerOn = false
            powerAutoOwned = false
            autoSelected["POWER"] = false
            SecureProfileManager.clearFeature(
                CrgProfile.FEATURE_POWER_PLUS
            )
            powerStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_POWER_PLUS
                )
        }

        if (!rewardAllowed) {
            xpOn = false
            xpAutoOwned = false
            coinOn = false
            coinAutoOwned = false
            autoSelected["XP"] = false
            autoSelected["COIN"] = false
            SecureProfileManager.clearFeature(CrgProfile.FEATURE_RUN_REWARD)
            xpStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            coinStatusText = xpStatusText
        }

        if (!potatoAllowed) {
            potatoCoinOn = false
            potatoCoinAutoOwned = false
            potatoRapidOn = false
            potatoRapidAutoOwned = false
            potatoUltimateOn = false
            potatoUltimateAutoOwned = false
            autoSelected["POTATO_COIN"] = false
            autoSelected["POTATO_RAPID"] = false
            autoSelected["ULTIMATE"] = false
            SecureProfileManager.clearFeature(CrgProfile.FEATURE_POTATO)
            potatoCoinStatusText = controlBlockedText(CrgProfile.FEATURE_POTATO)
            potatoRapidStatusText = potatoCoinStatusText
            potatoUltimateStatusText = potatoCoinStatusText
        }

        if (!baseSpeedAllowed) {
            baseSpeedOn = false
            baseSpeedAutoOwned = false
            autoSelected["BASE_SPEED"] = false
            SecureProfileManager.clearFeature(CrgProfile.FEATURE_BASE_SPEED)
            baseSpeedStatusText = controlBlockedText(CrgProfile.FEATURE_BASE_SPEED)
        }

        if (!recoveryAllowed) {
            pitLiftOn = false
            pitLiftAutoOwned = false
            reviveOn = false
            reviveAutoOwned = false
            autoSelected["PIT_LIFT"] = false
            autoSelected["REVIVE"] = false
            SecureProfileManager.clearFeature(CrgProfile.FEATURE_RECOVERY)
            val blocked = controlBlockedText(CrgProfile.FEATURE_RECOVERY)
            pitLiftStatusText = blocked
            reviveStatusText = blocked
        }

        if (!jumpAllowed) {
            unlimitedJumpOn = false
            unlimitedJumpAutoOwned = false
            autoSelected["UNLIMITED_JUMP"] = false
            SecureProfileManager.clearFeature(CrgProfile.FEATURE_UNLIMITED_JUMP)
            unlimitedJumpStatusText = controlBlockedText(CrgProfile.FEATURE_UNLIMITED_JUMP)
        }

        if (!control.writeAllowed) {
            autoMaster = false
            speedAutoOwned = false
            giantOn = false
            giantAutoOwned = false
            superOn = false
            superAutoOwned = false
            powerOn = false
            powerAutoOwned = false
            xpOn = false
            xpAutoOwned = false
            coinOn = false
            coinAutoOwned = false
            potatoCoinOn = false
            potatoCoinAutoOwned = false
            potatoRapidOn = false
            potatoRapidAutoOwned = false
            potatoUltimateOn = false
            potatoUltimateAutoOwned = false
            baseSpeedOn = false
            baseSpeedAutoOwned = false
            pitLiftOn = false
            pitLiftAutoOwned = false
            reviveOn = false
            reviveAutoOwned = false
            unlimitedJumpOn = false
            unlimitedJumpAutoOwned = false
        }

        if (
            restoreSpeed || restoreHp || restoreGiant || restoreSuper ||
            restorePower || restoreReward || restorePotatoCoin || restorePotatoRapid ||
            restorePotatoUltimate || restoreBaseSpeed || stopRecovery || stopJump
        ) {
            Thread(
                {
                    if (stopRecovery) {
                        try {
                            recoveryMod.disableAllBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (stopJump) {
                        try {
                            jumpMod.disableBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restoreBaseSpeed) {
                        try {
                            baseSpeedMod.restoreBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restorePotatoCoin) {
                        try {
                            potatoCoinMod.restoreBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restorePotatoRapid) {
                        try {
                            potatoRapidMod.restoreBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restorePotatoUltimate) {
                        try {
                            potatoUltimateMod.restoreBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restoreReward) {
                        try {
                            runRewardMod.restoreAllBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restorePower) {
                        try {
                            powerPlusMod.disable { }
                        } catch (_: Exception) {
                        }
                    }

                    if (restoreSuper) {
                        try {
                            nativeEffectMod.restoreFeatureBlockingBestEffort(
                                CrgProfile.FEATURE_SUPER
                            )
                        } catch (_: Exception) {
                        }
                    }

                    if (restoreGiant) {
                        try {
                            nativeEffectMod.restoreFeatureBlockingBestEffort(
                                CrgProfile.FEATURE_GIANT
                            )
                        } catch (_: Exception) {
                        }
                    }

                    if (restoreHp) {
                        try {
                            hpMod.restoreBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (restoreSpeed) {
                        try {
                            gameSpeedMod.restoreBlockingBestEffort()
                        } catch (_: Exception) {
                        }
                    }

                    if (!giantAllowed) {
                        SecureProfileManager.clearFeature(
                            CrgProfile.FEATURE_GIANT
                        )
                    }

                    if (!superAllowed) {
                        SecureProfileManager.clearFeature(
                            CrgProfile.FEATURE_SUPER
                        )
                    }

                    if (!powerAllowed) {
                        SecureProfileManager.clearFeature(
                            CrgProfile.FEATURE_POWER_PLUS
                        )
                    }

                    if (!rewardAllowed) {
                        SecureProfileManager.clearFeature(CrgProfile.FEATURE_RUN_REWARD)
                    }

                    if (!potatoAllowed) {
                        SecureProfileManager.clearFeature(CrgProfile.FEATURE_POTATO)
                    }

                    if (!baseSpeedAllowed) {
                        SecureProfileManager.clearFeature(CrgProfile.FEATURE_BASE_SPEED)
                    }

                    if (!recoveryAllowed) {
                        SecureProfileManager.clearFeature(CrgProfile.FEATURE_RECOVERY)
                    }

                    if (!jumpAllowed) {
                        SecureProfileManager.clearFeature(CrgProfile.FEATURE_UNLIMITED_JUMP)
                    }

                    handler.post {
                        if (menuVisible) {
                            renderTab()
                        }
                    }
                },
                "mw-control-restore"
            ).apply {
                isDaemon = true
                start()
            }
        } else {
            if (!giantAllowed) {
                SecureProfileManager.clearFeature(
                    CrgProfile.FEATURE_GIANT
                )
            }

            if (!superAllowed) {
                SecureProfileManager.clearFeature(
                    CrgProfile.FEATURE_SUPER
                )
            }

            if (!powerAllowed) {
                SecureProfileManager.clearFeature(
                    CrgProfile.FEATURE_POWER_PLUS
                )
            }

            if (!rewardAllowed) {
                SecureProfileManager.clearFeature(CrgProfile.FEATURE_RUN_REWARD)
            }

            if (!potatoAllowed) {
                SecureProfileManager.clearFeature(CrgProfile.FEATURE_POTATO)
            }

            if (!baseSpeedAllowed) {
                SecureProfileManager.clearFeature(CrgProfile.FEATURE_BASE_SPEED)
            }

            if (!recoveryAllowed) {
                SecureProfileManager.clearFeature(CrgProfile.FEATURE_RECOVERY)
            }

            if (!jumpAllowed) {
                SecureProfileManager.clearFeature(CrgProfile.FEATURE_UNLIMITED_JUMP)
            }

            if (menuVisible) {
                renderTab()
            }
        }
    }


    private fun remainingMillis():
            Long {

        return SessionManager
            .licenseRemainingMillis()
    }

    private fun remainingText():
            String {

        var total =
            (
                    remainingMillis() /
                            1000L
                    )
                .coerceAtLeast(
                    0L
                )

        val days =
            total /
                    86400L

        total %=
            86400L

        val h =
            total /
                    3600L

        total %=
            3600L

        val m =
            total /
                    60L

        val s =
            total %
                    60L

        val clock =
            String.format(
                Locale.US,
                "%02d:%02d:%02d",
                h,
                m,
                s
            )

        return if (
            days > 0L
        ) {

            if (
                language ==
                EN
            ) {
                "${days}d $clock"
            } else {
                "${days}วัน $clock"
            }

        } else {

            clock
        }
    }

    private fun expiryText():
            String {

        val expiryMillis =
            SessionManager
                .licenseExpiryMillis()

        if (
            expiryMillis <= 0L
        ) {

            return "--/--/---- • --:--:--"
        }

        return Instant
            .ofEpochMilli(
                expiryMillis
            )
            .atZone(
                ZoneId.of(
                    "Asia/Vientiane"
                )
            )
            .format(
                DateTimeFormatter.ofPattern(
                    "dd/MM/yyyy • HH:mm:ss",
                    Locale.US
                )
            )
    }

    private fun updateCountdown() {

        val licenseExpired =
            remainingMillis() <=
                    0L

        val sessionExpired =
            SessionManager
                .sessionRemainingMillis() <=
                    0L

        licenseChip?.let {

            it.text =
                if (
                    licenseExpired ||
                    sessionExpired
                ) {
                    tr(
                        "● หมดอายุ",
                        "● Expired"
                    )
                } else {
                    tr(
                        "● ใช้งานได้",
                        "● Active"
                    )
                }

            pill(
                it,

                if (
                    licenseExpired ||
                    sessionExpired
                ) {
                    "#3A151A"
                } else {
                    "#112D20"
                },

                if (
                    licenseExpired ||
                    sessionExpired
                ) {
                    "#7C2831"
                } else {
                    "#205A3A"
                },

                if (
                    licenseExpired ||
                    sessionExpired
                ) {
                    "#FF8792"
                } else {
                    "#4ADE80"
                }
            )
        }

        countdownChip?.let {

            it.visibility =
                if (
                    showCountdown
                ) {
                    View.VISIBLE
                } else {
                    View.GONE
                }

            it.text =
                if (
                    licenseExpired
                ) {
                    "00:00:00"
                } else {
                    remainingText()
                }
        }

        onlineChip?.let {

            it.visibility =
                if (
                    showOnline
                ) {
                    View.VISIBLE
                } else {
                    View.GONE
                }

            it.text =
                tr(
                    "● ออนไลน์",
                    "● Online"
                )
        }

        expiryLabel?.text =
            tr(
                "หมดอายุ ${expiryText()}",
                "Expires ${expiryText()}"
            )

        if (
            !licenseInvalidated &&
            (
                    licenseExpired ||
                            sessionExpired
                    )
        ) {

            forceLicenseLogout(
                if (
                    licenseExpired
                ) {
                    "KEY_EXPIRED_LOCAL"
                } else {
                    "SESSION_EXPIRED_LOCAL"
                }
            )
        }
    }

    private fun forceLicenseLogout(
        reason:
        String
    ) {

        if (
            licenseInvalidated
        ) {
            return
        }

        licenseInvalidated =
            true

        Log.w(
            TAG,
            "License invalidated: $reason"
        )

        val restoreGameSpeed =
            speedOn &&
                    ::gameSpeedMod.isInitialized

        val restoreHp =
            (
                    hpOn ||
                            hpAutoOwned
                    ) &&
                    ::hpMod.isInitialized

        val restoreNativeEffects =
            (
                    giantOn ||
                            giantAutoOwned ||
                            boxPumpOwnsGiant ||
                            superOn ||
                            superAutoOwned
                    ) &&
                    ::nativeEffectMod.isInitialized

        val restorePower =
            (
                    powerOn ||
                            powerAutoOwned
                    ) &&
                    ::powerPlusMod.isInitialized

        val restoreReward =
            (
                    xpOn ||
                            xpAutoOwned ||
                            coinOn ||
                            coinAutoOwned
                    ) &&
                    ::runRewardMod.isInitialized

        val restorePotatoCoin =
            potatoCoinOn &&
                    ::potatoCoinMod.isInitialized

        val restorePotatoRapid =
            potatoRapidOn &&
                    ::potatoRapidMod.isInitialized

        val restorePotatoUltimate =
            (potatoUltimateOn || potatoUltimateAutoOwned) &&
                    ::potatoUltimateMod.isInitialized

        val restoreBaseSpeed =
            baseSpeedOn &&
                    ::baseSpeedMod.isInitialized

        val stopRecovery =
            ::recoveryMod.isInitialized &&
                (
                    pitLiftOn ||
                        reviveOn ||
                        recoveryMod.isPitLiftEnabled() ||
                        recoveryMod.isReviveEnabled()
                )

        val stopJump =
            ::jumpMod.isInitialized &&
                (unlimitedJumpOn || jumpMod.isEnabled())

        autoMaster =
            false

        hpOn =
            false

        hpAutoOwned =
            false

        speedOn =
            false

        giantOn =
            false

        giantAutoOwned =
            false

        giantSizeAutoOwned =
            false

        giantSizeOn =
            false

        superOn =
            false

        superAutoOwned =
            false

        powerOn =
            false

        powerAutoOwned =
            false

        xpOn =
            false

        xpAutoOwned =
            false

        coinOn =
            false

        coinAutoOwned =
            false

        potatoCoinOn =
            false

        potatoRapidOn =
            false

        potatoUltimateOn =
            false

        potatoUltimateAutoOwned =
            false

        baseSpeedOn =
            false

        pitLiftOn =
            false

        reviveOn =
            false

        unlimitedJumpOn =
            false

        hideMenu(
            false
        )

        hideW()
        hideQuickModButton()

        handler.removeCallbacks(
            heartbeatTicker
        )

        handler.removeCallbacks(
            countdownTicker
        )

        /*
         * Keep the root worker alive until every real feature has restored.
         * Restore work is done off the UI thread.
         */
        Thread(
            {

                if (stopRecovery) {
                    try {
                        recoveryMod.disableAllBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (stopJump) {
                    try {
                        jumpMod.disableBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (restoreBaseSpeed) {
                    try {
                        baseSpeedMod.restoreBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (restorePotatoCoin) {
                    try {
                        potatoCoinMod.restoreBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (restorePotatoRapid) {
                    try {
                        potatoRapidMod.restoreBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (restorePotatoUltimate) {
                    try {
                        potatoUltimateMod.restoreBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (restoreReward) {
                    try {
                        runRewardMod.restoreAllBlockingBestEffort()
                    } catch (ignored: Exception) {
                    }
                }

                if (restorePower) {
                    try {
                        powerPlusMod.disable { }
                    } catch (ignored: Exception) {
                    }
                }

                if (
                    restoreNativeEffects
                ) {
                    try {
                        nativeEffectMod.restoreAllBlockingBestEffort()
                    } catch (
                        ignored: Exception
                    ) {
                    }
                }

                if (
                    restoreHp
                ) {
                    try {
                        hpMod.restoreBlockingBestEffort()
                    } catch (
                        ignored: Exception
                    ) {
                    }
                }

                if (
                    restoreGameSpeed
                ) {
                    try {
                        gameSpeedMod.restoreBlockingBestEffort()
                    } catch (
                        ignored: Exception
                    ) {
                    }
                }

                if (BOT_LAB_ENABLED && ::botLab.isInitialized) {
                    botLab.shutdown()
                }

                SecureProfileManager.clear()
                SessionManager.clear()
                ControlPlaneState.reset()
                RootMemoryClient.shutdown()

                handler.post {
                    stopSelf()
                }
            },
            "mw-license-restore"
        )
            .apply {
                isDaemon =
                    true
                start()
            }

        /*
         * Failsafe only. Normal path exits much sooner.
         */
        handler.postDelayed(
            {
                SecureProfileManager.clear()
                SessionManager.clear()
                ControlPlaneState.reset()
                RootMemoryClient.shutdown()
                stopSelf()
            },
            10000L
        )
    }

    // ---------------------------------------------------------------------
    // Floating W
    // ---------------------------------------------------------------------

    private fun createW() {
        val size = wSizePx()
        val defaultX = (resources.displayMetrics.widthPixels - size - dp(18)).coerceAtLeast(0)

        wLp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(P_W_X, defaultX)
            y = prefs.getInt(P_W_Y, dp(220))
        }

        wView = TextView(this).apply {
            text = ""
            gravity = Gravity.CENTER
            includeFontPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setBackgroundResource(R.drawable.m_woif_logo_head)
            elevation = dp(10).toFloat()
        }

        installWDrag(wView!!)
    }

    private fun installWDrag(view: View) {
        view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = wLp ?: return false

                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        downX = e.rawX
                        downY = e.rawY
                        moved = false
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (abs(dx) > dp(3) || abs(dy) > dp(3)) moved = true

                        val maxX = (resources.displayMetrics.widthPixels - v.width).coerceAtLeast(0)
                        val maxY = (resources.displayMetrics.heightPixels - v.height).coerceAtLeast(0)

                        lp.x = (startX + dx.toInt()).coerceIn(0, maxX)
                        lp.y = (startY + dy.toInt()).coerceIn(0, maxY)

                        if (wVisible) wm.updateViewLayout(v, lp)
                        return true
                    }

                    MotionEvent.ACTION_UP -> {
                        if (moved) saveWPosition() else openMenuFromW()
                        return true
                    }

                    MotionEvent.ACTION_CANCEL -> return true
                }

                return false
            }
        })
    }

    private fun openMenuFromW() {
        if (foregroundPackage != GAME_PACKAGE) return
        hideW()
        showMenu()
    }

    private fun showW() {
        if (wVisible || menuVisible || foregroundPackage != GAME_PACKAGE) return
        val view = wView ?: return
        val lp = wLp ?: return

        try {
            wm.addView(view, lp)
            wVisible = true
        } catch (e: Exception) {
            Log.e(TAG, "showW", e)
        }
    }

    private fun hideW() {
        if (!wVisible) return

        try {
            wView?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }

        wVisible = false
    }

    private fun saveWPosition() {
        val lp = wLp ?: return
        prefs.edit().putInt(P_W_X, lp.x).putInt(P_W_Y, lp.y).apply()
    }

    // ---------------------------------------------------------------------
    // Quick MOD floating ON/OFF
    // ---------------------------------------------------------------------

    private fun createQuickModButton() {
        val size = dp(56)

        val wSize = wSizePx()
        val defaultW =
            (resources.displayMetrics.widthPixels - wSize - dp(18))
                .coerceAtLeast(0)

        val defaultX =
            (defaultW - size - dp(12))
                .coerceAtLeast(0)

        val defaultY =
            prefs.getInt(
                P_W_Y,
                dp(220)
            )

        quickModLp =
            WindowManager.LayoutParams(
                size,
                size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
                .apply {
                    gravity =
                        Gravity.TOP or Gravity.START

                    x =
                        prefs.getInt(
                            P_QUICK_X,
                            defaultX
                        )

                    y =
                        prefs.getInt(
                            P_QUICK_Y,
                            defaultY
                        )
                }

        quickModView =
            TextView(this)
                .apply {
                    gravity =
                        Gravity.CENTER

                    includeFontPadding =
                        false

                    textSize =
                        12f

                    typeface =
                        Typeface.DEFAULT_BOLD

                    setTextColor(
                        Color.WHITE
                    )

                    elevation =
                        dp(10)
                            .toFloat()

                    contentDescription =
                        "Quick MOD ON/OFF"
                }

        updateQuickModButtonState(
            force = true
        )

        installQuickModDrag(
            quickModView!!
        )
    }

    private fun quickModBackground(
        enabled: Boolean
    ): GradientDrawable =
        GradientDrawable()
            .apply {
                shape =
                    GradientDrawable.OVAL

                setColor(
                    Color.parseColor(
                        if (enabled) {
                            "#16A34A"
                        } else {
                            "#DC2626"
                        }
                    )
                )

                setStroke(
                    dp(2),
                    Color.parseColor(
                        if (enabled) {
                            "#86EFAC"
                        } else {
                            "#FCA5A5"
                        }
                    )
                )
            }

    private fun updateQuickModButtonState(
        force: Boolean = false
    ) {
        val view =
            quickModView
                ?: return

        if (
            !force &&
            quickModRenderedState == autoMaster
        ) {
            return
        }

        quickModRenderedState =
            autoMaster

        view.text =
            if (autoMaster) {
                "ON"
            } else {
                "OFF"
            }

        view.background =
            quickModBackground(
                autoMaster
            )
    }

    private fun installQuickModDrag(
        view: View
    ) {
        view.setOnTouchListener(
            object : View.OnTouchListener {
                var startX =
                    0

                var startY =
                    0

                var downX =
                    0f

                var downY =
                    0f

                var moved =
                    false

                override fun onTouch(
                    v: View,
                    e: MotionEvent
                ): Boolean {
                    val lp =
                        quickModLp
                            ?: return false

                    when (
                        e.actionMasked
                    ) {
                        MotionEvent.ACTION_DOWN -> {
                            startX =
                                lp.x

                            startY =
                                lp.y

                            downX =
                                e.rawX

                            downY =
                                e.rawY

                            moved =
                                false

                            return true
                        }

                        MotionEvent.ACTION_MOVE -> {
                            val dx =
                                e.rawX -
                                    downX

                            val dy =
                                e.rawY -
                                    downY

                            if (
                                abs(dx) > dp(3) ||
                                abs(dy) > dp(3)
                            ) {
                                moved =
                                    true
                            }

                            val maxX =
                                (
                                    resources.displayMetrics.widthPixels -
                                        v.width
                                    )
                                    .coerceAtLeast(0)

                            val maxY =
                                (
                                    resources.displayMetrics.heightPixels -
                                        v.height
                                    )
                                    .coerceAtLeast(0)

                            lp.x =
                                (
                                    startX +
                                        dx.toInt()
                                    )
                                    .coerceIn(
                                        0,
                                        maxX
                                    )

                            lp.y =
                                (
                                    startY +
                                        dy.toInt()
                                    )
                                    .coerceIn(
                                        0,
                                        maxY
                                    )

                            if (
                                quickModVisible
                            ) {
                                wm.updateViewLayout(
                                    v,
                                    lp
                                )
                            }

                            return true
                        }

                        MotionEvent.ACTION_UP -> {
                            if (
                                moved
                            ) {
                                saveQuickModPosition()
                            } else {
                                toggleQuickModPreset()
                            }

                            return true
                        }

                        MotionEvent.ACTION_CANCEL ->
                            return true
                    }

                    return false
                }
            }
        )
    }

    private fun toggleQuickModPreset() {
        if (
            foregroundPackage != GAME_PACKAGE
        ) {
            return
        }

        if (
            !autoMaster &&
            autoSelected.none {
                (key, selected) ->
                    selected &&
                        isAutoKeyAvailable(
                            key
                        )
            }
        ) {
            /*
             * No preset selected: stay OFF.
             * V18.6.3 will decide Stable-silent vs Lab diagnostics.
             */
            if (
                BuildConfig.INTERNAL_BUILD
            ) {
                Log.w(
                    TAG,
                    "Quick MOD ignored: no AUTO preset selected"
                )
            }

            updateQuickModButtonState(
                force = true
            )

            return
        }

        setAutoMaster(
            !autoMaster
        )

        // setAutoMaster() updates both the floating circle and the live AUTO MODE
        // toggle immediately. Re-render visible content to keep dependent rows in sync.
        if (
            menuVisible
        ) {
            renderTab()
        }
    }

    private fun setQuickModEnabled(enabled: Boolean) {
        quickModEnabled = enabled

        prefs.edit()
            .putBoolean(P_QUICK_ENABLED, enabled)
            .apply()

        if (enabled && foregroundPackage == GAME_PACKAGE) {
            showQuickModButton()
            updateQuickModButtonState(force = true)
        } else if (!enabled) {
            hideQuickModButton()
        }
    }

    private fun showQuickModButton() {
        if (
            quickModVisible ||
            !quickModEnabled ||
            foregroundPackage != GAME_PACKAGE
        ) {
            return
        }

        val view =
            quickModView
                ?: return

        val lp =
            quickModLp
                ?: return

        updateQuickModButtonState(
            force = true
        )

        try {
            wm.addView(
                view,
                lp
            )

            quickModVisible =
                true
        } catch (
            e: Exception
        ) {
            Log.e(
                TAG,
                "showQuickModButton",
                e
            )
        }
    }

    private fun hideQuickModButton() {
        if (
            !quickModVisible
        ) {
            return
        }

        try {
            quickModView
                ?.let {
                    wm.removeView(
                        it
                    )
                }
        } catch (
            ignored: Exception
        ) {
        }

        quickModVisible =
            false
    }

    private fun saveQuickModPosition() {
        val lp =
            quickModLp
                ?: return

        prefs.edit()
            .putInt(
                P_QUICK_X,
                lp.x
            )
            .putInt(
                P_QUICK_Y,
                lp.y
            )
            .apply()
    }

    // ---------------------------------------------------------------------
    // Menu shell
    // ---------------------------------------------------------------------

    private fun createMenu() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded("#10141C", 22, "#343B49", 1)
            elevation = dp(16).toFloat()

            /*
             * Important: footer/content children must be clipped by the
             * rounded parent shape so the lower corners stay rounded too.
             */
            clipToOutline = true
        }

        root.addView(buildHeader())
        root.addView(buildTabs())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
            isScrollbarFadingEnabled = false
            setScrollBarSize(dp(5))

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                verticalScrollbarThumbDrawable = rounded("#7657F6", 100)
            }
        }

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }

        scroll.addView(
            body,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        contentScroll = scroll
        content = body

        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        root.addView(buildFooter())
        menuView = root

        val dim = menuDimensions()
        val defaultX = (resources.displayMetrics.widthPixels - dim.first - dp(28)).coerceAtLeast(dp(8))

        menuLp = WindowManager.LayoutParams(
            dim.first, dim.second,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(P_M_X, defaultX)
            y = prefs.getInt(P_M_Y, dp(55))
        }

        renderTab(resetScroll = true)
        updateTabs()
        updateCountdown()
    }

    private fun buildHeader(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(12))
            background = rounded("#151922", 22)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(2), dp(10), dp(2))
        }

        title.addView(txt(brandModTitle(), 17f, "#F5F7FB", true))
        title.addView(txt("CookieRun Classic • 26.7.12", 10f, "#7E8797").apply {
            setPadding(0, dp(3), 0, 0)
        })

        installMenuDrag(title)

        top.addView(
            title,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        top.addView(
            squareButton("−") { hideMenu(true) },
            LinearLayout.LayoutParams(dp(38), dp(36)).apply { marginEnd = dp(7) }
        )

        top.addView(
            squareButton("×") { enterHiddenOverlayMode() },
            LinearLayout.LayoutParams(dp(38), dp(36))
        )

        root.addView(top)

        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(11), 0, 0)
        }

        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        licenseChip = chipText(tr("● ใช้งานได้", "● Active")).also {
            pill(it, "#112D20", "#205A3A", "#4ADE80")
            chips.addView(it)
        }

        countdownChip = chipText(remainingText()).also {
            pill(it, "#1B1930", "#39325F", "#C4B5FD")
            chips.addView(
                it,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(8) }
            )
        }

        onlineChip = chipText(tr("● ออนไลน์", "● Online")).also {
            pill(it, "#102824", "#1F4C43", "#5EEAD4")
            chips.addView(
                it,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(8) }
            )
        }

        chipScroll.addView(chips)
        root.addView(chipScroll)

        expiryLabel =
            txt(
                tr(
                    "หมดอายุ ${expiryText()}",
                    "Expires ${expiryText()}"
                ),
                10f,
                "#737D8E"
            )
                .apply {
                    setPadding(
                        dp(2),
                        dp(8),
                        0,
                        0
                    )
                }

        root.addView(
            expiryLabel
        )

        return root
    }

    private fun installMenuDrag(view: View) {
        view.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = menuLp ?: return false
                val panel = menuView ?: return false

                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        downX = e.rawX
                        downY = e.rawY
                        moved = false
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (abs(dx) > dp(2) || abs(dy) > dp(2)) moved = true

                        val maxX = (resources.displayMetrics.widthPixels - panel.width).coerceAtLeast(0)
                        val maxY = (resources.displayMetrics.heightPixels - panel.height).coerceAtLeast(0)

                        lp.x = (startX + dx.toInt()).coerceIn(0, maxX)
                        lp.y = (startY + dy.toInt()).coerceIn(0, maxY)

                        if (menuVisible) wm.updateViewLayout(panel, lp)
                        return true
                    }

                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            prefs.edit().putInt(P_M_X, lp.x).putInt(P_M_Y, lp.y).apply()
                        }
                        return true
                    }

                    MotionEvent.ACTION_CANCEL -> return true
                }

                return false
            }
        })
    }

    private fun buildTabs(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(7), dp(10), 0)
            background = solid("#121720")
        }

        tabText.clear()
        tabLine.clear()

        visibleTabs().forEach { tab ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                setPadding(dp(4), dp(7), dp(4), 0)
                setOnClickListener {
                    activeTab = tab
                    updateTabs()
                    renderTab(resetScroll = true)
                }
            }

            val label = txt(tabName(tab), 11f, "#737D8E", true).apply {
                gravity = Gravity.CENTER
            }

            val line = View(this)

            item.addView(
                label,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(25)
                )
            )

            item.addView(
                line,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(3)
                ).apply { topMargin = dp(4) }
            )

            tabText[tab] = label
            tabLine[tab] = line

            root.addView(
                item,
                LinearLayout.LayoutParams(0, dp(45), 1f)
            )
        }

        return root
    }

    private fun visibleTabs(): List<Tab> =
        if (BuildConfig.INTERNAL_BUILD) {
            Tab.entries
        } else {
            Tab.entries.filter { it != Tab.DEV }
        }

    private fun tabName(tab: Tab) = when (tab) {
        Tab.HOME -> tr("หน้าหลัก", "Home")
        Tab.PLAY -> tr("เล่น", "Play")
        Tab.AUTO -> tr("อัตโนมัติ", "Auto")
        Tab.FARM -> tr("คุกกี้", "Cookie")
        Tab.PUMP -> tr("ปั้ม", "Pump")
        Tab.SETTINGS -> tr("ตั้งค่า", "Settings")
        Tab.DEV -> "DEV"
    }

    private fun updateTabs() {
        visibleTabs().forEach { tab ->
            val selected = tab == activeTab
            tabText[tab]?.setTextColor(Color.parseColor(if (selected) "#F3F4F8" else "#737D8E"))
            tabLine[tab]?.background = solid(if (selected) "#7657F6" else "#00000000")
        }
    }

    private fun buildFooter(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(10))
            background = solid("#0D1118")

            addView(
                txt(tr("● พร้อมใช้งาน", "● Ready"), 10f, "#4ADE80", true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )

            addView(txt(brandVersion(), 10f, "#596374", true))
        }
    }

    // ---------------------------------------------------------------------
    // Tabs content
    // ---------------------------------------------------------------------

    private fun renderTab(resetScroll: Boolean = false) {
        val root = content ?: return

        /*
         * Preset/slider selections rebuild the current tab. Preserve the
         * vertical position so choosing a value near the bottom does not
         * jump the user back to the top.
         */
        val oldScrollY = contentScroll?.scrollY ?: 0

        autoMasterToggleView = null
        root.removeAllViews()

        when (activeTab) {
            Tab.HOME -> home(root)
            Tab.PLAY -> play(root)
            Tab.AUTO -> auto(root)
            Tab.FARM -> farm(root)
            Tab.PUMP -> pump(root)
            Tab.SETTINGS -> settings(root)
            Tab.DEV -> dev(root)
        }

        contentScroll?.post {
            contentScroll?.scrollTo(
                0,
                if (resetScroll) 0 else oldScrollY
            )
        }
    }

    private fun home(root: LinearLayout) {
        val appContent =
            SessionManager.appContent()

        if (!BuildConfig.INTERNAL_BUILD) {
            root.addView(officialSupportBanner(appContent), itemLp())

            if (appContent.announcement.enabled) {
                root.addView(announcementCard(appContent.announcement), itemLp())
            }
        }

        root.addView(pageTitle(tr("หน้าหลัก", "Home"), tr("สถานะระบบและใบอนุญาต", "System and license overview")))

        if (!BuildConfig.INTERNAL_BUILD && appContent.guide.enabled) {
            root.addView(section(tr("เริ่มต้นใช้งาน", "GETTING STARTED")), sectionLp())
            root.addView(userQuickStartCard(appContent.guide), itemLp())
        }

        if (!BuildConfig.INTERNAL_BUILD && appContent.warning.enabled) {
            root.addView(section(tr("คำเตือนและความเสี่ยง", "WARNING & RISK")), sectionLp())
            root.addView(userRiskWarningCard(appContent.warning), itemLp())
        }

        root.addView(section(tr("สถานะระบบ", "SYSTEM STATUS")), sectionLp())

        if (!ControlPlaneState.canWrite()) {
            root.addView(
                lockedNotice(
                    tr(
                        "เวอร์ชันเกมนี้กำลังอัปเดต • MOD ถูกปิดชั่วคราว",
                        "This game version is being updated • MOD writes are temporarily disabled"
                    )
                ),
                itemLp()
            )
        }

        val grid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid.addView(
            statusCard(
                tr("เกม", "Game"),
                if (ControlPlaneState.canWrite()) {
                    tr("พร้อมใช้งาน", "Ready")
                } else {
                    tr("กำลังอัปเดต", "Updating")
                },
                if (ControlPlaneState.canWrite()) "#4ADE80" else "#F4B740"
            ),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) }
        )
        grid.addView(
            statusCard(tr("เซิร์ฟเวอร์", "Server"), tr("ออนไลน์", "Online"), "#5EEAD4"),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) }
        )
        root.addView(grid, itemLp())

        root.addView(section(tr("ใบอนุญาต", "LICENSE")), sectionLp())

        val lic = card()
        lic.addView(info("สถานะ", tr("ใช้งานได้", "Active"), "#4ADE80"))
        lic.addView(divider())
        lic.addView(info(tr("หมดอายุ", "Expires"), expiryText(), "#C4B5FD"))
        lic.addView(divider())
        lic.addView(info(tr("คงเหลือ", "Remaining"), remainingText(), "#F4B740"))
        root.addView(lic, itemLp())

        root.addView(section(tr("ข้อมูล", "INFORMATION")), sectionLp())

        val data = card()
        data.addView(info(tr("เกม", "Game"), "CookieRun Classic", "#DDE2EA"))
        data.addView(divider())
        data.addView(
            info(
                tr("เวอร์ชันเกม", "Game Version"),
                SessionManager.snapshot()?.gameVersion ?: "unknown",
                "#DDE2EA"
            )
        )
        data.addView(divider())
        data.addView(info(brandName(), "v${BuildConfig.VERSION_NAME}", "#A998FF"))
        root.addView(data, itemLp())
    }


    private fun localizedContent(
        th: String,
        en: String,
        fallback: String = ""
    ): String {
        val preferred =
            if (language == EN) en.trim() else th.trim()
        if (preferred.isNotEmpty()) {
            return preferred
        }

        val secondary =
            if (language == EN) th.trim() else en.trim()
        return secondary.ifEmpty { fallback }
    }

    private fun officialSupportBanner(
        appContent: AppContentSnapshot
    ): LinearLayout {
        return card().apply {
            background = rounded("#11172A", 16, "#3D356B", 1)
            setPadding(dp(16), dp(14), dp(16), dp(14))

            addView(
                txt("M WOIF • OFFICIAL", 13f, "#D8D1FF", true),
                subLp()
            )
            addView(
                txt(
                    tr(
                        "ช่องทางประกาศ อัปเดต และช่วยเหลืออย่างเป็นทางการ",
                        "Official announcements, updates and support"
                    ),
                    9f,
                    "#8F9AAC"
                ).apply { setPadding(0, dp(5), 0, dp(10)) },
                subLp()
            )

            val row = LinearLayout(this@FloatingMenuService).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            row.addView(
                button("Telegram", true) {
                    openOfficialLink(
                        appContent.support.telegramUrl,
                        "Telegram"
                    )
                },
                LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                    marginEnd = dp(5)
                }
            )
            row.addView(
                button("Website", false) {
                    openOfficialLink(
                        appContent.support.websiteUrl,
                        "Website"
                    )
                },
                LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                    marginStart = dp(5)
                }
            )
            addView(row, subLp())

            addView(
                txt(
                    tr(
                        "ข้อมูลหน้านี้อัปเดตจาก Server โดยไม่ต้องลง APK ใหม่",
                        "This page is updated from the server without reinstalling the APK"
                    ),
                    8f,
                    "#C4B5FD"
                ).apply { setPadding(0, dp(9), 0, 0) },
                subLp()
            )
        }
    }

    private fun announcementCard(
        announcement: AppContentAnnouncement
    ): LinearLayout {
        val level = announcement.level.lowercase()
        val border = when (level) {
            "critical" -> "#7F1D1D"
            "warning" -> "#62451D"
            else -> "#3D356B"
        }
        val titleColor = when (level) {
            "critical" -> "#FCA5A5"
            "warning" -> "#F4B740"
            else -> "#C4B5FD"
        }

        return card().apply {
            background = rounded("#151A24", 14, border, 1)

            val title = localizedContent(
                announcement.titleTh,
                announcement.titleEn,
                tr("ประกาศ", "Announcement")
            )
            val message = localizedContent(
                announcement.messageTh,
                announcement.messageEn
            )

            addView(txt(title, 11f, titleColor, true), subLp())
            if (message.isNotBlank()) {
                addView(
                    txt(message, 9f, "#C7CED9").apply {
                        setPadding(0, dp(7), 0, 0)
                    },
                    subLp()
                )
            }
        }
    }

    private fun userQuickStartCard(
        guide: AppContentGuide
    ): LinearLayout {
        return card().apply {
            val title = localizedContent(
                guide.titleTh,
                guide.titleEn,
                tr("วิธีใช้งาน M Woif", "How to use M Woif")
            )
            val body = localizedContent(
                guide.bodyTh,
                guide.bodyEn
            )
            val note = localizedContent(
                guide.noteTh,
                guide.noteEn
            )

            addView(txt(title, 12f, "#E8EBF1", true), subLp())

            if (body.isNotBlank()) {
                addView(
                    txt(body, 10f, "#AEB6C4").apply {
                        setPadding(0, dp(8), 0, 0)
                    },
                    subLp()
                )
            }

            if (note.isNotBlank()) {
                addView(divider())
                addView(
                    txt(note, 9f, "#8CE6B1", true),
                    subLp()
                )
            }
        }
    }

    private fun userRiskWarningCard(
        warning: AppContentWarning
    ): LinearLayout {
        val acknowledgedRevision =
            prefs.getLong(
                P_WARNING_ACK_REVISION,
                0L
            )

        val acknowledged =
            warning.revision > 0L &&
                acknowledgedRevision >= warning.revision

        return card().apply {
            background = rounded("#241A12", 14, "#62451D", 1)

            val title = localizedContent(
                warning.titleTh,
                warning.titleEn,
                tr("คำเตือนและความเสี่ยง", "Warning and Risk")
            )
            val body = localizedContent(
                warning.bodyTh,
                warning.bodyEn
            )
            val points = localizedContent(
                warning.pointsTh,
                warning.pointsEn
            )

            addView(txt(title, 12f, "#F4B740", true), subLp())

            if (body.isNotBlank()) {
                addView(
                    txt(body, 10f, "#E8C96E").apply {
                        setPadding(0, dp(8), 0, dp(8))
                    },
                    subLp()
                )
            }

            if (points.isNotBlank()) {
                addView(
                    txt(points, 9f, "#D2B46E"),
                    subLp()
                )
            }

            addView(divider())

            if (acknowledged) {
                addView(
                    txt(
                        tr(
                            "✓ รับทราบคำเตือนฉบับปัจจุบันแล้ว",
                            "✓ Current warning acknowledged"
                        ),
                        10f,
                        "#8CE6B1",
                        true
                    ),
                    subLp()
                )
            } else {
                addView(
                    button(
                        tr(
                            "ฉันอ่านและรับทราบคำเตือน",
                            "I have read and understand"
                        ),
                        true
                    ) {
                        prefs.edit()
                            .putLong(
                                P_WARNING_ACK_REVISION,
                                warning.revision
                            )
                            .apply()

                        Toast.makeText(
                            this@FloatingMenuService,
                            tr(
                                "บันทึกการรับทราบแล้ว",
                                "Acknowledgement saved"
                            ),
                            Toast.LENGTH_SHORT
                        ).show()

                        renderTab(resetScroll = false)
                    },
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(40)
                    )
                )
            }
        }
    }

    private fun openOfficialLink(
        url: String,
        label: String
    ) {
        val normalized = url.trim()

        if (normalized.isBlank()) {
            Toast.makeText(
                this,
                tr(
                    "$label ยังไม่ได้ตั้งค่าจาก Server",
                    "$label is not configured on the server"
                ),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val uri = runCatching { Uri.parse(normalized) }.getOrNull()
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http")) {
            Toast.makeText(
                this,
                tr(
                    "ลิงก์ $label ไม่ถูกต้อง",
                    "Invalid $label link"
                ),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        runCatching {
            startActivity(
                Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }.onFailure {
            Toast.makeText(
                this,
                tr(
                    "เปิด $label ไม่สำเร็จ",
                    "Unable to open $label"
                ),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun play(root: LinearLayout) {
        root.addView(
            pageTitle(
                tr("เล่น", "Play"),
                tr("ตั้งค่าระบบสำหรับการเล่น", "Gameplay configuration")
            )
        )

        // UI order follows the current 26.8.02 release feature hierarchy.
        root.addView(centerLine(tr("ความเร็ว", "SPEED")), sectionLp())
        root.addView(speedCard(), itemLp())
        root.addView(baseSpeedCard(), itemLp())

        if (autoMaster) {
            root.addView(
                lockedNotice(
                    tr(
                        "AUTO กำลังทำงาน • ปิด AUTO ก่อนเปิดระบบในหน้า เล่น",
                        "AUTO is active • Turn AUTO off before enabling Play systems"
                    )
                ),
                itemLp()
            )
        }

        root.addView(centerLine(tr("ระบบเล่น", "PLAY SYSTEMS")), sectionLp())
        root.addView(hpCard(), itemLp())

        val giantCard =
            nativeEffectCard(
                featureId = CrgProfile.FEATURE_GIANT,
                title = tr("ตัวใหญ่", "Giant"),
                desc = audienceText(
                    "เปิด Giant ระหว่างเล่น • เปิดรอไว้ก่อนเข้า Stage ได้",
                    "Enable Giant during play • Can be armed before entering a Stage",
                    "เปิดได้ทุกหน้า • เข้า Stage แล้วระบบเปิด Giant ให้อัตโนมัติ",
                    "Can be armed anywhere • Giant is applied automatically in Stage"
                ),
                enabled = if (autoMaster) giantAutoOwned else giantOn,
                statusText = giantStatusText
            ) { enabled ->
                setNativeManualEnabled(CrgProfile.FEATURE_GIANT, enabled)
            }

        // f03 = Giant + Giant Size. Giant Size is part of the same card.
        giantCard.addView(
            giantSizeFastLockSection(),
            subLp().apply { topMargin = dp(10) }
        )
        root.addView(giantCard, itemLp())

        root.addView(
            nativeEffectCard(
                featureId = CrgProfile.FEATURE_SUPER,
                title = tr("วิ่งเร็ว", "Super"),
                desc = audienceText(
                    "เปิด Super ระหว่างเล่น • เข้า Stage ใหม่ระบบทำงานให้อัตโนมัติ",
                    "Enable Super during play • Re-applies automatically on a new Stage",
                    "เปิดแล้ววิ่งเร็วตลอดใน Stage • เข้า Stage ใหม่ระบบเปิดให้อัตโนมัติ",
                    "Keeps Super active in Stage • Re-applies on a new Stage"
                ),
                enabled = if (autoMaster) superAutoOwned else superOn,
                statusText = superStatusText
            ) { enabled ->
                setNativeManualEnabled(CrgProfile.FEATURE_SUPER, enabled)
            },
            itemLp()
        )

        root.addView(centerLine(tr("XP / เลเวล • เหรียญ", "XP / Coin")), sectionLp())
        root.addView(xpCard(), itemLp())
        root.addView(coinCard(), itemLp())

        root.addView(centerLine(tr("ระบบเล่นเสริม", "EXTRA PLAY")), sectionLp())
        root.addView(reviveCard(), itemLp())
        root.addView(unlimitedJumpCard(), itemLp())
    }

    private fun giantSizeFastLockSection(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }

        val backendEnabled =
            ::nativeEffectMod.isInitialized &&
                nativeEffectMod.devGiantSizeFastLockIsEnabled()

        if (!autoMaster) {
            giantSizeOn = backendEnabled
        }

        val sizeUiEnabled =
            if (autoMaster) giantSizeAutoOwned else giantSizeOn

        root.addView(
            divider(),
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(1)
            ).apply {
                topMargin = dp(2)
                bottomMargin = dp(10)
            }
        )

        root.addView(
            settingToggle(
                tr("ขนาด Giant", "Giant Size"),
                sizeUiEnabled
            ) { enabled ->
                setGiantSizeFastLockEnabled(enabled)
            },
            subLp()
        )

        root.addView(
            txt(
                tr(
                    "เปิด Giant ก่อน • Giant Size แยก ON/OFF เอง • Giant ON จะไม่เปิดขนาดให้อัตโนมัติ",
                    "Enable Giant first • Giant Size has its own ON/OFF • Giant ON will not auto-enable size"
                ),
                9f,
                "#6F798A"
            ).apply { setPadding(0, dp(4), 0, dp(6)) },
            subLp()
        )

        root.addView(label(tr("โบนัสขนาด", "Size bonus")), subLp())

        val presets = listOf(10, 30, 50, 75, 100)
        root.addView(
            choices(
                presets.map { "+$it%" },
                presets.indexOf(giantSizePercent)
            ) { index ->
                giantSizePercent = presets[index]
                modSettingsStore.saveGiantSizePercent(giantSizePercent)
                applyGiantSizeValueIfActive()
                renderTab()
            },
            subLp()
        )

        root.addView(
            slider(
                "10%",
                "100%",
                giantSizePercent - 10,
                90,
                { "+$giantSizePercent%" }
            ) { progress ->
                giantSizePercent = 10 + progress
                modSettingsStore.saveGiantSizePercent(giantSizePercent)
                applyGiantSizeValueIfActive()
            },
            subLp()
        )

        root.addView(
            txt(
                if (sizeUiEnabled) {
                    tr(
                        "Giant Size ON • +$giantSizePercent% • แยกจาก Giant ON/OFF",
                        "Giant Size ON • +$giantSizePercent% • Independent from Giant ON/OFF"
                    )
                } else if (giantOn || giantAutoOwned) {
                    tr(
                        "Giant ON • Giant Size OFF • เปิดขนาดเพิ่มได้เอง",
                        "Giant ON • Giant Size OFF • Enable extra size manually"
                    )
                } else {
                    tr(
                        "Giant Size OFF • เปิด Giant ก่อนเมื่อต้องการใช้ขนาดเพิ่ม",
                        "Giant Size OFF • Enable Giant first to use extra size"
                    )
                },
                10f,
                if (sizeUiEnabled) "#8CE6B1" else "#8F9AAC"
            ).apply { setPadding(dp(4), dp(10), dp(4), dp(2)) },
            subLp()
        )

        return root
    }

    private fun applyGiantSizeValueIfActive() {
        if (
            !::nativeEffectMod.isInitialized ||
            !giantSizeOn
        ) {
            return
        }

        if (nativeEffectMod.devGiantSizeFastLockIsEnabled()) {
            val result = nativeEffectMod.devGiantSizeFastLockSetPercent(giantSizePercent)
            giantSizeStatusText = result.message
        } else {
            nativeEffectMod.devGiantSizeFastLockEnable(giantSizePercent) { result ->
                handler.post {
                    giantSizeOn =
                        result.ok && nativeEffectMod.devGiantSizeFastLockIsEnabled()
                    giantSizeStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
        }
    }

    private fun setGiantSizeFastLockEnabled(enabled: Boolean) {
        if (!::nativeEffectMod.isInitialized) {
            giantSizeOn = false
            return
        }

        if (autoMaster) {
            giantSizeOn = false
            giantSizeStatusText = tr(
                "ปิด AUTO ก่อนเปิด Giant Size",
                "Turn AUTO off before Giant Size"
            )
            renderTab()
            return
        }

        if (enabled) {
            // Desired-state semantics: no Character/Stage lookup here.
            // This allows Giant Size to be armed from Lobby/outside Stage.
            if (!giantOn) {
                giantSizeOn = false
                giantSizeStatusText = tr(
                    "เปิดตัวใหญ่ก่อน แล้วจึงเปิดขนาด Giant",
                    "Enable Giant first, then Giant Size"
                )
                Toast.makeText(
                    this,
                    giantSizeStatusText,
                    Toast.LENGTH_SHORT
                ).show()
                renderTab()
                return
            }

            giantSizeOn = true
            giantSizeStatusText = tr(
                "ON • พร้อม • รอเข้า Stage / รอ Giant ติด",
                "ON • Armed • Waiting for Stage / Giant"
            )
            renderTab()

            nativeEffectMod.devGiantSizeFastLockEnable(
                giantSizePercent
            ) { result ->
                handler.post {
                    giantSizeOn =
                        result.ok &&
                            nativeEffectMod.devGiantSizeFastLockIsEnabled()
                    giantSizeStatusText = result.message

                    if (!result.ok) {
                        Toast.makeText(
                            this,
                            result.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    if (activeTab == Tab.PLAY && menuVisible) {
                        renderTab()
                    }
                }
            }
        } else {
            giantSizeOn = false
            giantSizeStatusText = tr(
                "กำลังปิด Giant Size...",
                "Stopping Giant Size..."
            )

            nativeEffectMod.devGiantSizeFastLockDisable { result ->
                handler.post {
                    giantSizeOn = false
                    giantSizeStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) {
                        renderTab()
                    }
                }
            }
        }
    }

    private fun powerPlusCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed =
            ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POWER_PLUS)

        val backendEnabled =
            ::powerPlusMod.isInitialized && powerPlusMod.isEnabled()
        if (powerOn != backendEnabled && !powerAutoOwned) {
            powerOn = backendEnabled
        }

        root.addView(
            featureHeader(
                title = "Power+",
                desc = audienceText(
                    "Power+ ทำงานได้หนึ่งครั้งต่อ Stage • ปิดแล้วไม่ย้อนผลที่เกิดขึ้น",
                    "Power+ activates once per Stage • Turning it off does not undo the result",
                    "Mystery Box EP1–EP7 • 1 Stage ยิงได้ครั้งเดียว • OFF ไม่ย้อนผล",
                    "Mystery Box EP1–EP7 • Once per Stage • OFF does not undo"
                ),
                enabled = powerOn,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { enabled ->
                setPowerManualEnabled(enabled)
            }
        )

        if (!featureAllowed) {
            root.addView(featureUpdatingHint(), subLp())
        }

        val liveStatus =
            if (
                featureAllowed &&
                ::powerPlusMod.isInitialized &&
                powerPlusMod.isEnabled()
            ) {
                powerPlusMod.statusText()
            } else {
                powerStatusText
            }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus
            else controlBlockedText(CrgProfile.FEATURE_POWER_PLUS)
        )

        return root
    }

    private fun setPowerManualEnabled(enable: Boolean) {
        if (autoMaster || !::powerPlusMod.isInitialized) return

        if (
            enable &&
            !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POWER_PLUS)
        ) {
            powerOn = false
            powerStatusText = controlBlockedText(CrgProfile.FEATURE_POWER_PLUS)
            renderTab()
            return
        }

        if (!enable) {
            powerOn = false
            powerStatusText = tr(
                "กำลังปิด Power+...",
                "Disabling Power+..."
            )
            powerPlusMod.disable { result ->
                handler.post {
                    powerStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        powerStatusText = tr(
            "กำลังโหลด Secure Power+ Profile...",
            "Loading Secure Power+ Profile..."
        )
        renderTab()

        withPowerPlusProfile { profile, errorText ->
            handler.post {
                if (profile == null) {
                    powerOn = false
                    powerStatusText = errorText ?: tr(
                        "Secure Power+ Profile ยังไม่พร้อม",
                        "Secure Power+ Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@post
                }

                powerPlusMod.enable(profile) { result ->
                    handler.post inner@{
                        powerOn = powerPlusMod.isEnabled()
                        powerStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun setPowerAutoEnabled(enable: Boolean) {
        if (!::powerPlusMod.isInitialized) return

        if (!enable) {
            powerAutoOwned = false
            powerPlusMod.disable { result ->
                handler.post {
                    powerStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) renderTab()
                }
            }
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POWER_PLUS)) {
            powerAutoOwned = false
            autoSelected["POWER"] = false
            powerStatusText = controlBlockedText(CrgProfile.FEATURE_POWER_PLUS)
            return
        }

        withPowerPlusProfile { profile, errorText ->
            if (profile == null) {
                handler.post {
                    powerAutoOwned = false
                    powerStatusText = errorText ?: "Secure Power+ Profile ยังไม่พร้อม"
                }
                return@withPowerPlusProfile
            }

            powerPlusMod.enable(profile) { result ->
                handler.post {
                    powerAutoOwned = powerPlusMod.isEnabled()
                    powerStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) renderTab()
                }
            }
        }
    }

    private fun withPowerPlusProfile(
        callback: (PowerPlusProfile?, String?) -> Unit
    ) {
        val current = SecureProfileManager.getPowerPlus()
        if (current != null) {
            val cached = powerPlusMod.cacheProfile(current)
            if (cached.ok) callback(current, null)
            else callback(null, cached.message)
            return
        }

        SecureProfileManager.preloadPowerPlus { result ->
            val profile = SecureProfileManager.getPowerPlus()
            if (result is SecureProfileManager.Result.Success && profile != null) {
                val cached = powerPlusMod.cacheProfile(profile)
                if (cached.ok) callback(profile, null)
                else callback(null, cached.message)
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(
                    null,
                    secureNativeProfileStatus(
                        result,
                        tr("Power+ พร้อม", "Power+ ready")
                    )
                )
            } else {
                callback(
                    null,
                    tr(
                        "Secure Power+ Profile ยังไม่พร้อม",
                        "Secure Power+ Profile is not ready"
                    )
                )
            }
        }
    }

    private fun nativeEffectCard(
        featureId: String,
        title: String,
        desc: String,
        enabled: Boolean,
        statusText: String,
        onToggle: (Boolean) -> Unit
    ): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(featureId)

        root.addView(
            featureHeader(
                title = title,
                desc = desc,
                enabled = enabled,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed,
                onToggle = onToggle
            )
        )

        if (!featureAllowed) {
            root.addView(
                featureUpdatingHint(),
                subLp()
            )
        }

        val liveStatus =
            if (
                featureAllowed &&
                ::nativeEffectMod.isInitialized &&
                nativeEffectMod.isEnabled(featureId)
            ) {
                nativeEffectMod.statusText(featureId)
            } else {
                statusText
            }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(featureId)
        )

        return root
    }


    private fun devInitMember3Probe(root: LinearLayout) {
        root.addView(
            pageTitle(
                "00 • INITMEMBER3 HEART HANDOFF V12",
                tr(
                    "จับ initMember3 แยก Sender / Receiver แบบ READ ONLY • ไม่เก็บ session credential",
                    "READ-ONLY V12: synchronized body snapshot + sanitized Sender / Receiver handoff"
                )
            )
        )
        root.addView(section("00.1 • DEVPLAY / GAME BOOTSTRAP CAPTURE"), sectionLp())

        val card = featureCard()
        card.addView(
            txt(
                tr(
                    "กด ARM CAPTURE แล้วให้เกมทำ DevPlay / เข้าเกมตามธรรมชาติ • ตัว Probe ไม่ยิง API ไม่แก้ request และไม่แตะ token โดยตรง",
                    "Press ARM CAPTURE, then let the game perform DevPlay/bootstrap naturally. The probe never sends an API request, mutates a request, or directly handles tokens."
                ),
                9f,
                "#8F9AAC"
            ).apply {
                setPadding(dp(4), dp(2), dp(4), dp(8))
            },
            subLp()
        )

        val status = txt(
            initMember3ProbeText,
            8.6f,
            if (initMember3ProbeLastReport.contains("RESULT=FOUND_INITMEMBER3")) {
                "#4ADE80"
            } else {
                "#C8D0DC"
            }
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        initMember3ProbeView = status
        card.addView(status, subLp())

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row1.addView(
            button(
                if (initMember3ProbeRunning) {
                    tr("กำลังจับ...", "Capturing...")
                } else {
                    tr("ARM CAPTURE 20s", "ARM CAPTURE 20s")
                },
                true
            ) {
                runInitMember3ProbeCapture()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            }
        )
        row1.addView(
            button(tr("SCAN NOW", "SCAN NOW"), false) {
                runInitMember3ProbeSnapshot()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            }
        )
        card.addView(row1, subLp())

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row2.addView(
            button(tr("คัดลอก Report", "Copy report"), false) {
                copyInitMember3ProbeReport()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            }
        )
        row2.addView(
            button(tr("Reset", "Reset"), false) {
                if (!initMember3ProbeRunning) {
                    initMember3ProbeLastReport =
                        "INITMEMBER3_PROBE\nRESULT=NOT_RUN\n"
                    initMember3ProbeText =
                        "READY • กด ARM CAPTURE แล้วให้เกมทำ DevPlay / initMember3 ตามธรรมชาติ"
                    initMember3ProbeView?.text = initMember3ProbeText
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            }
        )
        card.addView(row2, subLp().apply { topMargin = dp(8) })

        val handoffStatus = txt(
            currentHeartAccountStatusText(),
            8.4f,
            "#93C5FD"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(4))
        }
        card.addView(handoffStatus, subLp())

        val currentAccountRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        currentAccountRow.addView(
            button(tr("SAVE CURRENT ACCOUNT", "SAVE CURRENT ACCOUNT"), false) {
                saveCurrentInitMember3Account()
                handoffStatus.text = currentHeartAccountStatusText()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            }
        )
        currentAccountRow.addView(
            button(tr("COPY CURRENT JSON", "COPY CURRENT JSON"), false) {
                copyCurrentInitMember3AccountJson()
                handoffStatus.text = currentHeartAccountStatusText()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            }
        )
        card.addView(currentAccountRow, subLp().apply { topMargin = dp(8) })

        val currentAccountClearRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        currentAccountClearRow.addView(
            button(tr("CLEAR CURRENT", "CLEAR CURRENT"), false) {
                clearCurrentInitMember3Account()
                handoffStatus.text = currentHeartAccountStatusText()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            }
        )
        currentAccountClearRow.addView(
            button(tr("COPY PUSH TOKEN", "COPY PUSH TOKEN"), false) {
                copyCurrentInitMember3PushToken()
                handoffStatus.text = currentHeartAccountStatusText()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            }
        )
        card.addView(currentAccountClearRow, subLp().apply { topMargin = dp(8) })

        card.addView(
            txt(
                tr(
                    "Profile 26.8.02 • V12.5 FINAL ENVELOPE META • จับและ export ทีละไอดีได้ทันที • ค่ายาวที่อาจเป็น session/token จะถูก REDACT",
                    "26.8.02 profile • V12.5 FINAL ENVELOPE META • capture/export one account at a time • long session/token-like values are REDACTED"
                ),
                8.2f,
                "#A78BFA"
            ).apply {
                setPadding(dp(4), dp(8), dp(4), dp(2))
            },
            subLp()
        )

        root.addView(card, itemLp())
    }



    private fun extractInitMember3Field(
        report: String,
        fieldName: String
    ): String {
        val prefix = "field.$fieldName="
        return report
            .lineSequence()
            .map { it.trim() }
            .firstOrNull { it.startsWith(prefix) }
            ?.removePrefix(prefix)
            ?.substringAfter(':', "")
            ?.trim()
            .orEmpty()
    }

    private fun saveCurrentInitMember3Account() {
        if (!BuildConfig.INTERNAL_BUILD) return

        val report = initMember3ProbeLastReport
        if (
            !report.contains("RESULT=FOUND_INITMEMBER3") ||
            !report.contains("map.status=COMPLETE_SAFE_SNAPSHOT")
        ) {
            Toast.makeText(
                this,
                tr(
                    "ยังจับไม่ครบ • ต้องได้ FOUND_INITMEMBER3 และ COMPLETE_SAFE_SNAPSHOT ก่อน",
                    "Capture incomplete • FOUND_INITMEMBER3 + COMPLETE_SAFE_SNAPSHOT required"
                ),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val clean = sanitizeHeartHandoffReport(report)
        val now = System.currentTimeMillis()

        heartHandoffPrefs().edit()
            .putString(P_HEART_CURRENT_REPORT, clean)
            .putLong(P_HEART_CURRENT_AT, now)
            .apply()

        val mid = extractInitMember3Field(clean, "mid").ifBlank { "UNKNOWN" }

        Toast.makeText(
            this,
            tr(
                "บันทึก Current Account แล้ว • MID=$mid",
                "Current Account saved • MID=$mid"
            ),
            Toast.LENGTH_SHORT
        ).show()

        DevConsole.log(
            "HEART-HANDOFF",
            "saved current account mid=$mid reportLines=${clean.lines().size}"
        )
    }

    private fun currentHeartAccountStatusText(): String {
        val prefs = heartHandoffPrefs()
        val report = prefs.getString(P_HEART_CURRENT_REPORT, "").orEmpty()
        val capturedAt = prefs.getLong(P_HEART_CURRENT_AT, 0L)
        val mid = extractInitMember3Field(report, "mid")
        val playerId = extractInitMember3Field(report, "playerId")

        return buildString {
            append("HEART HANDOFF • V12.5 final-envelope-meta\\n")
            append("CURRENT=")
            append(if (report.isNotBlank()) "CAPTURED" else "EMPTY")
            if (mid.isNotBlank()) append(" • MID=").append(mid)
            if (playerId.isNotBlank() && playerId != mid) {
                append(" • playerId=").append(playerId)
            }
            if (capturedAt > 0L) append("\\nCAPTURED_AT=").append(capturedAt)
            append("\\nEXPORT=ONE_ACCOUNT_AT_A_TIME")
            append("\\ncredentials=NOT_CAPTURED")
        }
    }

    private fun buildCurrentInitMember3AccountJson(): String {
        val prefs = heartHandoffPrefs()
        val report = prefs.getString(P_HEART_CURRENT_REPORT, "").orEmpty()
        val capturedAt = prefs.getLong(P_HEART_CURRENT_AT, 0L)

        if (report.isBlank()) return ""

        val account = reportToSafeJson(
            "account",
            report,
            capturedAt
        )

        val mid = extractInitMember3Field(report, "mid")
        val playerId = extractInitMember3Field(report, "playerId")

        return JSONObject().apply {
            put("format", "MWOIF_HEART_ACCOUNT_V12_1")
            put("game_version", "26.8.02")
            put("endpoint", "member/initMember3.ds")
            put("export_mode", "INDEPENDENT_ACCOUNT")
            put("account_id", mid)
            put("player_id", playerId)
            put("credential_policy", "NOT_CAPTURED")
            put("account", account)
        }.toString(2)
    }

    private fun copyCurrentInitMember3AccountJson() {
        if (!BuildConfig.INTERNAL_BUILD) return

        val prefs = heartHandoffPrefs()
        val report = prefs.getString(P_HEART_CURRENT_REPORT, "").orEmpty()

        if (report.isBlank()) {
            Toast.makeText(
                this,
                tr(
                    "ยังไม่มี Current Account • กด SAVE CURRENT ACCOUNT ก่อน",
                    "No Current Account saved • press SAVE CURRENT ACCOUNT first"
                ),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val json = buildCurrentInitMember3AccountJson()
        if (json.isBlank()) return

        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif Heart Account V12.1", json)
        )

        val mid = extractInitMember3Field(report, "mid").ifBlank { "UNKNOWN" }

        Toast.makeText(
            this,
            tr(
                "คัดลอก JSON ของ $mid แล้ว • เก็บไฟล์นี้ก่อนปิด/ล้างเกม",
                "Copied JSON for $mid • save this file before closing/resetting the game"
            ),
            Toast.LENGTH_LONG
        ).show()

        DevConsole.log(
            "HEART-HANDOFF",
            "current account json copied mid=$mid chars=${json.length}"
        )
    }

    private fun copyCurrentInitMember3PushToken() {
        if (!BuildConfig.INTERNAL_BUILD) return

        val token = extractInitMember3Field(
            initMember3ProbeLastReport,
            "pushToken"
        )

        if (
            token.isBlank() ||
            token.startsWith("<REDACTED") ||
            token.startsWith("<CAPTURED")
        ) {
            Toast.makeText(
                this,
                tr(
                    "ยังไม่มี pushToken จริง • ARM แล้วจับ initMember3 ใหม่ด้วย V12.5",
                    "No raw pushToken yet • ARM and capture initMember3 again with V12.5"
                ),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif initMember3 pushToken", token)
        )

        Toast.makeText(
            this,
            tr(
                "คัดลอก pushToken แล้ว • len=${token.length} • ไม่พิมพ์ค่าใน Log",
                "pushToken copied • len=${token.length} • value is not printed to logs"
            ),
            Toast.LENGTH_LONG
        ).show()

        DevConsole.log(
            "INITMEMBER3",
            "pushToken copied len=${token.length}"
        )
    }

    private fun clearCurrentInitMember3Account() {
        if (!BuildConfig.INTERNAL_BUILD) return

        heartHandoffPrefs().edit()
            .remove(P_HEART_CURRENT_REPORT)
            .remove(P_HEART_CURRENT_AT)
            .apply()

        Toast.makeText(
            this,
            tr("ล้าง Current Account แล้ว", "Current Account cleared"),
            Toast.LENGTH_SHORT
        ).show()

        DevConsole.log("HEART-HANDOFF", "current account cleared")
    }

    private fun heartHandoffPrefs(): SharedPreferences =
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun sanitizeHeartHandoffReport(report: String): String {
        val secretKeys = listOf(
            "accesstoken",
            "sessionkey",
            "authorization",
            "cookie",
            "refresh_token",
            "oven_access_token",
            "game_access_token",
            "device_secret",
            "pushtoken"
        )

        return report
            .lineSequence()
            .map { raw ->
                val line = raw.trimEnd()
                val lower = line.lowercase(Locale.US)
                if (secretKeys.any { lower.contains(it) }) {
                    val eq = line.indexOf('=')
                    if (eq >= 0) {
                        line.substring(0, eq + 1) + "<REDACTED>"
                    } else {
                        "<REDACTED_SECRET_LINE>"
                    }
                } else {
                    line
                }
            }
            .joinToString("\n")
    }

    private fun saveInitMember3HeartHandoff(role: String) {
        if (!BuildConfig.INTERNAL_BUILD) return
        val normalizedRole = role.lowercase(Locale.US)
        if (normalizedRole != "sender" && normalizedRole != "receiver") return

        if (!initMember3ProbeLastReport.contains("RESULT=FOUND_INITMEMBER3")) {
            Toast.makeText(
                this,
                tr(
                    "ยังไม่มี FOUND_INITMEMBER3 • ARM ก่อนแล้วเข้าเกมด้วยไอดีนี้",
                    "No FOUND_INITMEMBER3 yet • ARM first, then bootstrap this account"
                ),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val clean = sanitizeHeartHandoffReport(initMember3ProbeLastReport)
        val now = System.currentTimeMillis()
        val prefs = heartHandoffPrefs()

        prefs.edit().apply {
            if (normalizedRole == "sender") {
                putString(P_HEART_HANDOFF_SENDER_REPORT, clean)
                putLong(P_HEART_HANDOFF_SENDER_AT, now)
            } else {
                putString(P_HEART_HANDOFF_RECEIVER_REPORT, clean)
                putLong(P_HEART_HANDOFF_RECEIVER_AT, now)
            }
        }.apply()

        Toast.makeText(
            this,
            if (normalizedRole == "sender") {
                tr("บันทึก Sender snapshot แล้ว", "Sender snapshot saved")
            } else {
                tr("บันทึก Receiver snapshot แล้ว", "Receiver snapshot saved")
            },
            Toast.LENGTH_SHORT
        ).show()

        DevConsole.log(
            "HEART-HANDOFF",
            "saved role=$normalizedRole reportLines=${clean.lines().size}"
        )
    }

    private fun heartHandoffStatusText(): String {
        val prefs = heartHandoffPrefs()
        val sender = prefs.getString(P_HEART_HANDOFF_SENDER_REPORT, "").orEmpty()
        val receiver = prefs.getString(P_HEART_HANDOFF_RECEIVER_REPORT, "").orEmpty()
        val senderAt = prefs.getLong(P_HEART_HANDOFF_SENDER_AT, 0L)
        val receiverAt = prefs.getLong(P_HEART_HANDOFF_RECEIVER_AT, 0L)

        return buildString {
            append("HEART HANDOFF • schema-only\n")
            append("SENDER=")
            append(if (sender.isNotBlank()) "CAPTURED" else "EMPTY")
            if (senderAt > 0L) append(" @").append(senderAt)
            append("\nRECEIVER=")
            append(if (receiver.isNotBlank()) "CAPTURED" else "EMPTY")
            if (receiverAt > 0L) append(" @").append(receiverAt)
            append("\ncredentials=NOT_CAPTURED")
        }
    }

    private fun reportToSafeJson(
        role: String,
        report: String,
        capturedAt: Long
    ): JSONObject {
        val out = JSONObject()
        out.put("role", role)
        out.put("captured_at_epoch_ms", capturedAt)
        out.put("endpoint", "member/initMember3.ds")
        out.put("probe_version", "V12-SYNC-BODY-SNAPSHOT")
        out.put("handoff_version", "V12-HEART-SCHEMA-ONLY")
        out.put("read_only", true)
        out.put("credentials_captured", false)
        out.put("report", sanitizeHeartHandoffReport(report))

        val structural = JSONObject()
        report.lineSequence().forEach { raw ->
            val line = raw.trim()
            val idx = line.indexOf('=')
            if (idx <= 0) return@forEach
            val key = line.substring(0, idx).trim()
            val value = line.substring(idx + 1).trim()
            val lower = key.lowercase(Locale.US)

            if (
                lower.contains("token") ||
                lower.contains("session") ||
                lower.contains("authorization") ||
                lower.contains("cookie") ||
                lower.contains("secret")
            ) {
                return@forEach
            }

            if (
                key in setOf(
                    "probeVersion",
                    "captureMode",
                    "READ_ONLY",
                    "RESULT",
                    "endpoint",
                    "endpointStringGH",
                    "builderGH",
                    "requestVtableGH",
                    "requestObjects",
                    "matched",
                    "req.s+0x48",
                    "req.s+0xC0",
                    "map.status",
                    "map.mode"
                )
            ) {
                structural.put(key, value)
            }
        }
        out.put("structural", structural)

        val payloadFields = JSONObject()
        report.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (!line.startsWith("field.")) return@forEach
            val idx = line.indexOf('=')
            if (idx <= 6) return@forEach
            val fieldName = line.substring(6, idx).trim()
            val value = line.substring(idx + 1).trim()
            val lower = fieldName.lowercase(Locale.US)
            if (
                lower.contains("token") ||
                lower.contains("session") ||
                lower.contains("authorization") ||
                lower.contains("cookie") ||
                lower.contains("secret")
            ) {
                val safeType = when {
                    value.startsWith("string:") -> "string:<REDACTED>"
                    value.startsWith("int32:") -> "int32:<REDACTED>"
                    value.startsWith("int64:") -> "int64:<REDACTED>"
                    else -> "<REDACTED>"
                }
                payloadFields.put(fieldName, safeType)
            } else {
                payloadFields.put(fieldName, value)
            }
        }
        out.put("payload_fields", payloadFields)
        return out
    }

    private fun buildInitMember3HeartHandoffJson(): String {
        val prefs = heartHandoffPrefs()
        val sender = prefs.getString(P_HEART_HANDOFF_SENDER_REPORT, "").orEmpty()
        val receiver = prefs.getString(P_HEART_HANDOFF_RECEIVER_REPORT, "").orEmpty()
        val senderAt = prefs.getLong(P_HEART_HANDOFF_SENDER_AT, 0L)
        val receiverAt = prefs.getLong(P_HEART_HANDOFF_RECEIVER_AT, 0L)

        return JSONObject().apply {
            put("format", "MWOIF_HEART_HANDOFF_V12")
            put("game_version", "26.8.02")
            put("endpoint", "member/initMember3.ds")
            put("credential_policy", "NOT_CAPTURED")
            put("sender", reportToSafeJson("sender", sender, senderAt))
            put("receiver", reportToSafeJson("receiver", receiver, receiverAt))
        }.toString(2)
    }

    private fun copyInitMember3HeartHandoffJson() {
        if (!BuildConfig.INTERNAL_BUILD) return

        val prefs = heartHandoffPrefs()
        val sender = prefs.getString(P_HEART_HANDOFF_SENDER_REPORT, "").orEmpty()
        val receiver = prefs.getString(P_HEART_HANDOFF_RECEIVER_REPORT, "").orEmpty()

        if (sender.isBlank() || receiver.isBlank()) {
            Toast.makeText(
                this,
                tr(
                    "ต้อง SAVE SENDER และ SAVE RECEIVER ให้ครบก่อน",
                    "Save both SENDER and RECEIVER snapshots first"
                ),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val json = buildInitMember3HeartHandoffJson()
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif Heart Handoff V12", json)
        )
        Toast.makeText(
            this,
            tr("คัดลอก HEART HANDOFF JSON แล้ว", "HEART HANDOFF JSON copied"),
            Toast.LENGTH_SHORT
        ).show()
        DevConsole.log("HEART-HANDOFF", "json copied chars=${json.length}")
    }

    private fun clearInitMember3HeartHandoff() {
        if (!BuildConfig.INTERNAL_BUILD) return

        heartHandoffPrefs().edit()
            .remove(P_HEART_HANDOFF_SENDER_REPORT)
            .remove(P_HEART_HANDOFF_SENDER_AT)
            .remove(P_HEART_HANDOFF_RECEIVER_REPORT)
            .remove(P_HEART_HANDOFF_RECEIVER_AT)
            .apply()

        Toast.makeText(
            this,
            tr("ล้าง HEART HANDOFF แล้ว", "HEART HANDOFF cleared"),
            Toast.LENGTH_SHORT
        ).show()
        DevConsole.log("HEART-HANDOFF", "cleared")
    }

    private fun cleanInitMember3ProbeReport(message: String): String =
        message
            .removePrefix("game-process • ")
            .trim()

    private fun redactInitMember3PushTokenForDisplay(report: String): String =
        report
            .lineSequence()
            .map { raw ->
                val line = raw.trimEnd()
                val lower = line.lowercase(Locale.US)
                when {
                    lower.startsWith("field.pushtoken=") ->
                        "field.pushToken=string:<CAPTURED>"
                    lower.contains("key=pushtoken") ->
                        line.replace(
                            Regex("""value=string:[^ ]+"""),
                            "value=string:<CAPTURED>"
                        )
                    else -> line
                }
            }
            .joinToString("\n")

    private fun cleanSessionV13Report(message: String): String {
        val marker = "MWOIF_SESSION_STATE_V13"
        val idx = message.indexOf(marker)
        return if (idx >= 0) message.substring(idx).trim() else message.trim()
    }

    private fun redactSessionV13ForDisplay(report: String): String =
        report
            .lineSequence()
            .filterNot { it.startsWith("sessionJson=") }
            .map { line ->
                if (line.startsWith("sessionKey=")) {
                    "sessionKey=<REDACTED>"
                } else {
                    line
                }
            }
            .joinToString("\n")

    private fun sessionV13Display(report: String, prefix: String = ""): String {
        val safe = redactSessionV13ForDisplay(report)
        return buildString {
            if (prefix.isNotBlank()) appendLine(prefix)
            append(safe.ifBlank { "NO SESSION REPORT" })
        }.trimEnd()
    }

    private fun runSessionV13Read() {
        if (!BuildConfig.INTERNAL_BUILD) return
        sessionV13StatusText = "READ SESSION • กำลังอ่าน established game state..."
        sessionV13View?.text = sessionV13StatusText

        Thread({
            val result = InProcessGameControl.sessionState(
                context = this,
                includeSecret = false,
                timeoutMs = 5000L
            )
            val report = cleanSessionV13Report(result.message)
            sessionV13LastReport =
                if (report.isBlank()) {
                    "MWOIF_SESSION_STATE_V13\nRESULT=NO_REPORT\n"
                } else {
                    report
                }

            handler.post {
                val ready = sessionV13LastReport.contains("RESULT=READY")
                sessionV13StatusText = sessionV13Display(
                    sessionV13LastReport,
                    if (ready) "READY • established session found" else "WAIT • เข้าเกมให้ถึง Lobby ก่อน"
                )
                sessionV13View?.text = sessionV13StatusText
                Toast.makeText(
                    this,
                    if (ready) {
                        tr("เจอ Session แล้ว", "Established session found")
                    } else {
                        tr("Session ยังไม่พร้อม • เข้า Lobby ก่อน", "Session not ready • enter Lobby first")
                    },
                    Toast.LENGTH_SHORT
                ).show()
                DevConsole.log(
                    "SESSION_V13",
                    "read ok=${result.ok} ready=$ready"
                )
            }
        }, "mw-session-v13-read").apply {
            isDaemon = true
            start()
        }
    }

    private fun copySessionV13Json() {
        if (!BuildConfig.INTERNAL_BUILD) return

        Thread({
            val result = InProcessGameControl.sessionState(
                context = this,
                includeSecret = true,
                timeoutMs = 5000L
            )
            val report = cleanSessionV13Report(result.message)
            val json = report
                .lineSequence()
                .firstOrNull { it.startsWith("sessionJson=") }
                ?.substringAfter("sessionJson=")
                ?.trim()
                .orEmpty()

            handler.post {
                if (!result.ok || json.isBlank()) {
                    sessionV13LastReport = redactSessionV13ForDisplay(report)
                    sessionV13StatusText = sessionV13Display(
                        sessionV13LastReport,
                        "COPY FAILED • Session ยังไม่พร้อม"
                    )
                    sessionV13View?.text = sessionV13StatusText
                    Toast.makeText(
                        this,
                        tr("ยังไม่มี established session ให้คัดลอก", "No established session to copy"),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@post
                }

                val clipboard =
                    getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(
                    ClipData.newPlainText("M Woif V13 Session JSON", json)
                )

                sessionV13LastReport = redactSessionV13ForDisplay(report)
                sessionV13StatusText = sessionV13Display(
                    sessionV13LastReport,
                    "COPIED • SESSION JSON อยู่ใน Clipboard"
                )
                sessionV13View?.text = sessionV13StatusText
                Toast.makeText(
                    this,
                    tr("คัดลอก Session JSON แล้ว", "Session JSON copied"),
                    Toast.LENGTH_SHORT
                ).show()
                DevConsole.log(
                    "SESSION_V13",
                    "session JSON copied; secret not logged"
                )
            }
        }, "mw-session-v13-copy").apply {
            isDaemon = true
            start()
        }
    }

    private fun copySessionV13RedactedReport() {
        val text = redactSessionV13ForDisplay(sessionV13LastReport)
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(
            ClipData.newPlainText("M Woif V13 Session Report", text)
        )
        Toast.makeText(
            this,
            tr("คัดลอก Session Report แล้ว", "Session report copied"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun cleanAuthV13Report(message: String): String {
        val marker = "MWOIF_AUTH_CONTEXT_V13_1"
        val idx = message.indexOf(marker)
        return if (idx >= 0) message.substring(idx).trim() else message.trim()
    }

    private fun redactAuthV13ForDisplay(report: String): String =
        report
            .lineSequence()
            .filterNot { it.startsWith("authJson=") }
            .map { line ->
                when {
                    line.startsWith("gameAccessToken=") ->
                        "gameAccessToken=<REDACTED>"
                    else -> line
                }
            }
            .joinToString("\n")

    private fun authV13Display(report: String, prefix: String = ""): String {
        val safe = redactAuthV13ForDisplay(report)
        return buildString {
            if (prefix.isNotBlank()) appendLine(prefix)
            append(safe.ifBlank { "NO AUTH REPORT" })
        }.trimEnd()
    }

    private fun runAuthContextV13Read() {
        if (!BuildConfig.INTERNAL_BUILD) return
        authV13StatusText = "READ AUTH CONTEXT • GAME process..."
        authV13View?.text = authV13StatusText

        Thread({
            val result = InProcessGameControl.authContext(
                context = this,
                includeSecret = false,
                timeoutMs = 5000L
            )
            val report = cleanAuthV13Report(result.message)
            handler.post {
                val ready = result.ok && report.contains("RESULT=READY")
                authV13StatusText = authV13Display(
                    report,
                    if (ready) {
                        "READY • game-owned auth materializer"
                    } else {
                        "WAIT • game auth context not ready"
                    }
                )
                authV13View?.text = authV13StatusText

                val reason = report
                    .lineSequence()
                    .firstOrNull { it.startsWith("reason=") }
                    ?.substringAfter("reason=")
                    ?.ifBlank { "NOT_READY" }
                    ?: "NOT_READY"

                Toast.makeText(
                    this,
                    if (ready) {
                        tr("เจอ Auth Context แล้ว", "Auth Context ready")
                    } else {
                        tr(
                            "Auth Context ยังไม่พร้อม • $reason",
                            "Auth context not ready • $reason"
                        )
                    },
                    Toast.LENGTH_SHORT
                ).show()

                DevConsole.log(
                    "AUTH_V13_1",
                    "read gameProcess=${result.ok} ready=$ready source=GAME_OWNED_MATERIALIZER"
                )
            }
        }, "mw-auth-v13-1-read").apply {
            isDaemon = true
            start()
        }
    }

    private fun copyAuthContextV13Json() {
        if (!BuildConfig.INTERNAL_BUILD) return
        authV13StatusText = "COPY AUTH CONTEXT JSON • GAME process..."
        authV13View?.text = authV13StatusText

        Thread({
            val result = InProcessGameControl.authContext(
                context = this,
                includeSecret = true,
                timeoutMs = 5000L
            )
            val report = cleanAuthV13Report(result.message)
            val json = report
                .lineSequence()
                .firstOrNull { it.startsWith("authJson=") }
                ?.substringAfter("authJson=")
                ?.trim()
                .orEmpty()

            handler.post {
                if (!result.ok || json.isBlank()) {
                    authV13StatusText = authV13Display(
                        report,
                        "COPY FAILED • Auth Context ยังไม่พร้อม"
                    )
                    authV13View?.text = authV13StatusText
                    Toast.makeText(
                        this,
                        tr("ยังไม่มี Auth Context ให้คัดลอก", "No Auth Context to copy"),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@post
                }

                val clipboard =
                    getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(
                    ClipData.newPlainText(
                        "M Woif V13.1 Auth Context JSON",
                        json
                    )
                )

                // Render only the redacted report. Never render/log the JSON.
                val redacted = InProcessGameControl.authContext(
                    context = this,
                    includeSecret = false,
                    timeoutMs = 5000L
                )
                val redactedReport = cleanAuthV13Report(redacted.message)
                authV13StatusText = authV13Display(
                    redactedReport,
                    "COPIED • AUTH CONTEXT JSON อยู่ใน Clipboard"
                )
                authV13View?.text = authV13StatusText
                Toast.makeText(
                    this,
                    tr("คัดลอก Auth Context JSON แล้ว", "Auth Context JSON copied"),
                    Toast.LENGTH_SHORT
                ).show()
                DevConsole.log(
                    "AUTH_V13_1",
                    "auth JSON copied from GAME process; token not logged"
                )
            }
        }, "mw-auth-v13-1-copy").apply {
            isDaemon = true
            start()
        }
    }

    private fun devSessionStateV13(root: LinearLayout) {
        root.addView(
            pageTitle(
                "00 • SESSION STATE EXPORT V13",
                tr(
                    "เข้าเกมตามปกติให้ถึง Lobby แล้วอ่าน established session จาก game state โดยตรง • ไม่ต้อง ARM / ไม่ scan request heap",
                    "Normal game login to Lobby, then read the established session directly from long-lived game state. No ARM and no request-heap scan."
                )
            )
        )
        root.addView(section("00.1 • ESTABLISHED SESSION REUSE"), sectionLp())

        val card = featureCard()
        card.addView(
            txt(
                tr(
                    "วิธีใช้: Login A หรือ B ตามปกติ → เข้า Lobby → READ SESSION → ถ้าขึ้น READY ให้ COPY SESSION JSON แล้วนำเข้า Python ตาม Slot ที่ต้องการ",
                    "Flow: login A or B normally → enter Lobby → READ SESSION → when READY, COPY SESSION JSON and import it into the matching Python slot."
                ),
                9f,
                "#8F9AAC"
            ).apply {
                setPadding(dp(4), dp(2), dp(4), dp(8))
            },
            subLp()
        )

        val status = txt(
            sessionV13StatusText,
            8.6f,
            if (sessionV13LastReport.contains("RESULT=READY")) "#4ADE80" else "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        sessionV13View = status
        card.addView(status, subLp())

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row1.addView(
            button(tr("READ SESSION", "READ SESSION"), true) {
                runSessionV13Read()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            })
        row1.addView(
            button(tr("COPY SESSION JSON", "COPY SESSION JSON"), false) {
                copySessionV13Json()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            })
        card.addView(row1, subLp())

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row2.addView(
            button(tr("COPY REDACTED REPORT", "COPY REDACTED REPORT"), false) {
                copySessionV13RedactedReport()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            })
        row2.addView(
            button(tr("CLEAR", "CLEAR"), false) {
                sessionV13LastReport =
                    "MWOIF_SESSION_STATE_V13\nRESULT=NOT_RUN\n"
                sessionV13StatusText =
                    "READY • เข้าเกมให้ถึง Lobby แล้วกด READ SESSION"
                sessionV13View?.text = sessionV13StatusText
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            })
        card.addView(row2, subLp().apply { topMargin = dp(8) })

        // V13.1 Auth Context is attached directly to the proven V13 card.
        // This keeps the V13 Session UI intact and guarantees the two new
        // actions are actually rendered by FloatingMenuService.
        card.addView(
            txt(
                "00.2 • AUTH CONTEXT EXPORT V13.1 • GAME-OWNED",
                9f,
                "#8F9AAC"
            ).apply {
                setPadding(dp(4), dp(14), dp(4), dp(6))
            },
            subLp()
        )

        val authStatus = txt(
            authV13StatusText,
            8.6f,
            if (authV13StatusText.contains("RESULT=READY")) "#4ADE80" else "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        authV13View = authStatus
        card.addView(authStatus, subLp())

        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row3.addView(
            button(tr("READ AUTH CONTEXT", "READ AUTH CONTEXT"), true) {
                runAuthContextV13Read()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            })
        row3.addView(
            button(tr("COPY AUTH CONTEXT JSON", "COPY AUTH CONTEXT JSON"), false) {
                copyAuthContextV13Json()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            })
        card.addView(row3, subLp().apply { topMargin = dp(8) })

        root.addView(card, sectionLp())
    }

    private fun initMember3ProbeDisplay(
        report: String,
        prefix: String = ""
    ): String {
        val safeReport = redactInitMember3PushTokenForDisplay(report)
        val lines = safeReport
            .lineSequence()
            .filter { it.isNotBlank() }
            .take(120)
            .toList()

        return buildString {
            if (prefix.isNotBlank()) {
                appendLine(prefix)
            }
            if (lines.isEmpty()) {
                append("NO REPORT")
            } else {
                append(lines.joinToString("\n"))
            }
        }.trimEnd()
    }

    private fun runInitMember3ProbeSnapshot() {
        if (!BuildConfig.INTERNAL_BUILD || initMember3ProbeRunning) return

        initMember3ProbeText = "SCAN NOW • กำลังอ่าน game-process request objects..."
        initMember3ProbeView?.text = initMember3ProbeText

        Thread({
            val result = InProcessGameControl.initMember3Probe(
                context = this,
                timeoutMs = 9000L
            )
            val report = cleanInitMember3ProbeReport(result.message)
            initMember3ProbeLastReport =
                if (report.isBlank()) {
                    "INITMEMBER3_PROBE\nRESULT=NO_REPORT\n"
                } else {
                    report
                }

            handler.post {
                initMember3ProbeText =
                    initMember3ProbeDisplay(
                        initMember3ProbeLastReport,
                        if (result.ok) "SCAN NOW • OK" else "SCAN NOW • WAIT/FAIL"
                    )
                initMember3ProbeView?.text = initMember3ProbeText
                DevConsole.log(
                    "INITMEMBER3",
                    "scanNow ok=${result.ok} result=${initMember3ProbeLastReport.lineSequence().firstOrNull().orEmpty()}"
                )
            }
        }, "mw-initmember3-scan").apply {
            isDaemon = true
            start()
        }
    }

    private fun runInitMember3ProbeCapture() {
        if (!BuildConfig.INTERNAL_BUILD) return
        if (initMember3ProbeRunning) {
            Toast.makeText(
                this,
                tr("InitMember3 Probe กำลังทำงาน", "InitMember3 Probe is already running"),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        initMember3ProbeRunning = true
        initMember3ProbeLastReport =
            "INITMEMBER3_PROBE\nRESULT=ARMED\n"
        initMember3ProbeText =
            "ARMED 20s • ปิดเมนูแล้วให้เกมทำ DevPlay / initMember3 ตามธรรมชาติ"
        initMember3ProbeView?.text = initMember3ProbeText
        DevConsole.log("INITMEMBER3", "ARM CAPTURE 20s")

        Thread({
            val startedAt = android.os.SystemClock.elapsedRealtime()
            val deadline = startedAt + 20_000L
            var attempt = 0
            var found = false
            var lastReport =
                "INITMEMBER3_PROBE\nRESULT=WAITING\n"
            var lastRequestObjectReport = ""

            while (
                initMember3ProbeRunning &&
                android.os.SystemClock.elapsedRealtime() < deadline &&
                !found
            ) {
                attempt += 1

                val result = InProcessGameControl.initMember3Probe(
                    context = this,
                    timeoutMs = 9000L
                )
                val report = cleanInitMember3ProbeReport(result.message)

                if (report.isNotBlank()) {
                    lastReport = report
                    if (report.contains("RESULT=REQUEST_OBJECTS_FOUND")) {
                        lastRequestObjectReport = report
                    }
                }

                found = report.contains("RESULT=FOUND_INITMEMBER3")

                val elapsed =
                    android.os.SystemClock.elapsedRealtime() - startedAt
                handler.post {
                    initMember3ProbeText =
                        initMember3ProbeDisplay(
                            report.ifBlank { lastReport },
                            "CAPTURE • attempt=$attempt • ${elapsed}ms / 20000ms"
                        )
                    initMember3ProbeView?.text = initMember3ProbeText
                }

                if (!found) {
                    try {
                        Thread.sleep(120L)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }

            val finalReport =
                when {
                    found -> lastReport
                    lastRequestObjectReport.isNotBlank() ->
                        buildString {
                            appendLine("INITMEMBER3_CAPTURE")
                            appendLine("RESULT=TIMEOUT_WITH_REQUEST_OBJECTS")
                            appendLine("attempts=$attempt")
                            appendLine("--- LAST REQUEST OBJECT SNAPSHOT ---")
                            append(lastRequestObjectReport)
                        }
                    else ->
                        buildString {
                            appendLine("INITMEMBER3_CAPTURE")
                            appendLine("RESULT=TIMEOUT_NOT_FOUND")
                            appendLine("attempts=$attempt")
                            appendLine("--- LAST SNAPSHOT ---")
                            append(lastReport)
                        }
                }

            initMember3ProbeLastReport = finalReport
            initMember3ProbeRunning = false

            handler.post {
                initMember3ProbeText =
                    initMember3ProbeDisplay(
                        finalReport,
                        if (found) {
                            "FOUND • initMember3 request object"
                        } else {
                            "CAPTURE END • ยังไม่เจอ exact initMember3"
                        }
                    )
                initMember3ProbeView?.text = initMember3ProbeText
                Toast.makeText(
                    this,
                    if (found) {
                        tr("เจอ initMember3 แล้ว • คัดลอก Report", "initMember3 found • copy the report")
                    } else {
                        tr("ยังไม่เจอ exact request • ลอง ARM ก่อน Login", "Exact request not found • ARM before login")
                    },
                    Toast.LENGTH_SHORT
                ).show()
                DevConsole.log(
                    "INITMEMBER3",
                    "capture end found=$found attempts=$attempt"
                )
            }
        }, "mw-initmember3-capture").apply {
            isDaemon = true
            start()
        }
    }

    private fun copyInitMember3ProbeReport() {
        if (!BuildConfig.INTERNAL_BUILD) return

        val text = buildString {
            appendLine("=== M WOIF LAB • INITMEMBER3 HEART HANDOFF V12.6 FAST HOT-RANGE CAPTURE ===")
            appendLine("CAPTURE_ONLY=true")
            appendLine("probeVersion=V12-SYNC-BODY-SNAPSHOT")
            appendLine("endpoint=member/initMember3.ds")
            appendLine("endpointGH=0x007269E4")
            appendLine("builderGH=0x01640B40")
            appendLine("requestVtableGH=0x020EC238")
            appendLine("--- CAPTURE ---")
            append(redactInitMember3PushTokenForDisplay(initMember3ProbeLastReport))
        }

        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(
            ClipData.newPlainText(
                "M Woif Lab initMember3 Probe",
                text
            )
        )
        Toast.makeText(
            this,
            tr("คัดลอก initMember3 Report แล้ว", "initMember3 report copied"),
            Toast.LENGTH_SHORT
        ).show()
        DevConsole.log(
            "INITMEMBER3",
            "report copied (${text.lines().size} lines)"
        )
    }


    private fun heartSendDsProbeDisplay(
        report: String,
        prefix: String = ""
    ): String {
        val lines = report
            .lineSequence()
            .filter { it.isNotBlank() }
            .map { line ->
                if (line.startsWith("envelope.data=")) {
                    val len = line.removePrefix("envelope.data=").length
                    "envelope.data=<CAPTURED len=$len>"
                } else {
                    line
                }
            }
            .take(100)
            .toList()

        return buildString {
            if (prefix.isNotBlank()) appendLine(prefix)
            if (lines.isEmpty()) append("NO REPORT") else append(lines.joinToString("\n"))
        }.trimEnd()
    }

    private fun runHeartSendDsProbeCapture() {
        if (!BuildConfig.INTERNAL_BUILD || heartSendDsProbeRunning) return

        heartSendDsProbeRunning = true
        heartSendDsProbeLastReport = "HEART_SEND_DS_PROBE\nRESULT=ARMED\n"
        heartSendDsProbeText =
            "ARMED V13.3 EVENT 20s • ปิดเมนู แล้วกดส่งใจจริง 1 ครั้ง"
        heartSendDsProbeView?.text = heartSendDsProbeText
        DevConsole.log("HEART_DS", "ARM CAPTURE 20s")

        Thread({
            // V13.3 always clears/restores any previous event hook before arming.
            InProcessGameControl.heartSendDsProbeReset(
                context = this,
                timeoutMs = 5000L
            )

            val startedAt = android.os.SystemClock.elapsedRealtime()
            val deadline = startedAt + 20_000L
            var attempt = 0
            var found = false
            var lastReport = "HEART_SEND_DS_PROBE\nRESULT=WAITING\n"

            while (
                heartSendDsProbeRunning &&
                android.os.SystemClock.elapsedRealtime() < deadline &&
                !found
            ) {
                attempt += 1
                val result = InProcessGameControl.heartSendDsProbe(
                    context = this,
                    timeoutMs = 9000L
                )
                val report = cleanInitMember3ProbeReport(result.message)
                if (report.isNotBlank()) lastReport = report
                found = report.contains("RESULT=FOUND_HEART_SEND")

                val elapsed = android.os.SystemClock.elapsedRealtime() - startedAt
                handler.post {
                    heartSendDsProbeText = heartSendDsProbeDisplay(
                        report.ifBlank { lastReport },
                        "CAPTURE • attempt=$attempt • ${elapsed}ms / 20000ms"
                    )
                    heartSendDsProbeView?.text = heartSendDsProbeText
                }

                if (!found) {
                    try {
                        Thread.sleep(50L)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }

            if (!found) {
                InProcessGameControl.heartSendDsProbeReset(
                    context = this,
                    timeoutMs = 5000L
                )
            }

            heartSendDsProbeLastReport = lastReport
            heartSendDsProbeRunning = false
            handler.post {
                heartSendDsProbeText = heartSendDsProbeDisplay(
                    lastReport,
                    if (found) "FOUND • sendLifeMail2 captured" else "CAPTURE END • not found"
                )
                heartSendDsProbeView?.text = heartSendDsProbeText
                Toast.makeText(
                    this,
                    if (found) {
                        tr("เจอ sendLifeMail2 แล้ว • กด COPY REPORT", "sendLifeMail2 found • press COPY REPORT")
                    } else {
                        tr("ยังไม่เจอ • ARM แล้วกดส่งใจจริงอีกครั้ง", "Not found • arm and send one heart again")
                    },
                    Toast.LENGTH_SHORT
                ).show()
            }
        }, "mw-heart-send-ds-capture").apply {
            isDaemon = true
            start()
        }
    }

    private fun copyHeartSendDsProbeReport() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val text = buildString {
            appendLine("=== M WOIF LAB • HEART SEND DS CAPTURE V13.5 ===")
            appendLine("READ_ONLY=true")
            appendLine("endpoint=game/sendLifeMail2.ds")
            appendLine("endpointGH=0x007B24A9")
            appendLine("builderGH=0x013D4D10")
            appendLine("requestVtableGH=0x020EC238")
            appendLine("--- CAPTURE ---")
            append(heartSendDsProbeLastReport)
        }
        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(
            ClipData.newPlainText("M Woif Lab Heart Send DS Probe", text)
        )
        Toast.makeText(
            this,
            tr("คัดลอก Heart DS Report แล้ว", "Heart DS report copied"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun devHeartSendDsProbe(root: LinearLayout) {
        root.addView(section("00.2 • HEART SEND DS ENVELOPE CAPTURE"), sectionLp())
        val card = featureCard()
        card.addView(
            txt(
                tr(
                    "CAPTURE ONLY • V13.3 ใช้ temporary serializer hook • กด ARM แล้วปิดเมนู จากนั้นส่งใจจริง 1 ครั้ง • ไม่แก้ request/payload และจะ restore hook หลังจับ/timeout",
                    "READ ONLY • arm, close menu, then send one heart normally. Captures ValueMap, plaintext wire when present, and final isEncryptedData/data envelope."
                ),
                9f,
                "#8F9AAC"
            ),
            subLp()
        )

        val status = txt(heartSendDsProbeText, 8.4f, "#C8D0DC").apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        heartSendDsProbeView = status
        card.addView(status, subLp())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            button(tr("ARM HEART CAPTURE 20s", "ARM HEART CAPTURE 20s"), true) {
                runHeartSendDsProbeCapture()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        row.addView(
            button(tr("COPY REPORT", "COPY REPORT"), false) {
                copyHeartSendDsProbeReport()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        card.addView(row, subLp())

        val reset = button(tr("READ CRYPTO / RESET", "READ CRYPTO / RESET"), false) {
            if (!heartSendDsProbeRunning) {
                heartSendDsProbeText = "READING • protocol v4 crypto profile..."
                heartSendDsProbeView?.text = heartSendDsProbeText

                Thread({
                    val r = InProcessGameControl.heartSendDsProbeReset(
                        context = this,
                        timeoutMs = 5000L
                    )
                    heartSendDsProbeLastReport = r.message
                    val found = r.message.contains("crypto.result=FOUND")
                    handler.post {
                        heartSendDsProbeText =
                            if (found) {
                                "CRYPTO FOUND • กด COPY REPORT • ไม่ต้องส่งใจ"
                            } else {
                                "CRYPTO READ FAILED • กด COPY REPORT"
                            }
                        heartSendDsProbeView?.text = heartSendDsProbeText
                    }
                }, "mw-heart-send-ds-crypto-read").apply {
                    isDaemon = true
                    start()
                }
            }
        }
        card.addView(reset, subLp().apply { topMargin = dp(8) })
        card.addView(
            txt(
                "V13.5 NEXT: กด READ CRYPTO / RESET แล้ว COPY REPORT ได้ทันที • ไม่ต้อง ARM และไม่ต้องส่งใจ",
                8.4f,
                "#8F9AAC"
            ),
            subLp().apply { topMargin = dp(6) }
        )
        root.addView(card, sectionLp())
    }

    private fun dev(root: LinearLayout) {
        if (!BuildConfig.INTERNAL_BUILD) {
            root.addView(pageTitle("DEV", "Internal tools are unavailable"))
            return
        }

        // V13 established-session export replaces request-heap capture as the
        // primary bootstrap handoff. Existing V12.6 probe stays below it as a
        // diagnostic fallback and no other DEV tool is changed.
        devSessionStateV13(root)
        devInitMember3Probe(root)
        devHeartSendDsProbe(root)

        // Update finders are additive. Existing AUTO LAB remains unchanged.
        devGiantSuper(root)
        devBuildUpdateFinder(root)

        root.addView(
            pageTitle(
                "12 • POWDER PUMP DEV",
                tr(
                    "สถานะสด รายงาน Error และเครื่องมือทดสอบ Powder Pump",
                    "Live state, error report and Powder Pump test tools"
                )
            )
        )
        root.addView(section("12.1 • POWDER PUMP DIAGNOSTICS"), sectionLp())
        val powderDevCard = featureCard()
        powderPumpDevDiagnosticsText = fetchPowderPumpDevDiagnostics()
        val powderDiagnostics = txt(
            powderPumpDevDiagnosticsText,
            8.4f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        powderPumpDevDiagnosticsView = powderDiagnostics
        powderDevCard.addView(powderDiagnostics, subLp())

        val powderDevActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        powderDevActions.addView(
            button(tr("คัดลอก Powder Report", "Copy Powder report"), false) {
                copyPowderPumpLabReport()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            }
        )
        powderDevActions.addView(
            button(tr("Cleanup Retain", "Cleanup retain"), false) {
                cleanupPowderPumpLabRetain()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            }
        )
        powderDevCard.addView(powderDevActions, subLp().apply { topMargin = dp(8) })
        powderDevCard.addView(
            button(tr("Reset DEV Report", "Reset DEV report"), false) {
                resetPowderPumpDevReport()
            },
            subLp().apply { topMargin = dp(8); height = dp(42) }
        )
        root.addView(powderDevCard, itemLp())

        root.addView(section("12.2 • POWDER PUMP TEST TOOLS"), sectionLp())
        val powderTestCard = featureCard()
        powderTestCard.addView(
            txt(
                tr(
                    "ใช้เฉพาะทดสอบ Internal • ผลและ Error จะค้างอยู่ใน Diagnostics ด้านบน",
                    "Internal tests only • results and errors remain in Diagnostics above"
                ),
                9f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(2), dp(4), dp(8)) },
            subLp()
        )
        val powderTestRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        powderTestRow1.addView(
            button(tr("ทดสอบ 1 รอบ", "One round"), false) {
                if (!powderPumpLabRunning) runPowderPumpLabOneRound()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        powderTestRow1.addView(
            button("BUY x10", false) {
                if (!powderPumpLabRunning) runPowderPumpBurst10Experiment()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        powderTestCard.addView(powderTestRow1, subLp())
        powderTestCard.addView(
            button("BUY x10 → BATCH BREAK", false) {
                if (!powderPumpLabRunning) runPowderPumpBurst10BatchExperiment()
            },
            subLp().apply { topMargin = dp(8); height = dp(42) }
        )
        powderTestCard.addView(
            button(tr("Connection Lost / Retry", "Connection Lost / Retry"), false) {
                if (!powderPumpLabRunning) triggerPowderPumpConnectionRetry()
            },
            subLp().apply { topMargin = dp(8); height = dp(42) }
        )
        powderTestCard.addView(
            txt(
                tr(
                    "ปุ่มนี้ใช้ทดสอบ flow เดิมหลัง Coin ต่ำกว่า 5,000 เท่านั้น • ถ้า Coin ยังพอซื้อ ระบบจะไม่ยิง request",
                    "Tests the old retry flow only below 5,000 Coin • blocked while Coin can still buy"
                ),
                8.5f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(6), dp(4), dp(2)) },
            subLp()
        )
        root.addView(powderTestCard, itemLp())

        root.addView(
            pageTitle(
                "13 • TOWER PUMP DEV",
                tr(
                    "สถานะ Mission, Result/Commit และ Error ของ Tower Lab",
                    "Tower Lab mission, result/commit and error diagnostics"
                )
            )
        )
        root.addView(section("13.1 • TOWER DIAGNOSTICS"), sectionLp())
        val towerDevCard = featureCard()
        towerPumpDevDiagnosticsText = fetchTowerPumpDevDiagnostics()
        val towerDiagnostics = txt(
            towerPumpDevDiagnosticsText,
            8.4f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        towerPumpDevDiagnosticsView = towerDiagnostics
        towerDevCard.addView(towerDiagnostics, subLp())

        val towerDevActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        towerDevActions.addView(
            button(tr("อ่านสถานะ Tower", "Read Tower state"), false) {
                if (!towerPumpLabRunning) runTowerPumpStateRead()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginEnd = dp(5)
            }
        )
        towerDevActions.addView(
            button(tr("คัดลอก Tower Report", "Copy Tower report"), false) {
                copyTowerPumpLabReport()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
            }
        )
        towerDevCard.addView(towerDevActions, subLp().apply { topMargin = dp(8) })
        towerDevCard.addView(
            button(tr("Reset Tower DEV", "Reset Tower DEV"), false) {
                resetTowerPumpDevReport()
            },
            subLp().apply { topMargin = dp(8); height = dp(42) }
        )
        root.addView(towerDevCard, itemLp())

        root.addView(section("13.2 • TOWER AUTO PASS / MANUAL PLAY"), sectionLp())
        val towerTestCard = featureCard()
        towerTestCard.addView(
            txt(
                tr(
                    "เปิดปั้มไว้ แล้วเลือกด่าน/กดเล่นเอง • ระบบเปิดเฉพาะ ความเร็วพื้นฐานคุกกี้ + Giant + Super • รอ secondaryState 0→1 ตอนถึงประตู แล้วค่อยตั้ง Mission เป็น required/required ก่อน Result",
                    "Leave the pump enabled and start stages manually. Only Cookie Base Speed + Giant + Super are enabled. The Lab waits for secondaryState 0→1 at the gate, then sets mission progress to required/required before Result."
                ),
                9f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(2), dp(4), dp(8)) },
            subLp()
        )
        towerTestCard.addView(
            button(
                if (towerPumpLabRunning) tr("ปิด Tower Auto Pass", "Stop Tower Auto Pass")
                else tr("เปิด Tower Auto Pass", "Start Tower Auto Pass"),
                false
            ) {
                runTowerPumpAutoPassToggle()
            },
            subLp().apply { height = dp(42) }
        )
        towerTestCard.addView(
            txt(
                tr(
                    "V1.9 ห้ามใช้ Game Speed กับ Tower • Mission จะถูกแตะเฉพาะตอนถึงประตูเท่านั้น • Type 0 ใช้ exact-stat game-thread route, Type 1/2 ใช้ typed source exact requiredValue • ไม่เขียน totalStar / bestStage / completedFlag / pendingCommit โดยตรง",
                    "V1.9 never uses Game Speed for Tower. Mission progress is changed only at the gate. Type 0 uses the exact-stat game-thread route; Types 1/2 use the typed source exact requiredValue. totalStar, bestStage, completedFlag, and pendingCommit are never written directly."
                ),
                8.5f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(7), dp(4), dp(2)) },
            subLp()
        )
        root.addView(towerTestCard, itemLp())

        root.addView(
            pageTitle(
                "11 • AUTO LAB",
                tr(
                    "Play #2 Entry • PRE_RUN Object Locator",
                    "Play #2 Entry • PRE_RUN Object Locator"
                )
            )
        )

        root.addView(section("11.1 • AUTO A2 • จุดเข้า PLAY #2"), sectionLp())
        val workflowCard = featureCard()
        workflowCard.addView(
            txt(
                "PRE_RUN OBJECT LOCATOR  •  V6 ADAPTIVE / NO CODE HOOK",
                9f,
                "#A78BFA"
            ).apply {
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(4), dp(2), dp(4), dp(4))
            },
            subLp()
        )
        workflowCard.addView(
            txt(
                tr(
                    "Flow: PREPARE → กด Play #1 → LOCATE screenBase → Code Play #2 → RUN_STARTED",
                    "Flow: PREPARE → press Play #1 → LOCATE screenBase → Code Play #2 → RUN_STARTED"
                ),
                9f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(1), dp(4), dp(8)) },
            subLp()
        )

        autoA2EasyStatusView = txt(
            autoA2EasyStatusText,
            11f,
            when (autoA2LabPhase) {
                AutoA2LabPhase.PASS -> "#4ADE80"
                AutoA2LabPhase.FAILED -> "#FB7185"
                AutoA2LabPhase.READY_FOR_PLAY1 -> "#FACC15"
                else -> "#E5E7EB"
            }
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        workflowCard.addView(autoA2EasyStatusView, subLp())

        workflowCard.addView(
            button(tr("AUTO A2 • NEXT", "AUTO A2 • NEXT"), true) {
                runAutoA2EasyStep()
            },
            subLp().apply { topMargin = dp(10) }
        )

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(
            button(tr("เริ่มทดสอบใหม่", "Reset Test"), false) {
                resetAutoA2LabTest()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        actionRow.addView(
            button(tr("คัดลอกรายงาน", "Copy Report"), false) {
                copyDevLog()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        workflowCard.addView(actionRow, subLp().apply { topMargin = dp(8) })
        root.addView(workflowCard, itemLp())

        root.addView(section("11.2 • ผลล่าสุด"), sectionLp())
        val resultCard = featureCard()
        nativePlay2ProbeView = txt(
            nativePlay2ProbeText,
            9f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        resultCard.addView(nativePlay2ProbeView, subLp())
        root.addView(resultCard, itemLp())

        root.addView(section("11.3 • ข้อมูลเทคนิค"), sectionLp())
        val techCard = featureCard()
        autoA2TechnicalView = txt(
            autoA2TechnicalText,
            9f,
            "#94A3B8"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(6), dp(6), dp(6), dp(8))
        }
        techCard.addView(autoA2TechnicalView, subLp())

        nativeEffectLabLogView = txt(
            autoA2FilteredLog(120).ifBlank { "ยังไม่มี AUTO A2 log" },
            8.5f,
            "#9CA3AF"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            visibility = if (autoA2TechLogVisible) View.VISIBLE else View.GONE
            setPadding(dp(6), dp(8), dp(6), dp(6))
        }
        techCard.addView(nativeEffectLabLogView, subLp())
        techCard.addView(
            button(
                if (autoA2TechLogVisible) tr("ซ่อน Technical Log", "Hide Technical Log")
                else tr("แสดง Technical Log", "Show Technical Log"),
                false
            ) {
                autoA2TechLogVisible = !autoA2TechLogVisible
                renderTab(false)
            },
            subLp().apply { topMargin = dp(8) }
        )
        root.addView(techCard, itemLp())
    }

    private fun devGiantSuper(root: LinearLayout) {
        if (!BuildConfig.INTERNAL_BUILD || !::giantSuperDev.isInitialized) return

        buildUpdateDevSectionViews.clear()

        // 00 • RUNTIME AUTO FINDER — independent from every Secure Profile.
        if (::buildUpdateDev.isInitialized) {
            root.addView(section("00 • ระบบค้นหา Runtime อัตโนมัติ"), sectionLp())
            val runtimeCard = featureCard()
            runtimeCard.addView(
                txt(
                    "หา Root / CookieRun / libgame / load bias / StageService / Character เองจาก process จริง • ไม่ต้องเปิด f06 หรือ MOD ตัวอื่นก่อน",
                    9f,
                    "#8F9AAC"
                ),
                subLp()
            )
            val runtimeStatus = txt(
                "พร้อม • กดค้นหา Runtime ได้เลย",
                8.8f,
                "#C8D0DC"
            ).apply {
                typeface = Typeface.MONOSPACE
                setTextIsSelectable(true)
                setPadding(dp(4), dp(7), dp(4), dp(7))
            }
            buildUpdateDevSectionViews["00"] = runtimeStatus
            runtimeCard.addView(runtimeStatus, subLp().apply { topMargin = dp(7) })
            runtimeCard.addView(
                button("ค้นหา Runtime อัตโนมัติ", true) {
                    devBuildFinderRun("00", "กำลังค้นหา Runtime…") {
                        buildUpdateDev.probeShared(::onBuildUpdateDevResult)
                    }
                },
                subLp().apply { topMargin = dp(8) }
            )
            root.addView(runtimeCard, itemLp())
        }

        // 01 • GIANT
        root.addView(section("01 • ตัวใหญ่ (GIANT)"), sectionLp())
        val giantCard = featureCard()
        giantCard.addView(
            txt(
                "ตรวจค่า Giant ของ Build ใหม่ • Probe / จับจาก Giant ของจริง / ทดสอบ ON-OFF แยกเฉพาะ Giant",
                9f,
                "#8F9AAC"
            ),
            subLp()
        )
        giantSuperDevView = txt(
            giantSuperDev.reportText(),
            8.8f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(4), dp(7), dp(4), dp(7))
        }
        giantCard.addView(giantSuperDevView, subLp())
        giantSuperDevView?.let { buildUpdateDevSectionViews["01"] = it }

        val giantProbeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        giantProbeRow.addView(
            button("ตรวจ Runtime", false) {
                devBuildFinderRun("01", "Giant • กำลังตรวจ Runtime…") {
                    buildUpdateDev.probeShared(::onBuildUpdateDevResult)
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        giantProbeRow.addView(
            button("จับ Giant จากเกมจริง", true) {
                devBuildFinderRun("01", "Giant • กำลังเตรียม Natural Capture…") {
                    buildUpdateDev.armEffectCapture(5, "Giant", ::onBuildUpdateDevResult)
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        giantCard.addView(giantProbeRow, subLp().apply { topMargin = dp(8) })

        val giantToggleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        giantToggleRow.addView(
            button("เปิด Giant", true) { setNativeManualEnabled(CrgProfile.FEATURE_GIANT, true) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        giantToggleRow.addView(
            button("ปิด Giant", false) { setNativeManualEnabled(CrgProfile.FEATURE_GIANT, false) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        giantCard.addView(giantToggleRow, subLp().apply { topMargin = dp(7) })
        giantCard.addView(
            button("หยุดการจับ Giant / คืนสถานะ", false) {
                giantSuperDev.stopCapture { result ->
                    handler.post {
                        giantSuperDevView?.text = result.report
                        superDevView?.text = result.report
                        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    }
                }
            },
            subLp().apply { topMargin = dp(7) }
        )
        val giantLogRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        giantLogRow.addView(
            button("คัดลอกรายงาน", false) { copyGiantSuperDevLog() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        giantLogRow.addView(
            button("ล้างรายงาน", false) { clearGiantSuperDevLog() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        giantCard.addView(giantLogRow, subLp().apply { topMargin = dp(7) })
        root.addView(giantCard, itemLp())

        // 02 • SUPER
        root.addView(section("02 • วิ่งเร็ว (SUPER)"), sectionLp())
        val superCard = featureCard()
        superCard.addView(
            txt(
                "ตรวจค่า Super ของ Build ใหม่ • Probe / จับจาก Super ของจริง / ทดสอบ ON-OFF แยกเฉพาะ Super",
                9f,
                "#8F9AAC"
            ),
            subLp()
        )
        superDevView = txt(
            giantSuperDev.reportText(),
            8.8f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(4), dp(7), dp(4), dp(7))
        }
        superCard.addView(superDevView, subLp())
        superDevView?.let { buildUpdateDevSectionViews["02"] = it }

        val superProbeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        superProbeRow.addView(
            button("ตรวจ Runtime", false) {
                devBuildFinderRun("02", "Super • กำลังตรวจ Runtime…") {
                    buildUpdateDev.probeShared(::onBuildUpdateDevResult)
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        superProbeRow.addView(
            button("จับ Super จากเกมจริง", true) {
                devBuildFinderRun("02", "Super • กำลังเตรียม Natural Capture…") {
                    buildUpdateDev.armEffectCapture(7, "Super", ::onBuildUpdateDevResult)
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        superCard.addView(superProbeRow, subLp().apply { topMargin = dp(8) })

        val superToggleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        superToggleRow.addView(
            button("เปิด Super", true) { setNativeManualEnabled(CrgProfile.FEATURE_SUPER, true) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        superToggleRow.addView(
            button("ปิด Super", false) { setNativeManualEnabled(CrgProfile.FEATURE_SUPER, false) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        superCard.addView(superToggleRow, subLp().apply { topMargin = dp(7) })
        superCard.addView(
            button("หยุดการจับ Super / คืนสถานะ", false) {
                giantSuperDev.stopCapture { result ->
                    handler.post {
                        giantSuperDevView?.text = result.report
                        superDevView?.text = result.report
                        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    }
                }
            },
            subLp().apply { topMargin = dp(7) }
        )
        val superLogRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        superLogRow.addView(
            button("คัดลอกรายงาน", false) { copyGiantSuperDevLog() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        superLogRow.addView(
            button("ล้างรายงาน", false) { clearGiantSuperDevLog() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        superCard.addView(superLogRow, subLp().apply { topMargin = dp(7) })
        root.addView(superCard, itemLp())

        // 03 • GIANT SIZE
        // Stable DEV control only. The old Candidate Finder API was removed
        // from NativeEffectMod; use the existing Fast Lock backend instead.
        root.addView(section("03 • ขนาด Giant (GIANT SIZE)"), sectionLp())
        val sizeDevCard = featureCard()
        sizeDevCard.addView(
            txt(
                "ใช้เมื่อ Giant ACTIVE แล้ว • ใช้ Fast Lock ตัวที่ผ่านแล้ว • ปิดแล้วหยุด Lock ทันที",
                9f,
                "#8F9AAC"
            ),
            subLp()
        )
        giantSizeDevView = txt(
            nativeEffectMod.devGiantSizeFastLockStatusText(),
            8.8f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(4), dp(8), dp(4), dp(4))
        }
        sizeDevCard.addView(giantSizeDevView, subLp().apply { topMargin = dp(6) })

        sizeDevCard.addView(txt("ขนาดเพิ่มจากค่า Giant ปกติ", 9f, "#94A3B8"), subLp().apply { topMargin = dp(8) })
        val percentRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(10, 30, 50).forEachIndexed { index, percent ->
            percentRow.addView(
                button("+$percent%", percent == 30) {
                    val result = nativeEffectMod.devGiantSizeFastLockSetPercent(percent)
                    giantSizeDevView?.text = nativeEffectMod.devGiantSizeFastLockStatusText()
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                    if (index > 0) marginStart = dp(4)
                    if (index < 2) marginEnd = dp(4)
                }
            )
        }
        sizeDevCard.addView(percentRow, subLp().apply { topMargin = dp(4) })

        val sizeToggleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sizeToggleRow.addView(
            button("เปิด Giant Size", true) {
                nativeEffectMod.devGiantSizeFastLockEnable(30) { result ->
                    handler.post {
                        giantSizeDevView?.text = nativeEffectMod.devGiantSizeFastLockStatusText()
                        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    }
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        sizeToggleRow.addView(
            button("ปิด Giant Size", false) {
                nativeEffectMod.devGiantSizeFastLockDisable { result ->
                    handler.post {
                        giantSizeDevView?.text = nativeEffectMod.devGiantSizeFastLockStatusText()
                        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    }
                }
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        sizeDevCard.addView(sizeToggleRow, subLp().apply { topMargin = dp(8) })
        root.addView(sizeDevCard, itemLp())

        giantSuperRegressionView = txt(giantSuperRegressionText(), 9f, "#94A3B8")
    }

    private fun devBuildUpdateFinder(root: LinearLayout) {
        if (!BuildConfig.INTERNAL_BUILD || !::buildUpdateDev.isInitialized) return

        fun singleActionSection(
            sectionKey: String,
            sectionTitle: String,
            description: String,
            buttonTitle: String,
            action: () -> Unit,
            extraButtonTitle: String? = null,
            extraAction: (() -> Unit)? = null
        ) {
            root.addView(section(sectionTitle), sectionLp())
            val card = featureCard()
            card.addView(txt(description, 9f, "#8F9AAC"), subLp())
            val statusView = txt(
                "พร้อม • ยังไม่ได้เริ่มตรวจ",
                8.8f,
                "#C8D0DC"
            ).apply {
                typeface = Typeface.MONOSPACE
                setTextIsSelectable(true)
                setPadding(dp(4), dp(7), dp(4), dp(7))
            }
            buildUpdateDevSectionViews[sectionKey] = statusView
            card.addView(statusView, subLp().apply { topMargin = dp(7) })

            if (extraButtonTitle == null || extraAction == null) {
                card.addView(
                    button(buttonTitle, false) {
                        devBuildFinderRun(sectionKey, "$sectionTitle • กำลังทำงาน…", action)
                    },
                    subLp().apply { topMargin = dp(8) }
                )
            } else {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(
                    button(buttonTitle, false) {
                        devBuildFinderRun(sectionKey, "$sectionTitle • กำลังทำงาน…", action)
                    },
                    LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
                )
                row.addView(
                    button(extraButtonTitle, false) {
                        buildUpdateDevActiveSection = sectionKey
                        extraAction()
                    },
                    LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
                )
                card.addView(row, subLp().apply { topMargin = dp(8) })
            }
            root.addView(card, itemLp())
        }

        singleActionSection(
            "04",
            "04 • Power+ (f05)",
            "หา GameEvent / MysteryBox / native family ของ Power+ ใน Build ใหม่ • READ ONLY",
            "ตรวจ Power+",
            { buildUpdateDev.probePowerPlus(::onBuildUpdateDevResult) }
        )

        singleActionSection(
            "05",
            "05 • XP / เหรียญ (f06)",
            "ตรวจ Runtime/โครงสร้างที่ XP และเหรียญใช้ • Feature นี้ไม่ใช่ Anchor ของ DEV ตัวอื่นแล้ว",
            "ตรวจ Runtime กลาง",
            { buildUpdateDev.probeShared(::onBuildUpdateDevResult) }
        )

        singleActionSection(
            "06",
            "06 • Potato (f07)",
            "หา Potato object / vtable / passive vector ของ Build ใหม่ • ส่วน Continuous Coin hook ต้องยืนยันแยกก่อนใช้งานจริง",
            "ตรวจ Potato",
            { buildUpdateDev.probePotato(::onBuildUpdateDevResult) }
        )

        singleActionSection(
            "07",
            "07 • ความเร็วพื้นฐานคุกกี้ (f08)",
            "สแกนตำแหน่ง Base Speed ใหม่รอบ Character • READ ONLY • ไม่เขียนค่าความเร็ว",
            "สแกน Base Speed",
            { buildUpdateDev.scanBaseSpeed(::onBuildUpdateDevResult) }
        )

        singleActionSection(
            "08",
            "08 • ยกจากหลุม / ชุบชีวิต (f09)",
            "กดเริ่มจับ แล้วใช้ Pit Lift หรือ Revive ของจริง 1 ครั้ง • Finder จะหา recovery list / subtype ของ Build ใหม่",
            "เริ่มจับ Pit / Revive",
            { buildUpdateDev.armRecoveryCapture(::onBuildUpdateDevResult) },
            "หยุดการจับ",
            { buildUpdateDev.stop(::onBuildUpdateDevResult) }
        )

        singleActionSection(
            "09",
            "09 • กระโดดไม่จำกัด (f10)",
            "ยืนบนพื้น → เริ่มจับ → Jump #1 → Jump #2 • Finder จะหา action singleton และ vtable ใหม่",
            "เริ่มจับ Jump",
            { buildUpdateDev.armJumpCapture(::onBuildUpdateDevResult) },
            "หยุดการจับ",
            { buildUpdateDev.stop(::onBuildUpdateDevResult) }
        )

        root.addView(section("10 • รายงาน BUILD UPDATE"), sectionLp())
        val reportCard = featureCard()
        reportCard.addView(
            txt(
                "ผลล่าสุดจาก f05-f10 • คัดลอก Report ส่งมาได้ทันที • Finder ชุดนี้ไม่ patch เกม",
                9f,
                "#8F9AAC"
            ),
            subLp()
        )
        buildUpdateDevView = txt(
            buildUpdateDev.reportText(),
            8.8f,
            "#C8D0DC"
        ).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        reportCard.addView(buildUpdateDevView, subLp())

        val controlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controlRow.addView(
            button("หยุด Finder ทั้งหมด", false) { buildUpdateDev.stop(::onBuildUpdateDevResult) },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }
        )
        controlRow.addView(
            button("คัดลอกรายงาน", false) { copyBuildUpdateDevReport() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) }
        )
        reportCard.addView(controlRow, subLp().apply { topMargin = dp(8) })
        root.addView(reportCard, itemLp())
    }

    private fun devBuildFinderRun(sectionKey: String, startMessage: String, action: () -> Unit) {
        if (!BuildConfig.INTERNAL_BUILD || !::buildUpdateDev.isInitialized) return
        buildUpdateDevActiveSection = sectionKey
        buildUpdateDevSectionViews[sectionKey]?.text = "status=START\n$startMessage"
        buildUpdateDevView?.text = "status=START\n$startMessage"
        Toast.makeText(this, startMessage, Toast.LENGTH_SHORT).show()

        // Finder ทำ Runtime self-discovery เอง และทุก action จะยกเลิกงานค้นหา
        // เก่าที่ยังค้างอยู่ก่อนเริ่มงานใหม่ จึงไม่เกิดอาการกดปุ่มแล้วเงียบ
        // เพราะ queue ติดอยู่กับ scan ก่อนหน้า.
        action()
    }

    private fun onBuildUpdateDevResult(result: BuildUpdateDevFinder.Result) {
        handler.post {
            val text = result.report.ifBlank { buildUpdateDev.reportText() }
            buildUpdateDevSectionViews[buildUpdateDevActiveSection]?.text = text
            buildUpdateDevView?.text = text
            Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyBuildUpdateDevReport() {
        if (!BuildConfig.INTERNAL_BUILD || !::buildUpdateDev.isInitialized) return
        val text = buildString {
            appendLine("=== M WOIF LAB • BUILD UPDATE REPORT ===")
            appendLine("status=${buildUpdateDev.statusText()}")
            append(buildUpdateDev.reportText())
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("M Woif Build Update DEV", text))
        Toast.makeText(this, "คัดลอก Build Update Report แล้ว", Toast.LENGTH_SHORT).show()
    }

    private fun devProbeNativeEffect(featureId: String) {
        if (!BuildConfig.INTERNAL_BUILD || !::giantSuperDev.isInitialized) return

        withNativeProfile(featureId) { profile, error ->
            if (profile == null) {
                handler.post {
                    Toast.makeText(
                        this,
                        error ?: "Secure Profile ยังไม่พร้อม",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@withNativeProfile
            }

            giantSuperDev.cacheProfile(profile)
            giantSuperDev.probeAsync(featureId) { result ->
                handler.post {
                    giantSuperDevView?.text = result.report
                    superDevView?.text = result.report
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun devArmNativeCapture(featureId: String) {
        if (!BuildConfig.INTERNAL_BUILD || !::giantSuperDev.isInitialized) return

        withNativeProfile(featureId) { profile, error ->
            if (profile == null) {
                handler.post {
                    Toast.makeText(
                        this,
                        error ?: "Secure Profile ยังไม่พร้อม",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@withNativeProfile
            }

            giantSuperDev.armCapture(profile) { result ->
                handler.post {
                    giantSuperDevView?.text = result.report
                    superDevView?.text = result.report
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun giantSuperRegressionText(): String = buildString {
        appendLine("Giant: ${if (giantOn) "ON" else "OFF"} • $giantStatusText")
        append("Super: ${if (superOn) "ON" else "OFF"} • $superStatusText")
    }

    private fun copyGiantSuperDevLog() {
        if (!BuildConfig.INTERNAL_BUILD || !::giantSuperDev.isInitialized) return

        val text = buildString {
            appendLine("=== M WOIF LAB • GIANT / SUPER UPDATE REPORT ===")
            appendLine("status=${giantSuperDev.statusText()}")
            appendLine("--- FINDER ---")
            appendLine(giantSuperDev.reportText())
            appendLine("--- REGRESSION ---")
            appendLine(giantSuperRegressionText())
            appendLine("--- GIANT SIZE FINDER ---")
            append(nativeEffectMod.devGiantSizeFastLockStatusText())
        }

        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif Giant Super DEV", text)
        )

        Toast.makeText(this, "คัดลอกรายงาน Giant / Super แล้ว", Toast.LENGTH_SHORT).show()
    }

    private fun clearGiantSuperDevLog() {
        if (!BuildConfig.INTERNAL_BUILD || !::giantSuperDev.isInitialized) return

        giantSuperDev.clearReport()
        giantSuperDevView?.text = giantSuperDev.reportText()
        superDevView?.text = giantSuperDev.reportText()
        giantSuperRegressionView?.text = giantSuperRegressionText()
        giantSizeDevView?.text = nativeEffectMod.devGiantSizeFastLockStatusText()
        Toast.makeText(this, "ล้างรายงาน Giant / Super แล้ว", Toast.LENGTH_SHORT).show()
    }

    private fun updateDevViews() {
        if (!BuildConfig.INTERNAL_BUILD) return
        if (::giantSuperDev.isInitialized) {
            giantSuperDevView?.text = giantSuperDev.reportText()
            superDevView?.text = giantSuperDev.reportText()
            giantSuperRegressionView?.text = giantSuperRegressionText()
        }
        giantSizeDevView?.text = nativeEffectMod.devGiantSizeFastLockStatusText()
        nativePlay2ProbeView?.text = nativePlay2ProbeText
        autoA2EasyStatusView?.text = autoA2EasyStatusText
        autoA2EasyStatusView?.setTextColor(
            Color.parseColor(
                when (autoA2LabPhase) {
                    AutoA2LabPhase.PASS -> "#4ADE80"
                    AutoA2LabPhase.FAILED -> "#FB7185"
                    AutoA2LabPhase.READY_FOR_PLAY1 -> "#FACC15"
                    else -> "#E5E7EB"
                }
            )
        )
        autoA2TechnicalView?.text = autoA2TechnicalText
        nativeEffectLabLogView?.text = autoA2FilteredLog(120).ifBlank { "ยังไม่มี AUTO A2 log" }
        nativeEffectLabLogView?.visibility = if (autoA2TechLogVisible) View.VISIBLE else View.GONE
    }

    private fun autoA2LocatorMatches(text: String): Long? =
        Regex("matches=(\\d+)").find(text)?.groupValues?.getOrNull(1)?.toLongOrNull()

    private fun autoA2LocatorScreen(text: String): String =
        Regex("screenBase=(0x[0-9A-Fa-f]+)").find(text)?.groupValues?.getOrNull(1) ?: "0x0"

    private fun autoA2LocatorPrimaryHits(text: String): Long? =
        Regex("primaryHits=(\\d+)").find(text)?.groupValues?.getOrNull(1)?.toLongOrNull()

    private fun autoA2LocatorBest(text: String): String =
        Regex("best=(\\d+/6)").find(text)?.groupValues?.getOrNull(1) ?: "0/6"

    private fun autoA2LocatorMode(text: String): String =
        Regex("mode=([A-Z0-9_]+)").find(text)?.groupValues?.getOrNull(1) ?: "NONE"

    private fun autoA2FilteredLog(limit: Int): String {
        val lines = DevConsole.text(maxOf(limit * 4, 200)).lineSequence()
            .filter { line ->
                line.contains("[AUTO-A2]") ||
                    line.contains("[IP]") ||
                    line.contains("[APP]")
            }
            .toList()
        return lines.takeLast(limit).joinToString("\n")
    }

    private fun resetAutoA2LabTest() {
        autoA2LabPhase = AutoA2LabPhase.IDLE
        autoA2EasyStatusText = "READY\nกด AUTO A2 • NEXT เพื่อเตรียม PRE_RUN Locator"
        autoA2TechnicalText = "Bridge / PRE_RUN Locator ยังไม่ได้ตรวจ"
        nativePlay2ProbeText = "ยังไม่มีผล Code Play #2"
        DevConsole.log("AUTO-A2", "LAB test reset")
        updateDevViews()
    }

    private fun runAutoA2EasyStep() {
        if (!BuildConfig.INTERNAL_BUILD) return

        when (autoA2LabPhase) {
            AutoA2LabPhase.PASS -> {
                Toast.makeText(this, tr("AUTO A2 ผ่านแล้ว", "AUTO A2 already passed"), Toast.LENGTH_SHORT).show()
                return
            }
            AutoA2LabPhase.PREPARING,
            AutoA2LabPhase.LOCATING,
            AutoA2LabPhase.TRIGGERING -> return
            AutoA2LabPhase.READY_FOR_PLAY1 -> locateAutoA2PreRunObject()
            AutoA2LabPhase.IDLE,
            AutoA2LabPhase.FAILED -> prepareAutoA2Locator()
        }
    }

    private fun prepareAutoA2Locator() {
        autoA2LabPhase = AutoA2LabPhase.PREPARING
        autoA2EasyStatusText = "PREPARING...\nกำลังตรวจ Bridge และ PRE_RUN Locator profile"
        autoA2TechnicalText = "กำลังตรวจ Bridge / game-thread / native locator"
        nativePlay2ProbeText = "รอ PRE_RUN object หลัง Play #1"
        updateDevViews()

        Thread({
            val ping = InProcessGameControl.ping(this, 3000L)
            if (!ping.ok) {
                handler.post {
                    autoA2LabPhase = AutoA2LabPhase.FAILED
                    autoA2EasyStatusText = "PREPARE FAILED\n${ping.message}"
                    autoA2TechnicalText = ping.message
                    updateDevViews()
                }
                return@Thread
            }

            val arm = InProcessGameControl.preparePlay2Locator(this, 5000L)
            handler.post {
                autoA2TechnicalText = buildString {
                    appendLine("Bridge: ${ping.message}")
                    append("Locator: ${arm.message}")
                }
                if (!arm.ok) {
                    autoA2LabPhase = AutoA2LabPhase.FAILED
                    autoA2EasyStatusText = "PREPARE FAILED\n${arm.message}"
                    Toast.makeText(this, tr("PRE_RUN Locator เตรียมไม่สำเร็จ", "PRE_RUN Locator prepare failed"), Toast.LENGTH_LONG).show()
                } else {
                    autoA2LabPhase = AutoA2LabPhase.READY_FOR_PLAY1
                    autoA2EasyStatusText = buildString {
                        appendLine("STEP 1/3 • LOCATOR READY")
                        appendLine("1. กลับเกม แล้วกด Play #1 หนึ่งครั้ง")
                        appendLine("2. ห้ามกด Play #2")
                        append("3. กลับ DEV แล้วกด AUTO A2 • NEXT เพื่อ Locate")
                    }
                    Toast.makeText(this, tr("Locator พร้อม • ไปกด Play #1", "Locator ready • press Play #1"), Toast.LENGTH_LONG).show()
                }
                updateDevViews()
            }
        }, "woif-auto-a2-arm").start()
    }

    private fun locateAutoA2PreRunObject() {
        autoA2LabPhase = AutoA2LabPhase.LOCATING
        autoA2EasyStatusText = "STEP 2/3 • LOCATING\nกำลังค้นหา PRE_RUN screen object แบบ Adaptive ..."
        updateDevViews()

        Thread({
            val status = InProcessGameControl.locatePlay2PreRunObject(this, 6000L)
            val matches = autoA2LocatorMatches(status.message) ?: 0L
            val primaryHits = autoA2LocatorPrimaryHits(status.message) ?: 0L
            val best = autoA2LocatorBest(status.message)
            val mode = autoA2LocatorMode(status.message)
            val screen = autoA2LocatorScreen(status.message)

            handler.post {
                autoA2TechnicalText = status.message
                if (!status.ok || screen == "0x0") {
                    autoA2LabPhase = AutoA2LabPhase.FAILED
                    autoA2EasyStatusText = buildString {
                        appendLine("PRE_RUN LOCATOR FAILED")
                        appendLine("Play #1 ผ่านแล้ว แต่ยังระบุ screenBase แบบ unique ไม่ได้")
                        appendLine("matches=$matches • primaryHits=$primaryHits • best=$best")
                        appendLine("mode=$mode • screenBase=$screen")
                        append("ไม่ต้องกด Play #1 ซ้ำ • Copy Report ส่งผลนี้ได้เลย")
                    }
                    Toast.makeText(this, tr("Locator ยังหา PRE_RUN ไม่ได้", "PRE_RUN locator did not resolve"), Toast.LENGTH_LONG).show()
                    updateDevViews()
                    return@post
                }

                autoA2LabPhase = AutoA2LabPhase.TRIGGERING
                autoA2EasyStatusText = buildString {
                    appendLine("STEP 2/3 • PRE_RUN FOUND")
                    appendLine("screenBase=$screen • mode=$mode")
                    appendLine("matches=$matches • primaryHits=$primaryHits • best=$best")
                    append("STEP 3/3 • Resolver validation → Code Play #2 ...")
                }
                updateDevViews()
                runNativePlay2CodeTrigger()
            }
        }, "woif-auto-a2-verify").start()
    }

    private fun runNativePlay2CodeTrigger() {
        if (!BuildConfig.INTERNAL_BUILD) return

        autoA2LabPhase = AutoA2LabPhase.TRIGGERING
        nativePlay2ProbeText = "TRIGGERING • Code Play #2 ..."
        updateDevViews()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.NativePlay2CodeTriggerBackend")
                val method = cls.getMethod("trigger", Context::class.java)
                method.invoke(null, this)?.toString() ?: "AUTO A2 • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "AUTO A2 FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            result.lineSequence().take(80).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("AUTO-A2", line)
            }

            handler.post {
                nativePlay2ProbeText = result
                autoA2EasyStatusText = if (result.contains("status=RUN_STARTED")) {
                    autoA2LabPhase = AutoA2LabPhase.PASS
                    "PASS • RUN_STARTED\nAdaptive Locator → Resolver → Code Play #2 สำเร็จ"
                } else {
                    autoA2LabPhase = AutoA2LabPhase.FAILED
                    val bridgeLine = result.lineSequence()
                        .firstOrNull { it.startsWith("bridge=") }
                        ?.removePrefix("bridge=")
                        ?: "ดู LATEST RESULT"
                    "TRIGGER FAILED\n$bridgeLine"
                }
                Toast.makeText(
                    this,
                    if (result.contains("status=RUN_STARTED")) {
                        tr("Code Play #2 ผ่าน • RUN_STARTED", "Code Play #2 PASS • RUN_STARTED")
                    } else {
                        tr("AUTO A2 ยังไม่ผ่าน • ดูสถานะด้านบน", "AUTO A2 not passed • see status above")
                    },
                    Toast.LENGTH_SHORT
                ).show()
                updateDevViews()
            }
        }, "MWOIF-AUTO-A2-PLAY2").start()
    }

    private fun copyDevLog() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val text = buildString {
            appendLine("=== M WOIF LAB • AUTO A2 REPORT ===")
            appendLine("phase=${autoA2LabPhase.name}")
            appendLine("--- STATUS ---")
            appendLine(autoA2EasyStatusText)
            appendLine("--- TECHNICAL ---")
            appendLine(autoA2TechnicalText)
            appendLine("--- RESULT ---")
            appendLine(nativePlay2ProbeText)
            appendLine("--- AUTO A2 LOG ---")
            append(autoA2FilteredLog(300).ifBlank { "no AUTO A2 log" })
        }
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(ClipData.newPlainText("M Woif Lab AUTO A2 Report", text))
        Toast.makeText(this, tr("คัดลอก AUTO A2 Report แล้ว", "AUTO A2 report copied"), Toast.LENGTH_SHORT).show()
        DevConsole.log("AUTO-A2", "report copied (${text.lines().size} lines)")
        updateDevViews()
    }

    private fun setNativeManualEnabled(
        featureId: String,
        enable: Boolean
    ) {
        if (BuildConfig.INTERNAL_BUILD) DevConsole.log("UI", "$featureId toggle=${if (enable) "ON" else "OFF"}")
        if (autoMaster || !::nativeEffectMod.isInitialized) {
            return
        }

        if (
            enable &&
            !ControlPlaneState.isFeatureAllowed(featureId)
        ) {
            setNativeManualState(featureId, false)
            setNativeStatus(featureId, controlBlockedText(featureId))
            renderTab()
            return
        }

        if (!enable) {
            if (
                featureId == CrgProfile.FEATURE_GIANT &&
                ::nativeEffectMod.isInitialized &&
                nativeEffectMod.devGiantSizeFastLockIsEnabled()
            ) {
                giantSizeOn = false
                nativeEffectMod.devGiantSizeFastLockDisable { result ->
                    handler.post {
                        giantSizeStatusText = result.message
                    }
                }
            }

            setNativeManualState(featureId, false)
            setNativeStatus(
                featureId,
                tr("กำลังปิด...", "Disabling...")
            )

            nativeEffectMod.disable(featureId) { result ->
                handler.post {
                    setNativeStatus(
                        featureId,
                        nativeEffectResultText(featureId, result)
                    )
                    if (activeTab == Tab.PLAY && menuVisible) {
                        renderTab()
                    }
                }
            }
            return
        }

        setNativeStatus(
            featureId,
            tr("กำลังโหลด Secure Profile...", "Loading Secure Profile...")
        )
        renderTab()

        withNativeProfile(featureId) { profile, errorText ->
            handler.post {
                if (profile == null) {
                    setNativeManualState(featureId, false)
                    setNativeStatus(
                        featureId,
                        errorText ?: tr(
                            "Secure Profile ยังไม่พร้อม",
                            "Secure Profile is not ready"
                        )
                    )
                    if (activeTab == Tab.PLAY && menuVisible) {
                        renderTab()
                    }
                    return@post
                }

                setNativeStatus(
                    featureId,
                    tr("กำลังเปิด Native effect...", "Enabling native effect...")
                )

                nativeEffectMod.enable(profile) { result ->
                    handler.post inner@{
                        setNativeManualState(featureId, nativeEffectMod.isEnabled(featureId))
                        setNativeStatus(
                            featureId,
                            nativeEffectResultText(featureId, result)
                        )
                        if (activeTab == Tab.PLAY && menuVisible) {
                            renderTab()
                        }
                    }
                }
            }
        }
    }

    private fun setNativeAutoEnabled(
        featureId: String,
        enable: Boolean
    ) {
        if (!::nativeEffectMod.isInitialized) {
            return
        }

        if (
            enable &&
            !ControlPlaneState.isFeatureAllowed(featureId)
        ) {
            setNativeAutoOwned(featureId, false)
            setNativeStatus(featureId, controlBlockedText(featureId))
            return
        }

        if (!enable) {
            setNativeAutoOwned(featureId, false)
            nativeEffectMod.disable(featureId) { result ->
                handler.post {
                    setNativeStatus(
                        featureId,
                        nativeEffectResultText(featureId, result)
                    )
                }
            }
            return
        }

        withNativeProfile(featureId) { profile, errorText ->
            if (profile == null) {
                handler.post {
                    setNativeAutoOwned(featureId, false)
                    setNativeStatus(
                        featureId,
                        errorText ?: tr(
                            "Secure Profile ยังไม่พร้อม",
                            "Secure Profile is not ready"
                        )
                    )
                }
                return@withNativeProfile
            }

            nativeEffectMod.enable(profile) { result ->
                handler.post {
                    setNativeAutoOwned(featureId, nativeEffectMod.isEnabled(featureId))
                    setNativeStatus(
                        featureId,
                        nativeEffectResultText(featureId, result)
                    )
                }
            }
        }
    }

    private fun withNativeProfile(
        featureId: String,
        callback: (NativeEffectProfile?, String?) -> Unit
    ) {
        val current = when (featureId) {
            CrgProfile.FEATURE_GIANT -> SecureProfileManager.getGiant()
            CrgProfile.FEATURE_SUPER -> SecureProfileManager.getSuper()
            else -> null
        }

        if (current != null) {
            val cached = nativeEffectMod.cacheProfile(current)
            if (cached.ok) {
                callback(current, null)
            } else {
                callback(null, cached.message)
            }
            return
        }

        val completion: (SecureProfileManager.Result) -> Unit = { result ->
            val profile = when (featureId) {
                CrgProfile.FEATURE_GIANT -> SecureProfileManager.getGiant()
                CrgProfile.FEATURE_SUPER -> SecureProfileManager.getSuper()
                else -> null
            }

            if (result is SecureProfileManager.Result.Success && profile != null) {
                val cached = nativeEffectMod.cacheProfile(profile)
                if (cached.ok) {
                    callback(profile, null)
                } else {
                    callback(null, cached.message)
                }
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(
                    null,
                    secureNativeProfileStatus(
                        result,
                        tr("Secure Profile พร้อม", "Secure Profile ready")
                    )
                )
            } else {
                callback(
                    null,
                    tr(
                        "Secure Profile ยังไม่พร้อม",
                        "Secure Profile is not ready"
                    )
                )
            }
        }

        when (featureId) {
            CrgProfile.FEATURE_GIANT -> SecureProfileManager.preloadGiant(callback = completion)
            CrgProfile.FEATURE_SUPER -> SecureProfileManager.preloadSuper(callback = completion)
            else -> callback(null, "Unknown feature")
        }
    }

    private fun setNativeManualState(
        featureId: String,
        enabled: Boolean
    ) {
        when (featureId) {
            CrgProfile.FEATURE_GIANT -> giantOn = enabled
            CrgProfile.FEATURE_SUPER -> superOn = enabled
        }
    }

    private fun setNativeAutoOwned(
        featureId: String,
        enabled: Boolean
    ) {
        when (featureId) {
            CrgProfile.FEATURE_GIANT -> giantAutoOwned = enabled
            CrgProfile.FEATURE_SUPER -> superAutoOwned = enabled
        }
    }

    private fun setNativeStatus(
        featureId: String,
        value: String
    ) {
        when (featureId) {
            CrgProfile.FEATURE_GIANT -> giantStatusText = value
            CrgProfile.FEATURE_SUPER -> superStatusText = value
        }
    }

    private fun nativeEffectResultText(
        featureId: String,
        result: NativeEffectMod.ActionResult
    ): String {
        if (result.ok) {
            return result.message
        }

        return when (result.errorCode) {
            "ROOT_REQUIRED" -> tr(
                "M Woif ต้องได้รับสิทธิ์ Root ก่อน",
                "M Woif requires Root permission"
            )

            "GAME_NOT_RUNNING",
            "LIBGAME_NOT_READY" -> tr(
                "เปิด CookieRun แล้วลองใหม่",
                "Open CookieRun and try again"
            )

            "SIGNATURE_MISMATCH",
            "HOOK_SIGNATURE_MISMATCH",
            "CAVE_PROFILE_MISMATCH" -> tr(
                "Native Profile ไม่ตรงเกมเวอร์ชันนี้",
                "Native Profile does not match this game version"
            )

            "HOOK_CONFLICT" -> tr(
                "พบ MOD/Script อื่นแก้ Native hook อยู่",
                "Another MOD/Script is using the native hook"
            )

            "NATIVE_TIMEOUT" -> tr(
                "Native command timeout • ปิดคำสั่งแล้ว",
                "Native command timed out • Command cleared"
            )

            "NATIVE_LAYOUT_INVALID" -> tr(
                "Character/Effect layout ไม่ตรง profile",
                "Character/Effect layout does not match the profile"
            )

            "INPROCESS_BRIDGE_FAILED",
            "INPROCESS_PING_FAILED" -> tr(
                "In-Process bridge ยังไม่พร้อม • ตรวจ LSPosed Scope หรือ DEV > Diagnostics",
                "In-Process bridge is not ready • Check LSPosed scope or DEV > Diagnostics"
            )

            "INPROCESS_VERIFY_FAILED" -> tr(
                "In-Process call กลับมาแล้ว แต่ EffectManager ยังไม่เปลี่ยน • ดู DEV Log",
                "In-Process call returned but EffectManager did not change • see DEV Log"
            )

            else -> result.message
        }
    }

    private fun hpCard(): LinearLayout {

        val root =
            featureCard()

        val featureAllowed =
            ControlPlaneState.isFeatureAllowed(
                CrgProfile.FEATURE_HP
            )

        if (featureAllowed && ::hpMod.isInitialized) {
            hpStatusText =
                hpMod.statusText()
        } else if (!featureAllowed) {
            hpStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_HP
                )
        }

        /*
         * HP V2 UI: one switch only.
         * ON always means INFINITE / ไม่ตายเลย.
         * Timed modes remain supported internally for backward compatibility,
         * but are intentionally not exposed in the customer UI.
         */
        hpMode = "INFINITE"

        root.addView(
            featureHeader(
                tr("อมตะ", "HP Protection"),
                audienceText(
                    "ไม่ตายระหว่างเล่น • เปิดรอไว้ก่อนเข้า Stage ได้",
                    "Stay alive during play • Can be armed before entering a Stage",
                    "เปิดได้ทุกหน้า • เกม/Stage ใหม่ระบบจับและเปิดให้อัตโนมัติ",
                    "Enable anywhere • Auto rebind on new game/stage"
                ),
                hpOn,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { enabled ->

                setHpManualEnabled(
                    enabled
                )
            }
        )

        if (!featureAllowed) {
            root.addView(
                featureUpdatingHint(),
                subLp()
            )
        }

        addDiagnosticStatus(root, hpStatusText)

        return root
    }

    private fun setHpManualEnabled(
        enable:
        Boolean
    ) {

        if (
            autoMaster ||
            !::hpMod.isInitialized
        ) {
            return
        }

        if (
            enable &&
            !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_HP)
        ) {
            hpOn = false
            hpStatusText = controlBlockedText(CrgProfile.FEATURE_HP)
            renderTab()
            return
        }

        if (
            enable
        ) {

            hpMode = "INFINITE"

            hpStatusText =
                tr(
                    "กำลังเปิด HP...",
                    "Enabling HP..."
                )

            hpMod.enable(
                hpMode
            ) { result ->

                handler.post {

                    hpOn =
                        result.ok

                    hpStatusText =
                        if (
                            result.ok
                        ) {
                            result.message
                        } else {
                            hpErrorText(
                                result
                            )
                        }

                    if (
                        activeTab ==
                        Tab.PLAY &&
                        menuVisible
                    ) {
                        renderTab()
                    }
                }
            }

        } else {

            hpOn =
                false

            hpMod.disable { result ->

                handler.post {

                    hpStatusText =
                        if (
                            result.ok
                        ) {
                            result.message
                        } else {
                            hpErrorText(
                                result
                            )
                        }

                    if (
                        activeTab ==
                        Tab.PLAY &&
                        menuVisible
                    ) {
                        renderTab()
                    }
                }
            }
        }
    }

    private fun setHpAutoEnabled(
        enable:
        Boolean
    ) {

        if (
            !::hpMod.isInitialized
        ) {
            return
        }

        if (
            enable &&
            !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_HP)
        ) {
            hpAutoOwned = false
            hpStatusText = controlBlockedText(CrgProfile.FEATURE_HP)
            return
        }

        hpAutoOwned =
            enable

        if (
            enable
        ) {

            hpMode = "INFINITE"

            hpMod.enable(
                hpMode
            ) { result ->

                handler.post {

                    hpAutoOwned =
                        result.ok

                    hpStatusText =
                        if (
                            result.ok
                        ) {
                            result.message
                        } else {
                            hpErrorText(
                                result
                            )
                        }
                }
            }

        } else {

            hpMod.disable { result ->

                handler.post {

                    hpAutoOwned =
                        false

                    hpStatusText =
                        if (
                            result.ok
                        ) {
                            result.message
                        } else {
                            hpErrorText(
                                result
                            )
                        }
                }
            }
        }
    }

    private fun hpErrorText(
        result:
        HpMod.ActionResult
    ): String {

        return when (
            result.errorCode
        ) {

            "ROOT_REQUIRED" ->
                tr(
                    "M Woif ต้องได้รับสิทธิ์ Root ก่อน",
                    "M Woif requires Root permission"
                )

            "PROFILE_NOT_READY" ->
                tr(
                    "Secure HP Profile ยังไม่พร้อม",
                    "Secure HP Profile is not ready"
                )

            "GAME_NOT_RUNNING",
            "LIBGAME_NOT_READY",
            "ELF_NOT_FOUND",
            "LOAD_BIAS_FAILED",
            "GLOBAL_FAILED",
            "GLOBAL_READ_FAILED" ->
                tr(
                    "HP ยังไม่พร้อม • เปิด CookieRun แล้วลองใหม่",
                    "HP is not ready • Open CookieRun and try again"
                )

            "RESTORE_FAILED" ->
                tr(
                    "HP Restore ยังไม่สำเร็จ",
                    "HP restore failed"
                )

            else ->
                result.message
        }
    }

    private fun speedCard(): LinearLayout {

        val root =
            featureCard()

        val featureAllowed =
            ControlPlaneState.isFeatureAllowed(
                CrgProfile.FEATURE_GAME_SPEED
            )

        if (
            featureAllowed &&
            ::gameSpeedMod.isInitialized
        ) {
            gameSpeedStatusText =
                gameSpeedMod.statusText()
        } else if (!featureAllowed) {
            gameSpeedStatusText =
                controlBlockedText(
                    CrgProfile.FEATURE_GAME_SPEED
                )
        }

        root.addView(
            featureHeader(
                tr(
                    "ความเร็วเกม",
                    "Game Speed"
                ),
                audienceText(
                    "ปรับความเร็วเกม • ตั้งค่าไว้แล้วเปิดหรือปิดได้ทันที",
                    "Adjust game speed • Set a value and toggle it anytime",
                    "เปิดได้ทุกหน้า • เกมเริ่มใหม่ระบบเชื่อม writer ให้อัตโนมัติ",
                    "Enable anywhere • Writer reconnects after game restart"
                ),
                if (autoMaster) speedAutoOwned else speedOn,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) {
                setGameSpeedEnabled(
                    it
                )
            }
        )

        root.addView(
            txt(
                tr(
                    "⚠ คำเตือน: Game Speed เปิดใช้งานได้ แต่ต้องระวังการตั้งค่าความเร็วสูง",
                    "⚠ Warning: Game Speed can be enabled, but use high speed values carefully"
                ),
                9f,
                "#FF4D5E",
                true
            ).apply {
                setPadding(dp(4), dp(8), dp(4), dp(2))
            },
            subLp()
        )

        if (!featureAllowed) {
            root.addView(
                featureUpdatingHint(),
                subLp()
            )

            addDiagnosticStatus(root, gameSpeedStatusText)

            return root
        }

        root.addView(
            label(
                tr(
                    "ความเร็ว",
                    "Speed"
                )
            ),
            subLp()
        )

        val presets =
            listOf(
                1,
                2,
                5,
                10,
                20,
                100,
                1000
            )

        root.addView(
            choices(
                presets.map {
                    "x$it"
                },
                presets.indexOf(
                    speed
                )
            ) { index ->

                speed =
                    presets[index]

                modSettingsStore.saveGameSpeed(speed)
                queueGameSpeedApply()

                renderTab()
            }
        )

        root.addView(
            slider(
                "1x",
                "1000x",
                speedToProgress(
                    speed
                ),
                1000,
                {
                    "x$speed"
                }
            ) { progress ->

                speed =
                    progressToSpeed(
                        progress
                    )

                modSettingsStore.saveGameSpeed(speed)
                queueGameSpeedApply()
            },
            subLp()
        )

        addDiagnosticStatus(root, gameSpeedStatusText)

        return root
    }

    private fun setGameSpeedEnabled(
        enabled: Boolean
    ) {

        if (autoMaster) return

        if (
            !::gameSpeedMod.isInitialized
        ) {
            return
        }

        if (
            enabled &&
            !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GAME_SPEED)
        ) {
            speedOn = false
            gameSpeedStatusText = controlBlockedText(CrgProfile.FEATURE_GAME_SPEED)
            renderTab()
            return
        }

        if (
            enabled
        ) {

            speedOn =
                true

            gameSpeedMod.enable(
                speed.toFloat()
            ) { result ->

                handler.post {

                    if (
                        result.ok
                    ) {

                        speedOn =
                            true

                        gameSpeedStatusText =
                            result.message

                    } else {

                        speedOn =
                            false

                        gameSpeedStatusText =
                            gameSpeedErrorText(
                                result
                            )
                    }

                    if (
                        activeTab ==
                        Tab.PLAY &&
                        menuVisible
                    ) {
                        renderTab()
                    }
                }
            }

        } else {

            speedOn =
                false

            gameSpeedMod.disable { result ->

                handler.post {

                    gameSpeedStatusText =
                        if (
                            !result.ok
                        ) {

                            tr(
                                "OFF แล้ว แต่ Restore x1 ไม่สำเร็จ: ${result.message}",
                                "OFF, but x1 restore failed: ${result.message}"
                            )

                        } else {

                            tr(
                                "OFF • Restore x1 ผ่าน",
                                "OFF • x1 restored"
                            )
                        }

                    if (
                        activeTab ==
                        Tab.PLAY &&
                        menuVisible
                    ) {
                        renderTab()
                    }
                }
            }
        }
    }

    private fun queueGameSpeedApply() {

        if (
            !speedOn ||
            !::gameSpeedMod.isInitialized ||
            !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GAME_SPEED)
        ) {
            return
        }

        speedApplyRunnable
            ?.let {
                handler.removeCallbacks(
                    it
                )
            }

        val runnable =
            Runnable {

                if (
                    !speedOn
                ) {
                    return@Runnable
                }

                gameSpeedMod.setSpeed(
                    speed.toFloat()
                ) { result ->

                    handler.post {

                        gameSpeedStatusText =
                            if (
                                result.ok
                            ) {
                                result.message
                            } else {
                                gameSpeedErrorText(
                                    result
                                )
                            }

                        if (
                            !result.ok
                        ) {
                            speedOn =
                                false
                        }

                        if (
                            activeTab ==
                            Tab.PLAY &&
                            menuVisible
                        ) {
                            renderTab()
                        }
                    }
                }
            }

        speedApplyRunnable =
            runnable

        handler.postDelayed(
            runnable,
            180L
        )
    }

    private fun gameSpeedErrorText(
        result:
        GameSpeedMod.ActionResult
    ): String {

        return when (
            result.errorCode
        ) {

            "ROOT_REQUIRED" ->
                tr(
                    "M Woif ต้องได้รับสิทธิ์ Root ก่อน",
                    "M Woif requires Root permission"
                )

            "RESOLVE_FAILED" ->
                tr(
                    "หา Game Speed ไม่เจอ • เปิดเกมถึง Lobby แล้วลองใหม่",
                    "Game Speed target not found • Reach the Lobby and try again"
                )

            "LOCK_START_FAILED",
            "LOCK_FAILED" ->
                tr(
                    "เปิด Game Speed writer ไม่สำเร็จ",
                    "Unable to start Game Speed writer"
                )

            "PROFILE_NOT_READY" ->
                tr(
                    "Secure Profile ยังไม่พร้อม",
                    "Secure Profile is not ready"
                )

            "WRITE_FAILED" ->
                tr(
                    "เขียน Game Speed ไม่สำเร็จ",
                    "Unable to write Game Speed"
                )

            "VERIFY_FAILED",
            "VERIFY_READ_FAILED" ->
                tr(
                    "Game Speed Verify ไม่ผ่าน",
                    "Game Speed verification failed"
                )

            "VALUE_RESET" ->
                result.message

            else ->
                result.message
        }
    }

    private fun withRunRewardProfile(
        callback: (RunRewardProfile?, String?) -> Unit
    ) {
        val current = SecureProfileManager.getRunReward()
        if (current != null) {
            val cached = runRewardMod.cacheProfile(current)
            if (cached.ok) callback(current, null)
            else callback(null, cached.message)
            return
        }

        SecureProfileManager.preloadRunReward { result ->
            val profile = SecureProfileManager.getRunReward()
            if (result is SecureProfileManager.Result.Success && profile != null) {
                val cached = runRewardMod.cacheProfile(profile)
                if (cached.ok) callback(profile, null)
                else callback(null, cached.message)
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(
                    null,
                    secureNativeProfileStatus(
                        result,
                        tr("XP/Coin พร้อม", "XP/Coin ready")
                    )
                )
            } else {
                callback(
                    null,
                    tr(
                        "Secure XP/Coin Profile ยังไม่พร้อม",
                        "Secure XP/Coin Profile is not ready"
                    )
                )
            }
        }
    }

    private fun setXpManualEnabled(enable: Boolean) {
        if (autoMaster || !::runRewardMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            xpOn = false
            xpStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            renderTab()
            return
        }

        if (!enable) {
            xpOn = false
            runRewardMod.setXpEnabled(false, xp) { result ->
                handler.post {
                    xpStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        xpStatusText = tr(
            "กำลังโหลด Secure XP/Coin Profile...",
            "Loading Secure XP/Coin Profile..."
        )
        renderTab()

        withRunRewardProfile { profile, errorText ->
            handler.post {
                if (profile == null) {
                    xpOn = false
                    xpStatusText = errorText ?: tr(
                        "Secure XP/Coin Profile ยังไม่พร้อม",
                        "Secure XP/Coin Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@post
                }

                runRewardMod.setXpEnabled(true, xp) { result ->
                    handler.post inner@{
                        xpOn = runRewardMod.isXpEnabled()
                        xpStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun setCoinManualEnabled(enable: Boolean) {
        if (autoMaster || !::runRewardMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            coinOn = false
            coinStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            renderTab()
            return
        }

        if (!enable) {
            coinOn = false
            runRewardMod.setCoinEnabled(false, coin) { result ->
                handler.post {
                    coinStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        coinStatusText = tr(
            "กำลังโหลด Secure XP/Coin Profile...",
            "Loading Secure XP/Coin Profile..."
        )
        renderTab()

        withRunRewardProfile { profile, errorText ->
            handler.post {
                if (profile == null) {
                    coinOn = false
                    coinStatusText = errorText ?: tr(
                        "Secure XP/Coin Profile ยังไม่พร้อม",
                        "Secure XP/Coin Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@post
                }

                runRewardMod.setCoinEnabled(true, coin) { result ->
                    handler.post inner@{
                        coinOn = runRewardMod.isCoinEnabled()
                        coinStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun setXpAutoEnabled(enable: Boolean) {
        if (!::runRewardMod.isInitialized) return

        if (!enable) {
            xpAutoOwned = false
            runRewardMod.setXpEnabled(false, xp) { result ->
                handler.post {
                    xpStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) renderTab()
                }
            }
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            xpAutoOwned = false
            autoSelected["XP"] = false
            xpStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            return
        }

        withRunRewardProfile { profile, errorText ->
            if (profile == null) {
                handler.post {
                    xpAutoOwned = false
                    xpStatusText = errorText ?: "Secure XP/Coin Profile ยังไม่พร้อม"
                }
                return@withRunRewardProfile
            }

            runRewardMod.setXpEnabled(true, xp) { result ->
                handler.post {
                    xpAutoOwned = runRewardMod.isXpEnabled()
                    xpStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) renderTab()
                }
            }
        }
    }

    private fun setCoinAutoEnabled(enable: Boolean) {
        if (!::runRewardMod.isInitialized) return

        if (!enable) {
            coinAutoOwned = false
            runRewardMod.setCoinEnabled(false, coin) { result ->
                handler.post {
                    coinStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) renderTab()
                }
            }
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            coinAutoOwned = false
            autoSelected["COIN"] = false
            coinStatusText = controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
            return
        }

        withRunRewardProfile { profile, errorText ->
            if (profile == null) {
                handler.post {
                    coinAutoOwned = false
                    coinStatusText = errorText ?: "Secure XP/Coin Profile ยังไม่พร้อม"
                }
                return@withRunRewardProfile
            }

            runRewardMod.setCoinEnabled(true, coin) { result ->
                handler.post {
                    coinAutoOwned = runRewardMod.isCoinEnabled()
                    coinStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) renderTab()
                }
            }
        }
    }

    private fun xpCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)
        val enabled = if (autoMaster) xpAutoOwned else xpOn

        root.addView(
            featureHeader(
                tr("XP / เลเวล", "XP"),
                audienceText(
                    "ตั้งค่า XP สำหรับ Stage • ปิดแล้วค่าใน Stage จะไม่ถูกรีเซ็ต",
                    "Set XP for the Stage • Turning it off does not reset the Stage value",
                    "ตั้งค่าได้ทุกหน้า • OFF ไม่คืน XP เป็น 0 • Stage ใหม่ค่อยทำงานใหม่",
                    "Can be armed anywhere • OFF never rolls XP back to 0 • Re-arms on a new Stage"
                ),
                enabled,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { setXpManualEnabled(it) }
        )

        if (!featureAllowed) root.addView(featureUpdatingHint(), subLp())

        val presets = listOf(0, 5000, 10000, 25000, 50000, 75000)

        root.addView(
            choices(presets.map { short(it) }, presets.indexOf(xp)) { i ->
                xp = presets[i]
                modSettingsStore.saveXp(xp)
                if (::runRewardMod.isInitialized && (xpOn || xpAutoOwned)) {
                    runRewardMod.updateXpValue(xp)
                }
                renderTab()
            },
            subLp()
        )

        root.addView(
            slider("0", "75K", xp / 500, 150, { number(xp) }) { p ->
                xp = (p * 500).coerceIn(0, 75_000)
                modSettingsStore.saveXp(xp)
                if (::runRewardMod.isInitialized && (xpOn || xpAutoOwned)) {
                    runRewardMod.updateXpValue(xp)
                }
            },
            subLp()
        )

        val liveStatus = if (
            featureAllowed && ::runRewardMod.isInitialized && (xpOn || xpAutoOwned)
        ) runRewardMod.xpStatusText() else xpStatusText

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
        )

        return root
    }

    private fun coinCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)
        val enabled = if (autoMaster) coinAutoOwned else coinOn

        root.addView(
            featureHeader(
                tr("เหรียญ", "Coin"),
                audienceText(
                    "ตั้งค่าเหรียญสำหรับ Stage • ปิดแล้วค่าใน Stage จะไม่ถูกรีเซ็ต",
                    "Set coins for the Stage • Turning it off does not reset the Stage value",
                    "ตั้งค่าได้ทุกหน้า • OFF ไม่คืน Coin เป็น 0 • Stage ใหม่ค่อยทำงานใหม่",
                    "Can be armed anywhere • OFF never rolls Coin back to 0 • Re-arms on a new Stage"
                ),
                enabled,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { setCoinManualEnabled(it) }
        )

        if (!featureAllowed) root.addView(featureUpdatingHint(), subLp())

        val presets = listOf(0, 100000, 200000, 300000, 400000, 440000)

        root.addView(
            choices(presets.map { short(it) }, presets.indexOf(coin)) { i ->
                coin = presets[i]
                modSettingsStore.saveCoin(coin)
                if (::runRewardMod.isInitialized && (coinOn || coinAutoOwned)) {
                    runRewardMod.updateCoinValue(coin)
                }
                renderTab()
            },
            subLp()
        )

        root.addView(
            slider("0", "440K", coin / 1000, 440, { number(coin) }) { p ->
                coin = (p * 1000).coerceIn(0, 440_000)
                modSettingsStore.saveCoin(coin)
                if (::runRewardMod.isInitialized && (coinOn || coinAutoOwned)) {
                    runRewardMod.updateCoinValue(coin)
                }
            },
            subLp()
        )

        val liveStatus = if (
            featureAllowed && ::runRewardMod.isInitialized && (coinOn || coinAutoOwned)
        ) runRewardMod.coinStatusText() else coinStatusText

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_RUN_REWARD)
        )

        return root
    }

    private fun withRecoveryProfile(
        callback: (RecoveryProfile?, String?) -> Unit
    ) {
        val current = SecureProfileManager.getRecovery()
        if (current != null) {
            val cached = recoveryMod.cacheProfile(current)
            if (cached.ok) callback(current, null)
            else callback(null, cached.message)
            return
        }

        SecureProfileManager.preloadRecovery { result ->
            val profile = SecureProfileManager.getRecovery()
            if (result is SecureProfileManager.Result.Success && profile != null) {
                val cached = recoveryMod.cacheProfile(profile)
                if (cached.ok) callback(profile, null)
                else callback(null, cached.message)
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(null, secureNativeProfileStatus(
                    result,
                    tr("Recovery พร้อม", "Recovery ready")
                ))
            } else {
                callback(null, tr(
                    "Secure Recovery Profile ยังไม่พร้อม",
                    "Secure Recovery Profile is not ready"
                ))
            }
        }
    }

    private fun setPitLiftEnabled(enable: Boolean) {
        if (autoMaster || !::recoveryMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)) {
            pitLiftOn = false
            pitLiftStatusText = controlBlockedText(CrgProfile.FEATURE_RECOVERY)
            renderTab()
            return
        }

        if (!enable) {
            pitLiftOn = false
            pitLiftStatusText = tr("กำลังปิด Pit Lift...", "Disabling Pit Lift...")
            renderTab()
            recoveryMod.setPitLiftEnabled(false) { result ->
                handler.post {
                    pitLiftOn = recoveryMod.isPitLiftEnabled()
                    pitLiftStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        pitLiftStatusText = tr(
            "กำลังโหลด Secure Recovery Profile...",
            "Loading Secure Recovery Profile..."
        )
        renderTab()

        withRecoveryProfile { profile, errorText ->
            handler.post outer@{
                if (profile == null) {
                    pitLiftOn = false
                    pitLiftStatusText = errorText ?: tr(
                        "Secure Recovery Profile ยังไม่พร้อม",
                        "Secure Recovery Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@outer
                }

                recoveryMod.setPitLiftEnabled(true) { result ->
                    handler.post {
                        pitLiftOn = recoveryMod.isPitLiftEnabled()
                        pitLiftStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun setReviveEnabled(enable: Boolean) {
        if (autoMaster || !::recoveryMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)) {
            reviveOn = false
            reviveStatusText = controlBlockedText(CrgProfile.FEATURE_RECOVERY)
            renderTab()
            return
        }

        if (!enable) {
            reviveOn = false
            reviveStatusText = tr("กำลังปิด Revive...", "Disabling Revive...")
            renderTab()
            recoveryMod.setReviveEnabled(false) { result ->
                handler.post {
                    reviveOn = recoveryMod.isReviveEnabled()
                    reviveStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        reviveStatusText = tr(
            "กำลังโหลด Secure Recovery Profile...",
            "Loading Secure Recovery Profile..."
        )
        renderTab()

        withRecoveryProfile { profile, errorText ->
            handler.post outer@{
                if (profile == null) {
                    reviveOn = false
                    reviveStatusText = errorText ?: tr(
                        "Secure Recovery Profile ยังไม่พร้อม",
                        "Secure Recovery Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@outer
                }

                recoveryMod.setReviveEnabled(true) { result ->
                    handler.post {
                        reviveOn = recoveryMod.isReviveEnabled()
                        reviveStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun pitLiftCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)
        val backendEnabled = ::recoveryMod.isInitialized && recoveryMod.isPitLiftEnabled()
        if (pitLiftOn != backendEnabled) pitLiftOn = backendEnabled

        root.addView(
            featureHeader(
                title = tr("ขึ้นจากหลุมไม่จำกัด", "Pit Lift Unlimited"),
                desc = audienceText(
                    "ขึ้นจากหลุมได้ไม่จำกัดระหว่างเล่น",
                    "Unlimited pit lifts during play",
                    "คืนจำนวนครั้งเฉพาะตอนตกหลุม • ใช้การยกขึ้นจากหลุมและ animation เดิมของเกม",
                    "Refunds usage only after a pit rescue • Keeps the game's native lift and animation"
                ),
                enabled = if (autoMaster) pitLiftAutoOwned else pitLiftOn,
                locked = autoMaster || !featureAllowed
            ) { setPitLiftEnabled(it) }
        )

        val liveStatus = if (featureAllowed && ::recoveryMod.isInitialized && recoveryMod.isPitLiftEnabled()) {
            recoveryMod.pitLiftStatusText()
        } else {
            pitLiftStatusText
        }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_RECOVERY)
        )

        return root
    }

    private fun reviveCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)
        val backendEnabled = ::recoveryMod.isInitialized && recoveryMod.isReviveEnabled()
        if (reviveOn != backendEnabled) reviveOn = backendEnabled

        root.addView(
            featureHeader(
                title = tr("ชุบชีวิตไม่จำกัด", "Revive Unlimited"),
                desc = audienceText(
                    "ชุบชีวิตได้ไม่จำกัดระหว่างเล่น",
                    "Unlimited revives during play",
                    "คืนจำนวนครั้งเฉพาะตอนตายจาก HP • ไม่คืนสิทธิ์เมื่อเป็นการตกหลุม",
                    "Refunds usage only after a non-pit death recovery • Pit rescues remain separate"
                ),
                enabled = if (autoMaster) reviveAutoOwned else reviveOn,
                locked = autoMaster || !featureAllowed
            ) { setReviveEnabled(it) }
        )

        val liveStatus = if (featureAllowed && ::recoveryMod.isInitialized && recoveryMod.isReviveEnabled()) {
            recoveryMod.reviveStatusText()
        } else {
            reviveStatusText
        }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_RECOVERY)
        )

        return root
    }

    private fun withUnlimitedJumpProfile(
        callback: (JumpProfile?, String?) -> Unit
    ) {
        val current = SecureProfileManager.getJump()
        if (current != null) {
            val cached = jumpMod.cacheProfile(current)
            if (cached.ok) callback(current, null)
            else callback(null, cached.message)
            return
        }

        SecureProfileManager.preloadJump { result ->
            val profile = SecureProfileManager.getJump()
            if (result is SecureProfileManager.Result.Success && profile != null) {
                val cached = jumpMod.cacheProfile(profile)
                if (cached.ok) callback(profile, null)
                else callback(null, cached.message)
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(null, secureNativeProfileStatus(result, tr(
                    "Unlimited Jump พร้อม",
                    "Unlimited Jump ready"
                )))
            } else {
                callback(null, tr(
                    "Secure Unlimited Jump Profile ยังไม่พร้อม",
                    "Secure Unlimited Jump Profile is not ready"
                ))
            }
        }
    }

    private fun setUnlimitedJumpEnabled(enable: Boolean) {
        if (autoMaster || !::jumpMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_UNLIMITED_JUMP)) {
            unlimitedJumpOn = false
            unlimitedJumpStatusText = controlBlockedText(CrgProfile.FEATURE_UNLIMITED_JUMP)
            renderTab()
            return
        }

        if (!enable) {
            unlimitedJumpOn = false
            unlimitedJumpStatusText = tr(
                "กำลังปิด Unlimited Jump...",
                "Disabling Unlimited Jump..."
            )
            renderTab()
            jumpMod.setEnabled(false) { result ->
                handler.post {
                    unlimitedJumpOn = jumpMod.isEnabled()
                    unlimitedJumpStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        unlimitedJumpStatusText = tr(
            "กำลังโหลด Secure Unlimited Jump Profile...",
            "Loading Secure Unlimited Jump Profile..."
        )
        renderTab()

        withUnlimitedJumpProfile { profile, errorText ->
            handler.post outer@{
                if (profile == null) {
                    unlimitedJumpOn = false
                    unlimitedJumpStatusText = errorText ?: tr(
                        "Secure Unlimited Jump Profile ยังไม่พร้อม",
                        "Secure Unlimited Jump Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@outer
                }

                jumpMod.setEnabled(true) { result ->
                    handler.post {
                        unlimitedJumpOn = jumpMod.isEnabled()
                        unlimitedJumpStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun unlimitedJumpCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed =
            ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_UNLIMITED_JUMP)
        val backendEnabled = ::jumpMod.isInitialized && jumpMod.isEnabled()
        if (unlimitedJumpOn != backendEnabled) unlimitedJumpOn = backendEnabled

        root.addView(
            featureHeader(
                title = tr("กระโดดไม่จำกัด", "Unlimited Jump"),
                desc = audienceText(
                    "กระโดดต่อเนื่องได้ไม่จำกัดระหว่างเล่น",
                    "Jump continuously without a limit during play",
                    "ใช้ Jump state เดิมของเกม • ไม่แก้ตำแหน่งหรือความเร็ว • ไม่ต้องใส่สมบัติ Multi Jump",
                    "Uses the game's native Jump state • No position/velocity writes • No Multi Jump treasure required"
                ),
                enabled = if (autoMaster) unlimitedJumpAutoOwned else unlimitedJumpOn,
                locked = autoMaster || !featureAllowed
            ) { setUnlimitedJumpEnabled(it) }
        )

        val liveStatus =
            if (featureAllowed && ::jumpMod.isInitialized && jumpMod.isEnabled()) {
                jumpMod.statusText()
            } else {
                unlimitedJumpStatusText
            }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus
            else controlBlockedText(CrgProfile.FEATURE_UNLIMITED_JUMP),
            if (unlimitedJumpOn) "#8CE6B1" else "#8F9AAC"
        )

        return root
    }

    private fun withBaseSpeedProfile(
        callback: (BaseSpeedProfile?, String?) -> Unit
    ) {
        val current = SecureProfileManager.getBaseSpeed()
        if (current != null) {
            val cached = baseSpeedMod.cacheProfile(current)
            if (cached.ok) callback(current, null)
            else callback(null, cached.message)
            return
        }

        SecureProfileManager.preloadBaseSpeed { result ->
            val profile = SecureProfileManager.getBaseSpeed()
            if (result is SecureProfileManager.Result.Success && profile != null) {
                val cached = baseSpeedMod.cacheProfile(profile)
                if (cached.ok) callback(profile, null)
                else callback(null, cached.message)
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(null, secureNativeProfileStatus(result, tr(
                    "ความเร็วพื้นฐานพร้อม",
                    "Base Speed ready"
                )))
            } else {
                callback(null, tr(
                    "Secure Base Speed Profile ยังไม่พร้อม",
                    "Secure Base Speed Profile is not ready"
                ))
            }
        }
    }

    private fun setBaseSpeedEnabled(enable: Boolean) {
        if (autoMaster || !::baseSpeedMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_BASE_SPEED)) {
            baseSpeedOn = false
            baseSpeedStatusText = controlBlockedText(CrgProfile.FEATURE_BASE_SPEED)
            renderTab()
            return
        }

        if (!enable) {
            baseSpeedOn = false
            baseSpeedStatusText = tr(
                "กำลังปิดความเร็วพื้นฐาน...",
                "Disabling Base Speed..."
            )
            renderTab()

            baseSpeedMod.setEnabled(false, baseSpeedMultiplier) { result ->
                handler.post {
                    baseSpeedOn = baseSpeedMod.isEnabled()
                    baseSpeedStatusText = result.message
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                }
            }
            return
        }

        baseSpeedStatusText = tr(
            "กำลังโหลด Secure Base Speed Profile...",
            "Loading Secure Base Speed Profile..."
        )
        renderTab()

        withBaseSpeedProfile { profile, errorText ->
            handler.post outer@{
                if (profile == null) {
                    baseSpeedOn = false
                    baseSpeedStatusText = errorText ?: tr(
                        "Secure Base Speed Profile ยังไม่พร้อม",
                        "Secure Base Speed Profile is not ready"
                    )
                    if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    return@outer
                }

                baseSpeedMod.setEnabled(true, baseSpeedMultiplier) { result ->
                    handler.post {
                        baseSpeedOn = baseSpeedMod.isEnabled()
                        baseSpeedStatusText = result.message
                        if (activeTab == Tab.PLAY && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun baseSpeedCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed =
            ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_BASE_SPEED)

        val backendEnabled =
            ::baseSpeedMod.isInitialized && baseSpeedMod.isEnabled()
        if (baseSpeedOn != backendEnabled) {
            baseSpeedOn = backendEnabled
        }

        root.addView(
            featureHeader(
                title = tr("ความเร็วพื้นฐานคุกกี้", "Cookie Base Speed"),
                desc = audienceText(
                    "ปรับความเร็วพื้นฐานของคุกกี้แยกจากความเร็วเกม",
                    "Adjust the cookie's base movement speed separately from game speed",
                    "ปรับความเร็วพื้นฐานของคุกกี้โดยไม่เร่งเวลาทั้งเกม • เปิดได้ทุกหน้า",
                    "Adjusts the cookie's base movement speed without speeding up the whole game • Can be armed anywhere"
                ),
                enabled = if (autoMaster) baseSpeedAutoOwned else baseSpeedOn,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { enabled ->
                setBaseSpeedEnabled(enabled)
            }
        )

        if (!featureAllowed) {
            root.addView(featureUpdatingHint(), subLp())
        }

        root.addView(
            label(tr("ตัวคูณความเร็ว", "Speed multiplier")),
            subLp()
        )

        val presets = listOf(0.5, 1.0, 2.0, 5.0, 10.0, 25.0, 50.0)
        val selectedIndex = presets.indices.minByOrNull {
            kotlin.math.abs(presets[it] - baseSpeedMultiplier)
        } ?: 1

        root.addView(
            choices(
                presets.map { String.format(java.util.Locale.US, "%.1fx", it) },
                selectedIndex
            ) { index ->
                baseSpeedMultiplier = presets[index]
                modSettingsStore.saveBaseSpeedMultiplier(baseSpeedMultiplier)
                if (::baseSpeedMod.isInitialized) {
                    baseSpeedMod.updateValue(baseSpeedMultiplier)
                    if (baseSpeedOn) baseSpeedStatusText = baseSpeedMod.statusText()
                }
                renderTab()
            },
            subLp()
        )

        val sliderProgress =
            ((baseSpeedMultiplier * 10.0).toInt() - 5).coerceIn(0, 45)

        root.addView(
            slider(
                "0.5x",
                "5.0x",
                sliderProgress,
                45,
                { String.format(java.util.Locale.US, "%.1fx", baseSpeedMultiplier) }
            ) { progress ->
                baseSpeedMultiplier = (5 + progress).toDouble() / 10.0
                modSettingsStore.saveBaseSpeedMultiplier(baseSpeedMultiplier)
                if (::baseSpeedMod.isInitialized) {
                    baseSpeedMod.updateValue(baseSpeedMultiplier)
                    if (baseSpeedOn) baseSpeedStatusText = baseSpeedMod.statusText()
                }
            },
            subLp()
        )

        val liveStatus =
            if (featureAllowed && ::baseSpeedMod.isInitialized && baseSpeedMod.isEnabled()) {
                baseSpeedMod.statusText()
            } else {
                baseSpeedStatusText
            }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus
            else controlBlockedText(CrgProfile.FEATURE_BASE_SPEED),
            if (baseSpeedOn) "#8CE6B1" else "#8F9AAC"
        )

        return root
    }

    private fun withPotatoProfile(
        requireUltimate: Boolean = false,
        requireCoin: Boolean = false,
        callback: (PotatoProfile?, String?) -> Unit
    ) {
        fun cacheControllers(profile: PotatoProfile): String? {
            val coinCached = potatoCoinMod.cacheProfile(profile)
            if (requireCoin && !coinCached.ok) return coinCached.message

            val rapidCached = potatoRapidMod.cacheProfile(profile)
            if (!rapidCached.ok) return rapidCached.message

            val ultimateCached = potatoUltimateMod.cacheProfile(profile)
            if (requireUltimate && !ultimateCached.ok) return ultimateCached.message
            return null
        }

        val current = SecureProfileManager.getPotato()
        if (current != null) {
            val error = cacheControllers(current)
            if (error == null) callback(current, null)
            else callback(null, error)
            return
        }

        SecureProfileManager.preloadPotato { result ->
            val profile = SecureProfileManager.getPotato()
            if (result is SecureProfileManager.Result.Success && profile != null) {
                val error = cacheControllers(profile)
                if (error == null) callback(profile, null)
                else callback(null, error)
            } else if (result is SecureProfileManager.Result.Failure) {
                callback(
                    null,
                    secureNativeProfileStatus(
                        result,
                        tr("Potato พร้อม", "Potato ready")
                    )
                )
            } else {
                callback(
                    null,
                    tr(
                        "Secure Potato Profile ยังไม่พร้อม",
                        "Secure Potato Profile is not ready"
                    )
                )
            }
        }
    }

    private fun setPotatoCoinEnabled(enable: Boolean) {
        if (autoMaster || !::potatoCoinMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            potatoCoinOn = false
            potatoCoinStatusText = controlBlockedText(CrgProfile.FEATURE_POTATO)
            renderTab()
            return
        }

        if (!enable) {
            potatoCoinOn = false
            potatoCoinMod.setEnabled(
                false,
                potatoCoinMode,
                potatoCoin,
                potatoCoinInterval
            ) { result ->
                handler.post {
                    potatoCoinStatusText = result.message
                    if (activeTab == Tab.FARM && menuVisible) renderTab()
                }
            }
            return
        }

        potatoCoinStatusText = tr(
            "กำลังโหลด Secure Potato Coin Profile...",
            "Loading Secure Potato Coin Profile..."
        )
        renderTab()

        withPotatoProfile(requireCoin = true) { profile, errorText ->
            handler.post {
                if (profile == null) {
                    potatoCoinOn = false
                    potatoCoinStatusText = errorText ?: tr(
                        "Secure Potato Coin Profile ยังไม่พร้อม",
                        "Secure Potato Coin Profile is not ready"
                    )
                    if (activeTab == Tab.FARM && menuVisible) renderTab()
                    return@post
                }

                potatoCoinMod.setEnabled(
                    true,
                    potatoCoinMode,
                    potatoCoin,
                    potatoCoinInterval
                ) { result ->
                    handler.post inner@{
                        potatoCoinOn = result.ok && potatoCoinMod.isEnabled()
                        potatoCoinStatusText = result.message
                        if (activeTab == Tab.FARM && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun setPotatoRapidEnabled(enable: Boolean) {
        if (autoMaster || !::potatoRapidMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            potatoRapidOn = false
            potatoRapidStatusText = controlBlockedText(CrgProfile.FEATURE_POTATO)
            renderTab()
            return
        }

        if (!enable) {
            potatoRapidOn = false
            potatoRapidMod.setEnabled(false, potatoRapid) { result ->
                handler.post {
                    potatoRapidStatusText = result.message
                    if (activeTab == Tab.FARM && menuVisible) renderTab()
                }
            }
            return
        }

        potatoRapidStatusText = tr(
            "กำลังโหลด Secure Potato Profile...",
            "Loading Secure Potato Profile..."
        )
        renderTab()

        withPotatoProfile(requireUltimate = false) { profile, errorText ->
            handler.post {
                if (profile == null) {
                    potatoRapidOn = false
                    potatoRapidStatusText = errorText ?: tr(
                        "Secure Potato Profile ยังไม่พร้อม",
                        "Secure Potato Profile is not ready"
                    )
                    if (activeTab == Tab.FARM && menuVisible) renderTab()
                    return@post
                }

                potatoRapidMod.setEnabled(true, potatoRapid) { result ->
                    handler.post inner@{
                        potatoRapidOn = potatoRapidMod.isEnabled()
                        potatoRapidStatusText = result.message
                        if (activeTab == Tab.FARM && menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun setPotatoUltimateManualEnabled(enable: Boolean) {
        if (autoMaster) return
        setPotatoUltimateEnabled(enable, autoOwner = false)
    }

    private fun setPotatoUltimateAutoEnabled(enable: Boolean) {
        setPotatoUltimateEnabled(enable, autoOwner = true)
    }

    private fun setPotatoUltimateEnabled(enable: Boolean, autoOwner: Boolean) {
        if (!::potatoUltimateMod.isInitialized) return

        if (enable && !ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            if (autoOwner) {
                potatoUltimateAutoOwned = false
                autoSelected["ULTIMATE"] = false
            } else {
                potatoUltimateOn = false
            }
            potatoUltimateStatusText = controlBlockedText(CrgProfile.FEATURE_POTATO)
            if (menuVisible) renderTab()
            return
        }

        if (!enable) {
            if (autoOwner) potatoUltimateAutoOwned = false else potatoUltimateOn = false
            potatoUltimateMod.setEnabled(
                false,
                potatoUltimateInfinite,
                potatoUltimateSeconds
            ) { result ->
                handler.post {
                    potatoUltimateStatusText = result.message
                    if (menuVisible) renderTab()
                }
            }
            return
        }

        potatoUltimateStatusText = tr(
            "กำลังโหลด Secure Potato Profile...",
            "Loading Secure Potato Profile..."
        )
        if (menuVisible) renderTab()

        withPotatoProfile(requireUltimate = true) { profile, errorText ->
            handler.post {
                if (profile == null) {
                    if (autoOwner) {
                        potatoUltimateAutoOwned = false
                        autoSelected["ULTIMATE"] = false
                    } else {
                        potatoUltimateOn = false
                    }
                    potatoUltimateStatusText = errorText ?: tr(
                        "Secure Potato Ultimate Profile ยังไม่พร้อม",
                        "Secure Potato Ultimate Profile is not ready"
                    )
                    if (menuVisible) renderTab()
                    return@post
                }

                potatoUltimateMod.setEnabled(
                    true,
                    potatoUltimateInfinite,
                    potatoUltimateSeconds
                ) { result ->
                    handler.post inner@{
                        if (result.ok) {
                            if (autoOwner) {
                                potatoUltimateAutoOwned = potatoUltimateMod.isEnabled()
                                potatoUltimateOn = false
                            } else {
                                potatoUltimateOn = potatoUltimateMod.isEnabled()
                                potatoUltimateAutoOwned = false
                            }
                        } else {
                            if (autoOwner) potatoUltimateAutoOwned = false else potatoUltimateOn = false
                        }
                        potatoUltimateStatusText = result.message
                        if (menuVisible) renderTab()
                    }
                }
            }
        }
    }

    private fun potatoCoinCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)

        root.addView(
            featureHeader(
                tr("Potato • จำนวนเหรียญ", "Potato • Coin Count"),
                tr(
                    "กำหนดเหรียญต่อการยิง • โหมดต่อเนื่องยิงเพิ่มระหว่างอัลติเมต",
                    "Set coins per shot • Continuous adds extra fires during Ultimate"
                ),
                if (autoMaster) potatoCoinAutoOwned else potatoCoinOn,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { setPotatoCoinEnabled(it) }
        )

        if (!featureAllowed) root.addView(featureUpdatingHint(), subLp())

        val modes = listOf("FIXED", "MASSIVE", "CONTINUOUS")
        val modeLabels = if (language == EN) {
            modes
        } else {
            listOf("คงที่", "จำนวนมาก", "ต่อเนื่อง")
        }
        root.addView(label(tr("โหมด", "Mode")), subLp())
        root.addView(
            choices(modeLabels, modes.indexOf(potatoCoinMode)) { i ->
                potatoCoinMode = modes[i]
                potatoCoin = if (potatoCoinMode == "MASSIVE") 500 else 100
                modSettingsStore.savePotatoCoin(
                    potatoCoinMode,
                    potatoCoin,
                    potatoCoinInterval
                )
                if (::potatoCoinMod.isInitialized && potatoCoinOn) {
                    potatoCoinMod.updateValue(
                        potatoCoinMode,
                        potatoCoin,
                        potatoCoinInterval
                    )
                }
                renderTab()
            }
        )

        val amounts = when (potatoCoinMode) {
            "MASSIVE" -> listOf(100, 300, 500, 1000)
            "CONTINUOUS" -> listOf(30, 100, 300, 500, 1000)
            else -> listOf(3, 10, 30, 100, 300, 500, 1000)
        }

        root.addView(label(tr("จำนวน", "Amount")), subLp())
        root.addView(
            choices(amounts.map { it.toString() }, amounts.indexOf(potatoCoin)) { i ->
                potatoCoin = amounts[i]
                modSettingsStore.savePotatoCoin(
                    potatoCoinMode,
                    potatoCoin,
                    potatoCoinInterval
                )
                if (::potatoCoinMod.isInitialized && potatoCoinOn) {
                    potatoCoinMod.updateValue(
                        potatoCoinMode,
                        potatoCoin,
                        potatoCoinInterval
                    )
                }
                renderTab()
            }
        )

        if (potatoCoinMode == "CONTINUOUS") {
            val intervals = listOf(0.10, 0.25, 0.50, 1.00, 2.00)
            val intervalLabels = if (language == EN) {
                intervals.map { String.format(Locale.US, "%.2fs", it) }
            } else {
                intervals.map { String.format(Locale.US, "%.2f วิ", it) }
            }
            val selectedInterval = intervals.indexOfFirst {
                kotlin.math.abs(it - potatoCoinInterval) < 0.0001
            }.let { if (it >= 0) it else 3 }

            root.addView(label(tr("ช่วงยิงต่อเนื่อง", "Continuous interval")), subLp())
            root.addView(
                choices(intervalLabels, selectedInterval) { i ->
                    potatoCoinInterval = intervals[i]
                    modSettingsStore.savePotatoCoin(
                        potatoCoinMode,
                        potatoCoin,
                        potatoCoinInterval
                    )
                    if (::potatoCoinMod.isInitialized && potatoCoinOn) {
                        potatoCoinMod.updateValue(
                            potatoCoinMode,
                            potatoCoin,
                            potatoCoinInterval
                        )
                    }
                    renderTab()
                },
                subLp()
            )
        }

        val liveStatus = if (
            featureAllowed && ::potatoCoinMod.isInitialized && (potatoCoinOn || potatoCoinAutoOwned)
        ) potatoCoinMod.statusText() else potatoCoinStatusText

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_POTATO)
        )

        return root
    }

    private fun potatoRapidCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)

        root.addView(
            featureHeader(
                tr("Potato • ตั้งเวลายิง 3 ครั้ง", "Potato • 3 Shot Timer"),
                tr("กำหนดช่วงเวลาการยิงให้ครบ 3 ครั้งก่อนเข้าอัลติเมต", "Set the 3-shot interval before Ultimate"),
                if (autoMaster) potatoRapidAutoOwned else potatoRapidOn,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { setPotatoRapidEnabled(it) }
        )

        if (!featureAllowed) root.addView(featureUpdatingHint(), subLp())

        val values = listOf(0.05, 0.10, 0.25, 0.50, 1.00, 2.00)
        val valueLabels = if (language == EN) {
            values.map { String.format(Locale.US, "%.2fs", it) }
        } else {
            values.map { String.format(Locale.US, "%.2f วิ", it) }
        }

        root.addView(
            choices(
                valueLabels,
                values.indexOf(potatoRapid)
            ) { i ->
                potatoRapid = values[i]
                modSettingsStore.savePotatoRapid(potatoRapid)
                if (::potatoRapidMod.isInitialized && potatoRapidOn) {
                    potatoRapidMod.updateValue(potatoRapid)
                }
                renderTab()
            },
            subLp()
        )

        root.addView(
            current(
                tr("ค่าปัจจุบัน", "Current"),
                if (language == EN) {
                    String.format(Locale.US, "%.2f s", potatoRapid)
                } else {
                    String.format(Locale.US, "%.2f วินาที", potatoRapid)
                }
            ),
            subLp()
        )

        val liveStatus = if (
            featureAllowed && ::potatoRapidMod.isInitialized && (potatoRapidOn || potatoRapidAutoOwned)
        ) potatoRapidMod.statusText() else potatoRapidStatusText

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_POTATO)
        )

        return root
    }

    private fun potatoUltimateCard(): LinearLayout {
        val root = featureCard()
        val featureAllowed = ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)
        val enabled = if (autoMaster) potatoUltimateAutoOwned else potatoUltimateOn

        root.addView(
            featureHeader(
                tr("Potato • อัลติเมต", "Potato • Ultimate"),
                tr(
                    "กำหนดเวลาอัลติเมต 1–10 นาที หรือเปิดแบบไม่หมด",
                    "Set Ultimate to 1–10 minutes or Infinite"
                ),
                enabled,
                locked = autoMaster && featureAllowed,
                updating = !featureAllowed
            ) { setPotatoUltimateManualEnabled(it) }
        )

        if (!featureAllowed) root.addView(featureUpdatingHint(), subLp())

        val labels = listOf(
            tr("1 นาที", "1 min"),
            tr("3 นาที", "3 min"),
            tr("5 นาที", "5 min"),
            tr("10 นาที", "10 min"),
            tr("ไม่หมด", "Infinite")
        )

        val selected = if (potatoUltimateInfinite) 4 else when (potatoUltimateSeconds) {
            60 -> 0
            180 -> 1
            300 -> 2
            600 -> 3
            else -> 2
        }

        root.addView(
            choices(labels, selected) { i ->
                if (i == 4) {
                    potatoUltimateInfinite = true
                } else {
                    potatoUltimateInfinite = false
                    potatoUltimateSeconds = listOf(60, 180, 300, 600)[i]
                }

                modSettingsStore.savePotatoUltimate(
                    potatoUltimateInfinite,
                    potatoUltimateSeconds
                )

                if (
                    ::potatoUltimateMod.isInitialized &&
                    (potatoUltimateOn || potatoUltimateAutoOwned)
                ) {
                    potatoUltimateMod.updateValue(
                        potatoUltimateInfinite,
                        potatoUltimateSeconds
                    )
                }
                renderTab()
            },
            subLp()
        )

        root.addView(
            current(
                tr("ค่าปัจจุบัน", "Current"),
                ultimateText()
            ),
            subLp()
        )

        val liveStatus = if (
            featureAllowed &&
            ::potatoUltimateMod.isInitialized &&
            (potatoUltimateOn || potatoUltimateAutoOwned)
        ) {
            potatoUltimateMod.statusText()
        } else {
            potatoUltimateStatusText
        }

        addDiagnosticStatus(
            root,
            if (featureAllowed) liveStatus else controlBlockedText(CrgProfile.FEATURE_POTATO)
        )

        return root
    }

    private fun auto(root: LinearLayout) {
        root.addView(
            pageTitle(
                tr("อัตโนมัติ", "Auto"),
                tr(
                    "เลือก MOD ที่ต้องการให้ AUTO ควบคุม • ค่าเริ่มต้นไม่เลือกทุกตัว",
                    "Choose which MODs AUTO controls • Nothing is selected by default"
                )
            )
        )

        root.addView(
            section(tr("M Woif BOT", "M Woif BOT")),
            sectionLp()
        )

        if (BOT_LAB_ENABLED && ::botLab.isInitialized) {
            root.addView(botLabCard(), itemLp())
        } else {
            root.addView(
                lockedNotice(
                    tr(
                        "BOT • กำลังอัปเดต\nกำลังสร้างและทดสอบระบบเล่นอัตโนมัติ • จะเปิดใช้งานเมื่อพร้อม",
                        "BOT • Updating\nThe automated play system is being built and tested • It will be enabled when ready"
                    )
                ),
                itemLp()
            )
        }

        val master = featureCard().apply {
            val header =
                featureHeader(
                    "AUTO MODE",
                    tr(
                        "เมื่อเปิด AUTO ระบบจะหยุด Manual แล้วเปิดเฉพาะ MOD ที่เลือกไว้",
                        "AUTO stops Manual controls and enables only the selected MODs"
                    ),
                    autoMaster,
                    locked = false
                ) { enabled ->
                    setAutoMaster(enabled)
                    renderTab()
                }

            autoMasterToggleView =
                header.getChildAt(header.childCount - 1) as? TextView

            addView(header)
        }
        root.addView(master, itemLp())

        val quickButtonCard = featureCard().apply {
            addView(
                featureHeader(
                    tr("ปุ่มลอย ON/OFF", "QUICK MOD BUTTON"),
                    tr(
                        "แสดงปุ่มลอยวงกลม ON/OFF สำหรับเปิดหรือปิด AUTO MODE ได้ทันที",
                        "Show the floating ON/OFF circle used to control AUTO MODE instantly"
                    ),
                    quickModEnabled,
                    locked = false
                ) { enabled ->
                    setQuickModEnabled(enabled)
                    renderTab()
                }
            )
        }
        root.addView(quickButtonCard, itemLp())

        val visibleAutoKeys = listOf(
            "SPEED",
            "BASE_SPEED",
            "HP",
            "GIANT",
            "GIANT_SIZE",
            "SUPER",
            "XP",
            "COIN",
            "REVIVE",
            "UNLIMITED_JUMP"
        )

        root.addView(section(tr("ความเร็ว", "SPEED")), sectionLp())
        listOf(
            Triple("SPEED", tr("ความเร็วเกม", "Game Speed"), "x$speed"),
            Triple(
                "BASE_SPEED",
                tr("ความเร็วพื้นฐานคุกกี้", "Cookie Base Speed"),
                String.format(Locale.US, "%.1fx", baseSpeedMultiplier)
            )
        ).forEach { (key, title, value) ->
            root.addView(autoRow(key, title, value), itemLp())
        }

        root.addView(section(tr("ระบบเล่น", "PLAY SYSTEMS")), sectionLp())
        listOf(
            Triple("HP", tr("อมตะ", "HP"), hpModeText()),
            Triple("GIANT", tr("ตัวใหญ่", "Giant"), tr("เข้า Stage แล้วเปิด", "Enable in Stage")),
            Triple("GIANT_SIZE", tr("ขนาด Giant", "Giant Size"), "+$giantSizePercent%"),
            Triple("SUPER", tr("วิ่งเร็ว", "Super"), tr("เข้า Stage แล้วเปิด", "Enable in Stage"))
        ).forEach { (key, title, value) ->
            root.addView(autoRow(key, title, value), itemLp())
        }

        root.addView(section(tr("XP / เลเวล • เหรียญ", "XP / Coin")), sectionLp())
        listOf(
            Triple("XP", tr("XP / เลเวล", "XP"), number(xp)),
            Triple("COIN", tr("เหรียญ", "Coin"), number(coin))
        ).forEach { (key, title, value) ->
            root.addView(autoRow(key, title, value), itemLp())
        }

        root.addView(section(tr("ระบบเล่นเสริม", "EXTRA PLAY")), sectionLp())
        listOf(
            Triple("REVIVE", tr("ชุบชีวิตไม่จำกัด", "Revive Unlimited"), tr("ไม่จำกัด", "Unlimited")),
            Triple("UNLIMITED_JUMP", tr("กระโดดไม่จำกัด", "Unlimited Jump"), tr("ไม่จำกัด", "Unlimited"))
        ).forEach { (key, title, value) ->
            root.addView(autoRow(key, title, value), itemLp())
        }

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(
            button(tr("เลือกทั้งหมด", "Select All"), true) {
                visibleAutoKeys.forEach { key ->
                    if (isAutoKeyAvailable(key)) autoSelected[key] = true
                }
                saveAutoSelection()
                if (autoMaster) applyAllSelectedAuto()
                renderTab()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) }
        )
        actions.addView(
            button(tr("ล้างทั้งหมด", "Clear All"), false) {
                autoSelected.keys.forEach { autoSelected[it] = false }
                saveAutoSelection()
                if (autoMaster) stopAllAutoOwned()
                renderTab()
            },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(6) }
        )
        root.addView(actions, sectionLp())

        val status = card()
        status.addView(info("AUTO", if (autoMaster) "ON" else "OFF", if (autoMaster) "#4ADE80" else "#98A2B2"))
        status.addView(divider())
        status.addView(
            info(
                tr("ปุ่มลอย ON/OFF", "Quick MOD button"),
                if (quickModEnabled) tr("แสดง", "Shown") else tr("ซ่อน", "Hidden"),
                if (quickModEnabled) "#4ADE80" else "#98A2B2"
            )
        )
        status.addView(divider())
        status.addView(
            info(
                tr("ระบบที่เลือก", "Selected"),
                "${visibleAutoKeys.count { autoSelected[it] == true }} / ${visibleAutoKeys.size}",
                "#C4B5FD"
            )
        )
        root.addView(status, sectionLp())
    }

    private fun botLabCard(): LinearLayout {
        val root = featureCard()

        root.addView(
            txt(
                tr("BOT LAB V7 • Random Mix QA + Mini 4/2", "BOT LAB V7 • Random Mix QA + Mini 4/2"),
                12f,
                "#F3F4F8",
                true
            )
        )
        root.addView(
            txt(
                tr(
                    "Stage-driven • ไม่ดัก touch • Jump/Slide สุ่มผสมต่อ Stage • สูงสุด 100 ครั้ง/ชนิด • Mini-game 4+2 • Recovery",
                    "Stage-driven • no touch interception • mixed randomized Jump/Slide per stage • up to 100 each • 4+2 mini-game • recovery"
                ),
                9f,
                "#8792A4"
            ).apply { setPadding(0, dp(5), 0, dp(10)) }
        )

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(
            button(tr("▶ เปิด BOT", "▶ Start BOT"), true) {
                if (botLab.startBot()) {
                    // BOT must never put M Woif into hidden-overlay mode.
                    // Close only the large panel, then explicitly restore both
                    // floating controls so MOD ON/OFF remains available.
                    if (overlayHiddenMode) {
                        exitHiddenOverlayMode(restoreVisible = false)
                    }
                    hideMenu(false)
                    showW()
                    if (quickModEnabled) {
                        showQuickModButton()
                        updateQuickModButtonState(force = true)
                    }
                }
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }
        )
        actions.addView(
            button(tr("■ หยุด BOT", "■ Stop BOT"), false) {
                botLab.stopBot()
                renderTab(resetScroll = false)
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) }
        )
        root.addView(actions, subLp())

        root.addView(divider(12, 12))
        root.addView(label(tr("การกดระหว่าง Stage", "Stage actions")))

        root.addView(
            slider(
                "0",
                "100",
                botLab.jumpCount().coerceIn(0, 100),
                100,
                { tr("Jump ${botLab.jumpCount()} ครั้ง", "Jump ${botLab.jumpCount()} times") }
            ) { progress ->
                botLab.setJumpCount(progress)
            },
            subLp()
        )

        root.addView(
            slider(
                "0",
                "100",
                botLab.slideCount().coerceIn(0, 100),
                100,
                { tr("Slide ${botLab.slideCount()} ครั้ง", "Slide ${botLab.slideCount()} times") }
            ) { progress ->
                botLab.setSlideCount(progress)
            },
            subLp()
        )

        val jumpProgress = ((botLab.jumpIntervalMs() - 250L) / 50L).toInt().coerceIn(0, 55)
        root.addView(
            slider(
                "250 ms",
                "3000 ms",
                jumpProgress,
                55,
                { "${botLab.jumpIntervalMs()} ms" }
            ) { progress ->
                botLab.setJumpIntervalMs(250L + progress.toLong() * 50L)
            },
            subLp()
        )

        val slideProgress = ((botLab.slideIntervalMs() - 250L) / 50L).toInt().coerceIn(0, 55)
        root.addView(
            slider(
                "250 ms",
                "3000 ms",
                slideProgress,
                55,
                { "${botLab.slideIntervalMs()} ms" }
            ) { progress ->
                botLab.setSlideIntervalMs(250L + progress.toLong() * 50L)
            },
            subLp()
        )

        root.addView(divider(12, 12))
        root.addView(label(tr("Navigation", "Navigation")))

        val startProgress = ((botLab.startTapIntervalMs() - 500L) / 100L).toInt().coerceIn(0, 25)
        root.addView(
            slider(
                "500 ms",
                "3000 ms",
                startProgress,
                25,
                { tr("Play 1/2 ทุก ${botLab.startTapIntervalMs()} ms", "Play 1/2 every ${botLab.startTapIntervalMs()} ms") }
            ) { progress ->
                botLab.setStartTapIntervalMs(500L + progress.toLong() * 100L)
            },
            subLp()
        )

        val postProgress = ((botLab.postTapIntervalMs() - 400L) / 50L).toInt().coerceIn(0, 42)
        root.addView(
            slider(
                "400 ms",
                "2500 ms",
                postProgress,
                42,
                { tr("หลังจบทุก ${botLab.postTapIntervalMs()} ms", "Post-stage every ${botLab.postTapIntervalMs()} ms") }
            ) { progress ->
                botLab.setPostTapIntervalMs(400L + progress.toLong() * 50L)
            },
            subLp()
        )

        val logic = card()
        logic.addView(info("Play 1 / Play 2", tr("กดตำแหน่ง Play เดียวกัน", "shared Play position"), "#C4B5FD"))
        logic.addView(divider())
        logic.addView(info("Stage", tr("ตรวจจาก StageService/Character", "StageService/Character detector"), "#4ADE80"))
        logic.addView(divider())
        logic.addView(info("Recovery", "Mini → X Popup → Play → OK/Confirm → Mystery", "#AEB6C3"))
        root.addView(logic, sectionLp())

        val status = card()
        status.addView(
            info(
                tr("สถานะ BOT", "BOT status"),
                botLab.status(),
                if (botLab.isRunning()) "#FBBF24" else "#4ADE80"
            )
        )
        status.addView(divider())
        status.addView(info("Phase", botLab.phase().name, "#C4B5FD"))
        status.addView(divider())
        status.addView(info("Stage", "${botLab.stageStateText()} • ${botLab.stageStatus()}", "#AEB6C3"))
        status.addView(divider())
        status.addView(info(tr("จำนวนรอบ", "Runs"), botLab.runCount().toString(), "#4ADE80"))
        root.addView(status, sectionLp())

        return root
    }

    private fun autoRow(key: String, title: String, value: String): LinearLayout {
        val selected = autoSelected[key] == true
        val available = isAutoKeyAvailable(key)

        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(12), dp(12))
            background = rounded(
                if (selected) "#111925" else "#0C1118",
                14,
                if (selected) "#2C3850" else "#202631",
                1
            )
            alpha = if (available) 1f else 0.55f

            setOnClickListener {
                if (!available) return@setOnClickListener
                val next = !(autoSelected[key] == true)

                // Giant Size is separately selectable, but Giant is required.
                if (key == "GIANT_SIZE" && next) {
                    autoSelected["GIANT"] = true
                }
                if (key == "GIANT" && !next) {
                    autoSelected["GIANT_SIZE"] = false
                    if (autoMaster) {
                        setGiantSizeAutoEnabled(false)
                    }
                }

                autoSelected[key] = next
                saveAutoSelection()

                if (autoMaster) {
                    if (key == "GIANT_SIZE" && next) {
                        applyAutoKey("GIANT", true)
                    }
                    applyAutoKey(key, next)
                }
                renderTab()
            }

            addView(
                TextView(this@FloatingMenuService).apply {
                    text = if (selected) "●" else "○"
                    gravity = Gravity.CENTER
                    textSize = 19f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor(if (selected) "#9A82FF" else "#687386"))
                },
                LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(10) }
            )

            val textArea = LinearLayout(this@FloatingMenuService).apply {
                orientation = LinearLayout.VERTICAL
                addView(txt(title, 12f, if (available) "#EEF1F6" else "#7A8493", true))
                addView(txt(value, 9f, "#747F90").apply { setPadding(0, dp(3), 0, 0) })
            }
            addView(textArea, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            addView(txt(tr("ตั้งค่า ›", "Configure ›"), 9f, "#A998FF", true).apply {
                setOnClickListener {
                    if (!available) return@setOnClickListener
                    activeTab = when (key) {
                        "POTATO_COIN", "POTATO_RAPID", "ULTIMATE" -> Tab.FARM
                        else -> Tab.PLAY
                    }
                    updateTabs()
                    renderTab(resetScroll = true)
                }
            })
        }
    }

    private fun isAutoKeyAvailable(key: String): Boolean = when (key) {
        "SPEED" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GAME_SPEED)
        "HP" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_HP)
        "GIANT" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GIANT)
        "GIANT_SIZE" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GIANT)
        "SUPER" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_SUPER)
        "POWER" -> false
        "XP", "COIN" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)
        "BASE_SPEED" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_BASE_SPEED)
        "PIT_LIFT" -> false
        "REVIVE" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)
        "UNLIMITED_JUMP" -> ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_UNLIMITED_JUMP)
        "POTATO_COIN", "POTATO_RAPID", "ULTIMATE" -> false
        else -> false
    }

    private fun farm(root: LinearLayout) {
        root.addView(
            pageTitle(
                tr("คุกกี้", "Cookie"),
                tr(
                    "ระบบเฉพาะคุกกี้",
                    "Cookie-specific systems"
                )
            )
        )

        root.addView(
            lockedNotice(
                tr(
                    "Potato System กำลังอัปเดต • ยังไม่เปิดใช้งานในเวอร์ชันนี้",
                    "Potato System is being updated • Not available in this version"
                )
            ),
            itemLp()
        )
    }

    private fun pump(root: LinearLayout) {
        root.addView(
            pageTitle(
                tr("ปั้ม", "Pump"),
                tr(
                    "ระบบปั้มอัตโนมัติของ M Woif",
                    "M Woif automated farming system"
                )
            )
        )

        root.addView(
            section(tr("M Woif Pump", "M Woif Pump")),
            sectionLp()
        )

        if (!BuildConfig.INTERNAL_BUILD) {
            root.addView(
                lockedNotice(
                    tr(
                        "ปั้ม • กำลังอัปเดต\nกำลังสร้างและทดสอบระบบปั้ม • จะเปิดใช้งานเมื่อระบบพร้อม",
                        "Pump • Updating\nThe farming system is being built and tested • It will be enabled when ready"
                    )
                ),
                itemLp()
            )
            return
        }

        root.addView(
            section(tr("ผงวิเศษ", "Magic Powder")),
            sectionLp()
        )

        val pumpCard = featureCard()

        val statusView = txt(
            powderPumpSimpleStatus,
            10f,
            if (powderPumpLabRunning) "#FACC15" else "#D7DCE5",
            true
        ).apply { setPadding(dp(4), dp(2), dp(4), dp(10)) }
        powderPumpStatusView = statusView
        pumpCard.addView(statusView, subLp())

        val drawsView = txt(
            tr(
                "สุ่มทั้งหมด  ${powderPumpTotalDraws} ครั้ง",
                "Total draws  ${powderPumpTotalDraws}"
            ),
            12f,
            "#E8EBF1",
            true
        ).apply { setPadding(dp(4), dp(5), dp(4), dp(4)) }
        powderPumpDrawsView = drawsView
        pumpCard.addView(drawsView, subLp())

        val brokenView = txt(
            tr(
                "ย่อยสำเร็จ  ${powderPumpTotalBroken} ชิ้น",
                "Broken  ${powderPumpTotalBroken}"
            ),
            12f,
            "#E8EBF1",
            true
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
        powderPumpBrokenView = brokenView
        pumpCard.addView(brokenView, subLp())

        val powderView = txt(
            tr(
                "ผงที่ได้รับ  +${powderPumpTotalPowder}",
                "Powder gained  +${powderPumpTotalPowder}"
            ),
            12f,
            "#E8EBF1",
            true
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(10)) }
        powderPumpPowderView = powderView
        pumpCard.addView(powderView, subLp())

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(
            button(
                tr("เริ่มปั้ม", "Start"),
                !powderPumpLabRunning
            ) {
                if (!powderPumpLabRunning) runPowderPumpTurbo()
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }
        )
        actions.addView(
            button(
                tr("หยุด", "Stop"),
                powderPumpLabRunning
            ) {
                if (powderPumpLabRunning) requestPowderPumpLabLoopStop()
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) }
        )
        pumpCard.addView(actions, subLp().apply { topMargin = dp(8) })

        root.addView(pumpCard, itemLp())

        root.addView(
            section(tr("หอคอยน้ำแข็ง • LAB", "Frozen Tower • LAB")),
            sectionLp()
        )

        val towerCard = featureCard()
        val towerStatus = txt(
            towerPumpSimpleStatus,
            10f,
            if (towerPumpLabRunning) "#FACC15" else "#D7DCE5",
            true
        ).apply { setPadding(dp(4), dp(2), dp(4), dp(10)) }
        towerPumpStatusView = towerStatus
        towerCard.addView(towerStatus, subLp())

        val towerFloor = txt(
            tr(
                "ด่านปัจจุบัน  ${if (towerPumpFloor > 0) towerPumpFloor else "-"}  •  ด่านสูงสุด ${if (towerPumpBestStage > 0) towerPumpBestStage else "-"}",
                "Current floor  ${if (towerPumpFloor > 0) towerPumpFloor else "-"}  •  Best ${if (towerPumpBestStage > 0) towerPumpBestStage else "-"}"
            ),
            11.5f,
            "#E8EBF1",
            true
        ).apply { setPadding(dp(4), dp(5), dp(4), dp(4)) }
        towerPumpFloorView = towerFloor
        towerCard.addView(towerFloor, subLp())

        val towerMission = txt(
            tr(
                "Mission  ${if (towerPumpMissionOrder in 1..3) towerPumpMissionOrder else "-"} / 3",
                "Mission  ${if (towerPumpMissionOrder in 1..3) towerPumpMissionOrder else "-"} / 3"
            ),
            11.5f,
            "#E8EBF1",
            true
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
        towerPumpMissionView = towerMission
        towerCard.addView(towerMission, subLp())

        val towerState = txt(
            tr(
                "เงื่อนไข ${towerPumpRawCondition} • จบด่าน ${towerPumpSecondaryState} • สำเร็จ ${towerPumpFinalSuccess}",
                "Condition ${towerPumpRawCondition} • End ${towerPumpSecondaryState} • Success ${towerPumpFinalSuccess}"
            ),
            10f,
            "#AEB7C6",
            false
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
        towerPumpStateView = towerState
        towerCard.addView(towerState, subLp())

        val towerCommit = txt(
            tr(
                "Result/Commit ${towerPumpPendingCommit} • ดาวบันทึก ${towerPumpCompletedFlag}",
                "Result/Commit ${towerPumpPendingCommit} • Star saved ${towerPumpCompletedFlag}"
            ),
            10f,
            "#AEB7C6",
            false
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(10)) }
        towerPumpCommitView = towerCommit
        towerCard.addView(towerCommit, subLp())

        val towerActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        towerActions.addView(
            button(tr("อ่านสถานะ", "Read state"), towerPumpLabRunning) {
                if (!towerPumpLabRunning) runTowerPumpStateRead()
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }
        )
        towerActions.addView(
            button(
                if (towerPumpLabRunning) tr("ปิดปั้ม", "Stop pump")
                else tr("เปิดปั้ม", "Start pump"),
                false
            ) {
                runTowerPumpAutoPassToggle()
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) }
        )
        towerCard.addView(towerActions, subLp().apply { topMargin = dp(8) })
        towerCard.addView(
            txt(
                tr(
                    "เปิดปั้มแล้วกดเข้า Tower เอง • เข้า Stage ระบบเปิด ความเร็วพื้นฐานคุกกี้ + Giant + Super • ยังไม่แตะ Mission ระหว่างทาง • พอถึงประตู (จบด่าน=1) ค่อยปรับ Mission ให้เท่ากับเป้าหมาย แล้วปล่อยเกมเข้า Result เอง",
                    "Start the pump and enter Tower manually. In Stage, Cookie Base Speed + Giant + Super are enabled. Mission progress is untouched until the gate trigger; then it is normalized to the exact requirement and the game enters Result normally."
                ),
                8.5f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(8), dp(4), dp(2)) },
            subLp()
        )
        root.addView(towerCard, itemLp())

        root.addView(
            section(tr("กล่อง EP1 • LAB", "EP1 Mystery Box • LAB")),
            sectionLp()
        )

        val boxCard = featureCard()
        val boxStatus = txt(
            boxPumpSimpleStatus,
            10f,
            if (boxPumpLabRunning) "#FACC15" else "#D7DCE5",
            true
        ).apply { setPadding(dp(4), dp(2), dp(4), dp(8)) }
        boxPumpStatusView = boxStatus
        boxCard.addView(boxStatus, subLp())

        val boxRound = txt(
            tr(
                "รอบที่  ${if (boxPumpRound > 0) boxPumpRound else "-"}",
                "Round  ${if (boxPumpRound > 0) boxPumpRound else "-"}"
            ),
            12f,
            "#E8EBF1",
            true
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
        boxPumpRoundView = boxRound
        boxCard.addView(boxRound, subLp())

        val boxPhase = txt(
            "phase=$boxPumpPhase • Giant=${if (boxPumpOwnsGiant) "PUMP" else "USER/READY"}",
            9f,
            "#8F9AAC"
        ).apply { setPadding(dp(4), dp(4), dp(4), dp(8)) }
        boxPumpPhaseView = boxPhase
        boxCard.addView(boxPhase, subLp())

        val boxActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        boxActions.addView(
            button(
                tr("เปิดปั้ม", "Start pump"),
                !boxPumpLabRunning
            ) {
                if (!boxPumpLabRunning) runBoxPumpTwoRoundTest()
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }
        )
        boxActions.addView(
            button(
                tr("หยุด", "Stop"),
                boxPumpLabRunning
            ) {
                if (boxPumpLabRunning) requestBoxPumpLabStop()
            },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) }
        )
        boxCard.addView(boxActions, subLp().apply { topMargin = dp(8) })
        boxCard.addView(
            button(tr("คัดลอก Box Report", "Copy Box report"), false) {
                copyBoxPumpLabReport()
            },
            subLp().apply { topMargin = dp(8); height = dp(42) }
        )
        boxCard.addView(
            txt(
                tr(
                    "V2: เปิดปั้มไว้แล้วกดเข้า EP1 / กดเล่นเอง • ระบบเปิด Giant เท่านั้น • พอ Cookie เริ่มวิ่งจริงจะวาร์ป 38390 • รอ 5 วินาทีให้เก็บกล่องแล้วบังคับ HP=0 • Result/รับรางวัล/กดเล่นรอบใหม่ทำเอง • ระบบจะรอรอบถัดไปอัตโนมัติจนกดหยุด • ไม่แตะ Tower",
                    "V2: Start the pump, then enter EP1 and press Play manually. The Lab enables Giant only. When the Cookie is actually moving it warps to 38390, waits 5 seconds for pickup, forces HP to 0, and then leaves Result/reward/manual replay to you. It re-arms for each new run until stopped. Tower is untouched."
                ),
                8.5f,
                "#8F9AAC"
            ).apply { setPadding(dp(4), dp(8), dp(4), dp(2)) },
            subLp()
        )
        root.addView(boxCard, itemLp())

        // Never rebuild the whole tab for live progress. Refresh only the
        // bound TextViews while an Internal Lab worker is running.
        refreshPowderPumpLiveState()
        refreshTowerPumpLiveState()
        refreshBoxPumpLiveState()
    }

    private fun invokePowderPumpBackendString(methodName: String): String? {
        if (!BuildConfig.INTERNAL_BUILD) return null
        return try {
            val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
            val method = cls.getMethod(methodName)
            method.invoke(null)?.toString()
        } catch (_: Throwable) {
            null
        }
    }

    private fun recordPowderPumpBackendFailure(report: String) {
        if (!BuildConfig.INTERNAL_BUILD) return
        runCatching {
            val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
            val method = cls.getMethod("recordExternalFailure", String::class.java)
            method.invoke(null, report)
        }
    }

    private fun powderLiveValue(text: String, key: String): String? =
        Regex("(?m)^${Regex.escape(key)}=([^\\r\\n]+)$")
            .find(text)
            ?.groupValues
            ?.getOrNull(1)
            ?.trim()

    private fun refreshPowderPumpLiveState() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val live = invokePowderPumpBackendString("getLiveUiState") ?: return

        powderPumpTotalDraws =
            powderLiveValue(live, "totalBought")?.toIntOrNull()
                ?: powderPumpTotalDraws
        powderPumpTotalBroken =
            powderLiveValue(live, "totalBroken")?.toIntOrNull()
                ?: powderPumpTotalBroken
        powderPumpTotalPowder =
            powderLiveValue(live, "totalPowder")?.toLongOrNull()
                ?: powderPumpTotalPowder

        val running = powderLiveValue(live, "running") == "true"
        val phase = powderLiveValue(live, "phase") ?: "READY"
        powderPumpSimpleStatus = when (phase) {
            "BREAKING", "VERIFYING", "CLEANUP", "FINAL_CLEANUP" ->
                tr("กำลังย่อย...", "Breaking...")
            "STOP_REQUESTED" ->
                tr("กำลังหยุดหลังจบรอบนี้...", "Stopping after current batch...")
            "WAIT_CONNECTION_RETRY" ->
                tr("เสร็จแล้ว • กด Confirm ในเกม", "Complete • confirm the connection popup")
            "STOPPED" -> tr("หยุดแล้ว", "Stopped")
            "ERROR" -> tr("มีข้อผิดพลาด • ดู DEV", "Error • see DEV")
            "COMPLETE" -> tr("เสร็จแล้ว", "Complete")
            else -> if (running) tr("กำลังปั้ม...", "Running...") else powderPumpSimpleStatus
        }
        updatePowderPumpLiveViews()
        if (activeTab == Tab.DEV && menuVisible) {
            refreshPowderPumpDevDiagnostics()
        }
    }

    private fun updatePowderPumpLiveViews() {
        powderPumpStatusView?.text = powderPumpSimpleStatus
        powderPumpStatusView?.setTextColor(
            Color.parseColor(if (powderPumpLabRunning) "#FACC15" else "#D7DCE5")
        )
        powderPumpDrawsView?.text = tr(
            "สุ่มทั้งหมด  ${powderPumpTotalDraws} ครั้ง",
            "Total draws  ${powderPumpTotalDraws}"
        )
        powderPumpBrokenView?.text = tr(
            "ย่อยสำเร็จ  ${powderPumpTotalBroken} ชิ้น",
            "Broken  ${powderPumpTotalBroken}"
        )
        powderPumpPowderView?.text = tr(
            "ผงที่ได้รับ  +${powderPumpTotalPowder}",
            "Powder gained  +${powderPumpTotalPowder}"
        )
    }

    private fun startPowderPumpLiveRefresh() {
        stopPowderPumpLiveRefresh()
        val task = object : Runnable {
            override fun run() {
                refreshPowderPumpLiveState()
                if (powderPumpLabRunning) {
                    handler.postDelayed(this, 150L)
                }
            }
        }
        powderPumpLiveRefreshRunnable = task
        handler.postDelayed(task, 120L)
    }

    private fun stopPowderPumpLiveRefresh() {
        powderPumpLiveRefreshRunnable?.let { handler.removeCallbacks(it) }
        powderPumpLiveRefreshRunnable = null
    }

    private fun fetchPowderPumpDevDiagnostics(): String {
        if (!BuildConfig.INTERNAL_BUILD) return "INTERNAL_BUILD_REQUIRED"
        val nativeReport = invokePowderPumpBackendString("getDevDiagnostics")
            ?: "POWDER PUMP DEV • backend diagnostics unavailable"
        val serviceReport = powderPumpLabStatusText
        return if (
            serviceReport.isNotBlank() &&
            serviceReport != "READY • TURBO LAB" &&
            serviceReport != "TURBO • RUNNING" &&
            !nativeReport.contains(serviceReport.take(80))
        ) {
            buildString {
                appendLine(nativeReport)
                appendLine()
                appendLine("SERVICE LAST TEST REPORT")
                append(serviceReport)
            }
        } else {
            nativeReport
        }
    }

    private fun refreshPowderPumpDevDiagnostics() {
        if (!BuildConfig.INTERNAL_BUILD) return
        powderPumpDevDiagnosticsText = fetchPowderPumpDevDiagnostics()
        powderPumpDevDiagnosticsView?.text = powderPumpDevDiagnosticsText
    }

    private fun resetPowderPumpDevReport() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) {
            Toast.makeText(
                this,
                tr("หยุดปั้มก่อน Reset DEV", "Stop Pump before resetting DEV"),
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        val result = invokePowderPumpBackendString("resetDevReport")
            ?: "POWDER PUMP DEV • RESET_FAILED"
        powderPumpLabStatusText = "READY • TURBO LAB"
        powderPumpTotalDraws = 0
        powderPumpTotalBroken = 0
        powderPumpTotalPowder = 0L
        powderPumpSimpleStatus = tr("พร้อมใช้งาน", "Ready")
        refreshPowderPumpDevDiagnostics()
        updatePowderPumpLiveViews()
        Toast.makeText(this, result, Toast.LENGTH_SHORT).show()
    }

    private fun runPowderPumpTurbo() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) return

        powderPumpLabRunning = true
        powderPumpSimpleStatus = tr("กำลังปั้ม...", "Running...")
        powderPumpTotalDraws = 0
        powderPumpTotalBroken = 0
        powderPumpTotalPowder = 0L
        powderPumpLabStatusText = "TURBO • RUNNING"
        if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
        startPowderPumpLiveRefresh()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
                val method = cls.getMethod(
                    "runTurboUntilCoinExhausted",
                    Context::class.java
                )
                method.invoke(null, this)?.toString()
                    ?: "POWDER PUMP TURBO • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "POWDER PUMP TURBO FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            if (result.startsWith("POWDER PUMP TURBO FAILED")) {
                recordPowderPumpBackendFailure(result)
            }

            result.lineSequence().take(420).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("PUMP-TURBO", line)
            }

            handler.post {
                powderPumpLabRunning = false
                powderPumpLabStatusText = result
                stopPowderPumpLiveRefresh()
                refreshPowderPumpLiveState()
                refreshPowderPumpDevDiagnostics()

                powderPumpTotalDraws =
                    Regex("(?m)^\\s*bought=(\\d+)\\s*$")
                        .find(result)
                        ?.groupValues
                        ?.getOrNull(1)
                        ?.toIntOrNull()
                        ?: powderPumpTotalDraws

                powderPumpTotalBroken =
                    Regex("(?m)^\\s*broken=(\\d+)\\s*$")
                        .find(result)
                        ?.groupValues
                        ?.getOrNull(1)
                        ?.toIntOrNull()
                        ?: powderPumpTotalBroken

                powderPumpTotalPowder =
                    Regex("(?m)^\\s*verifiedPowderStartToEnd=(\\d+)\\s*$")
                        .find(result)
                        ?.groupValues
                        ?.getOrNull(1)
                        ?.toLongOrNull()
                        ?: Regex("(?m)^\\s*powderDelta=(\\d+)\\s*$")
                            .find(result)
                            ?.groupValues
                            ?.getOrNull(1)
                            ?.toLongOrNull()
                        ?: powderPumpTotalPowder

                powderPumpSimpleStatus = when {
                    result.contains("STOP_REASON=STOPPED_BY_USER") ->
                        tr("หยุดแล้ว", "Stopped")
                    result.contains("finalFlow=CONNECTION_RETRY_TRIGGER_DISPATCHED") ||
                        result.contains("finalFlow=SERVER_REJECT_ALREADY_SENT_BY_LAST_BUY") ->
                        tr("เสร็จแล้ว • กด Confirm ในเกม", "Complete • confirm the connection popup")
                    result.contains("TURBO_STOPPED_CLEANLY") ->
                        tr("เสร็จแล้ว", "Complete")
                    else ->
                        tr("มีข้อผิดพลาด • ดู DEV", "Error • see DEV")
                }

                updatePowderPumpLiveViews()
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)

                Toast.makeText(
                    this,
                    powderPumpSimpleStatus,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }, "MWOIF-POWDER-TURBO").start()
    }

    private fun runPowderPumpLabOneRound() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) return

        powderPumpLabRunning = true
        powderPumpLabStatusText =
            "RUNNING • SAFE PAGE V2\nกำลังหา Treasure Shop page → BUY Box1 → Wait → BREAK → Verify ..."
        if (activeTab == Tab.PUMP && menuVisible) renderTab(false)

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
                val method = cls.getMethod("runOneRound", Context::class.java)
                method.invoke(null, this)?.toString()
                    ?: "POWDER PUMP LAB • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "POWDER PUMP LAB FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            result.lineSequence().take(180).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("PUMP-LAB", line)
            }

            handler.post {
                powderPumpLabRunning = false
                powderPumpLabStatusText = result
                refreshPowderPumpDevDiagnostics()
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
                Toast.makeText(
                    this,
                    if (result.contains("ONE_AUTO_ROUND_VERIFIED")) {
                        tr("Powder Pump LAB ผ่าน 1 รอบ", "Powder Pump Lab passed one round")
                    } else {
                        tr("Powder Pump LAB ยังไม่ผ่าน • ดูรายงาน", "Powder Pump Lab needs review")
                    },
                    Toast.LENGTH_LONG
                ).show()
            }
        }, "MWOIF-POWDER-PUMP-LAB").start()
    }

    private fun runPowderPumpBurst10Experiment() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) return

        powderPumpLabRunning = true
        powderPumpLabStatusText =
            "EXPERIMENT C • BURST10\nกำลังยิง Normal Box1 x10 ติดกันโดยไม่รอ response ..."
        if (activeTab == Tab.PUMP && menuVisible) renderTab(false)

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
                val method = cls.getMethod(
                    "runBurst10Experiment",
                    Context::class.java
                )
                method.invoke(null, this)?.toString()
                    ?: "POWDER PUMP LAB BURST10 • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "POWDER PUMP LAB BURST10 FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            result.lineSequence().take(320).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("PUMP-C", line)
            }

            handler.post {
                powderPumpLabRunning = false
                powderPumpLabStatusText = result
                refreshPowderPumpDevDiagnostics()
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
                Toast.makeText(
                    this,
                    when {
                        result.contains("BURST10_ACCEPTED_AND_CLEANED") ->
                            tr("C ผ่าน • Server รับ BUY 10/10", "C passed • Server accepted 10/10")
                        result.contains("BURST10_PARTIAL_ACCEPT_CLEANED") ->
                            tr("C ได้บางส่วน • ดูรายงาน", "C partially accepted • see report")
                        else ->
                            tr("C ไม่ผ่าน/ต้องตรวจสอบ • ดูรายงาน", "C failed/review required • see report")
                    },
                    Toast.LENGTH_LONG
                ).show()
            }
        }, "MWOIF-POWDER-BURST10").start()
    }

    private fun runPowderPumpBurst10BatchExperiment() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) return

        powderPumpLabRunning = true
        powderPumpLabStatusText =
            "EXPERIMENT V8 • BATCH BREAK\nBUY x10 พร้อมกัน → รอของครบ 10 → ส่ง BREAK ก้อนเดียว ..."
        if (activeTab == Tab.PUMP && menuVisible) renderTab(false)

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
                val method = cls.getMethod(
                    "runBurst10BatchBreakExperiment",
                    Context::class.java
                )
                method.invoke(null, this)?.toString()
                    ?: "POWDER PUMP LAB BATCH • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "POWDER PUMP LAB BATCH FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            result.lineSequence().take(360).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("PUMP-BATCH", line)
            }

            handler.post {
                powderPumpLabRunning = false
                powderPumpLabStatusText = result
                refreshPowderPumpDevDiagnostics()
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
                Toast.makeText(
                    this,
                    when {
                        result.contains("BURST10_BATCH_BREAK_VERIFIED") ->
                            tr("V8 ผ่าน • Batch BREAK ทำงาน", "V8 passed • Batch BREAK works")
                        result.contains("BATCH_BUY_PARTIAL") ->
                            tr("V8 BUY ได้ไม่ครบ • ดูรายงาน", "V8 partial BUY • see report")
                        else ->
                            tr("V8 ต้องตรวจสอบ • ดูรายงาน", "V8 needs review • see report")
                    },
                    Toast.LENGTH_LONG
                ).show()
            }
        }, "MWOIF-POWDER-BATCH-V8").start()
    }

    private fun requestPowderPumpLabLoopStop() {
        if (!BuildConfig.INTERNAL_BUILD || !powderPumpLabRunning) return

        val result = try {
            val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
            val method = cls.getMethod("requestLoopStop")
            method.invoke(null)?.toString()
                ?: "POWDER PUMP LAB LOOP • STOP_REQUESTED"
        } catch (t: Throwable) {
            val root = t.cause ?: t
            "POWDER PUMP LAB STOP FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
        }

        powderPumpLabStatusText = result
        powderPumpSimpleStatus =
            tr("กำลังหยุดหลังจบรอบนี้...", "Stopping after current batch...")
        updatePowderPumpLiveViews()
        refreshPowderPumpDevDiagnostics()
        Toast.makeText(
            this,
            tr("รับคำสั่งหยุดแล้ว • จะหยุดหลังจบรอบนี้", "Stop requested • finishing current round"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun triggerPowderPumpConnectionRetry() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) return

        powderPumpLabStatusText = "CONNECTION RETRY • กำลังตรวจ Coin และเรียก game-owned flow ..."
        refreshPowderPumpDevDiagnostics()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
                val method = cls.getMethod(
                    "triggerConnectionRetry",
                    Context::class.java
                )
                method.invoke(null, this)?.toString()
                    ?: "POWDER PUMP CONNECTION • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "POWDER PUMP CONNECTION FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            handler.post {
                powderPumpLabStatusText = result
                refreshPowderPumpLiveState()
                refreshPowderPumpDevDiagnostics()
                Toast.makeText(
                    this,
                    when {
                        result.contains("CONNECTION_RETRY_TRIGGER_DISPATCHED") ->
                            tr("ส่ง Connection Retry แล้ว • กด Confirm ในเกม", "Connection Retry sent • confirm in game")
                        result.contains("BLOCKED_COIN_NOT_LOW") ->
                            tr("Coin ยังมากกว่า 5,000 • ไม่ยิง request", "Coin is still above 5,000 • request blocked")
                        else -> result.take(180)
                    },
                    Toast.LENGTH_LONG
                ).show()
            }
        }, "MWOIF-POWDER-CONNECTION-RETRY").start()
    }

    private fun cleanupPowderPumpLabRetain() {
        if (!BuildConfig.INTERNAL_BUILD || powderPumpLabRunning) return

        powderPumpLabStatusText = "CLEANUP • กำลังปล่อย deferred retain ..."
        refreshPowderPumpDevDiagnostics()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.PowderPumpLabBackend")
                val method = cls.getMethod("cleanup", Context::class.java)
                method.invoke(null, this)?.toString()
                    ?: "POWDER PUMP LAB CLEANUP • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "POWDER PUMP LAB CLEANUP FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            handler.post {
                powderPumpLabStatusText = result
                refreshPowderPumpDevDiagnostics()
                Toast.makeText(this, result.take(180), Toast.LENGTH_SHORT).show()
            }
        }, "MWOIF-POWDER-PUMP-CLEANUP").start()
    }

    private fun copyPowderPumpLabReport() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val clipboard = getSystemService(ClipboardManager::class.java)
        val report = fetchPowderPumpDevDiagnostics()
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif Lab Powder Pump", report)
        )
        Toast.makeText(
            this,
            tr("คัดลอกรายงาน Powder Pump แล้ว", "Powder Pump report copied"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun invokeTowerPumpBackendString(methodName: String): String? {
        if (!BuildConfig.INTERNAL_BUILD) return null
        return try {
            val cls = Class.forName("com.woif.modmenu.TowerPumpLabBackend")
            val method = cls.getMethod(methodName)
            method.invoke(null)?.toString()
        } catch (_: Throwable) {
            null
        }
    }

    private fun recordTowerPumpBackendFailure(report: String) {
        if (!BuildConfig.INTERNAL_BUILD) return
        runCatching {
            val cls = Class.forName("com.woif.modmenu.TowerPumpLabBackend")
            val method = cls.getMethod("recordExternalFailure", String::class.java)
            method.invoke(null, report)
        }
    }

    private fun towerLiveValue(text: String, key: String): String? =
        Regex("(?m)^${Regex.escape(key)}=([^\\r\\n]+)$")
            .find(text)
            ?.groupValues
            ?.getOrNull(1)
            ?.trim()

    private fun refreshTowerPumpLiveState() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val live = invokeTowerPumpBackendString("getLiveUiState") ?: return

        towerPumpLabRunning = towerLiveValue(live, "running") == "true"
        towerPumpFloor = towerLiveValue(live, "floor")?.toIntOrNull() ?: towerPumpFloor
        towerPumpMissionOrder =
            towerLiveValue(live, "missionOrder")?.toIntOrNull() ?: towerPumpMissionOrder
        towerPumpBestStage =
            towerLiveValue(live, "bestStage")?.toIntOrNull() ?: towerPumpBestStage
        towerPumpRawCondition =
            towerLiveValue(live, "rawCondition")?.toIntOrNull() ?: towerPumpRawCondition
        towerPumpSecondaryState =
            towerLiveValue(live, "secondaryState")?.toIntOrNull() ?: towerPumpSecondaryState
        towerPumpFinalSuccess =
            towerLiveValue(live, "finalSuccess")?.toIntOrNull() ?: towerPumpFinalSuccess
        towerPumpPendingCommit =
            towerLiveValue(live, "pendingCommit")?.toIntOrNull() ?: towerPumpPendingCommit
        towerPumpCompletedFlag =
            towerLiveValue(live, "completedFlag")?.toIntOrNull() ?: towerPumpCompletedFlag

        val phase = towerLiveValue(live, "phase") ?: "READY"
        val message = towerLiveValue(live, "message") ?: "พร้อมทดสอบ"
        towerPumpSimpleStatus = when (phase) {
            "ARMED_WAIT_RUNTIME" -> tr("ปั้มเปิด • รอเกม/Tower พร้อม", "Pump on • waiting for game/Tower")
            "ARMED_WAIT_STAGE" -> tr("ปั้มเปิด • กดเล่น Tower ได้เลย", "Pump on • enter a Tower stage")
            "WAIT_ACTIVE_MISSION" -> tr("เข้า Stage แล้ว • รอ Mission/Character พร้อม", "Stage entered • waiting for mission/character")
            "WAIT_RUN_START" -> tr("Stage โหลดแล้ว • รอ Cookie เริ่มวิ่งจริง", "Stage loaded • waiting for actual run start")
            "ARMED_WAIT_MISSION" -> tr("ปั้มเปิด • รอ Mission ใหม่", "Pump on • waiting for a fresh mission")
            "WAIT_WARP_READY" -> tr("Mission พร้อม • รอ Character พร้อมสำหรับ Warp", "Mission ready • waiting for character warp target")
            "WARP_AND_APPLY_MISSION" -> tr("กำลังวาร์ปหน้าประตู + ทำ Mission ให้ผ่าน", "Warping to exit + applying mission")
            "WARPED_MISSION_SET_WAIT_GATE" -> tr("วาร์ปแล้ว • Mission ตั้งเป้าครบ • รอ Gate/Result", "Warped • mission target set • waiting for gate/result")
            "MISSION_PASSED_WAIT_RESULT" -> tr("Mission ผ่านแล้ว • ปล่อยเกมเข้า Result", "Mission passed • letting the game enter Result")
            "RESULT_PENDING" -> tr("ถึง Result แล้ว • รอ Commit", "Result reached • waiting for commit")
            "STAR_COMMITTED_WAIT_NEXT", "STAR_COMMITTED", "ONE_STAR_COMMITTED" ->
                tr("ดาวบันทึกแล้ว • ไป Mission ถัดไปได้เลย", "Star committed • continue to the next mission")
            "MISSION_APPLY_RETRY" -> tr("วาร์ปแล้ว • กำลังลองตั้ง Mission อีกครั้ง", "Warped • retrying mission write")
            "STOPPED" -> tr("ปั้ม Tower ปิดอยู่", "Tower pump is off")
            "ERROR" -> tr("มีข้อผิดพลาด • ดู DEV", "Error • see DEV")
            else -> message
        }

        updateTowerThreeModAssistForPhase(phase)
        updateTowerPumpLiveViews()
        if (activeTab == Tab.DEV && menuVisible) {
            refreshTowerPumpDevDiagnostics()
        }
    }

    private fun updateTowerPumpLiveViews() {
        towerPumpStatusView?.text = towerPumpSimpleStatus
        towerPumpStatusView?.setTextColor(
            Color.parseColor(if (towerPumpLabRunning) "#FACC15" else "#D7DCE5")
        )
        towerPumpFloorView?.text = tr(
            "ด่านปัจจุบัน  ${if (towerPumpFloor > 0) towerPumpFloor else "-"}  •  ด่านสูงสุด ${if (towerPumpBestStage > 0) towerPumpBestStage else "-"}",
            "Current floor  ${if (towerPumpFloor > 0) towerPumpFloor else "-"}  •  Best ${if (towerPumpBestStage > 0) towerPumpBestStage else "-"}"
        )
        towerPumpMissionView?.text = tr(
            "Mission  ${if (towerPumpMissionOrder in 1..3) towerPumpMissionOrder else "-"} / 3",
            "Mission  ${if (towerPumpMissionOrder in 1..3) towerPumpMissionOrder else "-"} / 3"
        )
        towerPumpStateView?.text = tr(
            "เงื่อนไข ${towerPumpRawCondition} • จบด่าน ${towerPumpSecondaryState} • สำเร็จ ${towerPumpFinalSuccess}",
            "Condition ${towerPumpRawCondition} • End ${towerPumpSecondaryState} • Success ${towerPumpFinalSuccess}"
        )
        towerPumpCommitView?.text = tr(
            "Result/Commit ${towerPumpPendingCommit} • ดาวบันทึก ${towerPumpCompletedFlag}",
            "Result/Commit ${towerPumpPendingCommit} • Star saved ${towerPumpCompletedFlag}"
        )
    }

    private fun startTowerPumpLiveRefresh() {
        stopTowerPumpLiveRefresh()
        val task = object : Runnable {
            override fun run() {
                refreshTowerPumpLiveState()
                if (towerPumpLabRunning) {
                    handler.postDelayed(this, 200L)
                }
            }
        }
        towerPumpLiveRefreshRunnable = task
        handler.postDelayed(task, 120L)
    }

    private fun stopTowerPumpLiveRefresh() {
        towerPumpLiveRefreshRunnable?.let { handler.removeCallbacks(it) }
        towerPumpLiveRefreshRunnable = null
    }

    private fun startTowerThreeModAssist() {
        if (!BuildConfig.INTERNAL_BUILD || towerThreeModAssistActive) return

        if (autoMaster) {
            towerThreeModAssistStatus = "SKIP • AUTO master is active"
            return
        }

        towerThreeModOwnsBaseSpeed = !baseSpeedOn
        towerThreeModOwnsGiant = !giantOn
        towerThreeModOwnsSuper = !superOn
        towerThreeModAssistActive = true
        towerThreeModAssistStatus = buildString {
            append("STARTING")
            append(" • BaseSpeed x")
            append(baseSpeedMultiplier)
            append(" • Giant • Super")
        }

        // Explicitly approved Tower assist only. Never call GameSpeedMod here.
        if (towerThreeModOwnsBaseSpeed) {
            setBaseSpeedEnabled(true)
        }
        if (towerThreeModOwnsGiant) {
            setNativeManualEnabled(CrgProfile.FEATURE_GIANT, true)
        }
        if (towerThreeModOwnsSuper) {
            setNativeManualEnabled(CrgProfile.FEATURE_SUPER, true)
        }

        towerThreeModAssistStatus = buildString {
            append("ACTIVE")
            append(" • BaseSpeed=")
            append(if (baseSpeedOn) "ON" else "REQUESTED")
            append(" x")
            append(baseSpeedMultiplier)
            append(" • Giant=")
            append(if (giantOn) "ON" else "REQUESTED")
            append(" • Super=")
            append(if (superOn) "ON" else "REQUESTED")
        }
    }

    private fun stopTowerThreeModAssist(reason: String) {
        if (!towerThreeModAssistActive) return

        val disableBase = towerThreeModOwnsBaseSpeed
        val disableGiant = towerThreeModOwnsGiant
        val disableSuper = towerThreeModOwnsSuper

        towerThreeModAssistActive = false
        towerThreeModOwnsBaseSpeed = false
        towerThreeModOwnsGiant = false
        towerThreeModOwnsSuper = false
        towerThreeModAssistStatus = "RESTORING • $reason"

        // Restore only features Tower Pump itself turned on. User-owned ON
        // states are preserved exactly.
        if (disableBase && baseSpeedOn) {
            setBaseSpeedEnabled(false)
        }
        if (disableGiant && giantOn) {
            setNativeManualEnabled(CrgProfile.FEATURE_GIANT, false)
        }
        if (disableSuper && superOn) {
            setNativeManualEnabled(CrgProfile.FEATURE_SUPER, false)
        }

        towerThreeModAssistStatus = "RESTORED • $reason"
    }

    private fun updateTowerThreeModAssistForPhase(phase: String) {
        if (!BuildConfig.INTERNAL_BUILD) return

        // V2.0 Warp mode never enables Cookie Base Speed / Giant / Super.
        // If an older Lab run left Tower-owned assist state active, restore it.
        if (towerThreeModAssistActive) {
            stopTowerThreeModAssist("WARP_MODE_DISABLED")
        }
        towerThreeModAssistStatus = "DISABLED_FOR_WARP_MODE • phase=$phase"
    }

    private fun fetchTowerPumpDevDiagnostics(): String {
        if (!BuildConfig.INTERNAL_BUILD) return "TOWER PUMP DEV • INTERNAL_BUILD_REQUIRED"
        val backend = invokeTowerPumpBackendString("getDevDiagnostics")
            ?: "TOWER PUMP DEV • backend diagnostics unavailable"
        return buildString {
            appendLine(backend)
            appendLine()
            appendLine("[TOWER WARP MODE]")
            appendLine("threeModAssist=DISABLED")
            appendLine("gameSpeedControl=DISABLED_FOR_TOWER")
            appendLine("warpRoute=Character+0x78->Object+0x30")
            appendLine("activeLegacyAssist=$towerThreeModAssistActive")
            append("status=$towerThreeModAssistStatus")
        }
    }

    private fun refreshTowerPumpDevDiagnostics() {
        if (!BuildConfig.INTERNAL_BUILD) return
        towerPumpDevDiagnosticsText = fetchTowerPumpDevDiagnostics()
        towerPumpDevDiagnosticsView?.text = towerPumpDevDiagnosticsText
    }

    private fun runTowerPumpStateRead() {
        if (!BuildConfig.INTERNAL_BUILD || towerPumpLabRunning) return

        towerPumpLabRunning = true
        towerPumpSimpleStatus = tr("กำลังอ่านสถานะ Tower...", "Reading Tower state...")
        updateTowerPumpLiveViews()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.TowerPumpLabBackend")
                val method = cls.getMethod("refreshState", Context::class.java)
                method.invoke(null, this)?.toString()
                    ?: "TOWER LAB STATE • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "TOWER LAB STATE FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            if (result.contains("FAILED") || result.contains("RESULT=ERROR")) {
                recordTowerPumpBackendFailure(result)
            }
            result.lineSequence().take(220).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("TOWER", line)
            }

            handler.post {
                towerPumpLabRunning = false
                refreshTowerPumpLiveState()
                refreshTowerPumpDevDiagnostics()
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
                Toast.makeText(
                    this,
                    if (result.contains("RESULT=ERROR") || result.contains("FAILED")) {
                        tr("อ่าน Tower ไม่ผ่าน • ดู DEV", "Tower read failed • see DEV")
                    } else {
                        tr("อ่านสถานะ Tower แล้ว", "Tower state read")
                    },
                    Toast.LENGTH_LONG
                ).show()
            }
        }, "MWOIF-TOWER-STATE").start()
    }

    private fun runTowerPumpAutoPassToggle() {
        if (!BuildConfig.INTERNAL_BUILD) return

        val wasRunning = towerPumpLabRunning
        towerPumpSimpleStatus = if (wasRunning) {
            tr("กำลังปิด Tower Warp Pump...", "Stopping Tower Warp Pump...")
        } else {
            tr("กำลังเปิด Tower Warp Pump...", "Starting Tower Warp Pump...")
        }
        updateTowerPumpLiveViews()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.TowerPumpLabBackend")
                if (wasRunning) {
                    val method = cls.getMethod("stopAutoPass")
                    method.invoke(null)?.toString()
                        ?: "TOWER AUTO PASS • stop returned empty"
                } else {
                    val method = cls.getMethod("startAutoPass", Context::class.java)
                    method.invoke(null, this)?.toString()
                        ?: "TOWER AUTO PASS • start returned empty"
                }
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "TOWER AUTO PASS FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            if (result.contains("FAILED") || result.contains("RESULT=ERROR")) {
                recordTowerPumpBackendFailure(result)
            }
            result.lineSequence().take(260).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("TOWER", line)
            }

            handler.post {
                refreshTowerPumpLiveState()
                if (!towerPumpLabRunning) stopTowerThreeModAssist("PUMP_STOPPED")
                refreshTowerPumpDevDiagnostics()

                if (towerPumpLabRunning) startTowerPumpLiveRefresh()
                else stopTowerPumpLiveRefresh()

                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
                if (activeTab == Tab.DEV && menuVisible) renderTab(false)

                Toast.makeText(
                    this,
                    if (result.contains("RESULT=ERROR") || result.contains("FAILED")) {
                        tr("Tower Warp Pump มีข้อผิดพลาด • ดู DEV", "Tower Warp Pump error • see DEV")
                    } else if (towerPumpLabRunning) {
                        tr("เปิดปั้มแล้ว • กดเข้า Tower Stage เองได้เลย", "Pump enabled • enter a Tower stage manually")
                    } else {
                        tr("ปิด Tower Warp Pump แล้ว", "Tower Warp Pump stopped")
                    },
                    Toast.LENGTH_LONG
                ).show()
            }
        }, "MWOIF-TOWER-AUTO-PASS-TOGGLE").start()
    }

    private fun runTowerPumpOneStarTest() {
        if (!BuildConfig.INTERNAL_BUILD || towerPumpLabRunning) return

        towerPumpLabRunning = true
        towerPumpSimpleStatus = tr("กำลังทดสอบ Tower 1 ดาว...", "Testing one Tower star...")
        updateTowerPumpLiveViews()
        startTowerPumpLiveRefresh()

        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.TowerPumpLabBackend")
                val method = cls.getMethod("runOneStarTest", Context::class.java)
                method.invoke(null, this)?.toString()
                    ?: "TOWER LAB ONE STAR • empty result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "TOWER LAB ONE STAR FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            if (result.contains("FAILED") || result.contains("RESULT=ERROR")) {
                recordTowerPumpBackendFailure(result)
            }
            result.lineSequence().take(360).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("TOWER", line)
            }

            handler.post {
                stopTowerPumpLiveRefresh()
                towerPumpLabRunning = false
                refreshTowerPumpLiveState()
                refreshTowerPumpDevDiagnostics()
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)

                val toast = when {
                    result.contains("ONE_STAR_COMMITTED") ->
                        tr("Tower LAB ผ่าน • ดาวถูกบันทึกจริง", "Tower Lab passed • star committed")
                    result.contains("RESULT_ROUTE_REACHED_WAIT_COMMIT") ->
                        tr("ถึง Result แล้ว • กลับหน้า Tower แล้วอ่านสถานะอีกครั้ง", "Result reached • return to Tower and read state")
                    result.contains("SUCCESS_STATE_ONLY_NEEDS_FINISH_ROUTE") ->
                        tr("Mission Success ผ่าน • ยังต้องหา Fast Stage Finish", "Mission success works • fast stage finish still needed")
                    else -> tr("Tower LAB ยังไม่ผ่าน • ดู DEV", "Tower Lab needs review • see DEV")
                }
                Toast.makeText(this, toast, Toast.LENGTH_LONG).show()
            }
        }, "MWOIF-TOWER-ONE-STAR").start()
    }

    private fun resetTowerPumpDevReport() {
        if (!BuildConfig.INTERNAL_BUILD || towerPumpLabRunning) return

        val result = invokeTowerPumpBackendString("resetDevReport")
            ?: "TOWER PUMP DEV • RESET_FAILED"
        towerPumpSimpleStatus = "ปั้มปิดอยู่ • เปิดปั้มแล้วกดเข้า Tower Stage เอง"
        towerPumpFloor = 0
        towerPumpMissionOrder = 0
        towerPumpBestStage = 0
        towerPumpRawCondition = 0
        towerPumpSecondaryState = 0
        towerPumpFinalSuccess = 0
        towerPumpPendingCommit = 0
        towerPumpCompletedFlag = 0
        refreshTowerPumpDevDiagnostics()
        updateTowerPumpLiveViews()
        Toast.makeText(this, result.take(180), Toast.LENGTH_SHORT).show()
    }

    private fun copyTowerPumpLabReport() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val clipboard = getSystemService(ClipboardManager::class.java)
        val report = fetchTowerPumpDevDiagnostics()
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif Lab Tower Pump", report)
        )
        Toast.makeText(
            this,
            tr("คัดลอกรายงาน Tower Pump แล้ว", "Tower Pump report copied"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun invokeBoxPumpBackendString(methodName: String): String? {
        if (!BuildConfig.INTERNAL_BUILD) return null
        return try {
            val cls = Class.forName("com.woif.modmenu.BoxPumpLabBackend")
            val method = cls.getMethod(methodName)
            method.invoke(null)?.toString()
        } catch (_: Throwable) {
            null
        }
    }

    private fun boxLiveValue(text: String, key: String): String? =
        Regex("(?m)^${Regex.escape(key)}=([^\r\n]+)$")
            .find(text)
            ?.groupValues
            ?.getOrNull(1)
            ?.trim()

    private fun refreshBoxPumpLiveState() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val live = invokeBoxPumpBackendString("getLiveUiState") ?: return
        val wasRunning = boxPumpLabRunning

        boxPumpLabRunning = boxLiveValue(live, "running") == "true"
        boxPumpRound = boxLiveValue(live, "round")?.toIntOrNull() ?: boxPumpRound
        boxPumpPhase = boxLiveValue(live, "phase") ?: boxPumpPhase
        val message = boxLiveValue(live, "message") ?: boxPumpSimpleStatus

        boxPumpSimpleStatus = when (boxPumpPhase) {
            "ARMED" -> tr("Box Pump พร้อม • กดเข้า EP1 เอง", "Box Pump armed • enter EP1 manually")
            "WAIT_MANUAL_RUN" -> tr("รอกดเล่น EP1 เอง", "Waiting for manual EP1 run")
            "GIANT_SETTLE" -> tr("เริ่มวิ่งแล้ว • รอ Giant ติด", "Run started • waiting for Giant")
            "WARP_PREBOX" -> tr("วาร์ปไปกล่อง 38390", "Warping to box point 38390")
            "PICKUP_DWELL" -> tr("รอเก็บกล่อง 5 วินาที", "Waiting 5 seconds for pickup")
            "FORCE_DEATH" -> tr("บังคับ HP=0", "Forcing HP=0")
            "WAIT_DEATH" -> tr("HP=0 • รอเกมตาย", "HP=0 • waiting for death")
            "WAIT_MANUAL_REWARD" -> tr("รับรางวัลเอง แล้วกดเล่นใหม่", "Collect reward manually, then play again")
            "STOP_REQUESTED" -> tr("กำลังหยุด Box Pump", "Stopping Box Pump")
            "STOPPED" -> tr("Box Pump หยุดแล้ว", "Box Pump stopped")
            "ERROR" -> tr("Box Pump ไม่ผ่าน • Copy Report", "Box Pump failed • Copy Report")
            else -> message
        }

        updateBoxPumpLiveViews()

        if (wasRunning && !boxPumpLabRunning) {
            releaseBoxPumpOwnedGiant("LAB_FINISHED")
        }
    }

    private fun updateBoxPumpLiveViews() {
        boxPumpStatusView?.text = boxPumpSimpleStatus
        boxPumpStatusView?.setTextColor(
            Color.parseColor(if (boxPumpLabRunning) "#FACC15" else "#D7DCE5")
        )
        boxPumpRoundView?.text = tr(
            "รอบที่  ${if (boxPumpRound > 0) boxPumpRound else "-"}",
            "Round  ${if (boxPumpRound > 0) boxPumpRound else "-"}"
        )
        boxPumpPhaseView?.text =
            "phase=$boxPumpPhase • Giant=${if (boxPumpOwnsGiant) "PUMP" else "USER/READY"}"
    }

    private fun startBoxPumpLiveRefresh() {
        stopBoxPumpLiveRefresh()
        val task = object : Runnable {
            override fun run() {
                refreshBoxPumpLiveState()
                if (boxPumpLabRunning) {
                    handler.postDelayed(this, 250L)
                } else {
                    if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
                }
            }
        }
        boxPumpLiveRefreshRunnable = task
        handler.postDelayed(task, 120L)
    }

    private fun stopBoxPumpLiveRefresh() {
        boxPumpLiveRefreshRunnable?.let { handler.removeCallbacks(it) }
        boxPumpLiveRefreshRunnable = null
    }

    private fun startBoxPumpBackendAfterGiantReady() {
        Thread({
            val result = try {
                val cls = Class.forName("com.woif.modmenu.BoxPumpLabBackend")
                val method = cls.getMethod("startManualLoop", Context::class.java)
                method.invoke(null, this)?.toString()
                    ?: "BOX PUMP LAB • empty start result"
            } catch (t: Throwable) {
                val root = t.cause ?: t
                "BOX PUMP LAB FAILED • ${root.javaClass.simpleName}: ${root.message ?: "unknown"}"
            }

            result.lineSequence().take(120).forEach { line ->
                if (line.isNotBlank()) DevConsole.log("BOX", line)
            }

            handler.post {
                refreshBoxPumpLiveState()
                if (boxPumpLabRunning) {
                    startBoxPumpLiveRefresh()
                } else {
                    releaseBoxPumpOwnedGiant("START_FAILED")
                }
                if (activeTab == Tab.PUMP && menuVisible) renderTab(false)
            }
        }, "MWOIF-BOX-PUMP-START").start()
    }

    private fun runBoxPumpTwoRoundTest() {
        if (!BuildConfig.INTERNAL_BUILD || boxPumpLabRunning) return

        if (autoMaster) {
            Toast.makeText(
                this,
                tr("ปิด AUTO Master ก่อนทดสอบ Box Pump", "Turn AUTO Master off before Box Pump Lab"),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (!::nativeEffectMod.isInitialized) {
            Toast.makeText(this, tr("Giant backend ยังไม่พร้อม", "Giant backend is not ready"), Toast.LENGTH_LONG).show()
            return
        }

        if (hpOn || hpAutoOwned || (::hpMod.isInitialized && hpMod.isEnabled())) {
            Toast.makeText(
                this,
                tr("ปิดอมตะ / HP Protection ก่อนเปิดปั้มกล่อง", "Turn off HP Protection before starting Box Pump"),
                Toast.LENGTH_LONG
            ).show()
            return
        }

        boxPumpSimpleStatus = tr("กำลังเตรียม Giant...", "Preparing Giant...")
        boxPumpRound = 0
        boxPumpPhase = "PREPARE_GIANT"
        updateBoxPumpLiveViews()

        if (nativeEffectMod.isEnabled(CrgProfile.FEATURE_GIANT)) {
            boxPumpOwnsGiant = false
            startBoxPumpBackendAfterGiantReady()
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GIANT)) {
            boxPumpSimpleStatus = tr("Giant ถูกปิดจาก Control Plane", "Giant is blocked by Control Plane")
            updateBoxPumpLiveViews()
            return
        }

        withNativeProfile(CrgProfile.FEATURE_GIANT) { profile, errorText ->
            handler.post {
                if (profile == null) {
                    boxPumpSimpleStatus = errorText ?: tr("Giant Profile ยังไม่พร้อม", "Giant profile not ready")
                    updateBoxPumpLiveViews()
                    return@post
                }

                nativeEffectMod.enable(profile) { result ->
                    handler.post inner@{
                        if (!result.ok || !nativeEffectMod.isEnabled(CrgProfile.FEATURE_GIANT)) {
                            boxPumpSimpleStatus = nativeEffectResultText(CrgProfile.FEATURE_GIANT, result)
                            boxPumpOwnsGiant = false
                            updateBoxPumpLiveViews()
                            return@inner
                        }

                        boxPumpOwnsGiant = true
                        boxPumpSimpleStatus = tr("Giant พร้อม • ปั้มรอให้กดเข้า EP1", "Giant ready • pump waiting for manual EP1")
                        updateBoxPumpLiveViews()
                        startBoxPumpBackendAfterGiantReady()
                    }
                }
            }
        }
    }

    private fun requestBoxPumpLabStop() {
        if (!BuildConfig.INTERNAL_BUILD) return
        runCatching {
            val cls = Class.forName("com.woif.modmenu.BoxPumpLabBackend")
            val method = cls.getMethod("requestStop")
            val result = method.invoke(null)?.toString() ?: "BOX PUMP LAB • stop empty"
            DevConsole.log("BOX", result)
        }
        boxPumpSimpleStatus = tr("กำลังหยุด Box Pump...", "Stopping Box Pump...")
        updateBoxPumpLiveViews()
        startBoxPumpLiveRefresh()
    }

    private fun releaseBoxPumpOwnedGiant(reason: String) {
        if (!boxPumpOwnsGiant || !::nativeEffectMod.isInitialized) return
        boxPumpOwnsGiant = false
        nativeEffectMod.disable(CrgProfile.FEATURE_GIANT) { result ->
            handler.post {
                DevConsole.log("BOX", "GIANT_RELEASE reason=$reason ok=${result.ok} ${result.message}")
                updateBoxPumpLiveViews()
            }
        }
    }

    private fun fetchBoxPumpDevDiagnostics(): String {
        if (!BuildConfig.INTERNAL_BUILD) return "BOX PUMP DEV • INTERNAL_BUILD_REQUIRED"
        return invokeBoxPumpBackendString("getDevDiagnostics")
            ?: "BOX PUMP DEV • backend diagnostics unavailable"
    }

    private fun copyBoxPumpLabReport() {
        if (!BuildConfig.INTERNAL_BUILD) return
        val report = fetchBoxPumpDevDiagnostics()
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(
            ClipData.newPlainText("M Woif Lab EP1 Box Pump", report)
        )
        Toast.makeText(
            this,
            tr("คัดลอก Box Pump Report แล้ว", "Box Pump report copied"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun settings(root: LinearLayout) {
        root.addView(pageTitle(tr("ตั้งค่า", "Settings"), tr("ภาษา ขนาด และการแสดงผล", "Language, size and display")))

        root.addView(section(tr("ภาษา", "LANGUAGE")), sectionLp())
        val langCard = card()
        langCard.addView(txt(tr("ภาษาแสดงผล", "Display Language"), 12f, "#E8EBF1", true))
        langCard.addView(
            choices(listOf("ไทย", "English"), if (language == EN) 1 else 0) { i ->
                language = if (i == 1) EN else TH
                prefs.edit().putString(P_LANG, language).apply()
                rebuildMenu()
            },
            subLp()
        )
        root.addView(langCard, itemLp())

        root.addView(section(tr("การแสดงผล", "DISPLAY")), sectionLp())
        val display = card()

        display.addView(txt(tr("ขนาดเมนู", "Menu Size"), 12f, "#E8EBF1", true))
        display.addView(
            choices(sizeLabels(), sizeIndex(menuSize)) { i ->
                menuSize = sizeFromIndex(i)
                prefs.edit().putString(P_MENU_SIZE, menuSize).apply()
                applyMenuSize()
                renderTab()
            },
            subLp()
        )

        display.addView(divider(14, 14))
        display.addView(txt(tr("ขนาดปุ่ม W", "W Button Size"), 12f, "#E8EBF1", true))
        display.addView(
            choices(sizeLabels(), sizeIndex(wSize)) { i ->
                wSize = sizeFromIndex(i)
                prefs.edit().putString(P_W_SIZE, wSize).apply()
                applyWSize()
                renderTab()
            },
            subLp()
        )

        display.addView(divider(14, 10))
        display.addView(settingToggle(tr("แสดงเวลาคงเหลือ", "Show countdown"), showCountdown) {
            showCountdown = it
            prefs.edit().putBoolean(P_SHOW_TIME, it).apply()
            updateCountdown()
        })
        display.addView(settingToggle(tr("แสดงสถานะออนไลน์", "Show online status"), showOnline) {
            showOnline = it
            prefs.edit().putBoolean(P_SHOW_ONLINE, it).apply()
            updateCountdown()
        })

        root.addView(display, itemLp())

        root.addView(section(tr("ตำแหน่ง", "POSITION")), sectionLp())
        val pos = card()
        pos.addView(button(tr("รีเซ็ตตำแหน่ง M Woif MOD", "Reset M Woif MOD position"), false) { resetMenuPosition() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        pos.addView(button(tr("รีเซ็ตตำแหน่ง W", "Reset W position"), false) { resetWPosition() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)).apply { topMargin = dp(8) })
        root.addView(pos, itemLp())

        root.addView(section(tr("การเข้าสู่ระบบ", "LOGIN")), sectionLp())
        val login = card()
        login.addView(settingToggle(tr("จดจำ Key", "Remember Key"), rememberKey) {
            rememberKey = it
            prefs.edit().putBoolean(P_REMEMBER, it).apply()
        })
        login.addView(txt(
            tr(
                "จำ Key ไม่ใช่ Auto Login — ยังต้องกด LOGIN ใหม่ทุกครั้ง",
                "Remember Key is not Auto Login — LOGIN is still required every launch"
            ),
            9f,
            "#697486"
        ).apply { setPadding(0, dp(9), 0, 0) })
        root.addView(login, itemLp())

        root.addView(section(tr("เกี่ยวกับ", "ABOUT")), sectionLp())
        val about = card()
        about.addView(info(brandMenuName(), "v${BuildConfig.VERSION_NAME}", "#A998FF"))
        about.addView(divider())
        about.addView(
            info(
                "CookieRun Classic",
                SessionManager.snapshot()?.gameVersion ?: "unknown",
                "#DDE2EA"
            )
        )
        root.addView(about, itemLp())
    }

    // ---------------------------------------------------------------------
    // Manual / AUTO ownership
    // ---------------------------------------------------------------------

    private fun setAutoMaster(enabled: Boolean) {
        if (enabled == autoMaster) {
            syncAutoMasterUi(forceQuick = true)
            return
        }

        if (enabled && !ControlPlaneState.canWrite()) {
            autoMaster = false
            syncAutoMasterUi(forceQuick = true)
            hpStatusText = controlBlockedText(CrgProfile.FEATURE_HP)
            renderTab()
            return
        }

        if (enabled) {
            val manualSpeed = speedOn
            val manualHp = hpOn
            val manualGiant = giantOn
            val manualGiantSize =
                giantSizeOn ||
                    (::nativeEffectMod.isInitialized &&
                        nativeEffectMod.devGiantSizeFastLockIsEnabled())
            val manualSuper = superOn
            val manualPower = powerOn
            val manualXp = xpOn
            val manualCoin = coinOn
            val manualBaseSpeed = baseSpeedOn
            val manualPitLift = pitLiftOn
            val manualRevive = reviveOn
            val manualJump = unlimitedJumpOn
            val manualPotatoCoin = potatoCoinOn
            val manualPotatoRapid = potatoRapidOn
            val manualUltimate = potatoUltimateOn

            resetManualPlayStates()
            autoMaster = true

            autoSelected.keys.forEach { key ->
                if (!isAutoKeyAvailable(key)) autoSelected[key] = false
            }
            saveAutoSelection()

            transitionSpeedToAuto(manualSpeed)

            if (manualHp && ::hpMod.isInitialized) {
                hpMod.disable { if (autoSelected["HP"] == true) setHpAutoEnabled(true) }
            } else if (autoSelected["HP"] == true) setHpAutoEnabled(true)

            transitionNativeToAuto(CrgProfile.FEATURE_GIANT, "GIANT", manualGiant)
            transitionGiantSizeToAuto(manualGiantSize)
            transitionNativeToAuto(CrgProfile.FEATURE_SUPER, "SUPER", manualSuper)

            if (manualPower && ::powerPlusMod.isInitialized) {
                powerPlusMod.disable { if (autoSelected["POWER"] == true) setPowerAutoEnabled(true) }
            } else if (autoSelected["POWER"] == true) setPowerAutoEnabled(true)

            if (manualXp || autoSelected["XP"] == true) setXpAutoEnabled(autoSelected["XP"] == true)
            if (manualCoin || autoSelected["COIN"] == true) setCoinAutoEnabled(autoSelected["COIN"] == true)

            transitionBaseSpeedToAuto(manualBaseSpeed)
            transitionRecoveryToAuto("PIT_LIFT", manualPitLift)
            transitionRecoveryToAuto("REVIVE", manualRevive)
            transitionJumpToAuto(manualJump)
            transitionPotatoCoinToAuto(manualPotatoCoin)
            transitionPotatoRapidToAuto(manualPotatoRapid)

            if (manualUltimate || autoSelected["ULTIMATE"] == true) {
                setPotatoUltimateAutoEnabled(autoSelected["ULTIMATE"] == true)
            }
        } else {
            autoMaster = false
            stopAllAutoOwned()
            resetManualPlayStates()
        }

        syncAutoMasterUi(forceQuick = true)
    }

    private fun syncAutoMasterUi(forceQuick: Boolean = false) {
        autoMasterToggleView?.let {
            styleToggle(it, autoMaster)
        }

        updateQuickModButtonState(
            force = forceQuick
        )
    }

    private fun applyAllSelectedAuto() {
        autoSelected.forEach { (key, selected) ->
            applyAutoKey(key, selected)
        }
    }

    private fun stopAllAutoOwned() {
        if (speedAutoOwned) setSpeedAutoEnabled(false)
        if (hpAutoOwned) setHpAutoEnabled(false)
        if (
            giantSizeAutoOwned ||
            (::nativeEffectMod.isInitialized &&
                nativeEffectMod.devGiantSizeFastLockIsEnabled())
        ) {
            setGiantSizeAutoEnabled(false)
        }
        if (giantAutoOwned) setNativeAutoEnabled(CrgProfile.FEATURE_GIANT, false)
        if (superAutoOwned) setNativeAutoEnabled(CrgProfile.FEATURE_SUPER, false)
        if (powerAutoOwned) setPowerAutoEnabled(false)
        if (xpAutoOwned) setXpAutoEnabled(false)
        if (coinAutoOwned) setCoinAutoEnabled(false)
        if (baseSpeedAutoOwned) setBaseSpeedAutoEnabled(false)
        if (pitLiftAutoOwned) setPitLiftAutoEnabled(false)
        if (reviveAutoOwned) setReviveAutoEnabled(false)
        if (unlimitedJumpAutoOwned) setUnlimitedJumpAutoEnabled(false)
        if (potatoCoinAutoOwned) setPotatoCoinAutoEnabled(false)
        if (potatoRapidAutoOwned) setPotatoRapidAutoEnabled(false)
        if (potatoUltimateAutoOwned) setPotatoUltimateAutoEnabled(false)
    }

    private fun applyAutoKey(key: String, enabled: Boolean) {
        if (enabled && !isAutoKeyAvailable(key)) {
            autoSelected[key] = false
            saveAutoSelection()
            return
        }
        when (key) {
            "SPEED" -> setSpeedAutoEnabled(enabled)
            "HP" -> setHpAutoEnabled(enabled)
            "GIANT" -> setNativeAutoEnabled(CrgProfile.FEATURE_GIANT, enabled)
            "GIANT_SIZE" -> setGiantSizeAutoEnabled(enabled)
            "SUPER" -> setNativeAutoEnabled(CrgProfile.FEATURE_SUPER, enabled)
            "POWER" -> setPowerAutoEnabled(enabled)
            "XP" -> setXpAutoEnabled(enabled)
            "COIN" -> setCoinAutoEnabled(enabled)
            "BASE_SPEED" -> setBaseSpeedAutoEnabled(enabled)
            "PIT_LIFT" -> setPitLiftAutoEnabled(enabled)
            "REVIVE" -> setReviveAutoEnabled(enabled)
            "UNLIMITED_JUMP" -> setUnlimitedJumpAutoEnabled(enabled)
            "POTATO_COIN" -> setPotatoCoinAutoEnabled(enabled)
            "POTATO_RAPID" -> setPotatoRapidAutoEnabled(enabled)
            "ULTIMATE" -> setPotatoUltimateAutoEnabled(enabled)
        }
    }

    private fun transitionSpeedToAuto(manualWasOn: Boolean) {
        if (!::gameSpeedMod.isInitialized) return
        if (manualWasOn) {
            gameSpeedMod.disable { if (autoSelected["SPEED"] == true) setSpeedAutoEnabled(true) }
        } else if (autoSelected["SPEED"] == true) setSpeedAutoEnabled(true)
    }

    private fun setSpeedAutoEnabled(enable: Boolean) {
        if (!::gameSpeedMod.isInitialized) return
        if (!enable) {
            speedAutoOwned = false
            gameSpeedMod.disable { result -> handler.post { gameSpeedStatusText = result.message } }
            return
        }
        if (!isAutoKeyAvailable("SPEED")) {
            speedAutoOwned = false
            autoSelected["SPEED"] = false
            return
        }
        gameSpeedMod.enable(speed.toFloat()) { result ->
            handler.post {
                speedAutoOwned = result.ok
                gameSpeedStatusText = result.message
                if (activeTab == Tab.AUTO && menuVisible) renderTab()
            }
        }
    }

    private fun transitionNativeToAuto(featureId: String, key: String, manualWasOn: Boolean) {
        if (!::nativeEffectMod.isInitialized) return
        if (manualWasOn) {
            nativeEffectMod.disable(featureId) {
                if (autoSelected[key] == true) setNativeAutoEnabled(featureId, true)
            }
        } else if (autoSelected[key] == true) setNativeAutoEnabled(featureId, true)
    }

    private fun transitionGiantSizeToAuto(manualWasOn: Boolean) {
        if (!::nativeEffectMod.isInitialized) return

        if (manualWasOn && nativeEffectMod.devGiantSizeFastLockIsEnabled()) {
            nativeEffectMod.devGiantSizeFastLockDisable {
                handler.post {
                    giantSizeOn = false
                    if (autoSelected["GIANT_SIZE"] == true) {
                        setGiantSizeAutoEnabled(true)
                    }
                }
            }
        } else if (autoSelected["GIANT_SIZE"] == true) {
            setGiantSizeAutoEnabled(true)
        }
    }

    private fun setGiantSizeAutoEnabled(enable: Boolean, attempt: Int = 0) {
        if (!::nativeEffectMod.isInitialized) {
            giantSizeAutoOwned = false
            return
        }

        if (!enable) {
            giantSizeAutoOwned = false
            giantSizeOn = false

            nativeEffectMod.devGiantSizeFastLockDisable { result ->
                handler.post {
                    giantSizeStatusText = result.message
                    if (activeTab == Tab.AUTO && menuVisible) {
                        renderTab()
                    }
                }
            }
            return
        }

        if (!isAutoKeyAvailable("GIANT_SIZE")) {
            giantSizeAutoOwned = false
            autoSelected["GIANT_SIZE"] = false
            saveAutoSelection()
            return
        }

        if (autoSelected["GIANT"] != true) {
            giantSizeAutoOwned = false
            giantSizeStatusText = tr(
                "AUTO Giant Size ต้องเลือก Giant ด้วย",
                "AUTO Giant Size also requires Giant"
            )
            return
        }

        /*
         * Manual -> AUTO can briefly put Giant between OFF and ON.
         * Wait until Giant desired-state is armed, then enable the independent
         * Giant Size worker.
         */
        if (!nativeEffectMod.isEnabled(CrgProfile.FEATURE_GIANT)) {
            giantSizeAutoOwned = false
            giantSizeStatusText = tr(
                "AUTO Giant Size • รอ Giant...",
                "AUTO Giant Size • Waiting for Giant..."
            )

            if (
                autoMaster &&
                autoSelected["GIANT_SIZE"] == true &&
                attempt < 24
            ) {
                handler.postDelayed(
                    {
                        if (
                            autoMaster &&
                            autoSelected["GIANT_SIZE"] == true
                        ) {
                            setGiantSizeAutoEnabled(true, attempt + 1)
                        }
                    },
                    125L
                )
            }
            return
        }

        nativeEffectMod.devGiantSizeFastLockEnable(giantSizePercent) { result ->
            handler.post {
                giantSizeAutoOwned =
                    result.ok &&
                        nativeEffectMod.devGiantSizeFastLockIsEnabled()
                giantSizeOn = false
                giantSizeStatusText = result.message

                if (activeTab == Tab.AUTO && menuVisible) {
                    renderTab()
                }
            }
        }
    }

    private fun transitionBaseSpeedToAuto(manualWasOn: Boolean) {
        if (!::baseSpeedMod.isInitialized) return
        if (manualWasOn) {
            baseSpeedMod.setEnabled(false, baseSpeedMultiplier) {
                if (autoSelected["BASE_SPEED"] == true) setBaseSpeedAutoEnabled(true)
            }
        } else if (autoSelected["BASE_SPEED"] == true) setBaseSpeedAutoEnabled(true)
    }

    private fun setBaseSpeedAutoEnabled(enable: Boolean) {
        if (!::baseSpeedMod.isInitialized) return
        if (!enable) {
            baseSpeedAutoOwned = false
            baseSpeedMod.setEnabled(false, baseSpeedMultiplier) { result ->
                handler.post { baseSpeedStatusText = result.message }
            }
            return
        }
        if (!isAutoKeyAvailable("BASE_SPEED")) {
            baseSpeedAutoOwned = false
            autoSelected["BASE_SPEED"] = false
            return
        }
        withBaseSpeedProfile { profile, errorText ->
            if (profile == null) {
                handler.post { baseSpeedAutoOwned = false; baseSpeedStatusText = errorText ?: "Profile not ready" }
            } else {
                baseSpeedMod.setEnabled(true, baseSpeedMultiplier) { result ->
                    handler.post { baseSpeedAutoOwned = result.ok && baseSpeedMod.isEnabled(); baseSpeedStatusText = result.message }
                }
            }
        }
    }

    private fun transitionRecoveryToAuto(key: String, manualWasOn: Boolean) {
        if (!::recoveryMod.isInitialized) return
        if (manualWasOn) {
            if (key == "PIT_LIFT") {
                recoveryMod.setPitLiftEnabled(false) { if (autoSelected[key] == true) setPitLiftAutoEnabled(true) }
            } else {
                recoveryMod.setReviveEnabled(false) { if (autoSelected[key] == true) setReviveAutoEnabled(true) }
            }
        } else if (autoSelected[key] == true) {
            if (key == "PIT_LIFT") setPitLiftAutoEnabled(true) else setReviveAutoEnabled(true)
        }
    }

    private fun setPitLiftAutoEnabled(enable: Boolean) {
        if (!::recoveryMod.isInitialized) return
        if (!enable) {
            pitLiftAutoOwned = false
            recoveryMod.setPitLiftEnabled(false) { result -> handler.post { pitLiftStatusText = result.message } }
            return
        }
        if (!isAutoKeyAvailable("PIT_LIFT")) { pitLiftAutoOwned = false; autoSelected["PIT_LIFT"] = false; return }
        withRecoveryProfile { profile, errorText ->
            if (profile == null) {
                handler.post { pitLiftAutoOwned = false; pitLiftStatusText = errorText ?: "Profile not ready" }
            } else {
                recoveryMod.setPitLiftEnabled(true) { result ->
                    handler.post { pitLiftAutoOwned = result.ok && recoveryMod.isPitLiftEnabled(); pitLiftStatusText = result.message }
                }
            }
        }
    }

    private fun setReviveAutoEnabled(enable: Boolean) {
        if (!::recoveryMod.isInitialized) return
        if (!enable) {
            reviveAutoOwned = false
            recoveryMod.setReviveEnabled(false) { result -> handler.post { reviveStatusText = result.message } }
            return
        }
        if (!isAutoKeyAvailable("REVIVE")) { reviveAutoOwned = false; autoSelected["REVIVE"] = false; return }
        withRecoveryProfile { profile, errorText ->
            if (profile == null) {
                handler.post { reviveAutoOwned = false; reviveStatusText = errorText ?: "Profile not ready" }
            } else {
                recoveryMod.setReviveEnabled(true) { result ->
                    handler.post { reviveAutoOwned = result.ok && recoveryMod.isReviveEnabled(); reviveStatusText = result.message }
                }
            }
        }
    }

    private fun transitionJumpToAuto(manualWasOn: Boolean) {
        if (!::jumpMod.isInitialized) return
        if (manualWasOn) {
            jumpMod.setEnabled(false) { if (autoSelected["UNLIMITED_JUMP"] == true) setUnlimitedJumpAutoEnabled(true) }
        } else if (autoSelected["UNLIMITED_JUMP"] == true) setUnlimitedJumpAutoEnabled(true)
    }

    private fun setUnlimitedJumpAutoEnabled(enable: Boolean) {
        if (!::jumpMod.isInitialized) return
        if (!enable) {
            unlimitedJumpAutoOwned = false
            jumpMod.setEnabled(false) { result -> handler.post { unlimitedJumpStatusText = result.message } }
            return
        }
        if (!isAutoKeyAvailable("UNLIMITED_JUMP")) { unlimitedJumpAutoOwned = false; autoSelected["UNLIMITED_JUMP"] = false; return }
        withUnlimitedJumpProfile { profile, errorText ->
            if (profile == null) {
                handler.post { unlimitedJumpAutoOwned = false; unlimitedJumpStatusText = errorText ?: "Profile not ready" }
            } else {
                jumpMod.setEnabled(true) { result ->
                    handler.post { unlimitedJumpAutoOwned = result.ok && jumpMod.isEnabled(); unlimitedJumpStatusText = result.message }
                }
            }
        }
    }

    private fun transitionPotatoCoinToAuto(manualWasOn: Boolean) {
        if (!::potatoCoinMod.isInitialized) return
        if (manualWasOn) {
            potatoCoinMod.setEnabled(false, potatoCoinMode, potatoCoin, potatoCoinInterval) {
                if (autoSelected["POTATO_COIN"] == true) setPotatoCoinAutoEnabled(true)
            }
        } else if (autoSelected["POTATO_COIN"] == true) setPotatoCoinAutoEnabled(true)
    }

    private fun setPotatoCoinAutoEnabled(enable: Boolean) {
        if (!::potatoCoinMod.isInitialized) return
        if (!enable) {
            potatoCoinAutoOwned = false
            potatoCoinMod.setEnabled(false, potatoCoinMode, potatoCoin, potatoCoinInterval) { result ->
                handler.post { potatoCoinStatusText = result.message }
            }
            return
        }
        if (!isAutoKeyAvailable("POTATO_COIN")) { potatoCoinAutoOwned = false; autoSelected["POTATO_COIN"] = false; return }
        withPotatoProfile(requireCoin = true) { profile, errorText ->
            if (profile == null) {
                handler.post { potatoCoinAutoOwned = false; potatoCoinStatusText = errorText ?: "Profile not ready" }
            } else {
                potatoCoinMod.setEnabled(true, potatoCoinMode, potatoCoin, potatoCoinInterval) { result ->
                    handler.post { potatoCoinAutoOwned = result.ok && potatoCoinMod.isEnabled(); potatoCoinStatusText = result.message }
                }
            }
        }
    }

    private fun transitionPotatoRapidToAuto(manualWasOn: Boolean) {
        if (!::potatoRapidMod.isInitialized) return
        if (manualWasOn) {
            potatoRapidMod.setEnabled(false, potatoRapid) {
                if (autoSelected["POTATO_RAPID"] == true) setPotatoRapidAutoEnabled(true)
            }
        } else if (autoSelected["POTATO_RAPID"] == true) setPotatoRapidAutoEnabled(true)
    }

    private fun setPotatoRapidAutoEnabled(enable: Boolean) {
        if (!::potatoRapidMod.isInitialized) return
        if (!enable) {
            potatoRapidAutoOwned = false
            potatoRapidMod.setEnabled(false, potatoRapid) { result -> handler.post { potatoRapidStatusText = result.message } }
            return
        }
        if (!isAutoKeyAvailable("POTATO_RAPID")) { potatoRapidAutoOwned = false; autoSelected["POTATO_RAPID"] = false; return }
        withPotatoProfile(requireUltimate = false) { profile, errorText ->
            if (profile == null) {
                handler.post { potatoRapidAutoOwned = false; potatoRapidStatusText = errorText ?: "Profile not ready" }
            } else {
                potatoRapidMod.setEnabled(true, potatoRapid) { result ->
                    handler.post { potatoRapidAutoOwned = result.ok && potatoRapidMod.isEnabled(); potatoRapidStatusText = result.message }
                }
            }
        }
    }

    private fun resetManualPlayStates() {
        hpOn = false
        speedOn = false
        giantOn = false
        giantSizeOn = false
        superOn = false
        powerOn = false
        xpOn = false
        coinOn = false
        potatoCoinOn = false
        potatoRapidOn = false
        potatoUltimateOn = false
        baseSpeedOn = false
        pitLiftOn = false
        reviveOn = false
        unlimitedJumpOn = false
    }

    // ---------------------------------------------------------------------
    // Components
    // ---------------------------------------------------------------------

    private fun pageTitle(title: String, subtitle: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(txt(title, 18f, "#F2F4F8", true))
        addView(txt(subtitle, 10f, "#737D8E").apply { setPadding(0, dp(4), 0, 0) })
    }

    private fun section(value: String) = txt(value, 9f, "#667184", true)

    private fun centerLine(value: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(View(this@FloatingMenuService).apply { background = solid("#2C3340") },
            LinearLayout.LayoutParams(0, dp(1), 1f))
        addView(txt(value, 10f, "#8690A0", true).apply { setPadding(dp(12), 0, dp(12), 0) })
        addView(View(this@FloatingMenuService).apply { background = solid("#2C3340") },
            LinearLayout.LayoutParams(0, dp(1), 1f))
    }

    private fun expandableSectionRow(
        title: String,
        expanded: Boolean,
        onClick: () -> Unit
    ) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = rounded("#0D131C", 14, "#293242", 1)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }

        addView(txt(title, 11f, "#DDE2EA", true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(txt(if (expanded) "▲" else "▼", 11f, "#A998FF", true))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(13), dp(15), dp(13))
        background = rounded("#0B1017", 15, "#202733", 1)
    }

    private fun featureCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded("#0B1017", 16, "#202733", 1)
    }

    private fun simpleFeature(
        title: String,
        desc: String,
        enabled: Boolean,
        onToggle: (Boolean) -> Unit
    ) =
        featureCard().apply {
            addView(featureHeader(title, desc, enabled, locked = false, onToggle = onToggle))
        }

    private fun manualSimpleFeature(
        title: String,
        desc: String,
        enabled: Boolean,
        onToggle: (Boolean) -> Unit
    ) =
        featureCard().apply {
            addView(
                featureHeader(
                    title,
                    desc,
                    enabled,
                    locked = autoMaster,
                    onToggle = onToggle
                )
            )
        }

    private fun featureHeader(
        title: String,
        desc: String,
        enabled: Boolean,
        locked: Boolean = false,
        updating: Boolean = false,
        onToggle: (Boolean) -> Unit
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL

            val textArea = LinearLayout(this@FloatingMenuService).apply {
                orientation = LinearLayout.VERTICAL
                addView(
                    txt(
                        title,
                        13f,
                        if (locked || updating) "#8A93A2" else "#EFF2F7",
                        true
                    )
                )
                addView(
                    txt(
                        if (locked) {
                            tr("$desc • ปิด AUTO ก่อนเปิด", "$desc • Turn AUTO off first")
                        } else {
                            desc
                        },
                        9f,
                        if (locked || updating) "#596373" else "#6F798A"
                    ).apply { setPadding(0, dp(4), 0, 0) }
                )
            }

            addView(
                textArea,
                LinearLayout.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1f
                ).apply { marginEnd = dp(12) }
            )

            val toggle = when {
                updating -> updatingToggle()
                locked -> lockedToggle()
                else -> toggle(enabled)
            }

            if (!locked && !updating) {
                toggle.setOnClickListener {
                    val next = toggle.text != "ON"
                    onToggle(next)
                    styleToggle(toggle, next)
                }
            }

            addView(toggle)
        }
    }

    private fun toggle(on: Boolean) = TextView(this).apply {
        gravity = Gravity.CENTER
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(13), dp(7), dp(13), dp(7))
        styleToggle(this, on)
    }

    private fun styleToggle(v: TextView, on: Boolean) {
        v.text = if (on) "ON" else "OFF"
        v.setTextColor(Color.parseColor(if (on) "#D9FBE4" else "#9BA5B5"))
        v.background = rounded(
            if (on) "#173925" else "#181E27",
            20,
            if (on) "#2C7047" else "#343E4D",
            1
        )
    }

    private fun lockedToggle() = TextView(this).apply {
        text = tr("ล็อก", "LOCK")
        gravity = Gravity.CENTER
        textSize = 9f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setTextColor(Color.parseColor("#6E7888"))
        background = rounded("#151A22", 20, "#2B323D", 1)
        isEnabled = false
    }

    private fun updatingToggle() = TextView(this).apply {
        text = tr("อัปเดต", "UPDATE")
        gravity = Gravity.CENTER
        textSize = 9f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setTextColor(Color.parseColor("#E8C96E"))
        background = rounded("#2B2111", 20, "#66501D", 1)
        isEnabled = false
    }

    private fun featureUpdatingHint() =
        txt(
            tr(
                "● กำลังอัปเดต • ใช้งานชั่วคราวไม่ได้",
                "● Updating • Temporarily unavailable"
            ),
            9f,
            "#E8C96E",
            true
        )

    private fun lockedNotice(message: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = rounded("#2B2111", 13, "#66501D", 1)

        addView(txt("!", 13f, "#F4B740", true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply {
            marginEnd = dp(9)
        })

        addView(
            txt(message, 10f, "#E8C96E", true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
    }

    private fun infoBanner(message: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(11), dp(14), dp(11))
        background = rounded("#111927", 13, "#293853", 1)

        addView(txt("i", 12f, "#A998FF", true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply {
            marginEnd = dp(9)
        })

        addView(
            txt(message, 10f, "#AEB6C4"),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
    }

    private fun settingToggle(title: String, value: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))

            addView(
                txt(title, 11f, "#DDE2EA"),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )

            val t = toggle(value)
            t.setOnClickListener {
                val next = t.text != "ON"
                onChange(next)
                styleToggle(t, next)
            }
            addView(t)
        }
    }

    private fun choices(labels: List<String>, selected: Int, onClick: (Int) -> Unit): HorizontalScrollView {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        labels.forEachIndexed { i, label ->
            val active = i == selected
            val chip = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setTextColor(Color.parseColor(if (active) "#F7F5FF" else "#8993A4"))
                background = rounded(
                    if (active) "#28213F" else "#151B24",
                    10,
                    if (active) "#7657F6" else "#303845",
                    1
                )
                setOnClickListener { onClick(i) }
            }

            row.addView(
                chip,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(37)).apply {
                    if (i > 0) marginStart = dp(6)
                }
            )
        }

        scroll.addView(row)
        return scroll
    }

    private fun slider(
        minText: String,
        maxText: String,
        progress: Int,
        maxProgress: Int,
        currentValue: () -> String,
        onProgress: (Int) -> Unit
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL

            val range = LinearLayout(this@FloatingMenuService).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(txt(minText, 9f, "#6F798A"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(txt(maxText, 9f, "#6F798A"))
            }
            addView(range)

            val valueText = txt(currentValue(), 12f, "#C4B5FD", true)

            val seek = SeekBar(this@FloatingMenuService).apply {
                this.max = maxProgress
                this.progress = progress.coerceIn(0, maxProgress)
                progressTintList = ColorStateList.valueOf(Color.parseColor("#7657F6"))
                progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#2A313D"))
                thumbTintList = ColorStateList.valueOf(Color.parseColor("#A998FF"))

                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                        onProgress(p)
                        valueText.text = currentValue()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }

            addView(seek)
            addView(current(tr("ค่าปัจจุบัน", "Current"), "", valueText))
        }
    }

    private fun current(label: String, value: String, custom: TextView? = null) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(txt(label, 10f, "#768091"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(custom ?: txt(value, 12f, "#C4B5FD", true))
    }

    private fun info(left: String, right: String, color: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(3), 0, dp(3))
        addView(txt(left, 10f, "#828C9C"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(txt(right, 10f, color, true))
    }

    private fun statusCard(label: String, value: String, color: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = rounded("#0B1017", 14, "#202733", 1)
        addView(txt(label, 9f, "#697486"))
        addView(txt("● $value", 11f, color, true).apply { setPadding(0, dp(5), 0, 0) })
    }

    private fun button(text: String, accent: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.parseColor(if (accent) "#FFFFFF" else "#AEB6C3"))
        background = rounded(
            if (accent) "#7657F6" else "#171D26",
            11,
            if (accent) "#A998FF" else "#343D4B",
            1
        )
        setOnClickListener { onClick() }
    }

    private fun squareButton(symbol: String, action: () -> Unit) = TextView(this).apply {
        text = symbol
        gravity = Gravity.CENTER
        textSize = 22f
        setTextColor(Color.parseColor("#9CA5B4"))
        background = rounded("#1A202A", 12)
        setOnClickListener { action() }
    }

    private fun chipText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 9f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun pill(v: TextView, fill: String, stroke: String, textColor: String) {
        v.setTextColor(Color.parseColor(textColor))
        v.background = rounded(fill, 18, stroke, 1)
    }

    private fun label(value: String) = txt(value, 9f, "#747F90", true)

    private fun divider(top: Int = 10, bottom: Int = 10) = View(this).apply {
        background = solid("#202733")
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }
    }

    private fun txt(value: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        includeFontPadding = false
        setTextColor(Color.parseColor(color))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: String, radius: Int, stroke: String? = null, strokeWidth: Int = 0) =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.parseColor(fill))
            if (stroke != null && strokeWidth > 0) {
                setStroke(dp(strokeWidth), Color.parseColor(stroke))
            }
        }

    private fun solid(color: String) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(Color.parseColor(color))
    }

    private fun itemLp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(10)
    }

    private fun sectionLp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(20)
    }

    private fun subLp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(12)
    }

    // ---------------------------------------------------------------------
    // Values / slider mapping
    // ---------------------------------------------------------------------

    private fun progressToSpeed(progress: Int): Int {
        val normalized = progress.coerceIn(0, 1000) / 1000.0
        return 1000.0.pow(normalized).roundToInt().coerceIn(1, 1000)
    }

    private fun speedToProgress(value: Int): Int {
        val v = value.coerceIn(1, 1000)
        if (v <= 1) return 0
        return (ln(v.toDouble()) / ln(1000.0) * 1000.0).roundToInt().coerceIn(0, 1000)
    }

    private fun hpModeText(): String =
        if (hpMode == "INFINITE") tr("ไม่ตายเลย", "Infinite")
        else if (language == EN) "$hpMode sec" else "$hpMode วินาที"

    private fun ultimateText(): String {
        if (potatoUltimateInfinite) return tr("ไม่หมด", "Infinite")
        val min = potatoUltimateSeconds / 60
        return if (language == EN) "$min min" else "$min นาที"
    }

    private fun short(value: Int): String =
        if (value >= 1000 && value % 1000 == 0) "${value / 1000}K" else value.toString()

    private fun number(value: Int) = String.format(Locale.US, "%,d", value)

    // ---------------------------------------------------------------------
    // Size / reset / rebuild
    // ---------------------------------------------------------------------

    private fun sizeLabels() = listOf(tr("เล็ก", "Small"), tr("กลาง", "Medium"), tr("ใหญ่", "Large"))

    private fun sizeIndex(value: String) = when (value) {
        SMALL -> 0
        LARGE -> 2
        else -> 1
    }

    private fun sizeFromIndex(i: Int) = when (i) {
        0 -> SMALL
        2 -> LARGE
        else -> MEDIUM
    }

    private fun menuDimensions(): Pair<Int, Int> {
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels

        val targetW = when (menuSize) {
            SMALL -> dp(620)
            LARGE -> dp(900)
            else -> dp(760)
        }

        val targetH = when (menuSize) {
            SMALL -> dp(460)
            LARGE -> dp(680)
            else -> dp(560)
        }

        return Pair(
            targetW.coerceAtMost((sw - dp(28)).coerceAtLeast(dp(320))),
            targetH.coerceAtMost((sh - dp(36)).coerceAtLeast(dp(340)))
        )
    }

    private fun wSizePx() = when (wSize) {
        SMALL -> dp(46)
        LARGE -> dp(66)
        else -> dp(56)
    }

    private fun wTextSize() = when (wSize) {
        SMALL -> 16f
        LARGE -> 23f
        else -> 20f
    }

    private fun applyMenuSize() {
        val lp = menuLp ?: return
        val dim = menuDimensions()
        lp.width = dim.first
        lp.height = dim.second
        clampMenu()

        if (menuVisible) {
            menuView?.let { wm.updateViewLayout(it, lp) }
        }
    }

    private fun applyWSize() {
        val lp = wLp ?: return
        val size = wSizePx()
        lp.width = size
        lp.height = size
        clampW()

        if (wVisible) {
            wView?.let { wm.updateViewLayout(it, lp) }
        }
    }

    private fun clampMenu() {
        val lp = menuLp ?: return
        val dim = menuDimensions()
        val maxX = (resources.displayMetrics.widthPixels - dim.first).coerceAtLeast(0)
        val maxY = (resources.displayMetrics.heightPixels - dim.second).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        prefs.edit().putInt(P_M_X, lp.x).putInt(P_M_Y, lp.y).apply()
    }

    private fun clampW() {
        val lp = wLp ?: return
        val size = wSizePx()
        val maxX = (resources.displayMetrics.widthPixels - size).coerceAtLeast(0)
        val maxY = (resources.displayMetrics.heightPixels - size).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        saveWPosition()
    }

    private fun resetMenuPosition() {
        val lp = menuLp ?: return
        val dim = menuDimensions()
        lp.x = (resources.displayMetrics.widthPixels - dim.first - dp(28)).coerceAtLeast(dp(8))
        lp.y = dp(55)
        prefs.edit().putInt(P_M_X, lp.x).putInt(P_M_Y, lp.y).apply()

        if (menuVisible) {
            menuView?.let { wm.updateViewLayout(it, lp) }
        }
    }

    private fun resetWPosition() {
        val lp = wLp ?: return
        val size = wSizePx()
        lp.x = (resources.displayMetrics.widthPixels - size - dp(18)).coerceAtLeast(0)
        lp.y = dp(220)
        saveWPosition()

        if (wVisible) {
            wView?.let { wm.updateViewLayout(it, lp) }
        }
    }

    private fun rebuildMenu() {
        val wasVisible = menuVisible

        if (wasVisible) {
            try {
                menuView?.let { wm.removeView(it) }
            } catch (_: Exception) {
            }
            menuVisible = false
        }

        menuView = null
        menuLp = null
        content = null
        contentScroll = null
        tabText.clear()
        tabLine.clear()

        createMenu()

        if (wasVisible) showMenu()
    }

    private fun showMenu() {
        if (menuVisible || foregroundPackage != GAME_PACKAGE) return
        val panel = menuView ?: return
        val lp = menuLp ?: return

        try {
            wm.addView(panel, lp)
            menuVisible = true
            updateCountdown()
        } catch (e: Exception) {
            Log.e(TAG, "showMenu", e)
            showW()
        }
    }

    private fun hideMenu(restoreW: Boolean) {
        if (menuVisible) {
            try {
                menuView?.let { wm.removeView(it) }
            } catch (_: Exception) {
            }
            menuVisible = false
        }

        if (restoreW && foregroundPackage == GAME_PACKAGE) showW()
    }

    // ---------------------------------------------------------------------
    // V18.6.2 Hidden / recording overlay mode
    // ---------------------------------------------------------------------

    private fun enterHiddenOverlayMode() {
        if (foregroundPackage != GAME_PACKAGE) return

        overlayHiddenMode = true

        // X is NOT exit/logout. It only removes every visible M Woif overlay.
        hideMenu(false)
        hideW()
        hideQuickModButton()
        ensureHiddenOverlayZones()

        if (BuildConfig.INTERNAL_BUILD) {
            Toast.makeText(
                this,
                tr(
                    "M Woif Lab: ซ่อน Overlay แล้ว • แตะ W เดิม 2 ครั้งเพื่อเรียกกลับ",
                    "M Woif Lab: overlay hidden • double-tap the old W position to restore"
                ),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun exitHiddenOverlayMode(restoreVisible: Boolean) {
        overlayHiddenMode = false
        hideHiddenOverlayZones()

        if (restoreVisible && foregroundPackage == GAME_PACKAGE) {
            showW()
            if (quickModEnabled) {
                showQuickModButton()
                syncAutoMasterUi(forceQuick = true)
            }
        }
    }

    private fun ensureHiddenOverlayZones() {
        if (!overlayHiddenMode || foregroundPackage != GAME_PACKAGE) return

        ensureHiddenWZone()

        if (quickModEnabled) {
            ensureHiddenQuickZone()
        } else {
            hideHiddenQuickZone()
        }
    }

    private fun ensureHiddenWZone() {
        if (hiddenWZoneVisible) return

        val sourceLp = wLp ?: return
        val size = wSizePx()

        val zone = hiddenWZone ?: View(this).also { view ->
            view.setBackgroundColor(Color.TRANSPARENT)

            val detector =
                GestureDetector(
                    this,
                    object : GestureDetector.SimpleOnGestureListener() {
                        override fun onDown(e: MotionEvent): Boolean = true

                        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                            // Intentionally silent/no-op. Restore requires double tap.
                            return true
                        }

                        override fun onDoubleTap(e: MotionEvent): Boolean {
                            exitHiddenOverlayMode(restoreVisible = true)
                            return true
                        }
                    }
                )

            view.setOnTouchListener { _, event ->
                detector.onTouchEvent(event)
            }

            hiddenWZone = view
        }

        val lp =
            WindowManager.LayoutParams(
                size,
                size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = sourceLp.x
                y = sourceLp.y
            }

        try {
            wm.addView(zone, lp)
            hiddenWZoneVisible = true
        } catch (e: Exception) {
            if (BuildConfig.INTERNAL_BUILD) {
                Log.e(TAG, "ensureHiddenWZone", e)
            }
        }
    }

    private fun ensureHiddenQuickZone() {
        if (hiddenQuickZoneVisible) return

        val sourceLp = quickModLp ?: return
        val size = dp(56)

        val zone = hiddenQuickZone ?: View(this).also { view ->
            view.setBackgroundColor(Color.TRANSPARENT)

            val detector =
                GestureDetector(
                    this,
                    object : GestureDetector.SimpleOnGestureListener() {
                        override fun onDown(e: MotionEvent): Boolean = true

                        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                            toggleHiddenQuickAuto()
                            return true
                        }

                        override fun onDoubleTap(e: MotionEvent): Boolean {
                            // Double tap here NEVER restores the overlay. Treat the
                            // gesture as one AUTO toggle so it cannot ON->OFF twice.
                            toggleHiddenQuickAuto()
                            return true
                        }
                    }
                )

            view.setOnTouchListener { _, event ->
                detector.onTouchEvent(event)
            }

            hiddenQuickZone = view
        }

        val lp =
            WindowManager.LayoutParams(
                size,
                size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = sourceLp.x
                y = sourceLp.y
            }

        try {
            wm.addView(zone, lp)
            hiddenQuickZoneVisible = true
        } catch (e: Exception) {
            if (BuildConfig.INTERNAL_BUILD) {
                Log.e(TAG, "ensureHiddenQuickZone", e)
            }
        }
    }

    private fun toggleHiddenQuickAuto() {
        val before = autoMaster
        toggleQuickModPreset()

        // Stable/User hidden mode is deliberately silent for screen recording.
        // Lab keeps visible diagnostics so failures are not hidden during testing.
        if (BuildConfig.INTERNAL_BUILD && before != autoMaster) {
            Toast.makeText(
                this,
                "AUTO ${if (autoMaster) "ON" else "OFF"}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun hideHiddenOverlayZones() {
        hideHiddenWZone()
        hideHiddenQuickZone()
    }

    private fun hideHiddenWZone() {
        if (!hiddenWZoneVisible) return

        try {
            hiddenWZone?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }

        hiddenWZoneVisible = false
    }

    private fun hideHiddenQuickZone() {
        if (!hiddenQuickZoneVisible) return

        try {
            hiddenQuickZone?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }

        hiddenQuickZoneVisible = false
    }

    // ---------------------------------------------------------------------
    // Android service helpers
    // ---------------------------------------------------------------------

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun startForegroundCompat() {
        val notification = createNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val channel = NotificationChannel(
            CHANNEL_ID,
            if (BuildConfig.INTERNAL_BUILD) "M Woif Lab Watcher" else "M Woif",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description =
                if (BuildConfig.INTERNAL_BUILD) {
                    "Keeps the M Woif Lab game overlay active"
                } else {
                    "M Woif"
                }
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }

        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)

        val pending = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(brandMenuName())
            .setContentText(
                if (BuildConfig.INTERNAL_BUILD) {
                    "Cookie Run watcher is active"
                } else {
                    tr("พร้อมใช้งาน", "Ready")
                }
            )
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(
                if (BuildConfig.INTERNAL_BUILD) {
                    Notification.VISIBILITY_PRIVATE
                } else {
                    Notification.VISIBILITY_SECRET
                }
            )
            .build()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {

        if (activeServiceForBoxPump === this) {
            activeServiceForBoxPump = null
        }

        val restoreSpeed =
            speedOn &&
                    ::gameSpeedMod.isInitialized

        val restoreHp =
            (
                    hpOn ||
                            hpAutoOwned
                    ) &&
                    ::hpMod.isInitialized

        val restoreNativeEffects =
            (
                    giantOn ||
                            giantAutoOwned ||
                            boxPumpOwnsGiant ||
                            superOn ||
                            superAutoOwned
                    ) &&
                    ::nativeEffectMod.isInitialized

        val restoreReward =
            (
                    xpOn ||
                            xpAutoOwned ||
                            coinOn ||
                            coinAutoOwned
                    ) &&
                    ::runRewardMod.isInitialized

        val restorePotatoCoin =
            potatoCoinOn &&
                    ::potatoCoinMod.isInitialized

        val restorePotatoRapid =
            potatoRapidOn &&
                    ::potatoRapidMod.isInitialized

        val restorePotatoUltimate =
            (potatoUltimateOn || potatoUltimateAutoOwned) &&
                    ::potatoUltimateMod.isInitialized

        val restoreBaseSpeed =
            baseSpeedOn &&
                    ::baseSpeedMod.isInitialized

        hpOn =
            false

        hpAutoOwned =
            false

        speedOn =
            false

        giantOn =
            false

        giantAutoOwned =
            false

        boxPumpOwnsGiant =
            false

        superOn =
            false

        superAutoOwned =
            false

        powerOn =
            false

        powerAutoOwned =
            false

        xpOn =
            false

        xpAutoOwned =
            false

        coinOn =
            false

        coinAutoOwned =
            false

        potatoCoinOn =
            false

        potatoRapidOn =
            false

        potatoUltimateOn =
            false

        potatoUltimateAutoOwned =
            false

        baseSpeedOn =
            false

        pitLiftOn =
            false

        reviveOn =
            false

        unlimitedJumpOn =
            false

        speedApplyRunnable
            ?.let {
                handler.removeCallbacks(
                    it
                )
            }

        speedApplyRunnable =
            null

        stopPowderPumpLiveRefresh()
        powderPumpStatusView = null
        powderPumpDrawsView = null
        powderPumpBrokenView = null
        powderPumpPowderView = null
        powderPumpDevDiagnosticsView = null

        stopTowerPumpLiveRefresh()
        towerPumpStatusView = null
        towerPumpFloorView = null
        towerPumpMissionView = null
        towerPumpStateView = null
        towerPumpCommitView = null
        towerPumpDevDiagnosticsView = null

        if (BuildConfig.INTERNAL_BUILD && boxPumpLabRunning) {
            runCatching {
                val cls = Class.forName("com.woif.modmenu.BoxPumpLabBackend")
                cls.getMethod("requestStop").invoke(null)
            }
        }
        stopBoxPumpLiveRefresh()
        boxPumpStatusView = null
        boxPumpRoundView = null
        boxPumpPhaseView = null

        if (
            ::jumpMod.isInitialized
        ) {
            jumpMod.shutdown()
        }

        if (
            ::recoveryMod.isInitialized
        ) {
            recoveryMod.shutdown()
        }

        if (
            ::baseSpeedMod.isInitialized
        ) {
            baseSpeedMod.shutdown(
                restore = restoreBaseSpeed
            )
        }

        if (
            ::potatoCoinMod.isInitialized
        ) {
            potatoCoinMod.shutdown(
                restore = restorePotatoCoin
            )
        }

        if (
            ::potatoRapidMod.isInitialized
        ) {
            potatoRapidMod.shutdown(
                restore = restorePotatoRapid
            )
        }

        if (
            ::potatoUltimateMod.isInitialized
        ) {
            potatoUltimateMod.shutdown(
                restore = restorePotatoUltimate
            )
        }

        if (
            ::runRewardMod.isInitialized
        ) {
            runRewardMod.shutdown(
                restore = restoreReward
            )
        }

        if (
            ::powerPlusMod.isInitialized
        ) {
            powerPlusMod.shutdown()
        }

        if (
            ::buildUpdateDev.isInitialized
        ) {
            buildUpdateDev.shutdown()
        }

        if (
            ::giantSuperDev.isInitialized
        ) {
            giantSuperDev.shutdown()
        }

        if (
            ::nativeEffectMod.isInitialized
        ) {

            nativeEffectMod.shutdown(
                restore =
                restoreNativeEffects
            )
        }

        if (
            ::hpMod.isInitialized
        ) {

            hpMod.shutdown(
                restore =
                restoreHp
            )
        }

        if (
            ::gameSpeedMod.isInitialized
        ) {

            gameSpeedMod.shutdown(
                restore =
                restoreSpeed
            )
        }

        if (BOT_LAB_ENABLED && ::botLab.isInitialized) {
            botLab.shutdown()
        }

        SecureProfileManager.clear()
        SessionManager.clear()
        ControlPlaneState.reset()

        handler.removeCallbacks(watcher)
        handler.removeCallbacks(countdownTicker)
        handler.removeCallbacks(heartbeatTicker)

        overlayHiddenMode = false
        hideHiddenOverlayZones()
        hideMenu(false)
        hideW()
        hideQuickModButton()

        RootMemoryClient.shutdown()

        super.onDestroy()
    }
}
