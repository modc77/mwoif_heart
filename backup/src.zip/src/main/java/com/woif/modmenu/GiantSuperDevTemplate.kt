package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Internal/Lab-only Giant/Super update helper.
 *
 * IMPORTANT:
 * - READ ONLY. This class never writes CookieRun memory.
 * - It does not replace NativeEffectMod and must not be used as the Play backend.
 * - It is intentionally tolerant of vtable changes so it remains useful after
 *   a game update: it reports actual runtime vptrs/GH offsets instead of failing
 *   immediately when the old profile vptr no longer matches.
 *
 * Main use after a CookieRun update:
 *  1) cache the current f03/f04 Secure Profile;
 *  2) Probe Runtime;
 *  3) Arm Giant/Super capture;
 *  4) collect the real in-game Giant/Super once;
 *  5) copy report to the Ghidra chat if the structure moved too much.
 */
class GiantSuperDevTemplate(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {

    companion object {
        private const val POLL_MS = 50L
        private const val CAPTURE_TIMEOUT_MS = 45_000L
        private const val NORMAL_STREAK_REQUIRED = 3
        private const val MAX_EFFECTS_HARD = 128
        private const val EFFECT_DUMP_BYTES = 0xC0
    }

    data class Result(
        val ok: Boolean,
        val message: String,
        val report: String = ""
    )

    private data class Runtime(
        val pid: Int,
        val moduleStart: Long,
        val moduleEnd: Long,
        val bias: Long,
        val dispatcher: Long,
        val remover: Long,
        val stageGlobal: Long
    )

    private data class CharacterCandidate(
        val pointer: Long,
        val source: String,
        val actualCharacterVptr: Long,
        val expectedCharacterVptr: Long,
        val managerPointer: Long,
        val actualManagerVptr: Long,
        val expectedManagerVptr: Long,
        val strictMatch: Boolean
    )

    private data class EffectInfo(
        val index: Int,
        val pointer: Long,
        val vptr: Long,
        val vptrGh: Long,
        val directType: Int?,
        val adjustedType: Int?,
        val isTarget: Boolean,
        val bytes: ByteArray?
    )

    private data class Snapshot(
        val label: String,
        val elapsedMs: Long,
        val runtime: Runtime,
        val character: CharacterCandidate?,
        val layout: String,
        val manager: Long,
        val begin: Long,
        val end: Long,
        val cap: Long,
        val count: Int,
        val effects: List<EffectInfo>
    ) {
        fun hasTarget(): Boolean = effects.any { it.isTarget }
    }

    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val profiles = ConcurrentHashMap<String, NativeEffectProfile>()

    @Volatile private var captureTask: ScheduledFuture<*>? = null
    @Volatile private var captureFeatureId: String? = null
    @Volatile private var captureStartedAt = 0L
    @Volatile private var baseline: Snapshot? = null
    @Volatile private var active: Snapshot? = null
    @Volatile private var normal: Snapshot? = null
    @Volatile private var normalStreak = 0
    @Volatile private var lastStatus = "DEV Giant/Super template ready"
    @Volatile private var lastReport = "ยังไม่ได้ Probe"

    fun cacheProfile(profile: NativeEffectProfile): Result {
        if (profile.featureId != CrgProfile.FEATURE_GIANT &&
            profile.featureId != CrgProfile.FEATURE_SUPER
        ) {
            return Result(false, "รองรับเฉพาะ Giant/Super")
        }
        profiles[profile.featureId] = profile
        return Result(true, "profile ${profile.featureId} cached • rev=${profile.revision}")
    }

    fun statusText(): String = lastStatus

    fun reportText(): String = lastReport

    fun clearReport() {
        lastStatus = "DEV Giant/Super template ready"
        lastReport = "ยังไม่ได้ Probe"
    }

    fun probeAsync(
        featureId: String,
        callback: (Result) -> Unit
    ) {
        executor.execute {
            val profile = profiles[featureId]
            if (profile == null) {
                callback(Result(false, "ยังไม่มี Secure Profile ของ $featureId"))
                return@execute
            }

            val snap = captureSnapshot(profile, "PROBE", 0L)
            if (snap == null) {
                lastStatus = "Probe ไม่สำเร็จ"
                lastReport = buildRuntimeFailureReport(profile)
                callback(Result(false, lastStatus, lastReport))
                return@execute
            }

            lastStatus = if (snap.character?.strictMatch == true) {
                "Probe OK • build/profile ยังตรง"
            } else {
                "Probe ได้ • vptr/profile เปลี่ยน ให้ดู GH offsets"
            }
            lastReport = snapshotReport(profile, snap)
            callback(Result(true, lastStatus, lastReport))
        }
    }

    fun armCapture(
        profile: NativeEffectProfile,
        callback: (Result) -> Unit
    ) {
        val cached = cacheProfile(profile)
        if (!cached.ok) {
            callback(cached)
            return
        }

        executor.execute {
            stopCaptureInternal(clearSnapshots = true)

            val start = SystemClock.elapsedRealtime()
            val base = captureSnapshot(profile, "BASELINE", 0L)
            if (base == null) {
                lastStatus = "อ่าน BASELINE ไม่สำเร็จ"
                lastReport = buildRuntimeFailureReport(profile)
                callback(Result(false, lastStatus, lastReport))
                return@execute
            }

            captureFeatureId = profile.featureId
            captureStartedAt = start
            baseline = base
            active = null
            normal = null
            normalStreak = 0
            lastStatus = "ARMED ${featureName(profile.featureId)} • ไปเก็บของจริง 1 ครั้ง"
            lastReport = buildCaptureReport(profile)

            captureTask = executor.scheduleWithFixedDelay(
                { pollCapture(profile) },
                POLL_MS,
                POLL_MS,
                TimeUnit.MILLISECONDS
            )
            callback(Result(true, lastStatus, lastReport))
        }
    }

    fun stopCapture(callback: ((Result) -> Unit)? = null) {
        executor.execute {
            val featureId = captureFeatureId
            stopCaptureInternal(clearSnapshots = false)
            lastStatus = if (featureId == null) "Capture idle" else "Capture stopped"
            val profile = featureId?.let { profiles[it] }
            if (profile != null) lastReport = buildCaptureReport(profile)
            callback?.invoke(Result(true, lastStatus, lastReport))
        }
    }

    fun shutdown() {
        stopCaptureInternal(clearSnapshots = false)
        executor.shutdownNow()
    }

    private fun pollCapture(profile: NativeEffectProfile) {
        val started = captureStartedAt
        if (started == 0L) return

        val elapsed = SystemClock.elapsedRealtime() - started
        if (elapsed > CAPTURE_TIMEOUT_MS) {
            stopCaptureInternal(clearSnapshots = false)
            lastStatus = if (active == null) {
                "TIMEOUT • ไม่พบ ${featureName(profile.featureId)} ของจริง"
            } else {
                "TIMEOUT • ACTIVE จับได้แล้ว แต่ยังไม่กลับ NORMAL"
            }
            lastReport = buildCaptureReport(profile)
            return
        }

        val snap = captureSnapshot(profile, "LIVE", elapsed) ?: return

        if (active == null) {
            if (snap.hasTarget()) {
                active = snap.copy(label = "ACTIVE")
                normalStreak = 0
                lastStatus = "ACTIVE ${featureName(profile.featureId)} detected"
                lastReport = buildCaptureReport(profile)
            }
            return
        }

        if (snap.hasTarget()) {
            normalStreak = 0
            return
        }

        // Do not treat a transitional effect as NORMAL. We require the effect
        // vector to return to the BASELINE count for several consecutive polls.
        val baselineCount = baseline?.count ?: 0
        if (snap.count == baselineCount) normalStreak++ else normalStreak = 0

        if (normalStreak >= NORMAL_STREAK_REQUIRED) {
            normal = snap.copy(label = "NORMAL")
            stopCaptureInternal(clearSnapshots = false)
            lastStatus = "COMPLETE • BASELINE / ACTIVE / NORMAL"
            lastReport = buildCaptureReport(profile)
        }
    }

    private fun captureSnapshot(
        profile: NativeEffectProfile,
        label: String,
        elapsedMs: Long
    ): Snapshot? {
        val rt = resolveRuntime(profile) ?: return null
        val character = resolveCharacterLoose(rt, profile)

        if (character == null) {
            return Snapshot(
                label = label,
                elapsedMs = elapsedMs,
                runtime = rt,
                character = null,
                layout = "UNKNOWN",
                manager = 0L,
                begin = 0L,
                end = 0L,
                cap = 0L,
                count = 0,
                effects = emptyList()
            )
        }

        return if (isEffectManagerListProfile(profile)) {
            captureListSnapshot(rt, profile, character, label, elapsedMs)
        } else {
            captureVectorSnapshot(rt, profile, character, label, elapsedMs)
        }
    }

    /**
     * Current/newer profile layout:
     *   Character + effectBeginOffset -> vector begin
     *   Character + effectEndOffset   -> vector end
     *   Character + effectCapOffset   -> vector cap
     *
     * effectManagerOffset can be an embedded EffectOwner/subobject vptr
     * (for example Character+0x148), so it is reported but never written.
     */
    private fun captureVectorSnapshot(
        rt: Runtime,
        profile: NativeEffectProfile,
        character: CharacterCandidate,
        label: String,
        elapsedMs: Long
    ): Snapshot {
        val begin = memory.readLong(rt.pid, character.pointer + profile.effectBeginOffset) ?: 0L
        val end = memory.readLong(rt.pid, character.pointer + profile.effectEndOffset) ?: 0L
        val cap = memory.readLong(rt.pid, character.pointer + profile.effectCapOffset) ?: 0L
        val count = vectorCount(begin, end, cap, profile.maxEffects)
        val effects = if (count == null) emptyList() else readVectorEffects(rt, profile, begin, count)

        return Snapshot(
            label = label,
            elapsedMs = elapsedMs,
            runtime = rt,
            character = character,
            layout = "VECTOR",
            manager = character.managerPointer,
            begin = begin,
            end = end,
            cap = cap,
            count = count ?: -1,
            effects = effects
        )
    }

    /**
     * Legacy/current-list profile layout used by some f03/f04 revisions:
     *   Character + effectManagerOffset -> EffectManager*
     *   manager + effectBeginOffset      -> intrusive-list sentinel
     *   manager + effectEndOffset        -> effect count
     *   node + effectCapOffset           -> effect*
     */
    private fun captureListSnapshot(
        rt: Runtime,
        profile: NativeEffectProfile,
        character: CharacterCandidate,
        label: String,
        elapsedMs: Long
    ): Snapshot {
        val manager = character.managerPointer
        if (!isPointer(manager)) {
            return Snapshot(
                label = label,
                elapsedMs = elapsedMs,
                runtime = rt,
                character = character,
                layout = "LIST",
                manager = manager,
                begin = 0L,
                end = 0L,
                cap = 0L,
                count = -1,
                effects = emptyList()
            )
        }

        val sentinel = manager + profile.effectBeginOffset
        val head = memory.readLong(rt.pid, sentinel) ?: 0L
        val tail = memory.readLong(rt.pid, sentinel + 8L) ?: 0L
        val rawCount = memory.readLong(rt.pid, manager + profile.effectEndOffset) ?: -1L
        val max = maxOf(profile.maxEffects, 1).coerceAtMost(MAX_EFFECTS_HARD)
        val safeCount = rawCount.takeIf { it in 0L..max.toLong() }?.toInt()
        val effects = readListEffects(rt, profile, sentinel, head, safeCount ?: max)

        return Snapshot(
            label = label,
            elapsedMs = elapsedMs,
            runtime = rt,
            character = character,
            layout = "LIST",
            manager = manager,
            begin = head,
            end = tail,
            cap = sentinel,
            count = safeCount ?: effects.size,
            effects = effects
        )
    }

    private fun resolveRuntime(profile: NativeEffectProfile): Runtime? {
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
        val maps = memory.maps(pid)
        val libgame = maps.filter { it.path.contains("libgame.so") }
        if (libgame.isEmpty()) return null

        val start = libgame.minOf { it.start }
        val end = libgame.maxOf { it.end }
        val bias = start - profile.imageBase

        return Runtime(
            pid = pid,
            moduleStart = start,
            moduleEnd = end,
            bias = bias,
            dispatcher = bias + profile.dispatcherAddress,
            remover = bias + profile.removerAddress,
            stageGlobal = bias + profile.stageServiceGlobal
        )
    }

    /**
     * Loose resolver: it deliberately does not reject a Character only because
     * the vtable changed after an update. The report tells us old vs actual GH.
     */
    private fun resolveCharacterLoose(
        rt: Runtime,
        profile: NativeEffectProfile
    ): CharacterCandidate? {
        val service = memory.readLong(rt.pid, rt.stageGlobal) ?: return null
        if (!isPointer(service)) return null

        val direct = memory.readLong(rt.pid, service + profile.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) {
            buildCandidate(rt, profile, direct, "direct")?.let { return it }
        }

        val jelly = memory.readLong(rt.pid, service + profile.serviceJellyManagerOffset) ?: 0L
        if (isPointer(jelly)) {
            val fallback = memory.readLong(rt.pid, jelly + profile.jellyManagerCharacterOffset) ?: 0L
            if (isPointer(fallback)) {
                buildCandidate(rt, profile, fallback, "jelly")?.let { return it }
            }
        }
        return null
    }

    private fun buildCandidate(
        rt: Runtime,
        profile: NativeEffectProfile,
        character: Long,
        source: String
    ): CharacterCandidate? {
        val charVptr = memory.readLong(rt.pid, character) ?: return null
        val rawManagerField = memory.readLong(rt.pid, character + profile.effectManagerOffset) ?: 0L

        val managerPointer: Long
        val managerVptr: Long
        if (isEffectManagerListProfile(profile)) {
            managerPointer = rawManagerField
            managerVptr = if (isPointer(managerPointer)) {
                memory.readLong(rt.pid, managerPointer) ?: 0L
            } else {
                0L
            }
        } else {
            // Vector/newer layout: effectManagerOffset may point at an embedded
            // owner/subobject whose first qword is itself the vptr.
            managerPointer = character + profile.effectManagerOffset
            managerVptr = rawManagerField
        }

        val expectedChar = rt.bias + profile.characterVptr
        val expectedManager = rt.bias + profile.effectManagerVptr

        return CharacterCandidate(
            pointer = character,
            source = source,
            actualCharacterVptr = charVptr,
            expectedCharacterVptr = expectedChar,
            managerPointer = managerPointer,
            actualManagerVptr = managerVptr,
            expectedManagerVptr = expectedManager,
            strictMatch = charVptr == expectedChar && managerVptr == expectedManager
        )
    }

    private fun isEffectManagerListProfile(profile: NativeEffectProfile): Boolean =
        profile.effectManagerOffset == 0x5E0L &&
            profile.effectBeginOffset == 0x18L &&
            profile.effectEndOffset == 0x28L &&
            profile.effectCapOffset == 0x10L

    private fun vectorCount(
        begin: Long,
        end: Long,
        cap: Long,
        profileMax: Int
    ): Int? {
        if (begin == 0L && end == 0L && cap == 0L) return 0
        if (!isPointer(begin) || end < begin || cap < end || (end - begin) % 8L != 0L) return null
        val count = ((end - begin) / 8L).toInt()
        val max = maxOf(profileMax, 1).coerceAtMost(MAX_EFFECTS_HARD)
        return count.takeIf { it in 0..max }
    }

    private fun readVectorEffects(
        rt: Runtime,
        profile: NativeEffectProfile,
        begin: Long,
        count: Int
    ): List<EffectInfo> {
        val out = ArrayList<EffectInfo>(count)
        repeat(count) { index ->
            val pointer = memory.readLong(rt.pid, begin + index * 8L) ?: return@repeat
            appendEffectInfo(out, rt, profile, index, pointer)
        }
        return out
    }

    private fun readListEffects(
        rt: Runtime,
        profile: NativeEffectProfile,
        sentinel: Long,
        firstNode: Long,
        maxNodes: Int
    ): List<EffectInfo> {
        val out = ArrayList<EffectInfo>()
        var node = firstNode
        var guard = 0

        while (node != sentinel && isPointer(node) && guard < maxNodes) {
            val pointer = memory.readLong(rt.pid, node + profile.effectCapOffset) ?: 0L
            appendEffectInfo(out, rt, profile, guard, pointer)
            node = memory.readLong(rt.pid, node) ?: break
            guard++
        }
        return out
    }

    private fun appendEffectInfo(
        out: MutableList<EffectInfo>,
        rt: Runtime,
        profile: NativeEffectProfile,
        index: Int,
        pointer: Long
    ) {
        if (!isPointer(pointer)) return

        val vptr = memory.readLong(rt.pid, pointer) ?: 0L
        val direct = memory.readInt(rt.pid, pointer + profile.effectIdDirectOffset)
        val adjusted = memory.readInt(rt.pid, pointer + profile.effectIdAdjustedOffset)
        val target = direct == profile.effectId || adjusted == profile.effectId

        out += EffectInfo(
            index = index,
            pointer = pointer,
            vptr = vptr,
            vptrGh = if (vptr != 0L) vptr - rt.bias else 0L,
            directType = direct,
            adjustedType = adjusted,
            isTarget = target,
            bytes = memory.readBytes(rt.pid, pointer, EFFECT_DUMP_BYTES)
        )
    }

    private fun snapshotReport(
        profile: NativeEffectProfile,
        snap: Snapshot
    ): String = buildString {
        appendLine("=== GIANT / SUPER DEV PROBE ===")
        appendLine("feature=${profile.featureId} effectId=${profile.effectId} rev=${profile.revision}")
        appendLine("pid=${snap.runtime.pid}")
        appendLine("libgame=0x${snap.runtime.moduleStart.toString(16)}-0x${snap.runtime.moduleEnd.toString(16)}")
        appendLine("bias=0x${snap.runtime.bias.toString(16)}")
        appendLine("dispatcherRT=0x${snap.runtime.dispatcher.toString(16)} GH=0x${profile.dispatcherAddress.toString(16)}")
        appendLine("removerRT=0x${snap.runtime.remover.toString(16)} GH=0x${profile.removerAddress.toString(16)}")
        appendLine("stageGlobalRT=0x${snap.runtime.stageGlobal.toString(16)} GH=0x${profile.stageServiceGlobal.toString(16)}")

        val c = snap.character
        if (c == null) {
            appendLine("character=NOT_FOUND")
        } else {
            appendLine("character=0x${c.pointer.toString(16)} src=${c.source} strict=${c.strictMatch}")
            appendLine("characterVptr RT=0x${c.actualCharacterVptr.toString(16)} GH=0x${gh(c.actualCharacterVptr, snap.runtime.bias).toString(16)} expectedGH=0x${profile.characterVptr.toString(16)}")
            appendLine("manager/owner=0x${c.managerPointer.toString(16)}")
            appendLine("managerVptr RT=0x${c.actualManagerVptr.toString(16)} GH=0x${gh(c.actualManagerVptr, snap.runtime.bias).toString(16)} expectedGH=0x${profile.effectManagerVptr.toString(16)}")
        }

        appendLine("effectLayout=${snap.layout} manager=0x${snap.manager.toString(16)}")
        appendLine("effectStorage begin/head=0x${snap.begin.toString(16)} end/tail=0x${snap.end.toString(16)} cap/sentinel=0x${snap.cap.toString(16)} count=${snap.count}")
        snap.effects.forEach { fx -> appendEffect(this, fx) }
    }.trimEnd()

    private fun buildCaptureReport(profile: NativeEffectProfile): String = buildString {
        appendLine("=== GIANT / SUPER NATURAL CAPTURE ===")
        appendLine("feature=${profile.featureId} effectId=${profile.effectId} rev=${profile.revision}")
        appendLine("status=$lastStatus")
        baseline?.let {
            appendLine("--- BASELINE ---")
            appendLine(snapshotReport(profile, it))
        }
        active?.let {
            appendLine("--- ACTIVE ---")
            appendLine(snapshotReport(profile, it))
        }
        normal?.let {
            appendLine("--- NORMAL ---")
            appendLine(snapshotReport(profile, it))
        }
    }.trimEnd()

    private fun buildRuntimeFailureReport(profile: NativeEffectProfile): String = buildString {
        appendLine("=== GIANT / SUPER DEV PROBE FAILED ===")
        appendLine("feature=${profile.featureId} effectId=${profile.effectId} rev=${profile.revision}")
        appendLine("gamePid=${memory.pidOf(CrgProfile.GAME_PACKAGE) ?: -1}")
        appendLine("hint=ถ้า libgame/profile/Stage resolver เปลี่ยนหนัก ให้ส่ง log นี้ไป Ghidra 5.5")
    }.trimEnd()

    private fun appendEffect(out: StringBuilder, fx: EffectInfo) {
        out.appendLine(
            "effect[${fx.index}] ptr=0x${fx.pointer.toString(16)} " +
                "vptrRT=0x${fx.vptr.toString(16)} vptrGH=0x${fx.vptrGh.toString(16)} " +
                "direct=${fx.directType ?: -1} adjusted=${fx.adjustedType ?: -1} target=${fx.isTarget}"
        )
        fx.bytes?.let {
            out.appendLine("  words=${compactWords(it, 14)}")
        }
    }

    private fun compactWords(bytes: ByteArray, maxWords: Int): String {
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val parts = ArrayList<String>()
        var offset = 0
        while (buffer.remaining() >= 4 && parts.size < maxWords) {
            val value = buffer.int
            if (value != 0) parts += "+0x${offset.toString(16)}=${value.toUInt().toString(16)}"
            offset += 4
        }
        return parts.joinToString(" ")
    }

    private fun stopCaptureInternal(clearSnapshots: Boolean) {
        captureTask?.cancel(false)
        captureTask = null
        captureFeatureId = null
        captureStartedAt = 0L
        normalStreak = 0
        if (clearSnapshots) {
            baseline = null
            active = null
            normal = null
        }
    }

    private fun gh(runtimeAddress: Long, bias: Long): Long =
        if (runtimeAddress == 0L) 0L else runtimeAddress - bias

    private fun featureName(featureId: String): String = when (featureId) {
        CrgProfile.FEATURE_GIANT -> "Giant"
        CrgProfile.FEATURE_SUPER -> "Super"
        else -> featureId
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L
}
