package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Cookie Base Speed desired-state controller (f08_v1).
 *
 * Ghidra-verified normal path:
 *   CRG_GameEvent_RunConstruct_010896B8
 *     -> initializes ProtectedFloat(Character + 0x1C0)
 *
 *   FUN_00F3C9E0(Character*)
 *     -> reads ProtectedFloat(Character + 0x1C0)
 *     -> applies the game's existing passive/state multipliers
 *
 * f08 scales +0x1C0 itself. This intentionally avoids the built-in
 * Character+0x628 -> Character+0x678 full-result override branch because that
 * branch bypasses the normal passive contribution path.
 *
 * No executable code is patched. The protected value is encoded in all three
 * native copies, verified after every write, and restored only while the same
 * PID/Character is still live.
 */
class BaseSpeedMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val TICK_MS = 100L
        private const val PROCESS_RECHECK_TICKS = 10
        private const val MIN_FACTOR = 0.25f
        private const val MAX_FACTOR = 5.0f
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val loadBias: Long,
        val stageServiceGlobal: Long
    )

    private data class ProtectedFieldInfo(
        val p8: Long,
        val p10: Long,
        val p18: Long,
        val salt: Int
    )

    private data class CharacterRuntime(
        val character: Long,
        var baselineSourceBits: Int,
        var restoreSourceBits: Int,
        var lastAppliedTargetBits: Int? = null,
        var sourceModified: Boolean = false
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var profile: BaseSpeedProfile? = null
    @Volatile private var runtime: Runtime? = null
    @Volatile private var characterRuntime: CharacterRuntime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var tickCounter = 0
    @Volatile private var nextResolveAt = 0L

    @Volatile private var enabled = false
    @Volatile private var targetFactor = 1.0f
    @Volatile private var status = "Base Speed พร้อม • รอเปิด"

    fun cacheProfile(value: BaseSpeedProfile): ActionResult {
        if (
            value.imageBase <= 0L ||
            value.stageServiceGlobal <= 0L ||
            value.serviceCharacterOffset < 0L ||
            value.serviceJellyManagerOffset < 0L ||
            value.jellyManagerCharacterOffset < 0L ||
            value.baseSourceOffset <= 0L ||
            value.protectedPtr8Offset < 0L ||
            value.protectedPtr10Offset < 0L ||
            value.protectedPtr18Offset < 0L ||
            value.protectedSaltOffset < 0L
        ) {
            return failure("PROFILE_INVALID", "Base Speed Secure Profile ไม่ครบ")
        }

        profile = value
        if (!enabled) status = "Base Speed พร้อม • เปิด ON ได้ทุกหน้า"
        ensureTask()
        return success("Secure Base Speed Profile พร้อม")
    }

    fun setEnabled(
        enable: Boolean,
        factor: Double,
        callback: (ActionResult) -> Unit
    ) {
        if (!factor.isFinite() || factor < MIN_FACTOR.toDouble() || factor > MAX_FACTOR.toDouble()) {
            callback(failure("VALUE_INVALID", "ค่า Base Speed ไม่ถูกต้อง"))
            return
        }

        targetFactor = factor.toFloat()
        enabled = enable
        ensureTask()

        executor.execute {
            if (!enable) {
                restoreIfSafe()
                // Force a fresh bind next time. A new Stage may reuse the same
                // heap address for a different Character instance.
                characterRuntime = null
                status = "Base Speed OFF"
            } else {
                characterRuntime?.lastAppliedTargetBits = null
                status = "Base Speed ON • รอ CookieRun / Stage"
                safeTick()
            }
            callback(success(status))
        }
    }

    fun updateValue(factor: Double) {
        if (!factor.isFinite() || factor < MIN_FACTOR.toDouble() || factor > MAX_FACTOR.toDouble()) return
        targetFactor = factor.toFloat()
        ensureTask()
        if (enabled) executor.execute { safeTick() }
    }

    fun isEnabled(): Boolean = enabled
    fun statusText(): String = status

    fun restoreBlockingBestEffort() {
        enabled = false
        restoreIfSafe()
        characterRuntime = null
        runtime = null
        status = "Base Speed OFF"
    }

    fun shutdown(restore: Boolean) {
        if (restore) {
            try {
                restoreBlockingBestEffort()
            } catch (_: Exception) {
            }
        }
        enabled = false
        closed = true
        task?.cancel(false)
        task = null
        characterRuntime = null
        runtime = null
        profile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleAtFixedRate(
            { safeTick() },
            TICK_MS,
            TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun safeTick() {
        try {
            tick()
        } catch (t: Throwable) {
            if (enabled) status = "Base Speed ON • retry • ${t.javaClass.simpleName}"
            DevConsole.log("BASE_SPEED", "tick ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun tick() {
        if (!enabled) return

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_BASE_SPEED)) {
            status = "Base Speed ON • กำลังอัปเดต • รอ Server"
            return
        }

        tickCounter += 1

        var rt = runtime
        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) return
            nextResolveAt = now + 1000L

            val prepared = prepareRuntime()
            if (!prepared.ok) {
                status = when (prepared.errorCode) {
                    "ROOT_REQUIRED" -> "Base Speed ON • รอ Root Worker"
                    "PROFILE_NOT_READY" -> "Base Speed ON • รอ Secure Profile"
                    "GAME_NOT_RUNNING" -> "Base Speed ON • รอ CookieRun"
                    else -> "Base Speed ON • กำลังจับ runtime ใหม่"
                }
                return
            }
            rt = runtime ?: return
        }

        if (tickCounter % PROCESS_RECHECK_TICKS == 0) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                characterRuntime = null
                runtime = null
                nextResolveAt = 0L
                status = if (livePid == null) {
                    "Base Speed ON • รอ CookieRun"
                } else {
                    "Base Speed ON • พบเกมใหม่ • กำลังเชื่อม"
                }
                return
            }
        }

        val p = profile() ?: return
        val character = resolveCharacter(rt, p)
        if (!isPointer(character)) {
            characterRuntime = null
            status = "Base Speed ON • พร้อม • รอ Stage"
            return
        }

        var current = characterRuntime
        if (current == null || current.character != character) {
            val sourceBits = decodeProtectedBits(
                rt.pid,
                character + p.baseSourceOffset,
                p,
                verifySecondCopy = true
            ) ?: run {
                status = "Base Speed ON • รอ Base Source"
                return
            }

            val sourceValue = java.lang.Float.intBitsToFloat(sourceBits)
            if (!sourceValue.isFinite() || sourceValue <= 0.0f) {
                status = "Base Speed ON • Base Source ยังไม่พร้อม"
                return
            }

            current = CharacterRuntime(
                character = character,
                baselineSourceBits = sourceBits,
                restoreSourceBits = sourceBits
            )
            characterRuntime = current
            DevConsole.log(
                "BASE_SPEED",
                "bind char=0x${character.toString(16)} base=$sourceValue"
            )
        }

        applyTarget(rt, current, p)
    }

    private fun applyTarget(rt: Runtime, current: CharacterRuntime, p: BaseSpeedProfile) {
        val multiplier = targetFactor
        if (!multiplier.isFinite() || multiplier < MIN_FACTOR || multiplier > MAX_FACTOR) return

        val sourceField = current.character + p.baseSourceOffset
        val liveBits = decodeProtectedBits(rt.pid, sourceField, p, verifySecondCopy = true) ?: run {
            characterRuntime = null
            status = "Base Speed ON • อ่าน Base Source ไม่สำเร็จ"
            return
        }

        // If CookieRun itself changed the source while the MOD was armed, adopt
        // the new game value as the new baseline instead of fighting/stomping it.
        val lastTarget = current.lastAppliedTargetBits
        if (lastTarget != null && liveBits != lastTarget) {
            val liveValue = java.lang.Float.intBitsToFloat(liveBits)
            if (!liveValue.isFinite() || liveValue <= 0.0f) {
                characterRuntime = null
                return
            }
            current.baselineSourceBits = liveBits
            current.restoreSourceBits = liveBits
            current.lastAppliedTargetBits = null
            current.sourceModified = false
            DevConsole.log("BASE_SPEED", "adopt game base=$liveValue")
        }

        val baseline = java.lang.Float.intBitsToFloat(current.baselineSourceBits)
        if (!baseline.isFinite() || baseline <= 0.0f) {
            characterRuntime = null
            return
        }

        val target = baseline * multiplier
        if (!target.isFinite() || target <= 0.0f) return
        val targetBits = java.lang.Float.floatToRawIntBits(target)

        val nowBits = decodeProtectedBits(rt.pid, sourceField, p, verifySecondCopy = true) ?: return
        if (nowBits != targetBits) {
            if (!writeProtectedBitsPreserveMask(rt.pid, sourceField, targetBits, p)) {
                status = "Base Speed ON • เขียน Base Source ไม่สำเร็จ"
                return
            }
            current.sourceModified = targetBits != current.restoreSourceBits
        }

        val verifiedBits = decodeProtectedBits(rt.pid, sourceField, p, verifySecondCopy = true)
        if (verifiedBits != targetBits) {
            status = "Base Speed ON • Verify ไม่ผ่าน"
            return
        }

        current.lastAppliedTargetBits = targetBits
        status = "Base Speed ON • ${String.format(Locale.US, "%.1f", multiplier)}x • Verify OK"
    }

    private fun restoreIfSafe() {
        val p = profile() ?: return
        val rt = runtime ?: return
        val current = characterRuntime ?: return

        if (memory.pidOf(CrgProfile.GAME_PACKAGE) != rt.pid) return
        if (resolveCharacter(rt, p) != current.character) return

        val sourceField = current.character + p.baseSourceOffset
        val liveBits = decodeProtectedBits(rt.pid, sourceField, p, verifySecondCopy = true) ?: return
        val lastTarget = current.lastAppliedTargetBits

        // Restore only if the field still contains our last applied value. If
        // CookieRun changed it after our last tick, that game-owned value wins.
        if (current.sourceModified && lastTarget != null && liveBits == lastTarget) {
            writeProtectedBitsPreserveMask(rt.pid, sourceField, current.restoreSourceBits, p)
        }

        DevConsole.log("BASE_SPEED", "restore char=0x${current.character.toString(16)}")
    }

    private fun protectedFieldInfo(
        pid: Int,
        field: Long,
        p: BaseSpeedProfile
    ): ProtectedFieldInfo? {
        val p8 = memory.readLong(pid, field + p.protectedPtr8Offset) ?: return null
        val p10 = memory.readLong(pid, field + p.protectedPtr10Offset) ?: return null
        val p18 = memory.readLong(pid, field + p.protectedPtr18Offset) ?: return null
        val salt = memory.readInt(pid, field + p.protectedSaltOffset) ?: return null
        if (!isPointer(p8) || !isPointer(p10) || !isPointer(p18)) return null
        return ProtectedFieldInfo(p8, p10, p18, salt)
    }

    private fun decodeProtectedBits(
        pid: Int,
        field: Long,
        p: BaseSpeedProfile,
        verifySecondCopy: Boolean
    ): Int? {
        val info = protectedFieldInfo(pid, field, p) ?: return null
        val p8 = memory.readBytes(pid, info.p8, 4) ?: return null
        if (p8.size != 4) return null
        val bits8 = decodeP8(p8)

        if (verifySecondCopy) {
            val p10 = memory.readBytes(pid, info.p10, 4) ?: return null
            if (p10.size != 4 || decodeP10(p10) != bits8) return null
        }
        return bits8
    }

    /**
     * Writes a protected 32-bit value without knowing the class-specific p18
     * lookup table. The current valid field reveals the four p18 XOR masks:
     * oldP18 = reversed(oldRawBytes) xor masks.
     *
     * The salt is not modified, so reusing those recovered masks produces the
     * exact native third-copy encoding for the new value. This makes f08 valid
     * for the +0x1C0 protected-float class even though its p18 table differs
     * from the Potato protected-float class.
     */
    private fun writeProtectedBitsPreserveMask(
        pid: Int,
        field: Long,
        bits: Int,
        p: BaseSpeedProfile
    ): Boolean {
        val info = protectedFieldInfo(pid, field, p) ?: return false
        val old8 = memory.readBytes(pid, info.p8, 4) ?: return false
        val old10 = memory.readBytes(pid, info.p10, 4) ?: return false
        val old18 = memory.readBytes(pid, info.p18, 4) ?: return false
        if (old8.size != 4 || old10.size != 4 || old18.size != 4) return false

        val oldBits = decodeP8(old8)
        if (decodeP10(old10) != oldBits) return false

        val oldB0 = oldBits and 0xFF
        val oldB1 = (oldBits ushr 8) and 0xFF
        val oldB2 = (oldBits ushr 16) and 0xFF
        val oldB3 = (oldBits ushr 24) and 0xFF

        val mask0 = (old18[0].toInt() and 0xFF) xor oldB3
        val mask1 = (old18[1].toInt() and 0xFF) xor oldB2
        val mask2 = (old18[2].toInt() and 0xFF) xor oldB1
        val mask3 = (old18[3].toInt() and 0xFF) xor oldB0

        val b0 = bits and 0xFF
        val b1 = (bits ushr 8) and 0xFF
        val b2 = (bits ushr 16) and 0xFF
        val b3 = (bits ushr 24) and 0xFF

        val e8 = byteArrayOf(
            (((b3 xor 0xC5) + 1) and 0xFF).toByte(),
            (((b2 xor 0x39) + 1) and 0xFF).toByte(),
            (((b1 xor 0xC5) + 1) and 0xFF).toByte(),
            (((b0 xor 0x39) + 1) and 0xFF).toByte()
        )
        val e10 = byteArrayOf(
            (((b0 xor 0x6A) + 1) and 0xFF).toByte(),
            (((b1 xor 0x94) + 1) and 0xFF).toByte(),
            (((b2 xor 0x6A) + 1) and 0xFF).toByte(),
            (((b3 xor 0x94) + 1) and 0xFF).toByte()
        )
        val e18 = byteArrayOf(
            (b3 xor mask0).toByte(),
            (b2 xor mask1).toByte(),
            (b1 xor mask2).toByte(),
            (b0 xor mask3).toByte()
        )

        val paused = memory.pause(pid)
        return try {
            val wrote = memory.writeBytes(pid, info.p8, e8) &&
                memory.writeBytes(pid, info.p10, e10) &&
                memory.writeBytes(pid, info.p18, e18)

            val verify8 = memory.readBytes(pid, info.p8, 4)
            val verify10 = memory.readBytes(pid, info.p10, 4)
            val verify18 = memory.readBytes(pid, info.p18, 4)
            val thirdCopyOk = verify18 != null && verify18.size == 4 &&
                ((verify18[0].toInt() and 0xFF) xor mask0) == b3 &&
                ((verify18[1].toInt() and 0xFF) xor mask1) == b2 &&
                ((verify18[2].toInt() and 0xFF) xor mask2) == b1 &&
                ((verify18[3].toInt() and 0xFF) xor mask3) == b0
            val verified = wrote && verify8 != null && verify10 != null &&
                verify8.size == 4 && verify10.size == 4 &&
                decodeP8(verify8) == bits && decodeP10(verify10) == bits && thirdCopyOk

            if (!verified) {
                memory.writeBytes(pid, info.p8, old8)
                memory.writeBytes(pid, info.p10, old10)
                memory.writeBytes(pid, info.p18, old18)
            }
            verified
        } finally {
            if (paused) memory.resume(pid)
        }
    }

    private fun decodeP8(bytes: ByteArray): Int {
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF

        val d0 = ((256 - b3) and 0xFF) xor 0xC6
        val d1 = ((256 - b2) and 0xFF) xor 0x3A
        val d2 = ((256 - b1) and 0xFF) xor 0xC6
        val d3 = ((256 - b0) and 0xFF) xor 0x3A
        return d0 or (d1 shl 8) or (d2 shl 16) or (d3 shl 24)
    }

    private fun decodeP10(bytes: ByteArray): Int {
        val e0 = bytes[0].toInt() and 0xFF
        val e1 = bytes[1].toInt() and 0xFF
        val e2 = bytes[2].toInt() and 0xFF
        val e3 = bytes[3].toInt() and 0xFF

        val b0 = ((256 - e0) and 0xFF) xor 0x95
        val b1 = ((256 - e1) and 0xFF) xor 0x6B
        val b2 = ((256 - e2) and 0xFF) xor 0x95
        val b3 = ((256 - e3) and 0xFF) xor 0x6B
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }

    private fun resolveCharacter(rt: Runtime, p: BaseSpeedProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun prepareRuntime(): ActionResult {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ยังไม่มี Root Worker")
        }

        val p = profile() ?: return failure("PROFILE_NOT_READY", "Secure Base Speed Profile ยังไม่พร้อม")
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: return failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return failure("LIBGAME_NOT_READY", "ยังไม่พบ libgame.so")

        val candidates = LinkedHashSet<Long>()
        for (range in ranges) {
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
            ?: return failure("ELF_NOT_FOUND", "หา ARM64 libgame ELF ไม่สำเร็จ")
        val loadBias = parseLoadBias(pid, elfBase)
            ?: return failure("LOAD_BIAS_FAILED", "หา libgame load bias ไม่สำเร็จ")

        val stageServiceGlobal = loadBias + (p.stageServiceGlobal - p.imageBase)
        if (stageServiceGlobal < 0x10000L) {
            return failure("RUNTIME_ADDRESS_FAILED", "คำนวณ Base Speed runtime address ไม่สำเร็จ")
        }

        if (memory.readLong(pid, stageServiceGlobal) == null) {
            return failure("GLOBAL_READ_FAILED", "อ่าน Base Speed StageService global ไม่สำเร็จ")
        }

        runtime = Runtime(pid, loadBias, stageServiceGlobal)
        status = "Base Speed ON • พร้อม • รอ Stage"
        DevConsole.log("BASE_SPEED", "runtime pid=$pid bias=0x${loadBias.toString(16)}")
        return success("Base Speed runtime พร้อม")
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun profile(): BaseSpeedProfile? {
        val active = SecureProfileManager.getBaseSpeed()
        if (active == null) {
            profile = null
            return null
        }
        if (profile !== active) profile = active
        return active
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun success(message: String) = ActionResult(true, null, message)
    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
