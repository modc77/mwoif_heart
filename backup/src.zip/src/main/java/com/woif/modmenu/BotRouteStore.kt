package com.woif.modmenu

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class BotRouteStore(context: Context) {

    companion object {
        private const val PREFS = "mwoif_bot_lab_routes"
        private const val MAX_STEPS = 600
        private const val MAX_CHECKPOINTS = 40
        val SLOTS = listOf("A", "B", "C", "D")
    }

    private val prefs =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(route: BotRecordedRoute): Boolean {
        val slot = normalizeSlot(route.slot) ?: return false
        val steps = route.steps.take(MAX_STEPS)
        val checkpoints = route.checkpoints
            .filter { it.id > 0 && it.afterTapIndex in 0..steps.size }
            .distinctBy { it.id }
            .take(MAX_CHECKPOINTS)

        val json = JSONObject().apply {
            put("version", 2)
            put("slot", slot)
            put("screenWidth", route.screenWidth)
            put("screenHeight", route.screenHeight)
            put("recordedAt", route.recordedAt)
            put(
                "steps",
                JSONArray().apply {
                    steps.forEach { step ->
                        put(
                            JSONObject().apply {
                                put("x", step.x)
                                put("y", step.y)
                                put("delayMs", step.delayMs.coerceIn(0L, 120_000L))
                            }
                        )
                    }
                }
            )
            put(
                "checkpoints",
                JSONArray().apply {
                    checkpoints.forEach { checkpoint ->
                        put(
                            JSONObject().apply {
                                put("id", checkpoint.id)
                                put("afterTapIndex", checkpoint.afterTapIndex)
                                put("offsetMs", checkpoint.offsetMs.coerceAtLeast(0L))
                            }
                        )
                    }
                }
            )
        }

        return prefs.edit()
            .putString(key(slot), json.toString())
            .commit()
    }

    fun load(slotRaw: String): BotRecordedRoute? {
        val slot = normalizeSlot(slotRaw) ?: return null
        val text = prefs.getString(key(slot), null) ?: return null

        return try {
            val json = JSONObject(text)
            val width = json.optInt("screenWidth", 0)
            val height = json.optInt("screenHeight", 0)
            if (width <= 0 || height <= 0) return null

            val stepArray = json.optJSONArray("steps") ?: JSONArray()
            val steps = ArrayList<BotTapStep>(stepArray.length().coerceAtMost(MAX_STEPS))

            for (index in 0 until stepArray.length().coerceAtMost(MAX_STEPS)) {
                val item = stepArray.optJSONObject(index) ?: continue
                val x = item.optInt("x", -1)
                val y = item.optInt("y", -1)
                if (x < 0 || y < 0) continue

                steps += BotTapStep(
                    x = x,
                    y = y,
                    delayMs = item.optLong("delayMs", 0L).coerceIn(0L, 120_000L)
                )
            }

            val checkpointArray = json.optJSONArray("checkpoints") ?: JSONArray()
            val checkpoints = ArrayList<BotRouteCheckpoint>(
                checkpointArray.length().coerceAtMost(MAX_CHECKPOINTS)
            )
            for (index in 0 until checkpointArray.length().coerceAtMost(MAX_CHECKPOINTS)) {
                val item = checkpointArray.optJSONObject(index) ?: continue
                val id = item.optInt("id", -1)
                val afterTapIndex = item.optInt("afterTapIndex", -1)
                if (id <= 0 || afterTapIndex !in 0..steps.size) continue

                checkpoints += BotRouteCheckpoint(
                    id = id,
                    afterTapIndex = afterTapIndex,
                    offsetMs = item.optLong("offsetMs", 0L).coerceAtLeast(0L)
                )
            }

            BotRecordedRoute(
                slot = slot,
                screenWidth = width,
                screenHeight = height,
                recordedAt = json.optLong("recordedAt", 0L),
                steps = steps,
                checkpoints = checkpoints.sortedWith(
                    compareBy<BotRouteCheckpoint> { it.afterTapIndex }.thenBy { it.id }
                )
            )
        } catch (_: Exception) {
            null
        }
    }

    fun clear(slotRaw: String) {
        normalizeSlot(slotRaw)?.let { slot ->
            prefs.edit().remove(key(slot)).apply()
        }
    }

    fun stepCount(slotRaw: String): Int = load(slotRaw)?.steps?.size ?: 0

    fun checkpointCount(slotRaw: String): Int = load(slotRaw)?.checkpoints?.size ?: 0

    private fun normalizeSlot(value: String): String? {
        val slot = value.trim().uppercase()
        return slot.takeIf { it in SLOTS }
    }

    private fun key(slot: String) = "route_$slot"
}
