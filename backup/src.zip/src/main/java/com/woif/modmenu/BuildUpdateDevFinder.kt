package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.LinkedHashMap
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Internal-only Build Update Finder.
 *
 * สำคัญ:
 * - DEV ตัวนี้ไม่โหลด f05/f06/f07/f08/f09/f10 Secure Profile เพื่อหา Runtime
 * - หา libgame / load bias / StageService / Character จาก process + structure จริง
 * - ใช้ natural capture / structure scan เพื่อหา candidate ของแต่ละ Feature
 * - READ ONLY ทุกเส้นทางในไฟล์นี้ ไม่มี write/patch เกม
 *
 * ค่าเก่าไม่ใช่ dependency และไม่จำเป็นต้องมี Server Profile พร้อมก่อนใช้งาน DEV.
 */
class BuildUpdateDevFinder(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val POLL_MS = 15L
        private const val CAPTURE_TIMEOUT_MS = 30_000L
        private const val RECOVERY_TIMEOUT_MS = 45_000L
        private const val MAX_VECTOR_COUNT = 128
        private const val MAX_LIST_COUNT = 128L

        // Generic protected-value container layout. This is a structure rule,
        // not a server-profile dependency.
        private const val PROTECTED_P8 = 0x08L
        private const val PROTECTED_P10 = 0x10L
        private const val PROTECTED_P18 = 0x18L

        // Semantic Power+ keys. These identify the passive family and are used
        // only as object-classification keys during READ ONLY discovery.
        private val POWER_KEYS = intArrayOf(5005, 5006, 5007, 5009, 5012, 5013, 5015)
    }

    data class Result(
        val ok: Boolean,
        val message: String,
        val report: String = ""
    )

    private data class RuntimeSnapshot(
        val pid: Int,
        val elfBase: Long,
        val loadBias: Long,
        val moduleStart: Long,
        val moduleEnd: Long,
        val stageGlobalRt: Long,
        val stageGlobalGh: Long,
        val service: Long,
        val serviceCharacterOffset: Long,
        val character: Long,
        val gameplayGlobalRt: Long,
        val gameplayGlobalGh: Long,
        val gameplayState: Long,
        val stageScore: Int,
        val stateScore: Int
    )

    private data class ServiceCandidate(
        val slotRt: Long,
        val slotGh: Long,
        val service: Long,
        val characterOffset: Long,
        val character: Long,
        val score: Int
    )

    private data class StateCandidate(
        val slotRt: Long,
        val slotGh: Long,
        val state: Long,
        val score: Int
    )

    private data class JumpAction(
        val actionRt: Long,
        val actionGh: Long,
        val vptrRt: Long,
        val vptrGh: Long
    )

    private data class JumpRingCandidate(
        val ringOffset: Long,
        val indexOffset: Long,
        val size: Int,
        val actions: LinkedHashMap<Long, JumpAction> = LinkedHashMap(),
        var samples: Int = 0
    )

    private data class RecoveryListCandidate(
        val sentinelOffset: Long,
        val countOffset: Long,
        val count: Long,
        val next: Long,
        val previous: Long
    )

    private data class ProtectedField(
        val offset: Long,
        val bits: Int,
        val floatValue: Float
    )

    private data class PotatoCandidate(
        val holderOffset: Long,
        val objectRt: Long,
        val vptrGh: Long,
        val protectedFields: List<ProtectedField>,
        val score: Int
    )

    private data class EffectVectorCandidate(
        val beginOffset: Long,
        val endOffset: Long,
        val capOffset: Long,
        val baselineCount: Int
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var activeTask: ScheduledFuture<*>? = null
    @Volatile private var operationTask: Future<*>? = null
    @Volatile private var runtimeCache: RuntimeSnapshot? = null
    @Volatile private var lastStatus = "พร้อม • DEV ค้นหา Build อัตโนมัติ"
    @Volatile private var lastReport = "ยังไม่ได้ตรวจ"

    private var jumpStartedAt = 0L
    private var jumpRuntime: RuntimeSnapshot? = null
    private var jumpCandidates = LinkedHashMap<String, JumpRingCandidate>()

    private var recoveryStartedAt = 0L
    private var recoveryRuntime: RuntimeSnapshot? = null
    private var recoveryBaseline = LinkedHashMap<Long, RecoveryListCandidate>()

    private var effectStartedAt = 0L
    private var effectRuntime: RuntimeSnapshot? = null
    private var effectId = 0
    private var effectLabel = "Effect"
    private var effectVectors = ArrayList<EffectVectorCandidate>()

    fun statusText(): String = lastStatus
    fun reportText(): String = lastReport

    fun clearReport() {
        cancelCurrentWork()
        lastStatus = "พร้อม • DEV ค้นหา Build อัตโนมัติ"
        lastReport = "ยังไม่ได้ตรวจ"
    }

    fun shutdown() {
        cancelCurrentWork()
        executor.shutdownNow()
    }

    fun stop(callback: ((Result) -> Unit)? = null) {
        cancelCurrentWork()
        lastStatus = "หยุดการจับ DEV แล้ว"
        callback?.invoke(Result(true, lastStatus, lastReport))
    }

    // ------------------------------------------------------------------
    // 00 • Runtime Auto Finder
    // ------------------------------------------------------------------

    fun probeShared(callback: (Result) -> Unit) {
        submitOperation(
            "กำลังค้นหา Runtime อัตโนมัติ…",
            "=== 00 • DEV RUNTIME AUTO FINDER ===\nstatus=SEARCHING • กำลังหา Root / PID / libgame / StageService / Character",
            callback
        ) {
            val rt = resolveRuntime()
            if (rt == null) {
                finish(false, "Runtime ยังหาไม่เจอ", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            val report = buildString {
                appendLine("=== 00 • DEV RUNTIME AUTO FINDER ===")
                appendLine("status=PASS • SELF_DISCOVERY")
                appendLine("profileDependency=NONE")
                appendLine("pid=${rt.pid}")
                appendLine("libgame=${hex(rt.moduleStart)}-${hex(rt.moduleEnd)}")
                appendLine("elfBase=${hex(rt.elfBase)} bias=${hex(rt.loadBias)}")
                appendLine("StageService RT=${hex(rt.stageGlobalRt)} GH=${staticHex(rt.stageGlobalGh)} score=${rt.stageScore}")
                appendLine("service=${hex(rt.service)}")
                appendLine("service->Character=+${staticHex(rt.serviceCharacterOffset)}")
                appendLine("character=${hex(rt.character)}")
                if (rt.gameplayState != 0L) {
                    appendLine("GameplayState RT=${hex(rt.gameplayGlobalRt)} GH=${staticHex(rt.gameplayGlobalGh)} score=${rt.stateScore}")
                    append("gameplayState=${hex(rt.gameplayState)}")
                } else {
                    append("GameplayState=UNRESOLVED • f10/f08/f07/f05 ยังใช้ Character ได้ตามปกติ")
                }
            }
            finish(true, "Runtime อัตโนมัติผ่าน", report, callback)
        }
    }

    // ------------------------------------------------------------------
    // 01/02 • Natural Effect capture without f03/f04 profile
    // ------------------------------------------------------------------

    fun armEffectCapture(targetEffectId: Int, label: String, callback: (Result) -> Unit) {
        submitOperation(
            "$label • กำลังเตรียม Natural Capture…",
            "status=PREPARING • กำลังหา Runtime / Character สำหรับ $label",
            callback
        ) {
            val rt = resolveRuntime()
            if (rt == null || !isPointer(rt.character)) {
                finish(false, "$label DEV • ต้องเข้า Stage", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            effectRuntime = rt
            effectId = targetEffectId
            effectLabel = label
            effectStartedAt = SystemClock.elapsedRealtime()
            effectVectors = discoverEffectVectors(rt)

            lastStatus = "$label พร้อมจับ • เก็บ $label ของจริง"
            lastReport = buildEffectReport("ARMED", null, null, null)
            activeTask = executor.scheduleAtFixedRate(
                { pollEffectCapture() },
                POLL_MS,
                POLL_MS,
                TimeUnit.MILLISECONDS
            )
            callback(Result(true, lastStatus, lastReport))
        }
    }

    private fun pollEffectCapture() {
        try {
            if (SystemClock.elapsedRealtime() - effectStartedAt > CAPTURE_TIMEOUT_MS) {
                stopTaskInternal()
                lastStatus = "$effectLabel หมดเวลา • ยังไม่พบ Effect ID $effectId"
                lastReport = buildEffectReport("TIMEOUT", null, null, null)
                return
            }
            var rt = effectRuntime ?: return
            rt = refreshCharacter(rt) ?: return
            effectRuntime = rt

            // Re-discover vectors because baseline can be empty.
            val vectors = (effectVectors + discoverEffectVectors(rt))
                .distinctBy { Triple(it.beginOffset, it.endOffset, it.capOffset) }

            for (v in vectors) {
                val begin = memory.readLong(rt.pid, rt.character + v.beginOffset) ?: continue
                val end = memory.readLong(rt.pid, rt.character + v.endOffset) ?: continue
                val count = vectorCount(begin, end)
                if (count !in 1..MAX_VECTOR_COUNT) continue
                for (i in 0 until count) {
                    val obj = memory.readLong(rt.pid, begin + i * 8L) ?: continue
                    if (!isPointer(obj)) continue
                    val vptr = memory.readLong(rt.pid, obj) ?: continue
                    if (!inModule(vptr, rt)) continue
                    val idOffset = findExactIntOffset(rt.pid, obj, effectId, 0x80L, 0xD8L)
                    if (idOffset != null) {
                        stopTaskInternal()
                        lastStatus = "$effectLabel จับครบแล้ว"
                        lastReport = buildEffectReport("COMPLETE", v, obj, idOffset)
                        return
                    }
                }
            }
        } catch (t: Throwable) {
            lastStatus = "$effectLabel กำลังจับใหม่ • ${t.javaClass.simpleName}"
        }
    }

    private fun discoverEffectVectors(rt: RuntimeSnapshot): ArrayList<EffectVectorCandidate> {
        val out = ArrayList<EffectVectorCandidate>()
        var off = 0x100L
        while (off <= 0x300L) {
            val begin = memory.readLong(rt.pid, rt.character + off) ?: 0L
            val end = memory.readLong(rt.pid, rt.character + off + 8L) ?: 0L
            val cap = memory.readLong(rt.pid, rt.character + off + 0x10L) ?: 0L
            val count = vectorCountAllowEmpty(begin, end, cap)
            if (count >= 0) out += EffectVectorCandidate(off, off + 8L, off + 0x10L, count)
            off += 8L
        }
        return out
    }

    private fun buildEffectReport(
        state: String,
        vector: EffectVectorCandidate?,
        obj: Long?,
        idOffset: Long?
    ): String {
        val rt = effectRuntime
        return buildString {
            appendLine("=== ${effectLabel.uppercase(Locale.US)} • NATURAL EFFECT SELF CAPTURE ===")
            appendLine("status=$state")
            appendLine("profileDependency=NONE")
            appendLine("effectId=$effectId")
            if (rt != null) {
                appendLine("StageService GH=${staticHex(rt.stageGlobalGh)}")
                appendLine("character=${hex(rt.character)}")
            }
            if (vector == null || obj == null || idOffset == null || rt == null) {
                append("instruction=เข้า Stage → ARM → เก็บ $effectLabel ของจริง")
            } else {
                val vptr = memory.readLong(rt.pid, obj) ?: 0L
                appendLine("effectVector b4=${staticHex(vector.beginOffset)} b5=${staticHex(vector.endOffset)} b6=${staticHex(vector.capOffset)}")
                appendLine("effectObject=${hex(obj)}")
                appendLine("effectVptr GH=${staticHex(gh(vptr, rt))}")
                appendLine("effectIdOffset=${staticHex(idOffset)}")
                append("RESULT: ab=${staticHex(gh(vptr, rt))} b7=${staticHex(idOffset)} e0=$effectId")
            }
        }.trimEnd()
    }

    // ------------------------------------------------------------------
    // 03 • Giant Size float-vector scan
    // ------------------------------------------------------------------

    fun scanGiantSizeFields(callback: (Result) -> Unit) {
        submitOperation("Giant Size • กำลังสแกน…", "status=SEARCHING • Giant Size", callback) {
            val rt = resolveRuntime()
            if (rt == null || !isPointer(rt.character)) {
                finish(false, "Giant Size DEV • ต้องเข้า Stage", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            val rows = ArrayList<String>()
            var off = 0x280L
            while (off <= 0x520L) {
                val a = memory.readFloat(rt.pid, rt.character + off)
                val b = memory.readFloat(rt.pid, rt.character + off + 4L)
                val c = memory.readFloat(rt.pid, rt.character + off + 8L)
                if (a != null && b != null && c != null &&
                    a.isFinite() && b.isFinite() && c.isFinite() &&
                    a in 0.05f..10.0f && b in 0.05f..10.0f && c in 0.05f..10.0f) {
                    val spread = maxOf(a, b, c) - minOf(a, b, c)
                    val score = when {
                        spread < 0.0005f -> 4
                        spread < 0.05f -> 3
                        else -> 1
                    }
                    rows += "score=$score g0=${staticHex(off)} g1=${staticHex(off + 4L)} g2=${staticHex(off + 8L)} values=${fmt(a)}/${fmt(b)}/${fmt(c)}"
                }
                off += 4L
            }
            rows.sortByDescending { line -> line.substringAfter("score=").substringBefore(' ').toIntOrNull() ?: 0 }

            val report = buildString {
                appendLine("=== 03 • GIANT SIZE • FLOAT VECTOR SELF SCAN ===")
                appendLine("status=${if (rows.isEmpty()) "NO_CANDIDATE" else "CANDIDATES"}")
                appendLine("profileDependency=NONE")
                appendLine("character=${hex(rt.character)}")
                appendLine("instruction=เปิด Giant ของจริงก่อนสแกน จะช่วยให้ vector ขนาดเด่นขึ้น")
                rows.take(36).forEachIndexed { i, row -> appendLine("#${i + 1} $row") }
                if (rows.size > 36) append("... ${rows.size - 36} more")
            }.trimEnd()
            finish(rows.isNotEmpty(), "Giant Size • พบ vector candidate ${rows.size} จุด", report, callback)
        }
    }

    // ------------------------------------------------------------------
    // 07 • Base Speed
    // ------------------------------------------------------------------

    fun scanBaseSpeed(callback: (Result) -> Unit) {
        submitOperation("f08 • กำลังสแกน Base Speed…", "status=SEARCHING • Base Speed", callback) {
            val rt = resolveRuntime()
            if (rt == null || !isPointer(rt.character)) {
                finish(false, "Base Speed DEV • ต้องเข้า Stage", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            val values = ArrayList<ProtectedField>()
            var off = 0x80L
            while (off <= 0x500L) {
                val bits = decodeProtectedBits(rt.pid, rt.character + off)
                if (bits != null) {
                    val f = Float.fromBits(bits)
                    if (f.isFinite() && abs(f) in 0.0001f..1000.0f) {
                        values += ProtectedField(off, bits, f)
                    }
                }
                off += 8L
            }

            // Prefer plausible movement multipliers/speeds, but do not rely on
            // any old c0 address.
            values.sortWith(
                compareByDescending<ProtectedField> {
                    when {
                        it.floatValue in 0.5f..20.0f -> 3
                        it.floatValue in 0.05f..100.0f -> 2
                        else -> 1
                    }
                }.thenBy { it.offset }
            )

            val report = buildString {
                appendLine("=== 07 • ความเร็วพื้นฐานคุกกี้ • SELF SCAN ===")
                appendLine("status=${if (values.isEmpty()) "NO_CANDIDATE" else "CANDIDATES"}")
                appendLine("profileDependency=NONE")
                appendLine("character=${hex(rt.character)}")
                appendLine("protectedLayout=+08/+10/+18")
                appendLine("candidates=${values.size}")
                values.take(36).forEachIndexed { i, v ->
                    appendLine("#${i + 1} c0=+${staticHex(v.offset)} value=${fmt(v.floatValue)} bits=${u32(v.bits)}")
                }
                if (values.size > 36) append("... ${values.size - 36} more")
            }.trimEnd()
            finish(values.isNotEmpty(), "Base Speed • พบ candidate ${values.size} จุด", report, callback)
        }
    }

    // ------------------------------------------------------------------
    // 09 • Jump
    // ------------------------------------------------------------------

    fun armJumpCapture(callback: (Result) -> Unit) {
        submitOperation(
            "f10 • กำลังเตรียมจับ Jump…",
            "=== 09 • f10 UNLIMITED JUMP • NATURAL SELF CAPTURE ===\nstatus=PREPARING • กำลังหา Runtime และ Character",
            callback
        ) {
            val rt = resolveRuntime()
            if (rt == null || !isPointer(rt.character)) {
                finish(false, "f10 DEV • ต้องเข้า Stage เท่านั้น", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            jumpRuntime = rt
            jumpCandidates.clear()
            jumpStartedAt = SystemClock.elapsedRealtime()

            for (size in 2..8) {
                var ring = 0x70L
                while (ring <= 0x240L) {
                    addJumpCandidate(ring, ring + size * 8L, size)
                    ring += 8L
                }
            }

            sampleJump()
            lastStatus = "f10 พร้อมจับ • ยืนพื้น → Jump #1 → Jump #2"
            lastReport = buildJumpReport("ARMED")
            activeTask = executor.scheduleAtFixedRate(
                { pollJump() },
                10L,
                10L,
                TimeUnit.MILLISECONDS
            )
            callback(Result(true, lastStatus, lastReport))
        }
    }

    private fun addJumpCandidate(ring: Long, index: Long, size: Int) {
        val key = "$ring:$index:$size"
        jumpCandidates.putIfAbsent(key, JumpRingCandidate(ring, index, size))
    }

    private fun pollJump() {
        try {
            if (SystemClock.elapsedRealtime() - jumpStartedAt > CAPTURE_TIMEOUT_MS) {
                stopTaskInternal()
                lastStatus = "f10 หมดเวลา • จับ Ground/Jump1/Jump2 ไม่ครบ"
                lastReport = buildJumpReport("TIMEOUT")
                return
            }
            sampleJump()
            val best = bestJumpCandidate()
            if (best != null && best.actions.size >= 3) {
                stopTaskInternal()
                lastStatus = "f10 ครบแล้ว • Ground / Jump1 / Jump2"
                lastReport = buildJumpReport("COMPLETE")
            }
        } catch (t: Throwable) {
            lastStatus = "f10 กำลังจับใหม่ • ${t.javaClass.simpleName}"
        }
    }

    private fun sampleJump() {
        var rt = jumpRuntime ?: return
        rt = refreshCharacter(rt) ?: return
        jumpRuntime = rt
        for (c in jumpCandidates.values) {
            val index = memory.readInt(rt.pid, rt.character + c.indexOffset) ?: continue
            if (index !in 0 until c.size) continue
            val action = memory.readLong(rt.pid, rt.character + c.ringOffset + index.toLong() * 8L) ?: continue
            if (!inModule(action, rt)) continue
            val vptr = memory.readLong(rt.pid, action) ?: continue
            if (!inModule(vptr, rt)) continue
            c.samples += 1
            c.actions.putIfAbsent(action, JumpAction(action, gh(action, rt), vptr, gh(vptr, rt)))
        }
    }

    private fun bestJumpCandidate(): JumpRingCandidate? =
        jumpCandidates.values
            .filter { it.samples > 0 }
            .sortedWith(compareByDescending<JumpRingCandidate> { it.actions.size }.thenByDescending { it.samples })
            .firstOrNull()

    private fun buildJumpReport(state: String): String {
        val rt = jumpRuntime
        val best = bestJumpCandidate()
        return buildString {
            appendLine("=== 09 • f10 UNLIMITED JUMP • NATURAL SELF CAPTURE ===")
            appendLine("status=$state")
            appendLine("profileDependency=NONE")
            if (rt != null) appendLine("character=${hex(rt.character)} StageServiceGH=${staticHex(rt.stageGlobalGh)}")
            if (best == null) {
                append("instruction=ยืนพื้น → เริ่มจับ → Jump #1 → Jump #2")
                return@buildString
            }
            appendLine("c0=${staticHex(best.ringOffset)} c1=${staticHex(best.indexOffset)} c2=${best.size}")
            val actions = best.actions.values.toList()
            actions.take(3).forEachIndexed { i, a ->
                val name = when (i) { 0 -> "Ground"; 1 -> "Jump1"; else -> "Jump2" }
                appendLine("$name actionGH=${staticHex(a.actionGh)} vtableGH=${staticHex(a.vptrGh)}")
            }
            if (actions.size >= 3) {
                appendLine("d0=${staticHex(actions[0].actionGh)} d1=${staticHex(actions[1].actionGh)} d2=${staticHex(actions[2].actionGh)}")
                append("e0=${staticHex(actions[0].vptrGh)} e1=${staticHex(actions[1].vptrGh)} e2=${staticHex(actions[2].vptrGh)}")
            }
        }.trimEnd()
    }

    // ------------------------------------------------------------------
    // 08 • Pit / Revive
    // ------------------------------------------------------------------

    fun armRecoveryCapture(callback: (Result) -> Unit) {
        submitOperation("f09 • กำลังเตรียมจับ Pit / Revive…", "status=PREPARING • Recovery", callback) {
            val rt = resolveRuntime(requireGameplayState = true)
            if (rt == null || !isPointer(rt.gameplayState)) {
                finish(false, "f09 DEV • หา GameplayState ไม่เจอ", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            recoveryRuntime = rt
            recoveryBaseline = scanRecoveryLists(rt).associateByTo(LinkedHashMap()) { it.sentinelOffset }
            recoveryStartedAt = SystemClock.elapsedRealtime()
            lastStatus = "f09 พร้อมจับ • ใช้ Pit Lift หรือ Revive ของจริง 1 ครั้ง"
            lastReport = buildRecoveryReport("ARMED", null, null)
            activeTask = executor.scheduleAtFixedRate(
                { pollRecovery() },
                20L,
                20L,
                TimeUnit.MILLISECONDS
            )
            callback(Result(true, lastStatus, lastReport))
        }
    }

    private fun pollRecovery() {
        try {
            if (SystemClock.elapsedRealtime() - recoveryStartedAt > RECOVERY_TIMEOUT_MS) {
                stopTaskInternal()
                lastStatus = "f09 หมดเวลา • ยังไม่เห็น recovery usage เปลี่ยน"
                lastReport = buildRecoveryReport("TIMEOUT", null, null)
                return
            }
            val rt = recoveryRuntime ?: return
            val now = scanRecoveryLists(rt)
            for (item in now) {
                val old = recoveryBaseline[item.sentinelOffset] ?: continue
                if (item.count != old.count) {
                    val subtype = decodeRecoverySubtype(rt, item)
                    stopTaskInternal()
                    lastStatus = "f09 จับ recovery list แล้ว"
                    lastReport = buildRecoveryReport("COMPLETE", item, subtype)
                    return
                }
            }
        } catch (t: Throwable) {
            lastStatus = "f09 กำลังจับใหม่ • ${t.javaClass.simpleName}"
        }
    }

    private fun scanRecoveryLists(rt: RuntimeSnapshot): List<RecoveryListCandidate> {
        val out = ArrayList<RecoveryListCandidate>()
        var off = 0x80L
        while (off <= 0xA00L) {
            val sentinel = rt.gameplayState + off
            val next = memory.readLong(rt.pid, sentinel) ?: 0L
            val prev = memory.readLong(rt.pid, sentinel + 8L) ?: 0L
            val count = memory.readLong(rt.pid, sentinel + 0x10L) ?: -1L
            if (count in 0..MAX_LIST_COUNT) {
                val valid = if (count == 0L) {
                    (next == 0L && prev == 0L) || (next == sentinel && prev == sentinel)
                } else {
                    isPointer(next) && isPointer(prev) &&
                        memory.readLong(rt.pid, next + 8L) == sentinel &&
                        memory.readLong(rt.pid, prev) == sentinel
                }
                if (valid) out += RecoveryListCandidate(off, off + 0x10L, count, next, prev)
            }
            off += 8L
        }
        return out
    }

    private fun decodeRecoverySubtype(rt: RuntimeSnapshot, list: RecoveryListCandidate): Int? {
        val sentinel = rt.gameplayState + list.sentinelOffset
        val nodes = linkedSetOf<Long>()
        val head = memory.readLong(rt.pid, sentinel) ?: 0L
        val tail = memory.readLong(rt.pid, sentinel + 8L) ?: 0L
        if (isPointer(head) && head != sentinel) nodes += head
        if (isPointer(tail) && tail != sentinel) nodes += tail
        for (node in nodes) {
            val valueObject = memory.readLong(rt.pid, node + 0x10L) ?: continue
            if (!isPointer(valueObject)) continue
            val encoded = memory.readLong(rt.pid, valueObject + PROTECTED_P8) ?: continue
            if (!isPointer(encoded)) continue
            val bytes = memory.readBytes(rt.pid, encoded, 4) ?: continue
            if (bytes.size == 4) return decodeP8(bytes)
        }
        return null
    }

    private fun buildRecoveryReport(state: String, winner: RecoveryListCandidate?, subtype: Int?): String {
        val rt = recoveryRuntime
        return buildString {
            appendLine("=== 08 • f09 PIT / REVIVE • NATURAL SELF CAPTURE ===")
            appendLine("status=$state")
            appendLine("profileDependency=NONE")
            if (rt != null) {
                appendLine("GameplayStateGH=${staticHex(rt.gameplayGlobalGh)} state=${hex(rt.gameplayState)}")
                appendLine("character=${hex(rt.character)}")
            }
            appendLine("baselineLists=${recoveryBaseline.size}")
            if (winner == null) {
                append("instruction=ARM แล้วใช้ Pit Lift หรือ Revive ของจริง")
            } else {
                appendLine("d0=${staticHex(winner.sentinelOffset)} d1=${staticHex(winner.countOffset)}")
                appendLine("d2=00000000 d3=00000008 d4=00000010")
                appendLine("decodedSubtype=${subtype ?: -1}")
                if (subtype != null) append("e0=00000008 e1=${staticHex(subtype.toLong())}")
            }
        }.trimEnd()
    }

    // ------------------------------------------------------------------
    // 06 • Potato
    // ------------------------------------------------------------------

    fun probePotato(callback: (Result) -> Unit) {
        submitOperation("f07 • กำลังค้นหา Potato…", "status=SEARCHING • Potato", callback) {
            val rt = resolveRuntime()
            if (rt == null || !isPointer(rt.character)) {
                finish(false, "Potato DEV • ต้องเข้า Stage", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            val candidates = ArrayList<PotatoCandidate>()
            var holderOff = 0x100L
            while (holderOff <= 0x320L) {
                val holder = memory.readLong(rt.pid, rt.character + holderOff) ?: 0L
                if (isPointer(holder)) {
                    val begin = memory.readLong(rt.pid, holder) ?: 0L
                    val end = memory.readLong(rt.pid, holder + 8L) ?: 0L
                    val count = vectorCount(begin, end)
                    if (count in 1..MAX_VECTOR_COUNT) {
                        for (i in 0 until count) {
                            val obj = memory.readLong(rt.pid, begin + i * 8L) ?: continue
                            if (!isPointer(obj)) continue
                            val vptr = memory.readLong(rt.pid, obj) ?: continue
                            if (!inModule(vptr, rt)) continue
                            val fields = scanProtectedFields(rt.pid, obj, 0x10L, 0x520L)
                            if (fields.size >= 3) {
                                val score = fields.size * 2 + if (fields.any { it.offset >= 0x400L }) 2 else 0
                                candidates += PotatoCandidate(holderOff, obj, gh(vptr, rt), fields, score)
                            }
                        }
                    }
                }
                holderOff += 8L
            }

            val unique = candidates.distinctBy { Pair(it.holderOffset, it.objectRt) }
                .sortedByDescending { it.score }

            val report = buildString {
                appendLine("=== 06 • f07 POTATO • OBJECT SELF FINDER ===")
                appendLine("status=${if (unique.isEmpty()) "NO_CANDIDATE" else "CANDIDATES"}")
                appendLine("profileDependency=NONE")
                appendLine("character=${hex(rt.character)}")
                appendLine("candidates=${unique.size}")
                unique.take(10).forEachIndexed { i, c ->
                    appendLine("#${i + 1} score=${c.score} c0=${staticHex(c.holderOffset)} obj=${hex(c.objectRt)} c3=${staticHex(c.vptrGh)}")
                    appendLine("  protected=${c.protectedFields.take(16).joinToString(" ") { "+${staticHex(it.offset)}=${fmt(it.floatValue)}" }}")
                }
                append("NOTE: h0/h1/ha/ho เป็น code address • ส่ง c3/object report ให้ Ghidra 5.5 ไล่ code family ต่อ")
            }.trimEnd()
            finish(unique.isNotEmpty(), "Potato • พบ candidate ${unique.size} จุด", report, callback)
        }
    }

    // ------------------------------------------------------------------
    // 04 • Power+
    // ------------------------------------------------------------------

    fun probePowerPlus(callback: (Result) -> Unit) {
        submitOperation("f05 • กำลังค้นหา Power+…", "status=SEARCHING • Power+", callback) {
            val rt = resolveRuntime()
            if (rt == null || !isPointer(rt.character)) {
                finish(false, "Power+ DEV • ต้องเข้า Stage", buildRuntimeFailure(), callback)
                return@submitOperation
            }

            val events = findGameEventCandidates(rt)
            val manager = findPowerManagerCandidate(rt)
            val report = buildString {
                appendLine("=== 04 • f05 POWER+ • OBJECT SELF FINDER ===")
                appendLine("status=${if (events.isEmpty() && manager == null) "NO_CANDIDATE" else "CANDIDATES"}")
                appendLine("profileDependency=NONE")
                appendLine("character=${hex(rt.character)}")
                appendLine("-- GameEvent candidates --")
                if (events.isEmpty()) appendLine("none") else events.take(12).forEach { appendLine(it) }
                appendLine("-- Power manager / passive --")
                appendLine(manager ?: "not found")
                append("NOTE: a2/a3/a5 เป็น native code functions • ใช้ report นี้เป็น anchor ให้ Ghidra 5.5 ไล่ต่อ")
            }.trimEnd()
            finish(events.isNotEmpty() || manager != null, "Power+ • ตรวจ object เสร็จแล้ว", report, callback)
        }
    }

    private fun findGameEventCandidates(rt: RuntimeSnapshot): List<String> {
        val out = ArrayList<Pair<Int, String>>()
        var charOff = 0x280L
        while (charOff <= 0x620L) {
            val backref = memory.readLong(rt.pid, rt.character + charOff) ?: 0L
            if (isPointer(backref)) {
                var subtract = 0x80L
                while (subtract <= 0x380L) {
                    if (backref > subtract) {
                        val event = backref - subtract
                        val vptr = memory.readLong(rt.pid, event) ?: 0L
                        if (inModule(vptr, rt)) {
                            var score = 2
                            // Generic state-machine structure search.
                            var stateHit = ""
                            var indexOff = 0x100L
                            loop@ while (indexOff <= 0x240L) {
                                val idx = memory.readInt(rt.pid, event + indexOff)
                                if (idx != null && idx in 0..32) {
                                    var arrayOff = 0x100L
                                    while (arrayOff <= 0x240L) {
                                        val stateObj = memory.readLong(rt.pid, event + arrayOff + idx.toLong() * 8L) ?: 0L
                                        if (isPointer(stateObj)) {
                                            var valueOff = 0L
                                            while (valueOff <= 0x20L) {
                                                val sv = memory.readInt(rt.pid, stateObj + valueOff)
                                                if (sv != null && sv in 0..16) {
                                                    score += 5
                                                    stateHit = " cb=${staticHex(indexOff)} cc=${staticHex(arrayOff)} cd=${staticHex(valueOff)} state=$sv"
                                                    break@loop
                                                }
                                                valueOff += 4L
                                            }
                                        }
                                        arrayOff += 8L
                                    }
                                }
                                indexOff += 4L
                            }
                            if (score >= 7) {
                                out += score to "score=$score c0=${staticHex(charOff)} c1=${staticHex(subtract)} event=${hex(event)} c9=${staticHex(gh(vptr, rt))}$stateHit"
                            }
                        }
                    }
                    subtract += 8L
                }
            }
            charOff += 8L
        }
        return out.sortedByDescending { it.first }.map { it.second }.distinct()
    }

    private fun findPowerManagerCandidate(rt: RuntimeSnapshot): String? {
        // Search data globals around StageService. This uses semantic episode
        // keys rather than an old a1 address.
        var delta = -0x20000L
        while (delta <= 0x20000L) {
            val slotRt = rt.stageGlobalRt + delta
            val manager = memory.readLong(rt.pid, slotRt) ?: 0L
            if (isPointer(manager)) {
                var sentinelOff = 0x18L
                while (sentinelOff <= 0x80L) {
                    val sentinel = manager + sentinelOff
                    val startOff = sentinelOff + 8L
                    var node = memory.readLong(rt.pid, manager + startOff) ?: 0L
                    var guard = 0
                    while (isPointer(node) && node != sentinel && guard++ < 24) {
                        // Try common node object slots and common object->config slots.
                        for (nodeObjOff in longArrayOf(0x10L, 0x18L, 0x20L)) {
                            val obj = memory.readLong(rt.pid, node + nodeObjOff) ?: continue
                            if (!isPointer(obj)) continue
                            val vptr = memory.readLong(rt.pid, obj) ?: 0L
                            if (!inModule(vptr, rt)) continue
                            for (configOff in longArrayOf(0x08L, 0x10L, 0x18L)) {
                                val config = memory.readLong(rt.pid, obj + configOff) ?: continue
                                if (!isPointer(config)) continue
                                for (keyOff in longArrayOf(0L, 4L, 8L)) {
                                    val key = memory.readInt(rt.pid, config + keyOff) ?: continue
                                    if (POWER_KEYS.contains(key)) {
                                        return "a1=${staticHex(slotRt - rt.loadBias)} manager=${hex(manager)} key=$key c3=${staticHex(sentinelOff)} c4=${staticHex(startOff)} nodeObj=+${staticHex(nodeObjOff)} objConfig=+${staticHex(configOff)} keyOff=+${staticHex(keyOff)} ca=${staticHex(gh(vptr, rt))}"
                                    }
                                }
                            }
                        }
                        node = memory.readLong(rt.pid, node + 8L) ?: 0L
                    }
                    sentinelOff += 8L
                }
            }
            delta += 8L
        }
        return null
    }

    // ------------------------------------------------------------------
    // Runtime self-discovery
    // ------------------------------------------------------------------

    private fun resolveRuntime(requireGameplayState: Boolean = false): RuntimeSnapshot? {
        if (Thread.currentThread().isInterrupted) return null
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) return null

        tryCachedRuntime(requireGameplayState)?.let { return it }

        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
        val maps = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (maps.isEmpty() || Thread.currentThread().isInterrupted) return null

        val elfCandidates = LinkedHashSet<Long>()
        maps.forEach { m ->
            elfCandidates += m.start
            if (m.offset > 0L && m.start > m.offset) elfCandidates += m.start - m.offset
        }
        val elfBase = elfCandidates.firstOrNull { validateElf(pid, it) } ?: return null
        val loadBias = parseLoadBias(pid, elfBase) ?: return null
        val moduleStart = maps.minOf { it.start }
        val moduleEnd = maps.maxOf { it.end }

        val stage = findStageServiceGlobal(pid, maps, loadBias, moduleStart, moduleEnd) ?: return null
        if (Thread.currentThread().isInterrupted) return null
        val state = findGameplayStateGlobal(pid, stage, loadBias, moduleStart, moduleEnd)
        if (requireGameplayState && state == null) return null

        return RuntimeSnapshot(
            pid = pid,
            elfBase = elfBase,
            loadBias = loadBias,
            moduleStart = moduleStart,
            moduleEnd = moduleEnd,
            stageGlobalRt = stage.slotRt,
            stageGlobalGh = stage.slotGh,
            service = stage.service,
            serviceCharacterOffset = stage.characterOffset,
            character = stage.character,
            gameplayGlobalRt = state?.slotRt ?: 0L,
            gameplayGlobalGh = state?.slotGh ?: 0L,
            gameplayState = state?.state ?: 0L,
            stageScore = stage.score,
            stateScore = state?.score ?: 0
        ).also { runtimeCache = it }
    }

    private fun tryCachedRuntime(requireGameplayState: Boolean): RuntimeSnapshot? {
        val cached = runtimeCache ?: return null
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
        if (pid != cached.pid) {
            runtimeCache = null
            return null
        }
        val service = memory.readLong(pid, cached.stageGlobalRt) ?: 0L
        if (!isPointer(service)) {
            runtimeCache = null
            return null
        }
        val character = memory.readLong(pid, service + cached.serviceCharacterOffset) ?: 0L
        val charVptr = if (isPointer(character)) memory.readLong(pid, character) ?: 0L else 0L
        if (!isPointer(character) || charVptr !in cached.moduleStart until cached.moduleEnd) {
            runtimeCache = null
            return null
        }

        var out = cached.copy(service = service, character = character)
        if (requireGameplayState && !isPointer(out.gameplayState)) {
            val stage = ServiceCandidate(
                out.stageGlobalRt, out.stageGlobalGh, service, out.serviceCharacterOffset, character, out.stageScore
            )
            val state = findGameplayStateGlobal(pid, stage, out.loadBias, out.moduleStart, out.moduleEnd) ?: return null
            out = out.copy(
                gameplayGlobalRt = state.slotRt,
                gameplayGlobalGh = state.slotGh,
                gameplayState = state.state,
                stateScore = state.score
            )
        }
        runtimeCache = out
        return out
    }

    private fun refreshCharacter(rt: RuntimeSnapshot): RuntimeSnapshot? {
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: return null
        if (pid != rt.pid) return resolveRuntime()
        val service = memory.readLong(pid, rt.stageGlobalRt) ?: 0L
        if (!isPointer(service)) return rt.copy(service = service, character = 0L)
        val character = memory.readLong(pid, service + rt.serviceCharacterOffset) ?: 0L
        return rt.copy(service = service, character = if (isPointer(character)) character else 0L)
    }

    private fun findStageServiceGlobal(
        pid: Int,
        maps: List<RootProcessMemory.MapEntry>,
        loadBias: Long,
        moduleStart: Long,
        moduleEnd: Long
    ): ServiceCandidate? {
        val writable = maps.filter { it.perms.contains("w") }
        val candidates = ArrayList<ServiceCandidate>()
        val seenServices = HashSet<Long>()
        var evaluated = 0

        for (m in writable) {
            var cursor = m.start
            while (cursor < m.end && evaluated < 16000 && !Thread.currentThread().isInterrupted) {
                val size = minOf(4096L, m.end - cursor).toInt()
                val bytes = memory.readBytes(pid, cursor, size) ?: break
                val page = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var i = 0
                while (i + 8 <= bytes.size && evaluated < 16000) {
                    val value = page.getLong(i)
                    if (
                        isPointer(value) &&
                        (value < moduleStart || value >= moduleEnd) &&
                        seenServices.add(value)
                    ) {
                        evaluated++
                        val slotRt = cursor + i
                        val scored = scoreServiceObject(pid, slotRt, value, loadBias, moduleStart, moduleEnd)
                        if (scored != null && scored.score >= 7) {
                            candidates += scored
                            if (scored.score >= 11) return scored
                        }
                    }
                    i += 8
                }
                cursor += size.toLong()
            }
            if (Thread.currentThread().isInterrupted) return null
        }

        return candidates.sortedWith(
            compareByDescending<ServiceCandidate> { it.score }
                .thenByDescending { it.slotGh }
        ).firstOrNull()
    }

    private fun scoreServiceObject(
        pid: Int,
        slotRt: Long,
        service: Long,
        loadBias: Long,
        moduleStart: Long,
        moduleEnd: Long
    ): ServiceCandidate? {
        if (Thread.currentThread().isInterrupted) return null
        val serviceBytes = memory.readBytes(pid, service, 0x88) ?: return null
        val serviceVptr = longAt(serviceBytes, 0) ?: return null
        if (serviceVptr !in moduleStart until moduleEnd) return null

        var best: ServiceCandidate? = null
        var off = 0
        while (off <= 0x80) {
            val character = longAt(serviceBytes, off) ?: 0L
            if (isPointer(character)) {
                val charBytes = memory.readBytes(pid, character, 0x3C8)
                if (charBytes != null) {
                    var score = 1
                    val charVptr = longAt(charBytes, 0) ?: 0L
                    if (charVptr in moduleStart until moduleEnd) {
                        score += 4
                        val ownerVptr = longAt(charBytes, 0x148) ?: 0L
                        if (ownerVptr in moduleStart until moduleEnd) score += 3

                        val begin = longAt(charBytes, 0x180) ?: 0L
                        val end = longAt(charBytes, 0x188) ?: 0L
                        val cap = longAt(charBytes, 0x190) ?: 0L
                        if (vectorCountAllowEmpty(begin, end, cap) >= 0) score += 2

                        val s0 = floatAt(charBytes, 0x3BC)
                        val s1 = floatAt(charBytes, 0x3C0)
                        val s2 = floatAt(charBytes, 0x3C4)
                        if (listOf(s0, s1, s2).all { it != null && it.isFinite() && it in 0.05f..20.0f }) score += 1

                        val candidate = ServiceCandidate(
                            slotRt, slotRt - loadBias, service, off.toLong(), character, score
                        )
                        if (best == null || candidate.score > best!!.score) best = candidate
                    }
                }
            }
            off += 8
        }
        return best
    }

    private fun findGameplayStateGlobal(
        pid: Int,
        stage: ServiceCandidate,
        loadBias: Long,
        moduleStart: Long,
        moduleEnd: Long
    ): StateCandidate? {
        val out = ArrayList<StateCandidate>()
        var delta = -0x100L
        while (delta <= 0x100L && !Thread.currentThread().isInterrupted) {
            val slotRt = stage.slotRt + delta
            val state = memory.readLong(pid, slotRt) ?: 0L
            if (isPointer(state) && state != stage.service && state != stage.character && (state < moduleStart || state >= moduleEnd)) {
                val score = scoreStateObject(pid, state)
                if (score > 0) out += StateCandidate(slotRt, slotRt - loadBias, state, score + if (delta == 0x28L) 2 else 0)
            }
            delta += 8L
        }
        return out.sortedWith(compareByDescending<StateCandidate> { it.score }.thenBy { abs(it.slotRt - stage.slotRt) }).firstOrNull()
    }

    private fun scoreStateObject(pid: Int, state: Long): Int {
        var score = 0
        var foundLists = 0
        var off = 0x80L
        while (off <= 0x900L && foundLists < 6) {
            val sentinel = state + off
            val next = memory.readLong(pid, sentinel) ?: 0L
            val prev = memory.readLong(pid, sentinel + 8L) ?: 0L
            val count = memory.readLong(pid, sentinel + 0x10L) ?: -1L
            if (count in 0..MAX_LIST_COUNT) {
                val valid = if (count == 0L) {
                    (next == 0L && prev == 0L) || (next == sentinel && prev == sentinel)
                } else {
                    isPointer(next) && isPointer(prev)
                }
                if (valid) {
                    foundLists++
                    score += if (count == 0L) 1 else 2
                }
            }
            off += 8L
        }
        return score
    }

    // ------------------------------------------------------------------
    // Generic helpers
    // ------------------------------------------------------------------

    private fun scanProtectedFields(pid: Int, base: Long, start: Long, end: Long): List<ProtectedField> {
        val out = ArrayList<ProtectedField>()
        var off = start
        while (off <= end) {
            val bits = decodeProtectedBits(pid, base + off)
            if (bits != null) {
                val f = Float.fromBits(bits)
                if (f.isFinite() && abs(f) < 1.0e8f) out += ProtectedField(off, bits, f)
            }
            off += 8L
        }
        return out
    }

    private fun decodeProtectedBits(pid: Int, field: Long): Int? {
        val p8 = memory.readLong(pid, field + PROTECTED_P8) ?: return null
        val p10 = memory.readLong(pid, field + PROTECTED_P10) ?: return null
        val p18 = memory.readLong(pid, field + PROTECTED_P18) ?: return null
        if (!isPointer(p8) || !isPointer(p10) || !isPointer(p18)) return null
        val a = memory.readBytes(pid, p8, 4) ?: return null
        val b = memory.readBytes(pid, p10, 4) ?: return null
        if (a.size != 4 || b.size != 4) return null
        val first = decodeP8(a)
        return if (decodeP10(b) == first) first else null
    }

    private fun decodeP8(bytes: ByteArray): Int {
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF
        val d0 = ((256 - b3) and 0xFF) xor 0xC6
        val d1 = ((256 - b2) and 0xFF) xor 0x3A
        val d2 = ((256 - b1) and 0xFF) xor 0xC6
        val d3 = ((256 - b0) and 0xFF) xor 0x3A
        return d0 or (d1 shl 8) or (d2 shl 16) or (d3 shl 24)
    }

    private fun decodeP10(bytes: ByteArray): Int {
        val e0 = bytes[0].toInt() and 0xFF
        val e1 = bytes[1].toInt() and 0xFF
        val e2 = bytes[2].toInt() and 0xFF
        val e3 = bytes[3].toInt() and 0xFF
        val b0 = ((256 - e0) and 0xFF) xor 0x95
        val b1 = ((256 - e1) and 0xFF) xor 0x6B
        val b2 = ((256 - e2) and 0xFF) xor 0x95
        val b3 = ((256 - e3) and 0xFF) xor 0x6B
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }

    private fun findExactIntOffset(pid: Int, base: Long, target: Int, start: Long, end: Long): Long? {
        var off = start
        while (off <= end) {
            if (memory.readInt(pid, base + off) == target) return off
            off += 4L
        }
        return null
    }

    private fun longAt(bytes: ByteArray, offset: Int): Long? {
        if (offset < 0 || offset + 8 > bytes.size) return null
        return ByteBuffer.wrap(bytes, offset, 8).order(ByteOrder.LITTLE_ENDIAN).long
    }

    private fun floatAt(bytes: ByteArray, offset: Int): Float? {
        if (offset < 0 || offset + 4 > bytes.size) return null
        return ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.LITTLE_ENDIAN).float
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF
        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 && machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null
        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(pid, elfBase + phoff + index.toLong() * phentsize.toLong(), phentsize) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) { selected = vaddr; break }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun vectorCount(begin: Long, end: Long): Int {
        if (!isPointer(begin) || end < begin) return -1
        val bytes = end - begin
        if (bytes % 8L != 0L) return -1
        val count = bytes / 8L
        return if (count in 0..MAX_VECTOR_COUNT.toLong()) count.toInt() else -1
    }

    private fun vectorCountAllowEmpty(begin: Long, end: Long, cap: Long): Int {
        if (begin == 0L && end == 0L && cap == 0L) return 0
        if (!isPointer(begin) || !isPointer(end) || !isPointer(cap)) return -1
        if (end < begin || cap < end) return -1
        val bytes = end - begin
        if (bytes % 8L != 0L) return -1
        val count = bytes / 8L
        return if (count in 0..MAX_VECTOR_COUNT.toLong()) count.toInt() else -1
    }

    private fun inModule(value: Long, rt: RuntimeSnapshot): Boolean = value >= rt.moduleStart && value < rt.moduleEnd
    private fun isPointer(value: Long): Boolean = value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L
    private fun gh(runtimeAddress: Long, rt: RuntimeSnapshot): Long = runtimeAddress - rt.loadBias
    private fun staticHex(value: Long): String = String.format(Locale.US, "%08X", value)
    private fun hex(value: Long): String = "0x${value.toString(16)}"
    private fun u32(value: Int): String = String.format(Locale.US, "%08X", value)
    private fun fmt(value: Float): String = String.format(Locale.US, "%.6f", value)

    private fun submitOperation(
        startMessage: String,
        startReport: String,
        callback: (Result) -> Unit,
        block: () -> Unit
    ) {
        cancelCurrentWork()
        lastStatus = startMessage
        lastReport = startReport
        callback(Result(true, startMessage, startReport))
        operationTask = executor.submit {
            try {
                if (!Thread.currentThread().isInterrupted) block()
            } finally {
                operationTask = null
            }
        }
    }

    private fun cancelCurrentWork() {
        operationTask?.cancel(true)
        operationTask = null
        stopTaskInternal()
    }

    private fun stopTaskInternal() {
        activeTask?.cancel(false)
        activeTask = null
        jumpStartedAt = 0L
        recoveryStartedAt = 0L
        effectStartedAt = 0L
    }

    private fun buildRuntimeFailure(): String = buildString {
        appendLine("=== DEV RUNTIME AUTO FINDER ===")
        appendLine("status=RUNTIME_NOT_READY")
        appendLine("profileDependency=NONE")
        appendLine("need: Root + CookieRun process + เข้า Stage")
        append("DEV จะหา libgame / StageService / Character เอง ไม่ต้องเปิด f06 หรือ Feature อื่นก่อน")
    }

    private fun finish(ok: Boolean, message: String, report: String, callback: (Result) -> Unit) {
        lastStatus = message
        lastReport = report
        callback(Result(ok, message, report))
    }
}
