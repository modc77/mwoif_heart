package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Read-only Stage detector for BOT LAB V5.
 *
 * It reuses the same StageService/Character chain already used by the run-reward
 * feature. No game memory is written here.
 */
class BotStageDetector(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {

    enum class State {
        ACTIVE,
        INACTIVE,
        NOT_READY
    }

    private data class Runtime(
        val pid: Int,
        val stageServiceGlobal: Long
    )

    private val appContext = context.applicationContext

    @Volatile private var runtime: Runtime? = null
    @Volatile private var nextResolveAt = 0L
    @Volatile private var lastStatus = "รอ Stage detector"

    fun status(): String = lastStatus

    /** Used by BOT recovery when CookieRun crashes or restarts. */
    fun gameProcessAlive(): Boolean = memory.pidOf(CrgProfile.GAME_PACKAGE) != null

    fun reset() {
        runtime = null
        nextResolveAt = 0L
        lastStatus = "รีเซ็ต Stage detector"
    }

    fun probe(): State {
        if (!RootMemoryClient.isReady()) {
            lastStatus = "รอ Root Worker"
            return State.NOT_READY
        }

        var rt = runtime
        if (rt != null) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                runtime = null
                rt = null
            }
        }

        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) {
                return State.NOT_READY
            }
            nextResolveAt = now + 1_000L

            rt = prepareRuntime()
            if (rt == null) {
                return State.NOT_READY
            }
            runtime = rt
        }

        val profile = SecureProfileManager.getRunReward()
        if (profile == null) {
            runtime = null
            lastStatus = "รอ Secure Stage Profile"
            return State.NOT_READY
        }

        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: run {
            runtime = null
            lastStatus = "StageService อ่านไม่ได้ • retry"
            return State.NOT_READY
        }

        if (!isPointer(service)) {
            lastStatus = "นอก Stage"
            return State.INACTIVE
        }

        val direct = memory.readLong(rt.pid, service + profile.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) {
            lastStatus = "Stage ACTIVE"
            return State.ACTIVE
        }

        val jelly = memory.readLong(rt.pid, service + profile.serviceJellyManagerOffset) ?: 0L
        if (isPointer(jelly)) {
            val fallback = memory.readLong(rt.pid, jelly + profile.jellyManagerCharacterOffset) ?: 0L
            if (isPointer(fallback)) {
                lastStatus = "Stage ACTIVE"
                return State.ACTIVE
            }
        }

        lastStatus = "นอก Stage"
        return State.INACTIVE
    }

    private fun prepareRuntime(): Runtime? {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            lastStatus = "Root Worker ยังไม่พร้อม"
            return null
        }

        val profile = SecureProfileManager.getRunReward()
        if (profile == null) {
            SecureProfileManager.preloadRunReward(forceRefresh = false, callback = null)
            lastStatus = "กำลังโหลด Stage Profile"
            return null
        }

        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
        if (pid == null) {
            lastStatus = "รอ CookieRun"
            return null
        }

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) {
            lastStatus = "รอ libgame.so"
            return null
        }

        val candidates = LinkedHashSet<Long>()
        ranges.forEach { range ->
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
        if (elfBase == null) {
            lastStatus = "หา libgame ELF ไม่เจอ"
            return null
        }

        val loadBias = parseLoadBias(pid, elfBase)
        if (loadBias == null) {
            lastStatus = "หา libgame bias ไม่สำเร็จ"
            return null
        }

        val stageServiceGlobal = loadBias + (profile.stageServiceGlobal - profile.imageBase)
        if (stageServiceGlobal < 0x10000L) {
            lastStatus = "Stage global ไม่ถูกต้อง"
            return null
        }

        if (memory.readLong(pid, stageServiceGlobal) == null) {
            lastStatus = "Stage global อ่านไม่ได้"
            return null
        }

        lastStatus = "Stage detector พร้อม"
        return Runtime(pid = pid, stageServiceGlobal = stageServiceGlobal)
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false

        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF

        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null

            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue

            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }

        return elfBase - (selected ?: return null)
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L &&
            value < 0x0001000000000000L &&
            value % 8L == 0L
}
