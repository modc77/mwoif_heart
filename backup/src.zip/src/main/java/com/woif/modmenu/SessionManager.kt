    package com.woif.modmenu

    import android.os.SystemClock
    import java.time.Instant

    /**
    * Current M Woif server-backed session.
    *
    * Session token is MEMORY ONLY.
    * It is intentionally not persisted to SharedPreferences.
    *
    * Therefore a fresh process/app start still requires LOGIN.
    */
    object SessionManager {

        data class Snapshot(
            val sessionToken: String,
            val deviceId: String,
            val gameId: String,
            val gameVersion: String,
            val appVersion: String,
            val licenseExpiryMillis: Long,
            val sessionExpiryMillis: Long,
            val heartbeatSeconds: Int,
            val appContent: AppContentSnapshot
        )

        private val lock =
            Any()

        private var snapshot:
                Snapshot? =
            null

        private var serverTimeAtSyncMillis =
            0L

        private var elapsedAtSyncMillis =
            0L

        fun authenticate(
            response: LoginResponse,
            appVersion: String
        ) {

            synchronized(
                lock
            ) {

                snapshot =
                    Snapshot(
                        sessionToken =
                        response.sessionToken,

                        deviceId =
                        response.deviceId,

                        gameId =
                        response.gameId,

                        gameVersion =
                        response.gameVersion,

                        appVersion =
                        appVersion,

                        licenseExpiryMillis =
                        parseUtc(
                            response.expiresAt
                        ),

                        sessionExpiryMillis =
                        parseUtc(
                            response.sessionExpiresAt
                        ),

                        heartbeatSeconds =
                        response.heartbeatSeconds
                            .coerceIn(
                                10,
                                600
                            ),

                        appContent =
                        response.appContent
                    )

                syncServerTimeLocked(
                    response.serverTime
                )
            }
        }

        fun update(
            response: CheckResponse
        ) {

            synchronized(
                lock
            ) {

                val current =
                    snapshot
                        ?: return

                snapshot =
                    current.copy(
                        gameVersion =
                        response.gameVersion,

                        licenseExpiryMillis =
                        parseUtc(
                            response.expiresAt
                        ),

                        sessionExpiryMillis =
                        parseUtc(
                            response.sessionExpiresAt
                        ),

                        heartbeatSeconds =
                        response.heartbeatSeconds
                            .coerceIn(
                                10,
                                600
                            ),

                        appContent =
                        response.appContent
                            ?: current.appContent
                    )

                syncServerTimeLocked(
                    response.serverTime
                )
            }
        }

        fun clear() {

            synchronized(
                lock
            ) {

                snapshot =
                    null

                serverTimeAtSyncMillis =
                    0L

                elapsedAtSyncMillis =
                    0L
            }
        }

        fun isAuthenticated():
                Boolean {

            synchronized(
                lock
            ) {

                val current =
                    snapshot
                        ?: return false

                return licenseRemainingMillisLocked(
                    current
                ) > 0L &&
                        sessionRemainingMillisLocked(
                            current
                        ) > 0L
            }
        }

        fun snapshot():
                Snapshot? {

            synchronized(
                lock
            ) {

                return snapshot?.copy()
            }
        }

        fun appContent():
                AppContentSnapshot {

            synchronized(
                lock
            ) {

                return snapshot
                    ?.appContent
                    ?: AppContentSnapshot.empty()
            }
        }

        fun appContentRevision():
                Long {

            synchronized(
                lock
            ) {

                return snapshot
                    ?.appContent
                    ?.revision
                    ?: 0L
            }
        }

        fun heartbeatSeconds():
                Int {

            synchronized(
                lock
            ) {

                return snapshot
                    ?.heartbeatSeconds
                    ?: 60
            }
        }

        fun serverNowMillis():
                Long {

            synchronized(
                lock
            ) {

                return serverNowMillisLocked()
            }
        }

        fun licenseExpiryMillis():
                Long {

            synchronized(
                lock
            ) {

                return snapshot
                    ?.licenseExpiryMillis
                    ?: 0L
            }
        }

        fun sessionExpiryMillis():
                Long {

            synchronized(
                lock
            ) {

                return snapshot
                    ?.sessionExpiryMillis
                    ?: 0L
            }
        }

        fun licenseRemainingMillis():
                Long {

            synchronized(
                lock
            ) {

                val current =
                    snapshot
                        ?: return 0L

                return licenseRemainingMillisLocked(
                    current
                )
            }
        }

        fun sessionRemainingMillis():
                Long {

            synchronized(
                lock
            ) {

                val current =
                    snapshot
                        ?: return 0L

                return sessionRemainingMillisLocked(
                    current
                )
            }
        }

        private fun syncServerTimeLocked(
            serverTime: String
        ) {

            serverTimeAtSyncMillis =
                parseUtc(
                    serverTime
                )

            elapsedAtSyncMillis =
                SystemClock.elapsedRealtime()
        }

        private fun serverNowMillisLocked():
                Long {

            if (
                serverTimeAtSyncMillis <= 0L ||
                elapsedAtSyncMillis <= 0L
            ) {

                return System.currentTimeMillis()
            }

            val elapsed =
                (
                        SystemClock.elapsedRealtime() -
                                elapsedAtSyncMillis
                        )
                    .coerceAtLeast(
                        0L
                    )

            return serverTimeAtSyncMillis +
                    elapsed
        }

        private fun licenseRemainingMillisLocked(
            current: Snapshot
        ): Long {

            return (
                    current.licenseExpiryMillis -
                            serverNowMillisLocked()
                    )
                .coerceAtLeast(
                    0L
                )
        }

        private fun sessionRemainingMillisLocked(
            current: Snapshot
        ): Long {

            return (
                    current.sessionExpiryMillis -
                            serverNowMillisLocked()
                    )
                .coerceAtLeast(
                    0L
                )
        }

        private fun parseUtc(
            value: String
        ): Long {

            return Instant.parse(
                value
            )
                .toEpochMilli()
        }
    }
