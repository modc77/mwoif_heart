package com.woif.modmenu

import android.content.Context

object GameVersionProvider {

    fun get(context: Context): String {
        return try {
            @Suppress("DEPRECATION")
            context.packageManager
                .getPackageInfo(
                    CrgProfile.GAME_PACKAGE,
                    0
                )
                .versionName
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?: "unknown"
        } catch (_: Exception) {
            "unknown"
        }
    }
}
