package com.woif.modmenu

import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object SecureProfileManager {

    sealed class Result {

        data class Success(
            val revision:
            String
        ) : Result()

        data class Failure(
            val code:
            String,
            val message:
            String
        ) : Result()
    }

    private val executor =
        Executors
            .newSingleThreadExecutor()

    /*
     * Secure Profile hardening policy:
     * - decrypted profiles are RAM-only
     * - hard client cache lifetime is capped at 180 seconds
     * - loaded profiles are proactively refreshed with a fresh server-issued
     *   AES key before expiry
     * - cacheGeneration prevents an old in-flight request from repopulating
     *   RAM after logout/session invalidation
     */
    private const val MAX_CACHE_TTL_SECONDS = 180
    private const val REFRESH_LEAD_MS = 90_000L

    @Volatile
    private var cacheGeneration = 0L

    private val gameSpeedLoading =
        AtomicBoolean(
            false
        )

    private val hpLoading =
        AtomicBoolean(
            false
        )

    private val giantLoading =
        AtomicBoolean(
            false
        )

    private val superLoading =
        AtomicBoolean(
            false
        )

    private val powerPlusLoading =
        AtomicBoolean(
            false
        )

    private val runRewardLoading =
        AtomicBoolean(
            false
        )

    private val potatoLoading =
        AtomicBoolean(
            false
        )

    private val baseSpeedLoading =
        AtomicBoolean(
            false
        )

    private val recoveryLoading =
        AtomicBoolean(
            false
        )

    private val jumpLoading =
        AtomicBoolean(
            false
        )

    @Volatile
    private var gameSpeed:
            GameSpeedProfile? =
        null

    @Volatile
    private var gameSpeedValidUntilElapsed =
        0L

    @Volatile
    private var hp:
            HpProfile? =
        null

    @Volatile
    private var hpValidUntilElapsed =
        0L

    @Volatile
    private var giant:
            NativeEffectProfile? =
        null

    @Volatile
    private var giantValidUntilElapsed =
        0L

    @Volatile
    private var superEffect:
            NativeEffectProfile? =
        null

    @Volatile
    private var superValidUntilElapsed =
        0L

    @Volatile
    private var powerPlus:
            PowerPlusProfile? =
        null

    @Volatile
    private var powerPlusValidUntilElapsed =
        0L

    @Volatile
    private var runReward:
            RunRewardProfile? =
        null

    @Volatile
    private var runRewardValidUntilElapsed =
        0L

    @Volatile
    private var potato:
            PotatoProfile? =
        null

    @Volatile
    private var potatoValidUntilElapsed =
        0L

    @Volatile
    private var baseSpeed:
            BaseSpeedProfile? =
        null

    @Volatile
    private var baseSpeedValidUntilElapsed =
        0L

    @Volatile
    private var recovery:
            RecoveryProfile? =
        null

    @Volatile
    private var recoveryValidUntilElapsed =
        0L

    @Volatile
    private var jump:
            JumpProfile? =
        null

    @Volatile
    private var jumpValidUntilElapsed =
        0L

    fun hasGameSpeed():
            Boolean {

        return getGameSpeed() !=
                null
    }

    fun getGameSpeed():
            GameSpeedProfile? {

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_GAME_SPEED)) {
            gameSpeed = null
            gameSpeedValidUntilElapsed = 0L
            return null
        }

        val current =
            gameSpeed
                ?: return null

        if (
            SystemClock.elapsedRealtime() >=
            gameSpeedValidUntilElapsed
        ) {

            gameSpeed =
                null

            gameSpeedValidUntilElapsed =
                0L

            return null
        }

        return current
    }

    fun hasHp():
            Boolean {

        return getHp() !=
                null
    }

    fun getHp():
            HpProfile? {

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_HP)) {
            hp = null
            hpValidUntilElapsed = 0L
            return null
        }

        val current =
            hp
                ?: return null

        if (
            SystemClock.elapsedRealtime() >=
            hpValidUntilElapsed
        ) {

            hp =
                null

            hpValidUntilElapsed =
                0L

            return null
        }

        return current
    }

    fun preloadGameSpeed(
        forceRefresh: Boolean = false,
        callback:
        ((Result) -> Unit)? =
            null
    ) {

        if (
            !forceRefresh &&
            hasGameSpeed()
        ) {

            callback?.invoke(
                Result.Success(
                    gameSpeed
                        ?.revision
                        ?: "cached"
                )
            )

            return
        }

        load(
            featureId =
            CrgProfile
                .FEATURE_GAME_SPEED,

            guard =
            gameSpeedLoading,

            callback =
            callback,

            onEnvelope = {
                    envelope ->

                val profile =
                    decryptGameSpeed(
                        envelope
                    )

                gameSpeed =
                    profile

                gameSpeedValidUntilElapsed =
                    profileValidUntil(
                        profile.ttlSeconds
                    )

                profile.revision
            }
        )
    }

    fun preloadHp(
        forceRefresh: Boolean = false,
        callback:
        ((Result) -> Unit)? =
            null
    ) {

        if (
            !forceRefresh &&
            hasHp()
        ) {

            callback?.invoke(
                Result.Success(
                    hp
                        ?.revision
                        ?: "cached"
                )
            )

            return
        }

        load(
            featureId =
            CrgProfile
                .FEATURE_HP,

            guard =
            hpLoading,

            callback =
            callback,

            onEnvelope = {
                    envelope ->

                val profile =
                    decryptHp(
                        envelope
                    )

                hp =
                    profile

                hpValidUntilElapsed =
                    profileValidUntil(
                        profile.ttlSeconds
                    )

                profile.revision
            }
        )
    }

    fun hasGiant(): Boolean {
        return getGiant() != null
    }

    fun getGiant(): NativeEffectProfile? {
        return getNativeEffectCached(
            featureId = CrgProfile.FEATURE_GIANT,
            current = giant,
            validUntil = giantValidUntilElapsed
        ) {
            giant = null
            giantValidUntilElapsed = 0L
        }
    }

    fun hasSuper(): Boolean {
        return getSuper() != null
    }

    fun getSuper(): NativeEffectProfile? {
        return getNativeEffectCached(
            featureId = CrgProfile.FEATURE_SUPER,
            current = superEffect,
            validUntil = superValidUntilElapsed
        ) {
            superEffect = null
            superValidUntilElapsed = 0L
        }
    }

    fun preloadGiant(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getGiant()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        load(
            featureId = CrgProfile.FEATURE_GIANT,
            guard = giantLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptNativeEffect(
                    envelope,
                    CrgProfile.FEATURE_GIANT
                )
                giant = profile
                giantValidUntilElapsed =
                    profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun preloadSuper(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getSuper()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        load(
            featureId = CrgProfile.FEATURE_SUPER,
            guard = superLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptNativeEffect(
                    envelope,
                    CrgProfile.FEATURE_SUPER
                )
                superEffect = profile
                superValidUntilElapsed =
                    profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun hasPowerPlus(): Boolean {
        return getPowerPlus() != null
    }

    fun getPowerPlus(): PowerPlusProfile? {
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POWER_PLUS)) {
            powerPlus = null
            powerPlusValidUntilElapsed = 0L
            return null
        }

        val current = powerPlus ?: return null
        if (SystemClock.elapsedRealtime() >= powerPlusValidUntilElapsed) {
            powerPlus = null
            powerPlusValidUntilElapsed = 0L
            return null
        }
        return current
    }

    fun preloadPowerPlus(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getPowerPlus()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        load(
            featureId = CrgProfile.FEATURE_POWER_PLUS,
            guard = powerPlusLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptPowerPlus(envelope)
                powerPlus = profile
                powerPlusValidUntilElapsed =
                    profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun hasRunReward(): Boolean {
        return getRunReward() != null
    }

    fun getRunReward(): RunRewardProfile? {
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            runReward = null
            runRewardValidUntilElapsed = 0L
            return null
        }

        val current = runReward ?: return null
        if (SystemClock.elapsedRealtime() >= runRewardValidUntilElapsed) {
            runReward = null
            runRewardValidUntilElapsed = 0L
            return null
        }
        return current
    }

    fun preloadRunReward(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getRunReward()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        load(
            featureId = CrgProfile.FEATURE_RUN_REWARD,
            guard = runRewardLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptRunReward(envelope)
                runReward = profile
                runRewardValidUntilElapsed =
                    profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun hasPotato(): Boolean {
        return getPotato() != null
    }

    fun getPotato(): PotatoProfile? {
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            potato = null
            potatoValidUntilElapsed = 0L
            return null
        }

        val current = potato ?: return null
        if (SystemClock.elapsedRealtime() >= potatoValidUntilElapsed) {
            potato = null
            potatoValidUntilElapsed = 0L
            return null
        }
        return current
    }

    fun preloadPotato(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getPotato()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        /*
         * Potato is shared by Rapid / Ultimate / Coin. If an early preload is
         * already in flight, do not start another HTTP request and do not drop
         * the toggle callback. The executor is single-threaded, so this waiter
         * runs immediately after the in-flight fetch/decrypt task.
         */
        if (potatoLoading.get()) {
            if (callback != null) {
                executor.execute {
                    val ready = getPotato()
                    callback.invoke(
                        if (ready != null) {
                            Result.Success(ready.revision)
                        } else {
                            Result.Failure(
                                "PROFILE_NOT_READY",
                                "Secure Potato Profile is not ready"
                            )
                        }
                    )
                }
            }
            return
        }

        load(
            featureId = CrgProfile.FEATURE_POTATO,
            guard = potatoLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptPotato(envelope)
                potato = profile
                potatoValidUntilElapsed =
                    profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun hasBaseSpeed(): Boolean {
        return getBaseSpeed() != null
    }

    fun getBaseSpeed(): BaseSpeedProfile? {
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_BASE_SPEED)) {
            baseSpeed = null
            baseSpeedValidUntilElapsed = 0L
            return null
        }

        val current = baseSpeed ?: return null
        if (SystemClock.elapsedRealtime() >= baseSpeedValidUntilElapsed) {
            baseSpeed = null
            baseSpeedValidUntilElapsed = 0L
            return null
        }
        return current
    }

    fun preloadBaseSpeed(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getBaseSpeed()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        load(
            featureId = CrgProfile.FEATURE_BASE_SPEED,
            guard = baseSpeedLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptBaseSpeed(envelope)
                baseSpeed = profile
                baseSpeedValidUntilElapsed = profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun hasRecovery(): Boolean {
        return getRecovery() != null
    }

    fun getRecovery(): RecoveryProfile? {
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)) {
            recovery = null
            recoveryValidUntilElapsed = 0L
            return null
        }

        val current = recovery ?: return null
        if (SystemClock.elapsedRealtime() >= recoveryValidUntilElapsed) {
            recovery = null
            recoveryValidUntilElapsed = 0L
            return null
        }
        return current
    }

    fun preloadRecovery(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getRecovery()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        if (recoveryLoading.get()) {
            if (callback != null) {
                executor.execute {
                    val ready = getRecovery()
                    callback.invoke(
                        if (ready != null) {
                            Result.Success(ready.revision)
                        } else {
                            Result.Failure(
                                "PROFILE_NOT_READY",
                                "Secure Recovery Profile is not ready"
                            )
                        }
                    )
                }
            }
            return
        }

        load(
            featureId = CrgProfile.FEATURE_RECOVERY,
            guard = recoveryLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptRecovery(envelope)
                recovery = profile
                recoveryValidUntilElapsed = profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    fun hasJump(): Boolean {
        return getJump() != null
    }

    fun getJump(): JumpProfile? {
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_UNLIMITED_JUMP)) {
            jump = null
            jumpValidUntilElapsed = 0L
            return null
        }

        val current = jump ?: return null
        if (SystemClock.elapsedRealtime() >= jumpValidUntilElapsed) {
            jump = null
            jumpValidUntilElapsed = 0L
            return null
        }
        return current
    }

    fun preloadJump(
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val current = getJump()
        if (!forceRefresh && current != null) {
            callback?.invoke(Result.Success(current.revision))
            return
        }

        if (jumpLoading.get()) {
            if (callback != null) {
                executor.execute {
                    val ready = getJump()
                    callback.invoke(
                        if (ready != null) {
                            Result.Success(ready.revision)
                        } else {
                            Result.Failure(
                                "PROFILE_NOT_READY",
                                "Secure Unlimited Jump Profile is not ready"
                            )
                        }
                    )
                }
            }
            return
        }

        load(
            featureId = CrgProfile.FEATURE_UNLIMITED_JUMP,
            guard = jumpLoading,
            callback = callback,
            onEnvelope = { envelope ->
                val profile = decryptJump(envelope)
                jump = profile
                jumpValidUntilElapsed = profileValidUntil(profile.ttlSeconds)
                profile.revision
            }
        )
    }

    /**
     * Catalog-driven Secure Profile entry point.
     *
     * Floating/UI code should ask for a known feature family instead of
     * duplicating the decoder mapping. The specialized preload methods remain
     * intact because runtime modules already use their typed profile accessors.
     */
    fun hasFeature(featureId: String): Boolean {
        val feature = FeatureCatalog.feature(featureId) ?: return false

        return when (feature.profileKind) {
            FeatureCatalog.ProfileKind.GAME_SPEED -> hasGameSpeed()
            FeatureCatalog.ProfileKind.HP -> hasHp()
            FeatureCatalog.ProfileKind.NATIVE_EFFECT ->
                when (featureId) {
                    CrgProfile.FEATURE_GIANT -> hasGiant()
                    CrgProfile.FEATURE_SUPER -> hasSuper()
                    else -> false
                }
            FeatureCatalog.ProfileKind.POWER_PLUS -> hasPowerPlus()
            FeatureCatalog.ProfileKind.RUN_REWARD -> hasRunReward()
            FeatureCatalog.ProfileKind.POTATO -> hasPotato()
            FeatureCatalog.ProfileKind.BASE_SPEED -> hasBaseSpeed()
            FeatureCatalog.ProfileKind.RECOVERY -> hasRecovery()
            FeatureCatalog.ProfileKind.UNLIMITED_JUMP -> hasJump()
        }
    }

    fun preloadFeature(
        featureId: String,
        forceRefresh: Boolean = false,
        callback: ((Result) -> Unit)? = null
    ) {
        val feature = FeatureCatalog.feature(featureId)

        if (feature == null) {
            callback?.invoke(
                Result.Failure(
                    "UNKNOWN_FEATURE",
                    "Feature is not present in the client catalog"
                )
            )
            return
        }

        when (feature.profileKind) {
            FeatureCatalog.ProfileKind.GAME_SPEED ->
                preloadGameSpeed(forceRefresh, callback)

            FeatureCatalog.ProfileKind.HP ->
                preloadHp(forceRefresh, callback)

            FeatureCatalog.ProfileKind.NATIVE_EFFECT ->
                when (featureId) {
                    CrgProfile.FEATURE_GIANT ->
                        preloadGiant(forceRefresh, callback)
                    CrgProfile.FEATURE_SUPER ->
                        preloadSuper(forceRefresh, callback)
                    else ->
                        callback?.invoke(
                            Result.Failure(
                                "PROFILE_MAPPING_MISSING",
                                "Native effect feature mapping is missing"
                            )
                        )
                }

            FeatureCatalog.ProfileKind.POWER_PLUS ->
                preloadPowerPlus(forceRefresh, callback)

            FeatureCatalog.ProfileKind.RUN_REWARD ->
                preloadRunReward(forceRefresh, callback)

            FeatureCatalog.ProfileKind.POTATO ->
                preloadPotato(forceRefresh, callback)

            FeatureCatalog.ProfileKind.BASE_SPEED ->
                preloadBaseSpeed(forceRefresh, callback)

            FeatureCatalog.ProfileKind.RECOVERY ->
                preloadRecovery(forceRefresh, callback)

            FeatureCatalog.ProfileKind.UNLIMITED_JUMP ->
                preloadJump(forceRefresh, callback)
        }
    }

    private fun getNativeEffectCached(
        featureId: String,
        current: NativeEffectProfile?,
        validUntil: Long,
        clear: () -> Unit
    ): NativeEffectProfile? {
        if (!ControlPlaneState.isFeatureAllowed(featureId)) {
            clear()
            return null
        }

        val value = current ?: return null
        if (SystemClock.elapsedRealtime() >= validUntil) {
            clear()
            return null
        }

        return value
    }

    /**
     * Refresh only profiles that are already resident in RAM and approaching
     * expiry. No profile is persisted. A profile refresh causes the server to
     * generate a brand-new AES-256-GCM key for that response.
     */
    fun refreshDueProfiles() {
        if (!SessionManager.isAuthenticated()) {
            clear()
            return
        }

        val now = SystemClock.elapsedRealtime()

        fun due(value: Any?, validUntil: Long): Boolean {
            return value != null &&
                validUntil > 0L &&
                validUntil - now <= REFRESH_LEAD_MS
        }

        if (due(gameSpeed, gameSpeedValidUntilElapsed)) {
            preloadGameSpeed(forceRefresh = true)
        }
        if (due(hp, hpValidUntilElapsed)) {
            preloadHp(forceRefresh = true)
        }
        if (due(giant, giantValidUntilElapsed)) {
            preloadGiant(forceRefresh = true)
        }
        if (due(superEffect, superValidUntilElapsed)) {
            preloadSuper(forceRefresh = true)
        }
        if (due(powerPlus, powerPlusValidUntilElapsed)) {
            preloadPowerPlus(forceRefresh = true)
        }
        if (due(runReward, runRewardValidUntilElapsed)) {
            preloadRunReward(forceRefresh = true)
        }
        if (due(potato, potatoValidUntilElapsed)) {
            preloadPotato(forceRefresh = true)
        }
        if (due(baseSpeed, baseSpeedValidUntilElapsed)) {
            preloadBaseSpeed(forceRefresh = true)
        }
        if (due(recovery, recoveryValidUntilElapsed)) {
            preloadRecovery(forceRefresh = true)
        }
        if (due(jump, jumpValidUntilElapsed)) {
            preloadJump(forceRefresh = true)
        }
    }

    private fun profileValidUntil(ttlSeconds: Int): Long {
        val effectiveTtl =
            ttlSeconds.coerceIn(60, MAX_CACHE_TTL_SECONDS)
        return SystemClock.elapsedRealtime() + effectiveTtl.toLong() * 1000L
    }

    fun clearFeature(featureId: String) {

        when (featureId) {
            CrgProfile.FEATURE_GAME_SPEED -> {
                gameSpeed = null
                gameSpeedValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_HP -> {
                hp = null
                hpValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_GIANT -> {
                giant = null
                giantValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_SUPER -> {
                superEffect = null
                superValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_POWER_PLUS -> {
                powerPlus = null
                powerPlusValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_RUN_REWARD -> {
                runReward = null
                runRewardValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_POTATO -> {
                potato = null
                potatoValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_BASE_SPEED -> {
                baseSpeed = null
                baseSpeedValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_RECOVERY -> {
                recovery = null
                recoveryValidUntilElapsed = 0L
            }

            CrgProfile.FEATURE_UNLIMITED_JUMP -> {
                jump = null
                jumpValidUntilElapsed = 0L
            }
        }
    }

    fun clear() {

        cacheGeneration += 1L

        gameSpeed =
            null

        gameSpeedValidUntilElapsed =
            0L

        hp =
            null

        hpValidUntilElapsed =
            0L

        giant =
            null

        giantValidUntilElapsed =
            0L

        superEffect =
            null

        superValidUntilElapsed =
            0L

        powerPlus =
            null

        powerPlusValidUntilElapsed =
            0L

        runReward =
            null

        runRewardValidUntilElapsed =
            0L

        potato =
            null

        potatoValidUntilElapsed =
            0L

        baseSpeed =
            null

        baseSpeedValidUntilElapsed =
            0L

        recovery =
            null

        recoveryValidUntilElapsed =
            0L

        jump =
            null

        jumpValidUntilElapsed =
            0L
    }

    private fun load(
        featureId:
        String,
        guard:
        AtomicBoolean,
        callback:
        ((Result) -> Unit)?,
        onEnvelope:
            (SecureProfileApi.Envelope) -> String
    ) {

        if (!FeatureCatalog.isKnownFeatureId(featureId)) {
            callback?.invoke(
                Result.Failure(
                    "UNKNOWN_FEATURE",
                    "Feature is not present in the client catalog"
                )
            )
            return
        }

        if (!ControlPlaneState.isFeatureAllowed(featureId)) {
            clearFeature(featureId)

            callback?.invoke(
                Result.Failure(
                    if (ControlPlaneState.canWrite()) {
                        "FEATURE_DISABLED"
                    } else {
                        "GAME_VERSION_BLOCKED"
                    },
                    ControlPlaneState.snapshot().message
                        ?: "Feature is unavailable"
                )
            )

            return
        }

        val session =
            SessionManager.snapshot()

        if (
            session ==
            null ||
            !SessionManager
                .isAuthenticated()
        ) {

            callback?.invoke(
                Result.Failure(
                    "NO_SESSION",
                    "No authenticated session"
                )
            )

            return
        }

        if (
            !guard.compareAndSet(
                false,
                true
            )
        ) {
            return
        }

        val generationAtStart = cacheGeneration

        executor.execute {

            val result =
                when (
                    val response =
                        SecureProfileApi.fetch(
                            session =
                            session,

                            featureId =
                            featureId
                        )
                ) {

                    is SecureProfileApi
                    .Result
                    .Failure -> {

                        Result.Failure(
                            response.code,
                            response.message
                        )
                    }

                    is SecureProfileApi
                    .Result
                    .Success -> {

                        try {

                            if (
                                generationAtStart != cacheGeneration ||
                                !SessionManager.isAuthenticated() ||
                                !ControlPlaneState.isFeatureAllowed(featureId)
                            ) {
                                Result.Failure(
                                    "PROFILE_DISCARDED",
                                    "Secure profile response is no longer valid"
                                )
                            } else {
                                val revision =
                                    onEnvelope(
                                        response.envelope
                                    )

                                Result.Success(
                                    revision
                                )
                            }

                        } catch (
                            e: Exception
                        ) {

                            Result.Failure(
                                "PROFILE_DECRYPT_FAILED",
                                e.message
                                    ?: "Decrypt failed"
                            )
                        }
                    }
                }

            guard.set(
                false
            )

            callback?.invoke(
                result
            )
        }
    }

    private fun decryptGameSpeed(
        envelope:
        SecureProfileApi.Envelope
    ): GameSpeedProfile {

        val json =
            decryptJson(
                envelope
            )

        if (
            json.getString(
                "f"
            ) !=
            CrgProfile
                .FEATURE_GAME_SPEED
        ) {
            error(
                "Feature mismatch"
            )
        }

        return GameSpeedProfile(
            a0 =
            hexLong(
                json.getString(
                    "a0"
                )
            ),

            a1 =
            hexLong(
                json.getString(
                    "a1"
                )
            ),

            a2 =
            hexLong(
                json.getString(
                    "a2"
                )
            ),

            a3 =
            hexLong(
                json.getString(
                    "a3"
                )
            ),

            a4 =
            hexLong(
                json.getString(
                    "a4"
                )
            ),

            a5 =
            hexLong(
                json.getString(
                    "a5"
                )
            ),

            a6 =
            json.getString(
                "a6"
            ),

            revision =
            json.getString(
                "r"
            ),

            ttlSeconds =
            json.optInt(
                "ttl",
                envelope.ttlSeconds
            )
                .coerceIn(
                    60,
                    1800
                )
        )
    }

    private fun decryptHp(
        envelope:
        SecureProfileApi.Envelope
    ): HpProfile {

        val json =
            decryptJson(
                envelope
            )

        if (
            json.getString(
                "f"
            ) !=
            CrgProfile
                .FEATURE_HP
        ) {
            error(
                "Feature mismatch"
            )
        }

        return HpProfile(
            a0 = hexLong(json.getString("a0")),
            a1 = hexLong(json.getString("a1")),

            b0 = hexLong(json.getString("b0")),
            b1 = hexLong(json.getString("b1")),
            b2 = hexLong(json.getString("b2")),
            b3 = hexLong(json.getString("b3")),

            b4 = hexLong(json.getString("b4")),
            b5 = hexLong(json.getString("b5")),
            b6 = hexLong(json.getString("b6")),
            b7 = hexLong(json.getString("b7")),

            b8 = hexLong(json.getString("b8")),
            b9 = hexLong(json.getString("b9")),
            ba = hexLong(json.getString("ba")),
            bb = hexLong(json.getString("bb")),

            k0 = hexInt(json.getString("k0")),
            k1 = hexInt(json.getString("k1")),
            k2 = hexInt(json.getString("k2")),
            k3 = hexInt(json.getString("k3")),

            v0 = hexInt(json.getString("v0")),
            v1 = hexInt(json.getString("v1")),

            revision =
            json.getString(
                "r"
            ),

            ttlSeconds =
            json.optInt(
                "ttl",
                envelope.ttlSeconds
            )
                .coerceIn(
                    60,
                    1800
                )
        )
    }

    private fun decryptRunReward(
        envelope: SecureProfileApi.Envelope
    ): RunRewardProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != CrgProfile.FEATURE_RUN_REWARD) {
            error("Feature mismatch")
        }

        return RunRewardProfile(
            imageBase = hexLong(json.getString("a0")),
            stateGlobal = hexLong(json.getString("a1")),
            stageServiceGlobal = hexLong(json.getString("a2")),

            mapOffset = hexLong(json.getString("b0")),
            bucketArrayOffset = hexLong(json.getString("b1")),
            bucketCountOffset = hexLong(json.getString("b2")),
            listHeadOffset = hexLong(json.getString("b3")),
            nodeNextOffset = hexLong(json.getString("b4")),
            nodeHashOffset = hexLong(json.getString("b5")),
            nodeKeyOffset = hexLong(json.getString("b6")),
            nodeFieldOffset = hexLong(json.getString("b7")),
            fieldTypeOffset = hexLong(json.getString("b8")),
            fieldValuePtrOffset = hexLong(json.getString("b9")),
            fieldFlagOffset = hexLong(json.getString("ba")),
            fieldKeyPtrOffset = hexLong(json.getString("bb")),

            serviceCharacterOffset = hexLong(json.getString("c0")),
            serviceJellyManagerOffset = hexLong(json.getString("c1")),
            jellyManagerCharacterOffset = hexLong(json.getString("c2")),

            rawCoinKey = hexInt(json.getString("k0")),
            rawXpKey = hexInt(json.getString("k1")),
            finalCoinKey = hexInt(json.getString("k2")),
            finalXpKey = hexInt(json.getString("k3")),
            mirrorCoinKey = hexInt(json.getString("k4")),
            mirrorXpKey = hexInt(json.getString("k5")),

            expectedType = hexInt(json.getString("v0")),
            expectedFlag = hexInt(json.getString("v1")),

            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun decryptPotato(
        envelope: SecureProfileApi.Envelope
    ): PotatoProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != CrgProfile.FEATURE_POTATO) {
            error("Feature mismatch")
        }

        val tableHex = json.getString("tb").trim()
        if (tableHex.length != 200 || !tableHex.matches(Regex("^[0-9A-Fa-f]{200}$"))) {
            error("Invalid Potato protected table")
        }
        val table = ByteArray(100) { index ->
            tableHex.substring(index * 2, index * 2 + 2).toInt(16).toByte()
        }

        return PotatoProfile(
            imageBase = hexLong(json.getString("a0")),
            stageServiceGlobal = hexLong(json.getString("a1")),

            serviceCharacterOffset = hexLong(json.getString("b0")),
            serviceJellyManagerOffset = hexLong(json.getString("b1")),
            jellyManagerCharacterOffset = hexLong(json.getString("b2")),

            potatoListPointerOffset = hexLong(json.getString("c0")),
            vectorBeginOffset = hexLong(json.getString("c1")),
            vectorEndOffset = hexLong(json.getString("c2")),
            potatoVtable = hexLong(json.getString("c3")),

            shotConfigOffset = hexLong(json.getString("d0")),
            shotCurrentOffset = hexLong(json.getString("d1")),

            // f07_v2 Ultimate fields. Optional so an app update can still
            // consume the older Rapid-only f07_v1 profile during rollout.
            ultimateCounterOffset = hexLong(json.optString("d2", "0")),
            ultimateDurationConfigOffset = hexLong(json.optString("d3", "0")),
            ultimateDurationCurrentOffset = hexLong(json.optString("d4", "0")),

            // f07_v3 Potato Coin fields/hook. Optional so Rapid/Ultimate can
            // still consume older f07_v1/v2 profiles during staged rollout.
            coinCountOffset = hexLong(json.optString("d5", "0")),
            ultimateCursorOffset = hexLong(json.optString("d6", "0")),
            continuousHookFunctionAddress = hexLong(json.optString("h0", "0")),
            continuousCoinFunctionAddress = hexLong(json.optString("h1", "0")),
            continuousPatchAddresses = json.optJSONArray("ha")?.let { array ->
                LongArray(array.length()) { index -> hexLong(array.getString(index)) }
            } ?: LongArray(0),
            continuousExpectedOriginal = json.optJSONArray("ho")?.let { array ->
                IntArray(array.length()) { index -> hexLong(array.getString(index)).toInt() }
            } ?: IntArray(0),
            continuousHookFunctionSignature = hexLong(json.optString("hs", "0")).toInt(),
            continuousMoveObjectOpcode = hexLong(json.optString("hm", "0")).toInt(),
            continuousNopOpcode = hexLong(json.optString("hn", "0")).toInt(),

            protectedPtr8Offset = hexLong(json.getString("e0")),
            protectedPtr10Offset = hexLong(json.getString("e1")),
            protectedPtr18Offset = hexLong(json.getString("e2")),
            protectedSaltOffset = hexLong(json.getString("e3")),
            protectedTable = table,

            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun decryptBaseSpeed(
        envelope: SecureProfileApi.Envelope
    ): BaseSpeedProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != CrgProfile.FEATURE_BASE_SPEED) {
            error("Feature mismatch")
        }

        return BaseSpeedProfile(
            imageBase = hexLong(json.getString("a0")),
            stageServiceGlobal = hexLong(json.getString("a1")),

            serviceCharacterOffset = hexLong(json.getString("b0")),
            serviceJellyManagerOffset = hexLong(json.getString("b1")),
            jellyManagerCharacterOffset = hexLong(json.getString("b2")),

            baseSourceOffset = hexLong(json.getString("c0")),

            protectedPtr8Offset = hexLong(json.getString("e0")),
            protectedPtr10Offset = hexLong(json.getString("e1")),
            protectedPtr18Offset = hexLong(json.getString("e2")),
            protectedSaltOffset = hexLong(json.getString("e3")),

            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun decryptRecovery(
        envelope: SecureProfileApi.Envelope
    ): RecoveryProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != CrgProfile.FEATURE_RECOVERY) {
            error("Feature mismatch")
        }

        return RecoveryProfile(
            imageBase = hexLong(json.getString("a0")),
            stageServiceGlobal = hexLong(json.getString("a1")),
            gameplayStateGlobal = hexLong(json.getString("a2")),

            serviceCharacterOffset = hexLong(json.getString("b0")),
            serviceJellyManagerOffset = hexLong(json.getString("b1")),
            jellyManagerCharacterOffset = hexLong(json.getString("b2")),

            characterYOffset = hexLong(json.getString("c0")),
            characterYPreviousOffset = hexLong(json.getString("c1")),
            characterReferenceOffset = hexLong(json.getString("c2")),

            recoveryListSentinelOffset = hexLong(json.getString("d0")),
            recoveryListCountOffset = hexLong(json.getString("d1")),
            listNodeNextOffset = hexLong(json.getString("d2")),
            listNodePreviousOffset = hexLong(json.getString("d3")),
            listNodeValueObjectOffset = hexLong(json.getString("d4")),
            protectedValuePtrOffset = hexLong(json.getString("e0")),

            recoverySubtype = hexLong(json.getString("e1")).toInt(),
            pitArmY = json.getString("e2").toFloat(),
            pitRecentWindowMs = json.getLong("e3"),
            refundDelayMs = json.getLong("e4"),
            maximumUsageDelta = json.getInt("e5"),

            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun decryptJump(
        envelope: SecureProfileApi.Envelope
    ): JumpProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != CrgProfile.FEATURE_UNLIMITED_JUMP) {
            error("Feature mismatch")
        }

        return JumpProfile(
            imageBase = hexLong(json.getString("a0")),
            stageServiceGlobal = hexLong(json.getString("a1")),

            serviceCharacterOffset = hexLong(json.getString("b0")),
            serviceJellyManagerOffset = hexLong(json.getString("b1")),
            jellyManagerCharacterOffset = hexLong(json.getString("b2")),

            actionRingOffset = hexLong(json.getString("c0")),
            actionRingIndexOffset = hexLong(json.getString("c1")),
            actionRingSize = json.getInt("c2"),

            groundActionStatic = hexLong(json.getString("d0")),
            jump1ActionStatic = hexLong(json.getString("d1")),
            jump2ActionStatic = hexLong(json.getString("d2")),

            groundVtableStatic = hexLong(json.getString("e0")),
            jump1VtableStatic = hexLong(json.getString("e1")),
            jump2VtableStatic = hexLong(json.getString("e2")),

            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun decryptPowerPlus(
        envelope: SecureProfileApi.Envelope
    ): PowerPlusProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != CrgProfile.FEATURE_POWER_PLUS) {
            error("Feature mismatch")
        }

        val keyArray = json.getJSONArray("ks")
        val keys = IntArray(keyArray.length()) { index ->
            keyArray.getInt(index)
        }

        return PowerPlusProfile(
            imageBase = hexLong(json.getString("a0")),
            managerGlobal = hexLong(json.getString("a1")),
            nativeAddAddress = hexLong(json.getString("a2")),
            nativeHasAddress = hexLong(json.getString("a3")),
            nativeRefreshAddress = hexLong(json.getString("a5")),
            stageServiceGlobal = hexLong(json.getString("a4")),
            serviceCharacterOffset = hexLong(json.getString("b0")),
            serviceJellyManagerOffset = hexLong(json.getString("b1")),
            jellyManagerCharacterOffset = hexLong(json.getString("b2")),
            characterGameEventBackrefOffset = hexLong(json.getString("c0")),
            gameEventBackrefSubtract = hexLong(json.getString("c1")),
            consumerSlotOffset = hexLong(json.getString("c2")),
            managerListSentinelOffset = hexLong(json.getString("c3")),
            managerListStartOffset = hexLong(json.getString("c4")),
            passiveNodePrevOffset = hexLong(json.getString("c5")),
            passiveNodeObjectOffset = hexLong(json.getString("c6")),
            passiveObjectConfigOffset = hexLong(json.getString("c7")),
            passiveConfigKeyOffset = hexLong(json.getString("c8")),
            expectedGameEventVtableAddress = hexLong(json.getString("c9")),
            expectedPowerObjectVtableAddress = hexLong(json.getString("ca")),
            gameEventStateIndexOffset = hexLong(json.getString("cb")),
            gameEventStateArrayOffset = hexLong(json.getString("cc")),
            gameEventStateValueOffset = hexLong(json.getString("cd")),
            gameEventReadyState = json.getInt("ce"),
            episodeKeys = keys,
            param3 = json.getInt("p0"),
            stageSettleMs = json.getLong("d0").coerceIn(0L, 5000L),
            retryMs = json.getLong("d1").coerceIn(100L, 5000L),
            commandTimeoutMs = json.getInt("to").coerceIn(500, 15000),
            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun decryptNativeEffect(
        envelope: SecureProfileApi.Envelope,
        expectedFeatureId: String
    ): NativeEffectProfile {
        val json = decryptJson(envelope)

        if (json.getString("f") != expectedFeatureId) {
            error("Feature mismatch")
        }

        return NativeEffectProfile(
            featureId = expectedFeatureId,
            imageBase = hexLong(json.getString("a0")),
            hookAddress = hexLong(json.getString("a1")),
            dispatcherAddress = hexLong(json.getString("a2")),
            removerAddress = hexLong(json.getString("a3")),
            stageServiceGlobal = hexLong(json.getString("a4")),
            caveA = hexLong(json.getString("a5")),
            caveB = hexLong(json.getString("a6")),
            caveC = hexLong(json.getString("a7")),
            factoryAddress = hexLong(json.getString("a8")),
            characterVptr = hexLong(json.getString("a9")),
            effectManagerVptr = hexLong(json.getString("aa")),
            effectVptr = hexLong(json.getString("ab")),
            mmapAddress = hexLong(json.getString("ac")),
            triggerVtableSlotOffset = hexLong(json.getString("ad")),
            triggerVtableTarget = hexLong(json.getString("ae")),
            effectId = json.getInt("e0"),
            serviceCharacterOffset = hexLong(json.getString("b0")),
            serviceJellyManagerOffset = hexLong(json.getString("b1")),
            jellyManagerCharacterOffset = hexLong(json.getString("b2")),
            effectManagerOffset = hexLong(json.getString("b3")),
            effectBeginOffset = hexLong(json.getString("b4")),
            effectEndOffset = hexLong(json.getString("b5")),
            effectCapOffset = hexLong(json.getString("b6")),
            effectIdDirectOffset = hexLong(json.getString("b7")),
            effectIdAdjustedOffset = hexLong(json.getString("b8")),
            hookSignature = hexIntArray(json.getJSONArray("hs")),
            dispatcherSignature = hexIntArray(json.getJSONArray("ds")),
            removerSignature = hexIntArray(json.getJSONArray("rs")),
            factorySignature = hexIntArray(json.getJSONArray("fs")),
            mmapSignature = hexIntArray(json.getJSONArray("ms")),
            caveBOriginal = hexIntArray(json.getJSONArray("cb")),
            maxEffects = json.optInt("mx", 64).coerceIn(1, 256),
            commandTimeoutMs = json.optInt("to", 5000).coerceIn(250, 15000),

            giantSizeXOffset = hexLong(json.optString("g0", "0")),
            giantSizeYOffset = hexLong(json.optString("g1", "0")),
            giantSizeZOffset = hexLong(json.optString("g2", "0")),
            giantSizeNormal = json.optDouble("g3", 0.0).toFloat(),
            giantSizeMinPercent = json.optInt("g4", 0).coerceAtLeast(0),
            giantSizeMaxPercent = json.optInt("g5", 0).coerceAtLeast(0),
            giantSizeLockDelayMs = json.optLong("g6", 0L).coerceAtLeast(0L),
            giantSizeRecheckWrites = json.optInt("g7", 0).coerceAtLeast(0),

            revision = json.getString("r"),
            ttlSeconds = json.optInt(
                "ttl",
                envelope.ttlSeconds
            ).coerceIn(60, 1800)
        )
    }

    private fun hexIntArray(array: JSONArray): IntArray {
        return IntArray(array.length()) { index ->
            hexInt(array.getString(index))
        }
    }

    private fun decryptJson(
        envelope:
        SecureProfileApi.Envelope
    ): JSONObject {

        val decoder =
            Base64.getDecoder()

        val wrappedKey =
            decoder.decode(
                envelope.encryptedKey
            )

        val aesKeyBytes =
            DeviceProfileKeyStore
                .unwrapAesKey(
                    wrappedKey
                )

        try {

            val iv =
                decoder.decode(
                    envelope.iv
                )

            val tag =
                decoder.decode(
                    envelope.tag
                )

            val ciphertext =
                decoder.decode(
                    envelope.ciphertext
                )

            val aad =
                decoder.decode(
                    envelope.aad
                )

            val cipher =
                Cipher.getInstance(
                    "AES/GCM/NoPadding"
                )

            val key =
                SecretKeySpec(
                    aesKeyBytes,
                    "AES"
                )

            cipher.init(
                Cipher.DECRYPT_MODE,
                key,
                GCMParameterSpec(
                    128,
                    iv
                )
            )

            cipher.updateAAD(
                aad
            )

            val encryptedWithTag =
                ByteArray(
                    ciphertext.size +
                            tag.size
                )

            System.arraycopy(
                ciphertext,
                0,
                encryptedWithTag,
                0,
                ciphertext.size
            )

            System.arraycopy(
                tag,
                0,
                encryptedWithTag,
                ciphertext.size,
                tag.size
            )

            val plaintext =
                cipher.doFinal(
                    encryptedWithTag
                )

            return try {

                JSONObject(
                    plaintext.toString(
                        Charsets.UTF_8
                    )
                )

            } finally {

                plaintext.fill(
                    0
                )
            }

        } finally {

            aesKeyBytes.fill(
                0
            )
        }
    }

    private fun hexLong(
        text:
        String
    ): Long {

        return text
            .trim()
            .removePrefix(
                "0x"
            )
            .toLong(
                16
            )
    }

    private fun hexInt(
        text:
        String
    ): Int {

        return text
            .trim()
            .removePrefix(
                "0x"
            )
            .toLong(
                16
            )
            .toInt()
    }
}
