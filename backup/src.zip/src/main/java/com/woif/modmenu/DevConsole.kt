package com.woif.modmenu

import android.os.SystemClock
import android.util.Log
import java.util.ArrayDeque

/**
 * Internal/Lab developer console.
 *
 * Stable builds execute no buffering because every entry point is guarded by
 * BuildConfig.INTERNAL_BUILD.  The console is intentionally generic so future
 * MOD engines (speed, HP, auto, potato, etc.) can publish diagnostics here.
 */
internal object DevConsole {
    private const val TAG = "MWOIF_DEV"
    private const val MAX_LINES = 300

    private val lock = Any()
    private val lines = ArrayDeque<String>()
    private val startedAt = SystemClock.elapsedRealtime()

    fun log(source: String, message: String) {
        if (!BuildConfig.INTERNAL_BUILD) return
        val clean = message.replace('\n', ' ').trim()
        if (clean.isEmpty()) return
        val elapsedMs = SystemClock.elapsedRealtime() - startedAt
        val line = "+${elapsedMs / 1000}.${(elapsedMs % 1000).toString().padStart(3, '0')} [$source] $clean"
        synchronized(lock) {
            if (lines.peekLast() == line) return
            while (lines.size >= MAX_LINES) lines.removeFirst()
            lines.addLast(line)
        }
        Log.d(TAG, "[$source] $clean")
    }

    fun text(maxLines: Int = 80): String {
        if (!BuildConfig.INTERNAL_BUILD) return ""
        val limit = maxLines.coerceIn(1, MAX_LINES)
        synchronized(lock) {
            return lines.toList().takeLast(limit).joinToString("\n")
        }
    }

    fun clear() {
        if (!BuildConfig.INTERNAL_BUILD) return
        synchronized(lock) { lines.clear() }
    }
}
