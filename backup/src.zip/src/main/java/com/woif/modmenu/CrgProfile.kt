package com.woif.modmenu

/**
 * Non-sensitive target identifiers only.
 *
 * Real resolver values are NOT stored in the APK.
 *
 * Feature IDs are sourced from FeatureCatalog so the app has one
 * authoritative registry for its known feature families.
 */
object CrgProfile {

    const val GAME_PACKAGE =
        "com.devsisters.crg"

    const val GAME_ID =
        "cookie_run_classic"

    const val FEATURE_GAME_SPEED =
        FeatureCatalog.F01_GAME_SPEED

    const val FEATURE_HP =
        FeatureCatalog.F02_HP

    const val FEATURE_GIANT =
        FeatureCatalog.F03_GIANT

    const val FEATURE_SUPER =
        FeatureCatalog.F04_SUPER

    const val FEATURE_POWER_PLUS =
        FeatureCatalog.F05_POWER_PLUS

    const val FEATURE_RUN_REWARD =
        FeatureCatalog.F06_RUN_REWARD

    const val FEATURE_POTATO =
        FeatureCatalog.F07_POTATO

    const val FEATURE_BASE_SPEED =
        FeatureCatalog.F08_BASE_SPEED

    const val FEATURE_RECOVERY =
        FeatureCatalog.F09_RECOVERY

    const val FEATURE_UNLIMITED_JUMP =
        FeatureCatalog.F10_UNLIMITED_JUMP

    val CLIENT_FEATURE_IDS =
        FeatureCatalog.SERVER_FEATURE_IDS
}
