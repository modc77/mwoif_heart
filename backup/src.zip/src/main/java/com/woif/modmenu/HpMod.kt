package com.woif.modmenu

import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

/**
 * HP / Energy V3 desired-state SAFE controller.
 *
 * Reference behavior matches the verified Lua V9 design:
 * - gameplay-state map
 * - protected int container (direct / XOR32)
 * - no-drain = modify Drain Interval only
 * - original Interval is restored on OFF / timer expiry
 * - Stage pointers are never written after a Stage edge
 * - game PID/runtime is rebound automatically after crash/restart
 * - ON remains armed while CookieRun/libgame/Stage is temporarily unavailable
 */
class HpMod(
    private val memory:
        RootProcessMemory =
        RootProcessMemory()
) {

    companion object {

        private const val TICK_MS =
            50L

        private const val RECHECK_EVERY_TICKS =
            4

        private const val PROCESS_RECHECK_EVERY_TICKS =
            10

        private const val MAX_BUCKET_COUNT =
            0x100000L

        private const val MAX_BUCKET_CHAIN =
            512

        private const val MAX_LIST_CHAIN =
            10000
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val stateGlobal: Long
    )

    private data class PropInfo(
        val key: Int,
        val node: Long,
        val valueType: Int,
        val encryptedFlag: Int,
        val encoding: Encoding,
        val valuePtr: Long,
        val keyPtr: Long,
        val value: Int
    )

    private data class StageRuntime(
        val state: Long,
        var interval: PropInfo,
        val originalInterval: Int,
        var expired: Boolean,
        var deadlineElapsed: Long?
    )

    private enum class Encoding {
        DIRECT,
        XOR32
    }

    private val executor =
        Executors
            .newSingleThreadScheduledExecutor()

    @Volatile
    private var enabled =
        false

    @Volatile
    private var mode =
        "INFINITE"

    @Volatile
    private var runtime:
            Runtime? =
        null

    @Volatile
    private var stage:
            StageRuntime? =
        null

    @Volatile
    private var task:
            ScheduledFuture<*>? =
        null

    @Volatile
    private var tickCounter =
        0

    @Volatile
    private var nextResolveAt =
        0L

    @Volatile
    private var status =
        "ยังไม่ได้เปิด HP"

    fun isPrepared():
            Boolean {

        return runtime !=
                null
    }

    fun isEnabled():
            Boolean {

        return enabled
    }

    fun statusText():
            String {

        val current =
            stage

        if (
            enabled &&
            current !=
            null &&
            !current.expired
        ) {

            val deadline =
                current.deadlineElapsed

            if (
                deadline !=
                null
            ) {

                val remaining =
                    ceil(
                        (
                            deadline -
                            SystemClock
                                .elapsedRealtime()
                        )
                            .coerceAtLeast(
                                0L
                            ) /
                            1000.0
                    )
                        .toInt()

                return if (
                    remaining >
                    0
                ) {
                    "ON • เหลือ ${remaining}s"
                } else {
                    status
                }
            }
        }

        return status
    }

    fun prepareAsync(
        callback:
            ((ActionResult) -> Unit)? =
            null
    ) {

        executor.execute {

            val current =
                runtime

            if (
                current != null
            ) {

                val livePid =
                    memory.pidOf(
                        CrgProfile.GAME_PACKAGE
                    )

                if (
                    livePid == current.pid
                ) {

                    callback?.invoke(
                        success(
                            "HP พร้อม • รอ Stage"
                        )
                    )

                    return@execute
                }

                stage = null
                runtime = null
            }

            val result =
                prepareRuntime()

            callback?.invoke(
                result
            )
        }
    }

    fun enable(
        requestedMode:
            String,
        callback:
            (ActionResult) -> Unit
    ) {

        val parsed =
            parseMode(
                requestedMode
            )

        if (
            parsed ==
            null
        ) {

            callback(
                failure(
                    "INVALID_MODE",
                    "โหมด HP ไม่ถูกต้อง"
                )
            )

            return
        }

        mode =
            requestedMode

        /*
         * HP V3 desired-state semantics:
         * ON is user intent. Runtime/process/profile availability is allowed
         * to lag behind and will be reconciled by the periodic task.
         */
        enabled =
            true

        status =
            "HP ON • กำลังเชื่อมเกม"

        executor.execute {

            ensureTask()

            /*
             * Try immediately when the game is already ready. Any operational
             * failure is intentionally NOT converted back to OFF.
             */
            safeTick()

            callback(
                success(
                    status
                )
            )
        }
    }

    fun updateMode(
        requestedMode:
            String,
        callback:
            ((ActionResult) -> Unit)? =
            null
    ) {

        if (
            parseMode(
                requestedMode
            ) ==
            null
        ) {

            callback?.invoke(
                failure(
                    "INVALID_MODE",
                    "โหมด HP ไม่ถูกต้อง"
                )
            )

            return
        }

        mode =
            requestedMode

        executor.execute {

            val current =
                stage

            if (
                enabled &&
                current !=
                null &&
                !current.expired
            ) {

                current.deadlineElapsed =
                    deadlineForMode()

                status =
                    if (
                        current.deadlineElapsed ==
                        null
                    ) {
                        "ON • ไม่ตายเลย"
                    } else {
                        "ON • ${modeLabel()}"
                    }
            }

            callback?.invoke(
                success(
                    status
                )
            )
        }
    }

    fun disable(
        callback:
            (ActionResult) -> Unit
    ) {

        enabled =
            false

        executor.execute {

            val result =
                restoreCurrentStage()

            stopTask()

            stage =
                null

            status =
                if (
                    result.ok
                ) {
                    "OFF • Restore แล้ว"
                } else {
                    result.message
                }

            callback(
                result
            )
        }
    }

    fun restoreBlockingBestEffort():
            ActionResult {

        enabled =
            false

        stopTask()

        val result =
            restoreCurrentStage()

        stage =
            null

        return result
    }

    fun shutdown(
        restore:
            Boolean
    ) {

        enabled =
            false

        stopTask()

        if (
            restore
        ) {
            try {
                restoreCurrentStage()
            } catch (
                ignored: Exception
            ) {
            }
        }

        stage =
            null

        runtime =
            null

        executor.shutdownNow()
    }

    private fun ensureTask() {

        if (
            task !=
            null
        ) {
            return
        }

        task =
            executor.scheduleAtFixedRate(
                {
                    safeTick()
                },
                TICK_MS,
                TICK_MS,
                TimeUnit.MILLISECONDS
            )
    }

    private fun stopTask() {

        task
            ?.cancel(
                false
            )

        task =
            null
    }

    private fun safeTick() {

        try {
            tick()
        } catch (
            ignored: Exception
        ) {
            /*
             * Fail closed for one tick. A transient Stage edge must not crash
             * the overlay service.
             */
        }
    }

    private fun tick() {

        if (
            !enabled
        ) {
            return
        }

        tickCounter +=
            1

        var currentRuntime =
            runtime

        if (
            currentRuntime ==
            null
        ) {

            val now =
                SystemClock
                    .elapsedRealtime()

            if (
                now <
                nextResolveAt
            ) {
                return
            }

            nextResolveAt =
                now +
                1000L

            val prepared =
                prepareRuntime()

            if (
                !prepared.ok
            ) {
                status =
                    when (prepared.errorCode) {
                        "ROOT_REQUIRED" ->
                            "HP ON • รอ Root Worker"

                        "PROFILE_NOT_READY" ->
                            "HP ON • รอ Secure HP Profile"

                        "GAME_NOT_RUNNING" ->
                            "HP ON • รอ CookieRun"

                        "LIBGAME_NOT_READY",
                        "ELF_NOT_FOUND",
                        "LOAD_BIAS_FAILED",
                        "GLOBAL_FAILED",
                        "GLOBAL_READ_FAILED" ->
                            "HP ON • กำลังจับ runtime ใหม่"

                        else ->
                            "HP ON • กำลังเชื่อมใหม่"
                    }
                return
            }

            currentRuntime =
                runtime
                    ?: return
        }

        /*
         * Process-generation check. A game crash/restart creates a new PID;
         * never keep using stateGlobal/Stage pointers from the old process.
         */
        if (
            tickCounter %
            PROCESS_RECHECK_EVERY_TICKS ==
            0
        ) {

            val livePid =
                memory.pidOf(
                    CrgProfile.GAME_PACKAGE
                )

            if (
                livePid == null ||
                livePid != currentRuntime.pid
            ) {

                stage = null
                runtime = null
                nextResolveAt = 0L

                status =
                    if (livePid == null) {
                        "HP ON • รอ CookieRun"
                    } else {
                        "HP ON • พบเกมใหม่ • กำลังเชื่อม"
                    }

                return
            }
        }

        val statePointer =
            memory.readLong(
                currentRuntime.pid,
                currentRuntime.stateGlobal
            )

        if (
            statePointer ==
            null
        ) {

            /*
             * Game process probably changed.
             * Never write through the old Stage pointer.
             */
            stage =
                null

            runtime =
                null

            status =
                "HP • กำลังรอเกม"

            return
        }

        if (
            statePointer <
            0x10000L
        ) {

            if (
                stage !=
                null
            ) {

                /*
                 * Exact Stage edge:
                 * old object is already gone, so clear cached pointers without
                 * trying to write stale memory.
                 */
                stage =
                    null
            }

            status =
                "HP ON • รอเข้า Stage"

            return
        }

        val currentStage =
            stage

        if (
            currentStage ==
            null ||
            currentStage.state !=
            statePointer
        ) {

            /*
             * New Stage. Do not restore an old Stage object here because the
             * state pointer changed already.
             */
            stage =
                null

            val resolved =
                resolveStage(
                    currentRuntime.pid,
                    statePointer
                )
                    ?: run {
                        status =
                            "HP ON • กำลังจับ Stage..."
                        return
                    }

            val wanted =
                profile()
                    ?.v1
                    ?: return

            val applied =
                writeInfo(
                    currentRuntime.pid,
                    resolved.interval,
                    wanted
                )

            if (
                applied ==
                null
            ) {

                status =
                    "HP • เขียน Stage ไม่สำเร็จ"

                return
            }

            stage =
                StageRuntime(
                    state =
                        statePointer,

                    interval =
                        applied,

                    originalInterval =
                        resolved.interval.value,

                    expired =
                        false,

                    deadlineElapsed =
                        deadlineForMode()
                )

            status =
                if (
                    deadlineForMode() ==
                    null
                ) {
                    "HP ON • ไม่ตายเลย"
                } else {
                    "HP ON • ${modeLabel()}"
                }

            return
        }

        if (
            currentStage.expired
        ) {
            return
        }

        val deadline =
            currentStage.deadlineElapsed

        if (
            deadline !=
            null &&
            SystemClock
                .elapsedRealtime() >=
            deadline
        ) {

            val restored =
                writeInfo(
                    currentRuntime.pid,
                    currentStage.interval,
                    currentStage.originalInterval
                )

            if (
                restored !=
                null
            ) {

                currentStage.interval =
                    restored

                currentStage.expired =
                    true

                currentStage.deadlineElapsed =
                    null

                status =
                    "HP ครบเวลา • Restore แล้ว"

            } else {

                status =
                    "HP ครบเวลา • กำลัง Retry Restore"
            }

            return
        }

        /*
         * Lightweight maintenance every 200ms.
         * The verified Lua normally needs only one write, but this protects
         * against a game-side rewrite without hammering the process.
         */
        if (
            tickCounter %
            RECHECK_EVERY_TICKS !=
            0
        ) {
            return
        }

        val refreshed =
            validateNode(
                currentRuntime.pid,
                currentStage.interval.node,
                profile()
                    ?.k3
                    ?: return,
                1,
                Int.MAX_VALUE
            )
                ?: run {

                    /*
                     * Map entry changed inside the same Stage.
                     * Re-bind the Stage safely rather than write stale data.
                     */
                    stage =
                        null

                    return
                }

        currentStage.interval =
            refreshed

        val wanted =
            profile()
                ?.v1
                ?: return

        if (
            refreshed.value !=
            wanted
        ) {

            val corrected =
                writeInfo(
                    currentRuntime.pid,
                    refreshed,
                    wanted
                )

            if (
                corrected !=
                null
            ) {
                currentStage.interval =
                    corrected
            }
        }
    }

    private data class ResolvedStage(
        val interval:
            PropInfo
    )

    private fun resolveStage(
        pid:
            Int,
        state:
            Long
    ): ResolvedStage? {

        val p =
            profile()
                ?: return null

        if (
            !probeStateMap(
                pid,
                state,
                p
            )
        ) {
            return null
        }

        val modeNode =
            findNode(
                pid,
                state,
                p.k0,
                p
            )
                ?: return null

        val hpNode =
            findNode(
                pid,
                state,
                p.k1,
                p
            )
                ?: return null

        val drainNode =
            findNode(
                pid,
                state,
                p.k2,
                p
            )
                ?: return null

        val intervalNode =
            findNode(
                pid,
                state,
                p.k3,
                p
            )
                ?: return null

        val modeInfo =
            validateNode(
                pid,
                modeNode,
                p.k0,
                0,
                32
            )
                ?: return null

        if (
            modeInfo.value !=
            p.v0
        ) {
            return null
        }

        /*
         * Validate the same core HP family used by the verified Lua.
         * We only modify Interval, but HP and Drain are checked to make sure
         * this is the expected gameplay-state map.
         */
        validateNode(
            pid,
            hpNode,
            p.k1,
            0,
            10_000_000
        )
            ?: return null

        validateNode(
            pid,
            drainNode,
            p.k2,
            0,
            Int.MAX_VALUE
        )
            ?: return null

        val intervalInfo =
            validateNode(
                pid,
                intervalNode,
                p.k3,
                1,
                Int.MAX_VALUE
            )
                ?: return null

        return ResolvedStage(
            interval =
                intervalInfo
        )
    }

    private fun probeStateMap(
        pid:
            Int,
        state:
            Long,
        p:
            HpProfile
    ): Boolean {

        val map =
            state +
                p.b0

        val bucketArray =
            memory.readLong(
                pid,
                map +
                    p.b1
            )
                ?: return false

        val bucketCount =
            memory.readLong(
                pid,
                map +
                    p.b2
            )
                ?: return false

        val listHead =
            memory.readLong(
                pid,
                map +
                    p.b3
            )
                ?: return false

        if (
            bucketArray <
            0x10000L
        ) {
            return false
        }

        if (
            bucketCount <=
            0L ||
            bucketCount >
            MAX_BUCKET_COUNT
        ) {
            return false
        }

        if (
            listHead <
            0x10000L
        ) {
            return false
        }

        return memory.readInt(
            pid,
            listHead +
                p.b6
        ) !=
            null
    }

    private fun findNode(
        pid:
            Int,
        state:
            Long,
        propertyKey:
            Int,
        p:
            HpProfile
    ): Long? {

        val map =
            state +
                p.b0

        val bucketArray =
            memory.readLong(
                pid,
                map +
                    p.b1
            )

        val bucketCount =
            memory.readLong(
                pid,
                map +
                    p.b2
            )

        if (
            bucketArray !=
            null &&
            bucketArray >=
            0x10000L &&
            bucketCount !=
            null &&
            bucketCount >
            0L &&
            bucketCount <=
            MAX_BUCKET_COUNT
        ) {

            val unsignedKey =
                propertyKey
                    .toLong() and
                    0xFFFFFFFFL

            val bucket =
                unsignedKey %
                    bucketCount

            val predecessor =
                memory.readLong(
                    pid,
                    bucketArray +
                        bucket *
                        8L
                )

            var node =
                if (
                    predecessor !=
                    null &&
                    predecessor >=
                    0x10000L
                ) {

                    memory.readLong(
                        pid,
                        predecessor +
                            p.b4
                    )

                } else {
                    null
                }

            var guard =
                0

            while (
                node !=
                null &&
                node >=
                0x10000L &&
                guard <
                MAX_BUCKET_CHAIN
            ) {

                val storedKey =
                    memory.readInt(
                        pid,
                        node +
                            p.b6
                    )

                val storedHash =
                    memory.readLong(
                        pid,
                        node +
                            p.b5
                    )

                if (
                    storedKey ==
                    propertyKey &&
                    storedHash ==
                    unsignedKey
                ) {
                    return node
                }

                node =
                    memory.readLong(
                        pid,
                        node +
                            p.b4
                    )

                guard +=
                    1
            }
        }

        var node =
            memory.readLong(
                pid,
                map +
                    p.b3
            )

        var guard =
            0

        while (
            node !=
            null &&
            node >=
            0x10000L &&
            guard <
            MAX_LIST_CHAIN
        ) {

            if (
                memory.readInt(
                    pid,
                    node +
                        p.b6
                ) ==
                propertyKey
            ) {
                return node
            }

            node =
                memory.readLong(
                    pid,
                    node +
                        p.b4
                )

            guard +=
                1
        }

        return null
    }

    private fun validateNode(
        pid:
            Int,
        node:
            Long,
        expectedKey:
            Int,
        minimum:
            Int,
        maximum:
            Int
    ): PropInfo? {

        val p =
            profile()
                ?: return null

        if (
            node <
            0x10000L
        ) {
            return null
        }

        val storedKey =
            memory.readInt(
                pid,
                node +
                    p.b6
            )
                ?: return null

        if (
            storedKey !=
            expectedKey
        ) {
            return null
        }

        val field =
            node +
                p.b7

        val valueType =
            memory.readInt(
                pid,
                field +
                    p.b8
            )
                ?: return null

        val encryptedFlag =
            memory.readByteUnsigned(
                pid,
                field +
                    p.ba
            )
                ?: return null

        val valuePtr =
            memory.readLong(
                pid,
                field +
                    p.b9
            )
                ?: return null

        val keyPtr =
            memory.readLong(
                pid,
                field +
                    p.bb
            )
                ?: 0L

        if (
            valuePtr <
            0x10000L
        ) {
            return null
        }

        val raw =
            memory.readInt(
                pid,
                valuePtr
            )
                ?: return null

        val encrypted =
            (
                encryptedFlag and
                1
            ) ==
                1

        val encoding:
                Encoding

        val value:
                Int

        if (
            encrypted &&
            (
                valueType ==
                1 ||
                valueType ==
                6
            )
        ) {

            if (
                keyPtr <
                0x10000L
            ) {
                return null
            }

            val xorKey =
                memory.readInt(
                    pid,
                    keyPtr
                )
                    ?: return null

            value =
                raw xor
                    xorKey

            encoding =
                Encoding.XOR32

        } else if (
            valueType ==
            2
        ) {

            /*
             * HP family is expected to be int32.
             */
            return null

        } else {

            value =
                raw

            encoding =
                Encoding.DIRECT
        }

        if (
            value <
            minimum ||
            value >
            maximum
        ) {
            return null
        }

        return PropInfo(
            key =
                expectedKey,

            node =
                node,

            valueType =
                valueType,

            encryptedFlag =
                encryptedFlag,

            encoding =
                encoding,

            valuePtr =
                valuePtr,

            keyPtr =
                keyPtr,

            value =
                value
        )
    }

    private fun writeInfo(
        pid:
            Int,
        info:
            PropInfo,
        wanted:
            Int
    ): PropInfo? {

        val paused =
            memory.pause(
                pid
            )

        return try {

            val refreshed =
                validateNode(
                    pid,
                    info.node,
                    info.key,
                    if (
                        info.key ==
                        profile()
                            ?.k3
                    ) {
                        1
                    } else {
                        0
                    },
                    Int.MAX_VALUE
                )
                    ?: return null

            val encoded =
                when (
                    refreshed.encoding
                ) {

                    Encoding.DIRECT ->
                        wanted

                    Encoding.XOR32 -> {

                        val xorKey =
                            memory.readInt(
                                pid,
                                refreshed.keyPtr
                            )
                                ?: return null

                        wanted xor
                            xorKey
                    }
                }

            if (
                !memory.writeInt(
                    pid,
                    refreshed.valuePtr,
                    encoded
                )
            ) {
                return null
            }

            val verified =
                validateNode(
                    pid,
                    refreshed.node,
                    refreshed.key,
                    if (
                        refreshed.key ==
                        profile()
                            ?.k3
                    ) {
                        1
                    } else {
                        0
                    },
                    Int.MAX_VALUE
                )

            if (
                verified ==
                null ||
                verified.value !=
                wanted
            ) {

                /*
                 * Best-effort rollback to the value observed immediately
                 * before this write.
                 */
                val rollback =
                    when (
                        refreshed.encoding
                    ) {

                        Encoding.DIRECT ->
                            refreshed.value

                        Encoding.XOR32 -> {

                            val xorKey =
                                memory.readInt(
                                    pid,
                                    refreshed.keyPtr
                                )

                            if (
                                xorKey !=
                                null
                            ) {
                                refreshed.value xor
                                    xorKey
                            } else {
                                refreshed.value
                            }
                        }
                    }

                memory.writeInt(
                    pid,
                    refreshed.valuePtr,
                    rollback
                )

                return null
            }

            verified

        } finally {

            if (
                paused
            ) {
                memory.resume(
                    pid
                )
            }
        }
    }

    /**
     * Internal Lab bridge for the already-existing HP feature.
     *
     * This is NOT a second HP controller and does not enable HP Protection.
     * It reuses this HpMod instance's verified gameplay-state map, current-HP
     * property (k1), protected-int encoding, and write verification.
     *
     * Only 0 / 1 are accepted because this bridge is used for controlled
     * death-state testing.
     */
    fun writeCurrentHpForLab(
        value: Int
    ): ActionResult {

        if (value != 0 && value != 1) {
            return failure(
                "INVALID_HP_LAB_VALUE",
                "Lab HP รับเฉพาะ 0 หรือ 1"
            )
        }

        var currentRuntime = runtime

        val livePid =
            memory.pidOf(
                CrgProfile.GAME_PACKAGE
            )

        if (livePid == null) {
            stage = null
            runtime = null

            return failure(
                "GAME_NOT_RUNNING",
                "ยังไม่พบ CookieRun"
            )
        }

        if (
            currentRuntime == null ||
            currentRuntime.pid != livePid
        ) {
            stage = null
            runtime = null

            val prepared = prepareRuntime()

            if (!prepared.ok) {
                return prepared
            }

            currentRuntime =
                runtime
                    ?: return failure(
                        "RUNTIME_NOT_READY",
                        "HP runtime ยังไม่พร้อม"
                    )
        }

        val p =
            profile()
                ?: return failure(
                    "PROFILE_NOT_READY",
                    "Secure HP Profile ยังไม่พร้อม"
                )

        val statePointer =
            memory.readLong(
                currentRuntime.pid,
                currentRuntime.stateGlobal
            )
                ?: return failure(
                    "STATE_READ_FAILED",
                    "อ่าน gameplay state ไม่สำเร็จ"
                )

        if (statePointer < 0x10000L) {
            return failure(
                "STAGE_NOT_READY",
                "ยังไม่พบ Stage สำหรับเขียน HP"
            )
        }

        if (
            !probeStateMap(
                currentRuntime.pid,
                statePointer,
                p
            )
        ) {
            return failure(
                "STATE_MAP_INVALID",
                "HP gameplay-state map ไม่ตรง profile"
            )
        }

        val modeNode =
            findNode(
                currentRuntime.pid,
                statePointer,
                p.k0,
                p
            )
                ?: return failure(
                    "MODE_NODE_NOT_FOUND",
                    "หา HP mode node ไม่เจอ"
                )

        val modeInfo =
            validateNode(
                currentRuntime.pid,
                modeNode,
                p.k0,
                0,
                32
            )
                ?: return failure(
                    "MODE_NODE_INVALID",
                    "HP mode node ไม่ถูกต้อง"
                )

        if (modeInfo.value != p.v0) {
            return failure(
                "MODE_MISMATCH",
                "HP gameplay mode ไม่ตรง profile"
            )
        }

        val hpNode =
            findNode(
                currentRuntime.pid,
                statePointer,
                p.k1,
                p
            )
                ?: return failure(
                    "HP_NODE_NOT_FOUND",
                    "หา Current HP node ไม่เจอ"
                )

        val hpInfo =
            validateNode(
                currentRuntime.pid,
                hpNode,
                p.k1,
                0,
                10_000_000
            )
                ?: return failure(
                    "HP_NODE_INVALID",
                    "Current HP node ไม่ถูกต้อง"
                )

        val before = hpInfo.value

        val written =
            writeInfo(
                currentRuntime.pid,
                hpInfo,
                value
            )
                ?: return failure(
                    "HP_LAB_WRITE_FAILED",
                    "เขียน Current HP=$value ไม่สำเร็จ"
                )

        return success(
            "Current HP=$value • before=$before • verify=${written.value}"
        )
    }

    private fun restoreCurrentStage():
            ActionResult {

        val current =
            stage

        val currentRuntime =
            runtime

        if (
            current ==
            null ||
            currentRuntime ==
            null
        ) {

            return success(
                "HP OFF • ไม่มี Stage ที่ต้อง Restore"
            )
        }

        val livePid =
            memory.pidOf(
                CrgProfile.GAME_PACKAGE
            )

        if (
            livePid != currentRuntime.pid
        ) {

            return success(
                "HP OFF • เกมเริ่ม process ใหม่แล้ว"
            )
        }

        /*
         * Before restoring, confirm the gameplay state still points to the
         * same Stage. If the Stage object is already gone, stale pointers are
         * intentionally discarded instead of written.
         */
        val liveState =
            memory.readLong(
                currentRuntime.pid,
                currentRuntime.stateGlobal
            )

        if (
            liveState !=
            current.state
        ) {

            return success(
                "HP OFF • Stage จบแล้ว"
            )
        }

        val restored =
            writeInfo(
                currentRuntime.pid,
                current.interval,
                current.originalInterval
            )

        return if (
            restored !=
            null
        ) {

            success(
                "HP OFF • Restore แล้ว"
            )

        } else {

            failure(
                "RESTORE_FAILED",
                "HP OFF แต่ Restore ยังไม่สำเร็จ"
            )
        }
    }

    private fun prepareRuntime():
            ActionResult {

        if (
            !memory.hasRoot()
        ) {

            return failure(
                "ROOT_REQUIRED",
                "M Woif ยังไม่มี Root Worker"
            )
        }

        val p =
            profile()

        if (
            p ==
            null
        ) {

            return failure(
                "PROFILE_NOT_READY",
                "Secure HP Profile ยังไม่พร้อม"
            )
        }

        val pid =
            memory.pidOf(
                CrgProfile
                    .GAME_PACKAGE
            )
                ?: return failure(
                    "GAME_NOT_RUNNING",
                    "ยังไม่พบ CookieRun"
                )

        val ranges =
            memory.maps(
                pid
            )
                .filter {
                    it.path
                        .contains(
                            "libgame.so"
                        )
                }

        if (
            ranges.isEmpty()
        ) {

            return failure(
                "LIBGAME_NOT_READY",
                "ยังไม่พบ libgame.so"
            )
        }

        val candidates =
            LinkedHashSet<Long>()

        for (
            range in
            ranges
        ) {

            candidates.add(
                range.start
            )

            if (
                range.offset >
                0L &&
                range.start >
                range.offset
            ) {

                candidates.add(
                    range.start -
                        range.offset
                )
            }
        }

        val elfBase =
            candidates
                .firstOrNull {
                    validateElf(
                        pid,
                        it
                    )
                }
                ?: return failure(
                    "ELF_NOT_FOUND",
                    "หา ARM64 libgame ELF ไม่สำเร็จ"
                )

        val loadBias =
            parseLoadBias(
                pid,
                elfBase
            )
                ?: return failure(
                    "LOAD_BIAS_FAILED",
                    "หา libgame load bias ไม่สำเร็จ"
                )

        val stateGlobal =
            loadBias +
                (
                    p.a1 -
                    p.a0
                )

        if (
            stateGlobal <
            0x10000L
        ) {

            return failure(
                "GLOBAL_FAILED",
                "คำนวณ HP state global ไม่สำเร็จ"
            )
        }

        /*
         * Reading the global itself is enough in Lobby.
         * A NULL/0 Stage pointer is valid while waiting outside a run.
         */
        if (
            memory.readLong(
                pid,
                stateGlobal
            ) ==
            null
        ) {

            return failure(
                "GLOBAL_READ_FAILED",
                "อ่าน HP state global ไม่สำเร็จ"
            )
        }

        runtime =
            Runtime(
                pid =
                    pid,

                stateGlobal =
                    stateGlobal
            )

        status =
            "HP พร้อม • รอ Stage"

        return success(
            status
        )
    }

    private fun validateElf(
        pid:
            Int,
        address:
            Long
    ): Boolean {

        val header =
            memory.readBytes(
                pid,
                address,
                0x40
            )
                ?: return false

        if (
            header.size <
            0x40
        ) {
            return false
        }

        val machine =
            ByteBuffer
                .wrap(
                    header,
                    0x12,
                    2
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )
                .short
                .toInt() and
                0xFFFF

        return (
            header[0]
                .toInt() and
                0xFF
            ) ==
                0x7F &&
            (
                header[1]
                    .toInt() and
                    0xFF
            ) ==
                0x45 &&
            (
                header[2]
                    .toInt() and
                    0xFF
            ) ==
                0x4C &&
            (
                header[3]
                    .toInt() and
                    0xFF
            ) ==
                0x46 &&
            (
                header[4]
                    .toInt() and
                    0xFF
            ) ==
                2 &&
            machine ==
                0xB7
    }

    private fun parseLoadBias(
        pid:
            Int,
        elfBase:
            Long
    ): Long? {

        val header =
            memory.readBytes(
                pid,
                elfBase,
                0x40
            )
                ?: return null

        val buffer =
            ByteBuffer
                .wrap(
                    header
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )

        val phoff =
            buffer.getLong(
                0x20
            )

        val phentsize =
            buffer.getShort(
                0x36
            )
                .toInt() and
                0xFFFF

        val phnum =
            buffer.getShort(
                0x38
            )
                .toInt() and
                0xFFFF

        if (
            phoff <=
            0L ||
            phentsize <
            0x38 ||
            phnum <=
            0 ||
            phnum >
            256
        ) {
            return null
        }

        var selected:
                Long? =
            null

        for (
            index in
            0 until phnum
        ) {

            val entry =
                memory.readBytes(
                    pid,
                    elfBase +
                        phoff +
                        index.toLong() *
                        phentsize.toLong(),
                    phentsize
                )
                    ?: return null

            val ph =
                ByteBuffer
                    .wrap(
                        entry
                    )
                    .order(
                        ByteOrder.LITTLE_ENDIAN
                    )

            if (
                ph.getInt(
                    0
                ) !=
                1
            ) {
                continue
            }

            val fileOffset =
                ph.getLong(
                    0x08
                )

            val vaddr =
                ph.getLong(
                    0x10
                )

            if (
                fileOffset ==
                0L
            ) {

                selected =
                    vaddr

                break
            }

            if (
                selected ==
                null
            ) {
                selected =
                    vaddr
            }
        }

        return elfBase -
            (
                selected
                    ?: return null
            )
    }

    private fun profile():
            HpProfile? {

        return SecureProfileManager
            .getHp()
    }

    private fun parseMode(
        text:
            String
    ): Int? {

        if (
            text ==
            "INFINITE"
        ) {
            return 0
        }

        val seconds =
            text.toIntOrNull()
                ?: return null

        return seconds
            .takeIf {
                it in
                1..300
            }
    }

    private fun deadlineForMode():
            Long? {

        val seconds =
            parseMode(
                mode
            )
                ?: return null

        if (
            seconds ==
            0
        ) {
            return null
        }

        return SystemClock
            .elapsedRealtime() +
            seconds.toLong() *
            1000L
    }

    private fun modeLabel():
            String {

        val seconds =
            parseMode(
                mode
            )
                ?: 0

        return if (
            seconds ==
            0
        ) {
            "ไม่ตายเลย"
        } else {
            "${seconds}s"
        }
    }

    private fun success(
        message:
            String
    ): ActionResult {

        return ActionResult(
            ok =
                true,

            errorCode =
                null,

            message =
                message
        )
    }

    private fun failure(
        code:
            String,
        message:
            String
    ): ActionResult {

        return ActionResult(
            ok =
                false,

            errorCode =
                code,

            message =
                message
        )
    }
}
