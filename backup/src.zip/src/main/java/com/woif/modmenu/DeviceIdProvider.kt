package com.woif.modmenu

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest

object DeviceIdProvider {

    fun get(
        context: Context
    ): String {

        val androidId =
            Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ANDROID_ID
            )
                ?.trim()
                .orEmpty()

        val source =
            buildString {

                append(
                    if (
                        androidId.isNotBlank()
                    ) {
                        androidId
                    } else {
                        "NO_ANDROID_ID"
                    }
                )

                append(
                    "|"
                )

                append(
                    context.packageName
                )

                append(
                    "|MWOIF_DEVICE_V1"
                )
            }

        val digest =
            MessageDigest.getInstance(
                "SHA-256"
            )
                .digest(
                    source.toByteArray(
                        Charsets.UTF_8
                    )
                )

        return digest.joinToString(
            separator = ""
        ) {
            "%02x".format(
                it
            )
        }
    }
}
