package com.woif.modmenu

/**
 * Decrypted in-memory profile.
 *
 * Field names are intentionally compact in the client build.
 * Mapping is documented only in the server package.
 */
data class GameSpeedProfile(
    val a0: Long,
    val a1: Long,
    val a2: Long,
    val a3: Long,
    val a4: Long,
    val a5: Long,
    val a6: String,
    val revision: String,
    val ttlSeconds: Int
)
