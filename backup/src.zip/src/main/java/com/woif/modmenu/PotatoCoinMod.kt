package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Potato Coin desired-state controller (f07_v3).
 *
 * FIXED / MASSIVE:
 *   writes the protected integer at CRCCookiePotatoSalad + coinCountOffset.
 *
 * CONTINUOUS:
 *   keeps the same protected count as the per-fire batch. During Potato
 *   Ultimate the normal coin skill path is skipped, so this controller uses
 *   the Lua/Ghidra-verified one-shot epilogue hook on FUN_00dc71c0. The hook
 *   exists only for one short window, calls FUN_00dc6cd4 once, then restores
 *   all original opcodes immediately.
 */
class PotatoCoinMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val TICK_MS = 50L
        private const val PROCESS_RECHECK_TICKS = 10
        private const val MAX_OBJECTS = 2048
        private const val MIN_COUNT = 1
        private const val MAX_COUNT = 1000
        private const val MASSIVE_MIN = 100
        private const val MIN_INTERVAL_SECONDS = 0.05
        private const val MAX_INTERVAL_SECONDS = 10.0
        private const val HOOK_POLL_MS = 10L
        private const val HOOK_WINDOW_MS = 500L
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val loadBias: Long,
        val stageServiceGlobal: Long,
        val potatoVtableRuntime: Long
    )

    private data class ProtectedFieldInfo(
        val p8: Long,
        val p10: Long,
        val p18: Long,
        val salt: Int
    )

    private data class StageRuntime(
        val character: Long,
        val objectAddress: Long,
        val originalCoinBits: Int,
        var lastCounter: Int,
        var coinModified: Boolean = false,
        var ultimateActive: Boolean = false,
        var nextContinuousAt: Long = 0L
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var cachedProfile: PotatoProfile? = null
    @Volatile private var runtime: Runtime? = null
    @Volatile private var stage: StageRuntime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var tickCounter = 0
    @Volatile private var nextResolveAt = 0L

    @Volatile private var enabled = false
    @Volatile private var mode = "FIXED"
    @Volatile private var targetCount = 100
    @Volatile private var intervalSeconds = 1.0
    @Volatile private var status = "Potato เหรียญ พร้อม • รอเปิด"

    @Volatile private var hookInstalled = false
    @Volatile private var hookPid = -1
    @Volatile private var hookAddresses = LongArray(0)

    fun cacheProfile(value: PotatoProfile): ActionResult {
        if (
            value.imageBase <= 0L ||
            value.stageServiceGlobal <= 0L ||
            value.serviceCharacterOffset < 0L ||
            value.serviceJellyManagerOffset < 0L ||
            value.jellyManagerCharacterOffset < 0L ||
            value.potatoListPointerOffset < 0L ||
            value.vectorBeginOffset < 0L ||
            value.vectorEndOffset < 0L ||
            value.potatoVtable <= 0L ||
            value.coinCountOffset <= 0L ||
            value.ultimateCounterOffset <= 0L ||
            value.ultimateDurationCurrentOffset <= 0L ||
            value.ultimateCursorOffset <= 0L ||
            value.continuousHookFunctionAddress <= 0L ||
            value.continuousCoinFunctionAddress <= 0L ||
            value.continuousPatchAddresses.size != 4 ||
            value.continuousExpectedOriginal.size != 4 ||
            value.continuousHookFunctionSignature == 0 ||
            value.continuousMoveObjectOpcode == 0 ||
            value.continuousNopOpcode == 0 ||
            value.protectedPtr8Offset < 0L ||
            value.protectedPtr10Offset < 0L ||
            value.protectedPtr18Offset < 0L ||
            value.protectedSaltOffset < 0L ||
            value.protectedTable.size != 100
        ) {
            return failure("PROFILE_INVALID", "Potato Coin Secure Profile ยังไม่รองรับ f07_v3")
        }

        cachedProfile = value
        if (!enabled) status = "Potato เหรียญ พร้อม • กด ON ได้ทุกหน้า"
        ensureTask()
        return success("Secure Potato Coin Profile พร้อม")
    }

    fun setEnabled(
        enable: Boolean,
        requestedMode: String,
        count: Int,
        interval: Double,
        callback: (ActionResult) -> Unit
    ) {
        val normalizedMode = normalizeMode(requestedMode)
            ?: run {
                callback(failure("MODE_INVALID", "โหมด Potato Coin ไม่ถูกต้อง"))
                return
            }
        if (!validCount(normalizedMode, count)) {
            callback(failure("VALUE_INVALID", "จำนวน Potato Coin ไม่ถูกต้อง"))
            return
        }
        if (!interval.isFinite() || interval !in MIN_INTERVAL_SECONDS..MAX_INTERVAL_SECONDS) {
            callback(failure("INTERVAL_INVALID", "ช่วงเวลา Potato Coin ต่อเนื่องไม่ถูกต้อง"))
            return
        }

        mode = normalizedMode
        targetCount = count
        intervalSeconds = interval
        enabled = enable
        ensureTask()

        executor.execute {
            if (!enable) {
                restoreIfSafe()
                stage = null
                status = "Potato เหรียญ OFF"
            } else {
                stage?.nextContinuousAt = 0L
                status = "Potato เหรียญ ON • รอ CookieRun / Stage"
                safeTick()
            }
            callback(success(status))
        }
    }

    fun updateValue(requestedMode: String, count: Int, interval: Double) {
        val normalizedMode = normalizeMode(requestedMode) ?: return
        if (!validCount(normalizedMode, count)) return
        if (!interval.isFinite() || interval !in MIN_INTERVAL_SECONDS..MAX_INTERVAL_SECONDS) return

        mode = normalizedMode
        targetCount = count
        intervalSeconds = interval
        stage?.nextContinuousAt = 0L
        ensureTask()
        if (enabled) executor.execute { safeTick() }
    }

    fun isEnabled(): Boolean = enabled
    fun statusText(): String = status

    fun restoreBlockingBestEffort() {
        enabled = false
        restoreIfSafe()
        stage = null
        runtime = null
        status = "Potato เหรียญ OFF"
    }

    fun shutdown(restore: Boolean) {
        if (restore) {
            try {
                restoreBlockingBestEffort()
            } catch (_: Exception) {
            }
        } else {
            try {
                restoreHookBestEffort()
            } catch (_: Exception) {
            }
        }

        enabled = false
        closed = true
        task?.cancel(false)
        task = null
        stage = null
        runtime = null
        cachedProfile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleAtFixedRate(
            { safeTick() },
            TICK_MS,
            TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun safeTick() {
        try {
            tick()
        } catch (t: Throwable) {
            restoreHookBestEffort()
            if (enabled) status = "Potato เหรียญ ON • retry • ${t.javaClass.simpleName}"
            DevConsole.log("POT", "coin tick ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun tick() {
        if (!enabled) return

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            restoreHookBestEffort()
            status = "Potato เหรียญ ON • กำลังอัปเดต • รอ Server"
            return
        }

        tickCounter += 1

        var rt = runtime
        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) return
            nextResolveAt = now + 1000L

            val prepared = prepareRuntime()
            if (!prepared.ok) {
                status = when (prepared.errorCode) {
                    "ROOT_REQUIRED" -> "Potato เหรียญ ON • รอ Root Worker"
                    "PROFILE_NOT_READY" -> "Potato เหรียญ ON • รอ Secure Profile"
                    "GAME_NOT_RUNNING" -> "Potato เหรียญ ON • รอ CookieRun"
                    else -> "Potato เหรียญ ON • กำลังจับ runtime ใหม่"
                }
                return
            }
            rt = runtime ?: return
        }

        if (tickCounter % PROCESS_RECHECK_TICKS == 0) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                restoreHookBestEffort()
                stage = null
                runtime = null
                nextResolveAt = 0L
                status = if (livePid == null) {
                    "Potato เหรียญ ON • รอ CookieRun"
                } else {
                    "Potato เหรียญ ON • พบเกมใหม่ • กำลังเชื่อม"
                }
                return
            }
        }

        val p = profile() ?: return
        val character = resolveCharacter(rt, p)
        if (!isPointer(character)) {
            restoreHookBestEffort()
            stage = null
            status = "Potato เหรียญ ON • พร้อม • รอ Stage"
            return
        }

        val potato = findPotatoObject(rt, character, p)
        if (!isPointer(potato)) {
            restoreHookBestEffort()
            stage = null
            status = "Potato เหรียญ ON • รอ Potato object"
            return
        }

        var current = stage
        if (current == null || current.character != character || current.objectAddress != potato) {
            restoreHookBestEffort()

            val coinBits = decodeProtectedBits(rt.pid, potato + p.coinCountOffset, p) ?: return
            val counter = decodeProtectedBits(rt.pid, potato + p.ultimateCounterOffset, p) ?: return
            val cursorBits = decodeProtectedBits(rt.pid, potato + p.ultimateCursorOffset, p) ?: return
            val durationBits = decodeProtectedBits(
                rt.pid,
                potato + p.ultimateDurationCurrentOffset,
                p
            ) ?: return

            val cursor = java.lang.Float.intBitsToFloat(cursorBits)
            val duration = java.lang.Float.intBitsToFloat(durationBits)
            if (counter !in 0..3 || !cursor.isFinite() || !duration.isFinite()) return

            current = StageRuntime(
                character = character,
                objectAddress = potato,
                originalCoinBits = coinBits,
                lastCounter = counter
            )
            stage = current
            DevConsole.log(
                "POT",
                "coin bind char=0x${character.toString(16)} obj=0x${potato.toString(16)} coin=$coinBits"
            )
        }

        applyCoin(rt, current, p)
    }

    private fun applyCoin(rt: Runtime, current: StageRuntime, p: PotatoProfile) {
        val wanted = targetCount
        val coinField = current.objectAddress + p.coinCountOffset
        val liveCoin = decodeProtectedBits(rt.pid, coinField, p) ?: run {
            stage = null
            restoreHookBestEffort()
            return
        }

        if (liveCoin != wanted) {
            if (!writeProtectedBits(rt.pid, coinField, wanted, p)) {
                status = "Potato เหรียญ ON • เขียนจำนวนไม่สำเร็จ"
                return
            }
            current.coinModified = true
        }

        val counter = decodeProtectedBits(
            rt.pid,
            current.objectAddress + p.ultimateCounterOffset,
            p
        ) ?: return
        if (counter !in 0..3) {
            restoreHookBestEffort()
            stage = null
            return
        }

        val enteredUltimate = current.lastCounter == 2 && counter == 0
        current.lastCounter = counter
        if (enteredUltimate) {
            current.ultimateActive = true
            current.nextContinuousAt = 0L
        }

        if (current.ultimateActive) {
            val durationBits = decodeProtectedBits(
                rt.pid,
                current.objectAddress + p.ultimateDurationCurrentOffset,
                p
            ) ?: return
            val duration = java.lang.Float.intBitsToFloat(durationBits)
            if (!duration.isFinite()) return
            if (duration <= 0.0f) {
                current.ultimateActive = false
                current.nextContinuousAt = 0L
                restoreHookBestEffort()
            }
        }

        if (mode != "CONTINUOUS") {
            restoreHookBestEffort()
            status = if (mode == "MASSIVE") {
                "Potato เหรียญ ON • จำนวนมาก $wanted • Verify OK"
            } else {
                "Potato เหรียญ ON • คงที่ $wanted • Verify OK"
            }
            return
        }

        if (!current.ultimateActive) {
            restoreHookBestEffort()
            status = "Potato เหรียญ ON • ต่อเนื่อง $wanted • รออัลติเมต • Verify OK"
            return
        }

        val now = System.currentTimeMillis()
        if (now >= current.nextContinuousAt) {
            current.nextContinuousAt = now + (intervalSeconds * 1000.0).toLong().coerceAtLeast(50L)
            val fired = fireContinuousCoinOnce(rt, current, p)
            if (!fired.ok) {
                status = fired.message
                return
            }
        }

        status = "Potato เหรียญ ON • ต่อเนื่อง $wanted / ${formatInterval(intervalSeconds)} วิ • Verify OK"
    }

    private fun fireContinuousCoinOnce(
        rt: Runtime,
        current: StageRuntime,
        p: PotatoProfile
    ): ActionResult {
        val cursorField = current.objectAddress + p.ultimateCursorOffset
        val before = decodeProtectedBits(rt.pid, cursorField, p)
            ?: return failure("CURSOR_READ_FAILED", "Potato Coin ต่อเนื่อง • อ่าน Ultimate cursor ไม่ได้")

        val installed = installContinuousHook(rt, p)
        if (!installed.ok) return installed

        var changed = false
        try {
            var elapsed = 0L
            while (elapsed < HOOK_WINDOW_MS) {
                Thread.sleep(HOOK_POLL_MS)
                elapsed += HOOK_POLL_MS

                if (memory.pidOf(CrgProfile.GAME_PACKAGE) != rt.pid) break
                val live = decodeProtectedBits(rt.pid, cursorField, p) ?: break
                if (live != before) {
                    changed = true
                    break
                }
            }
        } finally {
            val restored = restoreContinuousHook(rt, p)
            if (!restored) {
                return failure(
                    "HOOK_RESTORE_FAILED",
                    "Potato Coin ต่อเนื่อง • คืน code hook ไม่สำเร็จ"
                )
            }
        }

        if (changed) {
            DevConsole.log("POT", "coin continuous one-shot fired")
        }
        // A miss is not fatal; the next Ultimate segment may simply not have
        // occurred inside this short hook window.
        return success(if (changed) "Potato Coin ต่อเนื่อง • ยิงเพิ่มแล้ว" else "Potato Coin ต่อเนื่อง • รอ segment ถัดไป")
    }

    private fun installContinuousHook(rt: Runtime, p: PotatoProfile): ActionResult {
        if (hookInstalled && hookPid == rt.pid) return success("hook already installed")

        val functionRuntime = runtimeAddress(rt, p, p.continuousHookFunctionAddress)
        val coinRuntime = runtimeAddress(rt, p, p.continuousCoinFunctionAddress)
        val addresses = LongArray(4) { index ->
            runtimeAddress(rt, p, p.continuousPatchAddresses[index])
        }
        if (functionRuntime < 0x10000L || coinRuntime < 0x10000L || addresses.any { it < 0x10000L }) {
            return failure("HOOK_ADDRESS_FAILED", "Potato Coin ต่อเนื่อง • คำนวณ hook address ไม่สำเร็จ")
        }

        val functionOpcode = memory.readInt(rt.pid, functionRuntime)
            ?: return failure("HOOK_SIGNATURE_READ_FAILED", "Potato Coin ต่อเนื่อง • อ่าน hook signature ไม่ได้")
        if (functionOpcode != p.continuousHookFunctionSignature) {
            return failure("HOOK_SIGNATURE_MISMATCH", "Potato Coin ต่อเนื่อง • เวอร์ชัน hook ไม่ตรง")
        }

        val bl = encodeA64Bl(addresses[1], coinRuntime)
            ?: return failure("HOOK_BL_FAILED", "Potato Coin ต่อเนื่อง • สร้าง BL ไม่สำเร็จ")
        val patch = intArrayOf(
            p.continuousMoveObjectOpcode,
            bl,
            p.continuousNopOpcode,
            p.continuousNopOpcode
        )

        var actual = readWords(rt.pid, addresses)
            ?: return failure("HOOK_READ_FAILED", "Potato Coin ต่อเนื่อง • อ่าน code hook ไม่ได้")

        if (!actual.contentEquals(p.continuousExpectedOriginal)) {
            // Recover only our own abandoned one-shot patch from an interrupted
            // previous command. Anything else is treated as a build mismatch.
            if (actual.contentEquals(patch)) {
                if (!writeWords(rt.pid, addresses, p.continuousExpectedOriginal)) {
                    return failure("HOOK_RECOVERY_FAILED", "Potato Coin ต่อเนื่อง • กู้ original code ไม่สำเร็จ")
                }
                actual = readWords(rt.pid, addresses)
                    ?: return failure("HOOK_RECOVERY_READ_FAILED", "Potato Coin ต่อเนื่อง • ตรวจ original code ไม่ได้")
            }
        }

        if (!actual.contentEquals(p.continuousExpectedOriginal)) {
            return failure("HOOK_ORIGINAL_MISMATCH", "Potato Coin ต่อเนื่อง • original opcode ไม่ตรง build")
        }

        if (!writeWords(rt.pid, addresses, patch)) {
            return failure("HOOK_WRITE_FAILED", "Potato Coin ต่อเนื่อง • ติด one-shot hook ไม่สำเร็จ")
        }

        hookInstalled = true
        hookPid = rt.pid
        hookAddresses = addresses
        return success("Potato Coin one-shot hook พร้อม")
    }

    private fun restoreContinuousHook(rt: Runtime, p: PotatoProfile): Boolean {
        if (!hookInstalled) return true
        if (hookPid != rt.pid) {
            hookInstalled = false
            hookPid = -1
            hookAddresses = LongArray(0)
            return true
        }

        val addresses = if (hookAddresses.size == 4) hookAddresses else LongArray(4) { index ->
            runtimeAddress(rt, p, p.continuousPatchAddresses[index])
        }
        val ok = writeWords(rt.pid, addresses, p.continuousExpectedOriginal)
        if (ok) {
            hookInstalled = false
            hookPid = -1
            hookAddresses = LongArray(0)
        }
        return ok
    }

    private fun restoreHookBestEffort() {
        if (!hookInstalled) return
        val rt = runtime ?: return
        val p = profile() ?: return
        try {
            restoreContinuousHook(rt, p)
        } catch (_: Exception) {
        }
    }

    private fun restoreIfSafe() {
        restoreHookBestEffort()

        val p = profile() ?: return
        val rt = runtime ?: return
        val current = stage ?: return

        if (memory.pidOf(CrgProfile.GAME_PACKAGE) != rt.pid) return
        if (resolveCharacter(rt, p) != current.character) return
        if (findPotatoObject(rt, current.character, p) != current.objectAddress) return

        if (current.coinModified) {
            writeProtectedBits(
                rt.pid,
                current.objectAddress + p.coinCountOffset,
                current.originalCoinBits,
                p
            )
        }

        DevConsole.log("POT", "coin restore obj=0x${current.objectAddress.toString(16)}")
    }

    private fun findPotatoObject(rt: Runtime, character: Long, p: PotatoProfile): Long {
        val list = memory.readLong(rt.pid, character + p.potatoListPointerOffset) ?: return 0L
        if (!isPointer(list)) return 0L

        val begin = memory.readLong(rt.pid, list + p.vectorBeginOffset) ?: return 0L
        val end = memory.readLong(rt.pid, list + p.vectorEndOffset) ?: return 0L
        if (!isPointer(begin) || end < begin || end - begin > MAX_OBJECTS.toLong() * 8L) return 0L
        if ((end - begin) % 8L != 0L) return 0L

        var found = 0L
        var cursor = begin
        while (cursor < end) {
            val obj = memory.readLong(rt.pid, cursor) ?: return 0L
            if (isPointer(obj)) {
                val vtable = memory.readLong(rt.pid, obj)
                if (vtable == rt.potatoVtableRuntime) {
                    val coinInfo = protectedFieldInfo(rt.pid, obj + p.coinCountOffset, p)
                    val counterInfo = protectedFieldInfo(rt.pid, obj + p.ultimateCounterOffset, p)
                    val durationInfo = protectedFieldInfo(rt.pid, obj + p.ultimateDurationCurrentOffset, p)
                    val cursorInfo = protectedFieldInfo(rt.pid, obj + p.ultimateCursorOffset, p)
                    if (coinInfo != null && counterInfo != null && durationInfo != null && cursorInfo != null) {
                        if (found != 0L && found != obj) {
                            DevConsole.log("POT", "multiple Potato objects in current list")
                            return 0L
                        }
                        found = obj
                    }
                }
            }
            cursor += 8L
        }
        return found
    }

    private fun protectedFieldInfo(pid: Int, field: Long, p: PotatoProfile): ProtectedFieldInfo? {
        val p8 = memory.readLong(pid, field + p.protectedPtr8Offset) ?: return null
        val p10 = memory.readLong(pid, field + p.protectedPtr10Offset) ?: return null
        val p18 = memory.readLong(pid, field + p.protectedPtr18Offset) ?: return null
        val salt = memory.readInt(pid, field + p.protectedSaltOffset) ?: return null
        if (!isPointer(p8) || !isPointer(p10) || !isPointer(p18)) return null
        return ProtectedFieldInfo(p8, p10, p18, salt)
    }

    private fun decodeProtectedBits(pid: Int, field: Long, p: PotatoProfile): Int? {
        val info = protectedFieldInfo(pid, field, p) ?: return null
        val bytes = memory.readBytes(pid, info.p8, 4) ?: return null
        if (bytes.size != 4) return null

        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF

        val d0 = ((256 - b3) and 0xFF) xor 0xC6
        val d1 = ((256 - b2) and 0xFF) xor 0x3A
        val d2 = ((256 - b1) and 0xFF) xor 0xC6
        val d3 = ((256 - b0) and 0xFF) xor 0x3A

        return d0 or (d1 shl 8) or (d2 shl 16) or (d3 shl 24)
    }

    private fun writeProtectedBits(pid: Int, field: Long, bits: Int, p: PotatoProfile): Boolean {
        val info = protectedFieldInfo(pid, field, p) ?: return false
        val table = p.protectedTable
        if (table.size != 100) return false

        val b0 = bits and 0xFF
        val b1 = (bits ushr 8) and 0xFF
        val b2 = (bits ushr 16) and 0xFF
        val b3 = (bits ushr 24) and 0xFF

        val e8 = byteArrayOf(
            (((b3 xor 0xC5) + 1) and 0xFF).toByte(),
            (((b2 xor 0x39) + 1) and 0xFF).toByte(),
            (((b1 xor 0xC5) + 1) and 0xFF).toByte(),
            (((b0 xor 0x39) + 1) and 0xFF).toByte()
        )

        val e10 = byteArrayOf(
            (((b0 xor 0x6A) + 1) and 0xFF).toByte(),
            (((b1 xor 0x94) + 1) and 0xFF).toByte(),
            (((b2 xor 0x6A) + 1) and 0xFF).toByte(),
            (((b3 xor 0x94) + 1) and 0xFF).toByte()
        )

        val salt = info.salt.toLong() and 0xFFFF_FFFFL
        fun tableAt(delta: Int): Int {
            val index = ((salt + delta.toLong()) % 100L).toInt()
            return table[index].toInt() and 0xFF
        }

        val e18 = byteArrayOf(
            (b3 xor ((256 - tableAt(0)) and 0xFF)).toByte(),
            (b2 xor tableAt(1)).toByte(),
            (b1 xor ((256 - tableAt(2)) and 0xFF)).toByte(),
            (b0 xor tableAt(3)).toByte()
        )

        val old8 = memory.readBytes(pid, info.p8, 4) ?: return false
        val old10 = memory.readBytes(pid, info.p10, 4) ?: return false
        val old18 = memory.readBytes(pid, info.p18, 4) ?: return false

        val paused = memory.pause(pid)
        return try {
            val wrote = memory.writeBytes(pid, info.p8, e8) &&
                memory.writeBytes(pid, info.p10, e10) &&
                memory.writeBytes(pid, info.p18, e18)
            val verified = wrote && decodeProtectedBits(pid, field, p) == bits

            if (!verified) {
                memory.writeBytes(pid, info.p8, old8)
                memory.writeBytes(pid, info.p10, old10)
                memory.writeBytes(pid, info.p18, old18)
            }
            verified
        } finally {
            if (paused) memory.resume(pid)
        }
    }

    private fun readWords(pid: Int, addresses: LongArray): IntArray? {
        if (addresses.size != 4) return null
        if (addresses[1] != addresses[0] + 4L ||
            addresses[2] != addresses[0] + 8L ||
            addresses[3] != addresses[0] + 12L
        ) return null

        val bytes = memory.readBytes(pid, addresses[0], 16) ?: return null
        if (bytes.size != 16) return null
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        return IntArray(4) { buffer.getInt(it * 4) }
    }

    private fun writeWords(pid: Int, addresses: LongArray, words: IntArray): Boolean {
        if (addresses.size != 4 || words.size != 4) return false
        if (addresses[1] != addresses[0] + 4L ||
            addresses[2] != addresses[0] + 8L ||
            addresses[3] != addresses[0] + 12L
        ) return false

        val bytes = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN).apply {
            words.forEach { putInt(it) }
        }.array()
        val old = memory.readBytes(pid, addresses[0], 16) ?: return false

        val paused = memory.pause(pid)
        return try {
            val wrote = memory.writeBytes(pid, addresses[0], bytes)
            val verified = wrote && readWords(pid, addresses)?.contentEquals(words) == true
            if (!verified) memory.writeBytes(pid, addresses[0], old)
            verified
        } finally {
            if (paused) memory.resume(pid)
        }
    }

    private fun encodeA64Bl(fromAddress: Long, targetAddress: Long): Int? {
        val delta = targetAddress - fromAddress
        if (delta % 4L != 0L || delta < -0x08000000L || delta > 0x07FFFFFCL) return null
        val imm26 = (delta / 4L) and 0x03FF_FFFFL
        return (0x94000000L or imm26).toInt()
    }

    private fun resolveCharacter(rt: Runtime, p: PotatoProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun prepareRuntime(): ActionResult {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ยังไม่มี Root Worker")
        }

        val p = profile() ?: return failure("PROFILE_NOT_READY", "Secure Potato Profile ยังไม่พร้อม")
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: return failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return failure("LIBGAME_NOT_READY", "ยังไม่พบ libgame.so")

        val candidates = LinkedHashSet<Long>()
        for (range in ranges) {
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
            ?: return failure("ELF_NOT_FOUND", "หา ARM64 libgame ELF ไม่สำเร็จ")
        val loadBias = parseLoadBias(pid, elfBase)
            ?: return failure("LOAD_BIAS_FAILED", "หา libgame load bias ไม่สำเร็จ")

        val stageServiceGlobal = loadBias + (p.stageServiceGlobal - p.imageBase)
        val potatoVtableRuntime = loadBias + (p.potatoVtable - p.imageBase)
        if (stageServiceGlobal < 0x10000L || potatoVtableRuntime < 0x10000L) {
            return failure("RUNTIME_ADDRESS_FAILED", "คำนวณ Potato runtime address ไม่สำเร็จ")
        }

        if (memory.readLong(pid, stageServiceGlobal) == null) {
            return failure("GLOBAL_READ_FAILED", "อ่าน Potato StageService global ไม่สำเร็จ")
        }

        runtime = Runtime(pid, loadBias, stageServiceGlobal, potatoVtableRuntime)
        status = "Potato เหรียญ ON • พร้อม • รอ Stage"
        DevConsole.log(
            "POT",
            "coin runtime pid=$pid bias=0x${loadBias.toString(16)} vtable=0x${potatoVtableRuntime.toString(16)}"
        )
        return success("Potato Coin runtime พร้อม")
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun runtimeAddress(rt: Runtime, p: PotatoProfile, staticAddress: Long): Long =
        rt.loadBias + (staticAddress - p.imageBase)

    private fun profile(): PotatoProfile? {
        val active = SecureProfileManager.getPotato()
        if (active == null) {
            cachedProfile = null
            return null
        }
        if (cachedProfile !== active) cachedProfile = active
        return active
    }

    private fun normalizeMode(value: String): String? {
        val result = value.uppercase()
        return result.takeIf { it == "FIXED" || it == "MASSIVE" || it == "CONTINUOUS" }
    }

    private fun validCount(currentMode: String, value: Int): Boolean =
        if (currentMode == "MASSIVE") value in MASSIVE_MIN..MAX_COUNT
        else value in MIN_COUNT..MAX_COUNT

    private fun formatInterval(value: Double): String =
        String.format(java.util.Locale.US, "%.2f", value)

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun success(message: String) = ActionResult(true, null, message)
    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
