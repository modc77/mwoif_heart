package com.woif.modmenu

/**
 * Decrypted in-memory XP/Coin run-metric profile.
 *
 * Build-specific gameplay-state keys/layout are supplied by the server.
 */
data class RunRewardProfile(
    val imageBase: Long,
    val stateGlobal: Long,
    val stageServiceGlobal: Long,

    val mapOffset: Long,
    val bucketArrayOffset: Long,
    val bucketCountOffset: Long,
    val listHeadOffset: Long,
    val nodeNextOffset: Long,
    val nodeHashOffset: Long,
    val nodeKeyOffset: Long,
    val nodeFieldOffset: Long,
    val fieldTypeOffset: Long,
    val fieldValuePtrOffset: Long,
    val fieldFlagOffset: Long,
    val fieldKeyPtrOffset: Long,

    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,

    val rawCoinKey: Int,
    val rawXpKey: Int,
    val finalCoinKey: Int,
    val finalXpKey: Int,
    val mirrorCoinKey: Int,
    val mirrorXpKey: Int,

    val expectedType: Int,
    val expectedFlag: Int,

    val revision: String,
    val ttlSeconds: Int
)
