package com.woif.modmenu

/**
 * M Woif feature registry.
 *
 * This is the app-side source of truth for:
 * - server feature family IDs
 * - local control keys
 * - grouping/order
 * - runtime target
 * - parameter metadata/defaults
 * - implemented AUTO keys
 * - persistence policy
 *
 * Release availability itself is NOT hardcoded in the APK.
 * Stable / Canary / Internal enablement remains server-controlled by Control Plane.
 *
 * Runtime ON/OFF state is never persisted.
 */
object FeatureCatalog {

    // ---------------------------------------------------------------------
    // Server feature families
    // ---------------------------------------------------------------------

    const val F01_GAME_SPEED = "f01"
    const val F02_HP = "f02"
    const val F03_GIANT = "f03"
    const val F04_SUPER = "f04"
    const val F05_POWER_PLUS = "f05"
    const val F06_RUN_REWARD = "f06"
    const val F07_POTATO = "f07"
    const val F08_BASE_SPEED = "f08"
    const val F09_RECOVERY = "f09"
    const val F10_UNLIMITED_JUMP = "f10"

    /**
     * Intentionally dropped features.
     *
     * Keep these keys here only as validation guards so they cannot
     * accidentally return to the release catalog.
     */
    private val DROPPED_CONTROL_KEYS = setOf(
        "MAGNET",
        "PET_SKILL"
    )

    // ---------------------------------------------------------------------
    // Persistent value defaults
    // ---------------------------------------------------------------------

    const val DEFAULT_GAME_SPEED = 20
    const val DEFAULT_GIANT_SIZE_PERCENT = 30
    const val DEFAULT_XP = 10_000
    const val DEFAULT_COIN = 350_000
    const val MAX_XP = 75_000
    const val MAX_COIN = 440_000

    const val DEFAULT_POTATO_COIN_MODE = "FIXED"
    const val DEFAULT_POTATO_COIN = 100
    const val DEFAULT_POTATO_COIN_INTERVAL = 1.0
    const val DEFAULT_POTATO_RAPID = 1.0
    const val DEFAULT_POTATO_ULTIMATE_INFINITE = false
    const val DEFAULT_POTATO_ULTIMATE_SECONDS = 300

    const val DEFAULT_BASE_SPEED_MULTIPLIER = 1.0

    /**
     * UX V18.5 AUTO preset policy:
     * - all current MOD controls can be explicitly selected;
     * - no item is pre-selected;
     * - Giant Size is a Giant parameter, not a separate AUTO item.
     */
    val DEFAULT_AUTO_SELECTED: Set<String> = emptySet()

    enum class Group {
        PLAY_MAIN,
        PLAY_SUPPLEMENTAL,
        POTATO
    }

    enum class ControlKind {
        TOGGLE,
        TOGGLE_SLIDER,
        SLIDER,
        TOGGLE_VALUE,
        COMPOSITE
    }

    enum class RuntimeTarget {
        /**
         * The game process must exist; usable from Lobby/Stage depending on module.
         */
        GAME_ACTIVE,

        /**
         * Backend target exists only while a run/stage is active.
         * UI may arm the setting earlier, but runtime application is Stage-side.
         */
        STAGE
    }

    enum class ProfilePolicy {
        SECURE_PROFILE
    }

    enum class ReleasePolicy {
        /**
         * Stable / Canary / Internal availability comes from Control Plane.
         * The APK does not choose its own channel.
         */
        SERVER_CHANNEL
    }

    /**
     * Secure Profile decoder/backend family used by this feature.
     * This is metadata only; sensitive resolver values stay server-side.
     */
    enum class ProfileKind {
        GAME_SPEED,
        HP,
        NATIVE_EFFECT,
        POWER_PLUS,
        RUN_REWARD,
        POTATO,
        BASE_SPEED,
        RECOVERY,
        UNLIMITED_JUMP
    }

    enum class PreloadPolicy {
        EAGER,
        ON_DEMAND
    }

    data class NumberSpec(
        val min: Double?,
        val max: Double?,
        val step: Double?,
        val defaultValue: Double
    )

    data class Control(
        val key: String,
        val titleTh: String,
        val titleEn: String,
        val order: Int,
        val kind: ControlKind,
        val runtimeTarget: RuntimeTarget,
        val canArmBeforeTarget: Boolean,
        val persistValue: Boolean,
        val persistEnabled: Boolean = false,
        val autoKey: String? = null,
        val number: NumberSpec? = null
    )

    data class Feature(
        val featureId: String,
        val familyKey: String,
        val group: Group,
        val order: Int,
        val profileKind: ProfileKind,
        val preloadPolicy: PreloadPolicy = PreloadPolicy.EAGER,
        val profilePolicy: ProfilePolicy = ProfilePolicy.SECURE_PROFILE,
        val releasePolicy: ReleasePolicy = ReleasePolicy.SERVER_CHANNEL,
        val controls: List<Control>
    )

    // ---------------------------------------------------------------------
    // Catalog
    // ---------------------------------------------------------------------

    val features: List<Feature> = listOf(
        Feature(
            featureId = F01_GAME_SPEED,
            familyKey = "GAME_SPEED",
            profileKind = ProfileKind.GAME_SPEED,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_MAIN,
            order = 10,
            controls = listOf(
                Control(
                    key = "GAME_SPEED",
                    titleTh = "ความเร็วเกม",
                    titleEn = "Game Speed",
                    order = 10,
                    kind = ControlKind.TOGGLE_SLIDER,
                    runtimeTarget = RuntimeTarget.GAME_ACTIVE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "SPEED",
                    number = NumberSpec(
                        min = 1.0,
                        max = 1000.0,
                        step = 1.0,
                        defaultValue = DEFAULT_GAME_SPEED.toDouble()
                    )
                )
            )
        ),
        Feature(
            featureId = F02_HP,
            familyKey = "HP",
            profileKind = ProfileKind.HP,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_MAIN,
            order = 20,
            controls = listOf(
                Control(
                    key = "HP",
                    titleTh = "อมตะ",
                    titleEn = "Immortal",
                    order = 10,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "HP"
                )
            )
        ),
        Feature(
            featureId = F03_GIANT,
            familyKey = "GIANT",
            profileKind = ProfileKind.NATIVE_EFFECT,
            preloadPolicy = PreloadPolicy.ON_DEMAND,
            group = Group.PLAY_MAIN,
            order = 30,
            controls = listOf(
                Control(
                    key = "GIANT",
                    titleTh = "ตัวใหญ่",
                    titleEn = "Giant",
                    order = 10,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "GIANT"
                ),
                Control(
                    key = "GIANT_SIZE",
                    titleTh = "ขนาด Giant",
                    titleEn = "Giant Size",
                    order = 20,
                    kind = ControlKind.SLIDER,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    number = NumberSpec(
                        min = 10.0,
                        max = 100.0,
                        step = 1.0,
                        defaultValue = DEFAULT_GIANT_SIZE_PERCENT.toDouble()
                    )
                )
            )
        ),
        Feature(
            featureId = F04_SUPER,
            familyKey = "SUPER",
            profileKind = ProfileKind.NATIVE_EFFECT,
            preloadPolicy = PreloadPolicy.ON_DEMAND,
            group = Group.PLAY_MAIN,
            order = 40,
            controls = listOf(
                Control(
                    key = "SUPER",
                    titleTh = "วิ่งเร็ว",
                    titleEn = "Super",
                    order = 10,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "SUPER"
                )
            )
        ),
        Feature(
            featureId = F05_POWER_PLUS,
            familyKey = "POWER_PLUS",
            profileKind = ProfileKind.POWER_PLUS,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_MAIN,
            order = 50,
            controls = listOf(
                Control(
                    key = "POWER",
                    titleTh = "Power+",
                    titleEn = "Power+",
                    order = 10,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "POWER"
                )
            )
        ),
        Feature(
            featureId = F06_RUN_REWARD,
            familyKey = "RUN_REWARD",
            profileKind = ProfileKind.RUN_REWARD,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_MAIN,
            order = 60,
            controls = listOf(
                Control(
                    key = "XP",
                    titleTh = "XP / เลเวล",
                    titleEn = "XP",
                    order = 10,
                    kind = ControlKind.TOGGLE_VALUE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "XP",
                    number = NumberSpec(
                        min = 0.0,
                        max = MAX_XP.toDouble(),
                        step = 500.0,
                        defaultValue = DEFAULT_XP.toDouble()
                    )
                ),
                Control(
                    key = "COIN",
                    titleTh = "เหรียญ",
                    titleEn = "Coin",
                    order = 20,
                    kind = ControlKind.TOGGLE_VALUE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "COIN",
                    number = NumberSpec(
                        min = 0.0,
                        max = MAX_COIN.toDouble(),
                        step = 1_000.0,
                        defaultValue = DEFAULT_COIN.toDouble()
                    )
                )
            )
        ),
        Feature(
            featureId = F07_POTATO,
            familyKey = "POTATO",
            profileKind = ProfileKind.POTATO,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.POTATO,
            order = 10,
            controls = listOf(
                Control(
                    key = "POTATO_COIN",
                    titleTh = "Potato • เหรียญ",
                    titleEn = "Potato • Coin",
                    order = 10,
                    kind = ControlKind.COMPOSITE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "POTATO_COIN"
                ),
                Control(
                    key = "POTATO_RAPID",
                    titleTh = "Potato • ยิงเร็ว",
                    titleEn = "Potato • Rapid",
                    order = 20,
                    kind = ControlKind.TOGGLE_VALUE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "POTATO_RAPID",
                    number = NumberSpec(
                        min = 0.01,
                        max = 60.0,
                        step = 0.01,
                        defaultValue = DEFAULT_POTATO_RAPID
                    )
                ),
                Control(
                    key = "POTATO_ULTIMATE",
                    titleTh = "Potato • อัลติเมต",
                    titleEn = "Potato • Ultimate",
                    order = 30,
                    kind = ControlKind.COMPOSITE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "ULTIMATE"
                )
            )
        ),
        Feature(
            featureId = F08_BASE_SPEED,
            familyKey = "BASE_SPEED",
            profileKind = ProfileKind.BASE_SPEED,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_SUPPLEMENTAL,
            order = 10,
            controls = listOf(
                Control(
                    key = "BASE_SPEED",
                    titleTh = "ความเร็วพื้นฐานคุกกี้",
                    titleEn = "Cookie Base Speed",
                    order = 10,
                    kind = ControlKind.TOGGLE_SLIDER,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = true,
                    autoKey = "BASE_SPEED",
                    number = NumberSpec(
                        min = 0.5,
                        max = 5.0,
                        step = 0.1,
                        defaultValue = DEFAULT_BASE_SPEED_MULTIPLIER
                    )
                )
            )
        ),
        Feature(
            featureId = F09_RECOVERY,
            familyKey = "RECOVERY",
            profileKind = ProfileKind.RECOVERY,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_SUPPLEMENTAL,
            order = 20,
            controls = listOf(
                Control(
                    key = "PIT_LIFT",
                    titleTh = "ขึ้นจากหลุมไม่จำกัด",
                    titleEn = "Pit Lift Unlimited",
                    order = 10,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "PIT_LIFT"
                ),
                Control(
                    key = "REVIVE",
                    titleTh = "ชุบชีวิตไม่จำกัด",
                    titleEn = "Revive Unlimited",
                    order = 20,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "REVIVE"
                )
            )
        ),
        Feature(
            featureId = F10_UNLIMITED_JUMP,
            familyKey = "UNLIMITED_JUMP",
            profileKind = ProfileKind.UNLIMITED_JUMP,
            preloadPolicy = PreloadPolicy.EAGER,
            group = Group.PLAY_SUPPLEMENTAL,
            order = 30,
            controls = listOf(
                Control(
                    key = "UNLIMITED_JUMP",
                    titleTh = "กระโดดไม่จำกัด",
                    titleEn = "Unlimited Jump",
                    order = 10,
                    kind = ControlKind.TOGGLE,
                    runtimeTarget = RuntimeTarget.STAGE,
                    canArmBeforeTarget = true,
                    persistValue = false,
                    autoKey = "UNLIMITED_JUMP"
                )
            )
        )
    )

    private val featureById: Map<String, Feature> =
        features.associateBy { it.featureId }

    private val featureByControlKey: Map<String, Feature> =
        buildMap {
            features.forEach { feature ->
                feature.controls.forEach { control ->
                    put(control.key, feature)
                }
            }
        }

    val SERVER_FEATURE_IDS: List<String> =
        features
            .map { it.featureId }

    val KNOWN_FEATURE_IDS: Set<String> =
        SERVER_FEATURE_IDS.toSet()

    val controls: List<Control> =
        features
            .sortedWith(compareBy<Feature> { it.group.ordinal }.thenBy { it.order })
            .flatMap { feature ->
                feature.controls.sortedBy { it.order }
            }

    val implementedAutoKeys: Set<String> =
        controls
            .mapNotNull { it.autoKey }
            .toCollection(linkedSetOf())

    fun feature(featureId: String): Feature? =
        features.firstOrNull { it.featureId == featureId }

    fun control(key: String): Control? =
        controls.firstOrNull { it.key == key }

    fun controlsFor(group: Group): List<Control> =
        features
            .filter { it.group == group }
            .sortedBy { it.order }
            .flatMap { feature -> feature.controls.sortedBy { it.order } }

    fun isKnownFeatureId(featureId: String): Boolean =
        featureById.containsKey(featureId)

    fun featureForControl(controlKey: String): Feature? =
        featureByControlKey[controlKey]

    fun featureIdForControl(controlKey: String): String? =
        featureForControl(controlKey)?.featureId

    fun eagerFeatures(): List<Feature> =
        features.filter { it.preloadPolicy == PreloadPolicy.EAGER }

    /**
     * Pure validation: no logging, no crash, no side effects.
     *
     * 4.4 Release Validation can call this and block a release if errors exist.
     */
    fun validate(): List<String> {
        val errors = mutableListOf<String>()

        val featureIds = features.map { it.featureId }
        if (featureIds.size != featureIds.distinct().size) {
            errors += "Duplicate server featureId in FeatureCatalog"
        }

        val controlKeys = controls.map { it.key }
        if (controlKeys.size != controlKeys.distinct().size) {
            errors += "Duplicate control key in FeatureCatalog"
        }

        val autoKeys = controls.mapNotNull { it.autoKey }
        if (autoKeys.size != autoKeys.distinct().size) {
            errors += "Duplicate AUTO key in FeatureCatalog"
        }

        if (!implementedAutoKeys.containsAll(DEFAULT_AUTO_SELECTED)) {
            errors += "DEFAULT_AUTO_SELECTED contains unsupported AUTO key"
        }

        controls
            .filter { it.persistEnabled }
            .forEach {
                errors += "${it.key}: runtime ON/OFF state must not be persisted"
            }

        val accidentallyRestored = controlKeys.filter { it in DROPPED_CONTROL_KEYS }
        if (accidentallyRestored.isNotEmpty()) {
            errors += "Dropped controls returned to catalog: ${accidentallyRestored.joinToString()}"
        }

        features
            .filter { it.releasePolicy != ReleasePolicy.SERVER_CHANNEL }
            .forEach {
                errors += "${it.featureId}: release availability must remain server-controlled"
            }

        return errors
    }
}
