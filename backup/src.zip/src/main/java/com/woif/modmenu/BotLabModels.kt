package com.woif.modmenu

data class BotTapStep(
    val x: Int,
    val y: Int,
    val delayMs: Long
)

data class BotRouteCheckpoint(
    val id: Int,
    /** Number of taps that have already happened when this image was saved. */
    val afterTapIndex: Int,
    val offsetMs: Long
)

data class BotRecordedRoute(
    val slot: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val recordedAt: Long,
    val steps: List<BotTapStep>,
    val checkpoints: List<BotRouteCheckpoint> = emptyList()
)

/**
 * Kept for compatibility with the first BOT LAB build. V2 uses route checkpoints
 * instead of asking the user to manually manage Lobby/Stage/Result images.
 */
enum class BotScreenState {
    UNKNOWN,
    LOBBY,
    STAGE,
    RESULT
}

data class BotScreenDetection(
    val state: BotScreenState,
    val score: Float,
    val scores: Map<BotScreenState, Float>
)

data class BotCheckpointMatch(
    val checkpoint: BotRouteCheckpoint?,
    val score: Float
)
