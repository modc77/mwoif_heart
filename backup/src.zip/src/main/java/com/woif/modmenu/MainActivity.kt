package com.woif.modmenu

import android.app.AppOpsManager
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Process
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "WOIF_APP"
        private const val GAME_PACKAGE = "com.devsisters.crg"
        private const val GAME_ID = "cookie_run_classic"

        private const val PREFS = "woif_app_preferences"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_REMEMBER = "remember_key"
        private const val KEY_SAVED_LICENSE = "saved_license_key"

        private const val LANG_TH = "TH"
        private const val LANG_EN = "EN"
    }

    private lateinit var keyInputLayout: TextInputLayout
    private lateinit var keyInput: TextInputEditText
    private lateinit var loginButton: MaterialButton
    private lateinit var statusDot: TextView
    private lateinit var statusTitle: TextView
    private lateinit var statusText: TextView

    private lateinit var appTitle: TextView
    private lateinit var appSubtitle: TextView
    private lateinit var welcomeTitle: TextView
    private lateinit var welcomeSubtitle: TextView
    private lateinit var footerText: TextView

    private lateinit var thaiButton: MaterialButton
    private lateinit var englishButton: MaterialButton
    private lateinit var rememberKeyCheckBox: MaterialCheckBox

    private var loginAccepted = false
    private var loginBusy = false

    private val licenseExecutor: ExecutorService =
        Executors.newSingleThreadExecutor()

    private val rootExecutor: ExecutorService =
        Executors.newSingleThreadExecutor()

    private var language = LANG_TH

    private fun brandName(): String =
        if (BuildConfig.INTERNAL_BUILD) "M Woif Lab" else "M Woif"

    private fun brandFooter(): String =
        if (BuildConfig.INTERNAL_BUILD) {
            "M Woif Lab • v${BuildConfig.VERSION_NAME}"
        } else {
            "M Woif MOD MENU • v${BuildConfig.VERSION_NAME}"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        bindViews()
        loadLanguage()
        loadRememberedKey()
        applyLanguage()

        requestRootEarly()

        loginButton.setOnClickListener {

            if (loginAccepted) {
                prepareGameLaunch()
                return@setOnClickListener
            }

            val key =
                keyInput.text
                    ?.toString()
                    ?.trim()
                    .orEmpty()

            keyInputLayout.error = null

            if (key.isBlank()) {

                keyInputLayout.error =
                    tr(
                        "กรุณาใส่ License Key",
                        "Please enter your license key"
                    )

                setStatus(
                    "#F4B740",
                    tr(
                        "จำเป็นต้องใส่ License Key",
                        "License key required"
                    )
                )

                Toast.makeText(
                    this,
                    tr(
                        "กรุณาใส่ License Key",
                        "Please enter your license key"
                    ),
                    Toast.LENGTH_SHORT
                ).show()

                keyInput.requestFocus()

                return@setOnClickListener
            }

            if (loginBusy) {
                return@setOnClickListener
            }

            loginWithServer(
                key
            )
        }

        thaiButton.setOnClickListener {
            setLanguage(LANG_TH)
        }

        englishButton.setOnClickListener {
            setLanguage(LANG_EN)
        }

        rememberKeyCheckBox.setOnCheckedChangeListener { _, checked ->

            val prefs =
                getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )

            prefs.edit()
                .putBoolean(
                    KEY_REMEMBER,
                    checked
                )
                .apply()

            if (!checked) {

                prefs.edit()
                    .remove(
                        KEY_SAVED_LICENSE
                    )
                    .apply()
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (!::statusText.isInitialized) {
            return
        }

        syncRememberPreference()

        if (
            loginAccepted &&
            !SessionManager.isAuthenticated()
        ) {

            resetLoginState(
                tr(
                    "Session หมดอายุ • กรุณา LOGIN ใหม่",
                    "Session expired • Please LOGIN again"
                )
            )

            return
        }

        if (loginAccepted) {
            refreshPermissionStatus()
        }
    }

    private fun requestRootEarly() {

        /*
         * Let MainActivity become visible first. Some root managers are more
         * reliable about showing their permission dialog after the caller's
         * activity is already on screen.
         */
        window
            .decorView
            .postDelayed(
                {

                    rootExecutor.execute {

                        val granted =
                            try {

                                RootMemoryClient
                                    .ensureStarted(
                                        this
                                    )

                            } catch (
                                e: Exception
                            ) {

                                Log.e(
                                    TAG,
                                    "Early root exception",
                                    e
                                )

                                false
                            }

                        Log.d(
                            TAG,
                            "Early root request granted=$granted"
                        )
                    }
                },
                700L
            )
    }

    private fun bindViews() {

        keyInputLayout =
            findViewById(
                R.id.keyInputLayout
            )

        keyInput =
            findViewById(
                R.id.keyInput
            )

        loginButton =
            findViewById(
                R.id.loginButton
            )

        statusDot =
            findViewById(
                R.id.statusDot
            )

        statusTitle =
            findViewById(
                R.id.statusTitle
            )

        statusText =
            findViewById(
                R.id.statusText
            )

        appTitle =
            findViewById(
                R.id.appTitle
            )

        appSubtitle =
            findViewById(
                R.id.appSubtitle
            )

        welcomeTitle =
            findViewById(
                R.id.welcomeTitle
            )

        welcomeSubtitle =
            findViewById(
                R.id.welcomeSubtitle
            )

        footerText =
            findViewById(
                R.id.footerText
            )

        thaiButton =
            findViewById(
                R.id.thaiButton
            )

        englishButton =
            findViewById(
                R.id.englishButton
            )

        rememberKeyCheckBox =
            findViewById(
                R.id.rememberKeyCheckBox
            )
    }

    private fun loadLanguage() {

        val prefs =
            getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )

        language =
            prefs.getString(
                KEY_LANGUAGE,
                LANG_TH
            ) ?: LANG_TH
    }

    private fun loadRememberedKey() {

        val prefs =
            getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )

        val remember =
            prefs.getBoolean(
                KEY_REMEMBER,
                false
            )

        rememberKeyCheckBox.isChecked =
            remember

        if (remember) {

            val savedKey =
                prefs.getString(
                    KEY_SAVED_LICENSE,
                    ""
                ).orEmpty()

            if (savedKey.isNotBlank()) {

                keyInput.setText(
                    savedKey
                )

                keyInput.setSelection(
                    savedKey.length
                )
            }

        } else {

            prefs.edit()
                .remove(
                    KEY_SAVED_LICENSE
                )
                .apply()
        }
    }

    private fun syncRememberPreference() {

        val prefs =
            getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )

        val remember =
            prefs.getBoolean(
                KEY_REMEMBER,
                false
            )

        if (
            rememberKeyCheckBox.isChecked !=
            remember
        ) {

            rememberKeyCheckBox.setOnCheckedChangeListener(
                null
            )

            rememberKeyCheckBox.isChecked =
                remember

            rememberKeyCheckBox.setOnCheckedChangeListener { _, checked ->

                prefs.edit()
                    .putBoolean(
                        KEY_REMEMBER,
                        checked
                    )
                    .apply()

                if (!checked) {

                    prefs.edit()
                        .remove(
                            KEY_SAVED_LICENSE
                        )
                        .apply()
                }
            }
        }

        if (!remember) {

            prefs.edit()
                .remove(
                    KEY_SAVED_LICENSE
                )
                .apply()
        }
    }

    private fun saveRememberedKeyIfNeeded(
        key: String
    ) {

        val prefs =
            getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )

        if (rememberKeyCheckBox.isChecked) {

            prefs.edit()
                .putBoolean(
                    KEY_REMEMBER,
                    true
                )
                .putString(
                    KEY_SAVED_LICENSE,
                    key
                )
                .apply()

        } else {

            prefs.edit()
                .putBoolean(
                    KEY_REMEMBER,
                    false
                )
                .remove(
                    KEY_SAVED_LICENSE
                )
                .apply()
        }
    }

    private fun setLanguage(
        value: String
    ) {

        if (
            value != LANG_TH &&
            value != LANG_EN
        ) {
            return
        }

        language =
            value

        getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )
            .edit()
            .putString(
                KEY_LANGUAGE,
                value
            )
            .apply()

        applyLanguage()
    }

    private fun applyLanguage() {

        appTitle.text =
            brandName()

        appSubtitle.text =
            tr(
                "ตัวโหลดเกม COOKIE RUN",
                "COOKIE RUN GAME LOADER"
            )

        welcomeTitle.text =
            tr(
                "ยินดีต้อนรับกลับ",
                "Welcome back"
            )

        welcomeSubtitle.text =
            tr(
                "ใส่ License Key เพื่อดำเนินการต่อ",
                "Enter your license key to continue."
            )

        keyInputLayout.hint =
            "License Key"

        statusTitle.text =
            tr(
                "สถานะ",
                "Status"
            )

        footerText.text =
            brandFooter()

        thaiButton.text =
            "ไทย"

        englishButton.text =
            "EN"

        rememberKeyCheckBox.text =
            tr(
                "จดจำ License Key",
                "Remember License Key"
            )

        styleLanguageButtons()

        if (!loginAccepted) {

            loginButton.text =
                tr(
                    "เข้าสู่ระบบ",
                    "LOGIN"
                )

            setStatus(
                "#F4B740",
                tr(
                    "M Woif พร้อม • รอ License Key",
                    "M Woif ready • Waiting for license key"
                )
            )

        } else {

            loginButton.text =
                tr(
                    "เข้าเกม",
                    "ENTER GAME"
                )

            refreshPermissionStatus()
        }
    }

    private fun styleLanguageButtons() {

        val thaiSelected =
            language ==
                    LANG_TH

        val englishSelected =
            language ==
                    LANG_EN

        thaiButton.backgroundTintList =
            android.content.res.ColorStateList.valueOf(
                Color.parseColor(
                    if (
                        thaiSelected
                    ) {
                        "#7C5CF7"
                    } else {
                        "#171D27"
                    }
                )
            )

        thaiButton.setTextColor(
            Color.parseColor(
                if (
                    thaiSelected
                ) {
                    "#FFFFFF"
                } else {
                    "#8993A4"
                }
            )
        )

        englishButton.backgroundTintList =
            android.content.res.ColorStateList.valueOf(
                Color.parseColor(
                    if (
                        englishSelected
                    ) {
                        "#7C5CF7"
                    } else {
                        "#171D27"
                    }
                )
            )

        englishButton.setTextColor(
            Color.parseColor(
                if (
                    englishSelected
                ) {
                    "#FFFFFF"
                } else {
                    "#8993A4"
                }
            )
        )
    }

    private fun tr(
        th: String,
        en: String
    ): String {

        return if (
            language ==
            LANG_EN
        ) {
            en
        } else {
            th
        }
    }

    private fun refreshPermissionStatus() {

        val overlayReady =
            Settings.canDrawOverlays(
                this
            )

        val usageReady =
            hasUsageAccess()

        when {

            !overlayReady -> {

                setStatus(
                    "#F4B740",
                    tr(
                        "ต้องอนุญาตให้แสดงทับแอปอื่น",
                        "Overlay permission required"
                    )
                )
            }

            !usageReady -> {

                setStatus(
                    "#F4B740",
                    tr(
                        "ต้องเปิดสิทธิ์ Usage Access",
                        "Usage Access required"
                    )
                )
            }

            else -> {

                setStatus(
                    "#4ADE80",
                    tr(
                        "สิทธิ์พร้อม • พร้อมเข้าเกม",
                        "Permissions ready • Ready to enter game"
                    )
                )
            }
        }
    }

    private fun loginWithServer(
        key: String
    ) {

        loginBusy =
            true

        hideKeyboard()

        loginButton.isEnabled =
            false

        keyInput.isEnabled =
            false

        rememberKeyCheckBox.isEnabled =
            false

        thaiButton.isEnabled =
            false

        englishButton.isEnabled =
            false

        loginButton.text =
            tr(
                "กำลังตรวจสอบ...",
                "CHECKING..."
            )

        setStatus(
            "#F4B740",
            tr(
                "กำลังตรวจสอบ License กับ Server...",
                "Checking license with server..."
            )
        )

        val deviceId =
            DeviceIdProvider.get(
                this
            )

        val appVersion =
            getAppVersion()

        val gameVersion =
            GameVersionProvider.get(this)

        licenseExecutor.execute {

            val result =
                LicenseApi.login(
                    key =
                    key,

                    deviceId =
                    deviceId,

                    gameId =
                    GAME_ID,

                    gameVersion =
                    gameVersion,

                    appVersion =
                    appVersion
                )

            runOnUiThread {

                if (
                    isFinishing ||
                    isDestroyed
                ) {
                    return@runOnUiThread
                }

                loginBusy =
                    false

                when (
                    result
                ) {

                    is ApiResult.Success -> {

                        try {

                            SessionManager.authenticate(
                                response =
                                result.value,

                                appVersion =
                                appVersion
                            )

                            ControlPlaneState.update(
                                result.value.control
                            )

                            SecureProfileManager.clear()

                            SecureProfileManager
                                .preloadGameSpeed()

                            SecureProfileManager
                                .preloadHp()

                            /*
                             * Warm the shared f07 Potato profile while the user
                             * is still on the login screen. This hides normal
                             * network/decrypt latency from Rapid / Ultimate /
                             * Coin toggles once the game/menu opens.
                             */
                            if (
                                ControlPlaneState.isFeatureAllowed(
                                    CrgProfile.FEATURE_POTATO
                                )
                            ) {
                                SecureProfileManager.preloadPotato()
                            }

                            loginAccepted =
                                true

                            saveRememberedKeyIfNeeded(
                                key
                            )

                            keyInputLayout.error =
                                null

                            keyInput.isEnabled =
                                false

                            rememberKeyCheckBox.isEnabled =
                                true

                            loginButton.isEnabled =
                                true

                            loginButton.text =
                                tr(
                                    "เข้าเกม",
                                    "ENTER GAME"
                                )

                            /*
                             * Language may still be changed later from the
                             * floating menu. Login page controls are locked
                             * after authentication so the session screen
                             * remains stable.
                             */
                            thaiButton.isEnabled =
                                false

                            englishButton.isEnabled =
                                false

                            refreshPermissionStatus()

                            Toast.makeText(
                                this,
                                tr(
                                    "License ถูกต้อง • เข้าสู่ระบบสำเร็จ",
                                    "License valid • Login successful"
                                ),
                                Toast.LENGTH_SHORT
                            ).show()

                            Log.d(
                                TAG,
                                "Server license accepted"
                            )

                        } catch (
                            e: Exception
                        ) {

                            SecureProfileManager.clear()
                            SessionManager.clear()
                            ControlPlaneState.reset()

                            resetLoginState(
                                tr(
                                    "ข้อมูล License จาก Server ไม่ถูกต้อง",
                                    "Invalid license response from server"
                                )
                            )

                            if (BuildConfig.INTERNAL_BUILD) {
                                Log.e(
                                    TAG,
                                    "Unable to create server session",
                                    e
                                )
                            }
                        }
                    }

                    is ApiResult.Failure -> {

                        SecureProfileManager.clear()
                        SessionManager.clear()
                        ControlPlaneState.reset()

                        val text =
                            licenseErrorText(
                                result.error
                            )

                        resetLoginState(
                            text
                        )

                        if (result.error == "KEY_EXPIRED") {
                            keyInputLayout.error = null
                            showExpiredLicenseDialog(result)
                        } else {
                            keyInputLayout.error = text
                        }

                        if (BuildConfig.INTERNAL_BUILD) {
                            Log.w(
                                TAG,
                                "License rejected: ${result.error}"
                            )
                        }
                    }

                    is ApiResult.NetworkFailure -> {

                        SecureProfileManager.clear()
                        SessionManager.clear()
                        ControlPlaneState.reset()

                        resetLoginState(
                            tr(
                                "เชื่อมต่อ License Server ไม่ได้",
                                "Unable to reach license server"
                            )
                        )

                        if (BuildConfig.INTERNAL_BUILD) {
                            Log.e(
                                TAG,
                                "License network error: ${result.message}"
                            )
                        }
                    }
                }
            }
        }
    }

    private fun showExpiredLicenseDialog(
        failure: ApiResult.Failure
    ) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpLogin(22), dpLogin(18), dpLogin(22), dpLogin(22))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpLogin(22).toFloat()
                setColor(Color.parseColor("#0B1018"))
                setStroke(dpLogin(1), Color.parseColor("#30394A"))
            }
        }

        val closeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        closeRow.addView(
            TextView(this).apply {
                text = "×"
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#9AA5B5"))
                setOnClickListener { dialog.dismiss() }
            },
            LinearLayout.LayoutParams(dpLogin(38), dpLogin(38))
        )
        root.addView(closeRow)

        root.addView(TextView(this).apply {
            text = "⚠"
            textSize = 36f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F4B740"))
        })

        root.addView(TextView(this).apply {
            text = tr("License หมดอายุแล้ว", "License expired")
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F3F5F8"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dpLogin(8), 0, 0)
        })

        root.addView(TextView(this).apply {
            text = tr(
                "Key นี้หมดอายุและไม่สามารถใช้งาน M Woif ต่อได้",
                "This key has expired and can no longer use M Woif."
            )
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#8E99A9"))
            setPadding(dpLogin(12), dpLogin(10), dpLogin(12), 0)
        })

        val expiry = formatExpiredAt(failure.expiresAt)
        if (expiry.isNotBlank()) {
            root.addView(TextView(this).apply {
                text = tr("หมดอายุ", "Expired")
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#697486"))
                setPadding(0, dpLogin(18), 0, 0)
            })
            root.addView(TextView(this).apply {
                text = expiry
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#C9C1FF"))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, dpLogin(4), 0, 0)
            })
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dpLogin(20), 0, 0)
        }

        val telegram = MaterialButton(this).apply {
            text = tr("เข้ากลุ่ม Telegram", "Telegram")
            isAllCaps = false
            cornerRadius = dpLogin(14)
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                Color.parseColor("#7C5CF7")
            )
            isEnabled = !failure.supportTelegramUrl.isNullOrBlank()
            alpha = if (isEnabled) 1f else 0.45f
            setOnClickListener { openExternalUrl(failure.supportTelegramUrl) }
        }

        val website = MaterialButton(this).apply {
            text = tr("ไปยังเว็บไซต์", "Website")
            isAllCaps = false
            cornerRadius = dpLogin(14)
            setTextColor(Color.parseColor("#DDE2EA"))
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                Color.parseColor("#171D27")
            )
            strokeColor = android.content.res.ColorStateList.valueOf(
                Color.parseColor("#384253")
            )
            strokeWidth = dpLogin(1)
            isEnabled = !failure.websiteUrl.isNullOrBlank()
            alpha = if (isEnabled) 1f else 0.45f
            setOnClickListener { openExternalUrl(failure.websiteUrl) }
        }

        actions.addView(
            telegram,
            LinearLayout.LayoutParams(0, dpLogin(48), 1f).apply {
                marginEnd = dpLogin(6)
            }
        )
        actions.addView(
            website,
            LinearLayout.LayoutParams(0, dpLogin(48), 1f).apply {
                marginStart = dpLogin(6)
            }
        )
        root.addView(actions)

        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setDimAmount(0.62f)
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
        dialog.setOnShowListener {
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()
    }

    private fun formatExpiredAt(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        return try {
            val locale = if (language == LANG_TH) Locale("th", "TH") else Locale.US
            DateTimeFormatter
                .ofPattern("d MMM yyyy • HH:mm", locale)
                .withZone(ZoneId.systemDefault())
                .format(Instant.parse(raw))
        } catch (_: Exception) {
            raw
        }
    }

    private fun openExternalUrl(url: String?) {
        if (url.isNullOrBlank()) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(
                this,
                tr("ไม่สามารถเปิดลิงก์ได้", "Unable to open link"),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun dpLogin(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun resetLoginState(
        status: String
    ) {

        loginAccepted =
            false

        loginBusy =
            false

        loginButton.isEnabled =
            true

        keyInput.isEnabled =
            true

        rememberKeyCheckBox.isEnabled =
            true

        thaiButton.isEnabled =
            true

        englishButton.isEnabled =
            true

        loginButton.text =
            tr(
                "เข้าสู่ระบบ",
                "LOGIN"
            )

        setStatus(
            "#F87171",
            status
        )
    }

    private fun licenseErrorText(
        error: String
    ): String {

        return when (
            error
        ) {

            "INVALID_KEY" ->
                tr(
                    "License Key ไม่ถูกต้อง",
                    "Invalid license key"
                )

            "KEY_EXPIRED" ->
                tr(
                    "License Key หมดอายุแล้ว",
                    "License key has expired"
                )

            "KEY_DISABLED" ->
                tr(
                    "License Key ถูกปิดใช้งาน",
                    "License key is disabled"
                )

            "KEY_REVOKED" ->
                tr(
                    "License Key ถูกยกเลิก",
                    "License key has been revoked"
                )

            "DEVICE_MISMATCH" ->
                tr(
                    "Key นี้ถูกผูกกับอุปกรณ์อื่นแล้ว",
                    "This key is bound to another device"
                )

            "GAME_MISMATCH",
            "GAME_NOT_ALLOWED",
            "GAME_DISABLED" ->
                tr(
                    "License ไม่รองรับเกมนี้",
                    "License is not valid for this game"
                )

            "APP_UPDATE_REQUIRED" ->
                tr(
                    "M Woif เวอร์ชันนี้เก่าเกินไป",
                    "This M Woif version is too old"
                )

            "MAINTENANCE" ->
                tr(
                    "License Server กำลังปิดปรับปรุง",
                    "License server is under maintenance"
                )

            "SERVICE_DISABLED" ->
                tr(
                    "ระบบ Login ถูกปิดชั่วคราว",
                    "Login service is temporarily disabled"
                )

            else ->
                tr(
                    "ไม่สามารถตรวจสอบ License ได้ ($error)",
                    "License validation failed ($error)"
                )
        }
    }

    private fun getAppVersion():
            String {

        return try {

            @Suppress("DEPRECATION")
            packageManager
                .getPackageInfo(
                    packageName,
                    0
                )
                .versionName
                ?.takeIf {
                    it.isNotBlank()
                }
                ?: "1.0"

        } catch (
            e: Exception
        ) {

            "1.0"
        }
    }

    private fun prepareGameLaunch() {

        if (!SessionManager.isAuthenticated()) {

            SecureProfileManager.clear()
            SessionManager.clear()
            ControlPlaneState.reset()

            resetLoginState(
                tr(
                    "Session หมดอายุ • กรุณา LOGIN ใหม่",
                    "Session expired • Please LOGIN again"
                )
            )

            return
        }

        if (
            !Settings.canDrawOverlays(
                this
            )
        ) {

            setStatus(
                "#F4B740",
                tr(
                    "กรุณาอนุญาตให้ M Woif แสดงทับแอปอื่น",
                    "Please allow M Woif to display over other apps"
                )
            )

            Toast.makeText(
                this,
                tr(
                    "เปิดสิทธิ์ Display over other apps ให้ M Woif",
                    "Allow M Woif to display over other apps"
                ),
                Toast.LENGTH_LONG
            ).show()

            openOverlayPermission()

            return
        }

        if (!hasUsageAccess()) {

            setStatus(
                "#F4B740",
                tr(
                    "กรุณาเปิด Usage Access ให้ M Woif",
                    "Please enable Usage Access for M Woif"
                )
            )

            Toast.makeText(
                this,
                tr(
                    "เปิด Usage Access ให้ M Woif",
                    "Enable Usage Access for M Woif"
                ),
                Toast.LENGTH_LONG
            ).show()

            openUsageAccessSettings()

            return
        }

        val started =
            startFloatingMenu()

        if (!started) {

            setStatus(
                "#F87171",
                tr(
                    "ไม่สามารถเปิด M Woif Menu ได้",
                    "Unable to start M Woif menu"
                )
            )

            return
        }

        setStatus(
            "#4ADE80",
            tr(
                "M Woif พร้อม • กำลังเปิด Cookie Run",
                "M Woif ready • Opening Cookie Run"
            )
        )

        loginButton.postDelayed(
            {
                openCookieRun()
            },
            600
        )
    }

    private fun hasUsageAccess():
            Boolean {

        val appOps =
            getSystemService(
                Context.APP_OPS_SERVICE
            ) as AppOpsManager

        val mode =
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                packageName
            )

        return mode ==
                AppOpsManager.MODE_ALLOWED
    }

    private fun openUsageAccessSettings() {

        try {

            startActivity(
                Intent(
                    Settings.ACTION_USAGE_ACCESS_SETTINGS
                )
            )

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Unable to open Usage Access settings",
                e
            )
        }
    }

    private fun openOverlayPermission() {

        try {

            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse(
                        "package:$packageName"
                    )
                )
            )

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Unable to open overlay settings",
                e
            )
        }
    }

    private fun startFloatingMenu():
            Boolean {

        val intent =
            Intent(
                this,
                FloatingMenuService::class.java
            )

        return try {

            ContextCompat.startForegroundService(
                this,
                intent
            )

            true

        } catch (e: Exception) {

            Log.e(
                TAG,
                "FloatingMenuService start failed",
                e
            )

            false
        }
    }

    private fun openCookieRun() {

        val launchIntent =
            packageManager
                .getLaunchIntentForPackage(
                    GAME_PACKAGE
                )

        if (
            launchIntent ==
            null
        ) {

            setStatus(
                "#F87171",
                tr(
                    "ไม่พบ Cookie Run",
                    "Cookie Run not found"
                )
            )

            Toast.makeText(
                this,
                tr(
                    "ยังไม่ได้ติดตั้ง Cookie Run",
                    "Cookie Run is not installed"
                ),
                Toast.LENGTH_LONG
            ).show()

            return
        }

        launchIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK
        )

        startActivity(
            launchIntent
        )
    }

    private fun setStatus(
        color: String,
        text: String
    ) {

        statusDot.setTextColor(
            Color.parseColor(
                color
            )
        )

        statusText.text =
            text
    }

    private fun hideKeyboard() {

        val manager =
            getSystemService(
                Context.INPUT_METHOD_SERVICE
            ) as InputMethodManager

        currentFocus?.let { view ->

            manager.hideSoftInputFromWindow(
                view.windowToken,
                0
            )

            view.clearFocus()
        }
    }

    override fun onDestroy() {

        licenseExecutor.shutdownNow()
        rootExecutor.shutdownNow()

        super.onDestroy()
    }

}
