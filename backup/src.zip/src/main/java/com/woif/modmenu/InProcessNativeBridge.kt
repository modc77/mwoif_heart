package com.woif.modmenu

import android.content.Context
import android.util.Log
import java.io.File

/**
 * ARM64 native bridge loaded inside the CookieRun process by the LSPosed entry.
 *
 * MuMu runs CookieRun's ARM64 libgame through its configured native bridge
 * (libnb.so).  We therefore deliberately load the module's ARM64 libwoif.so
 * into the game process and let the native bridge execute the JNI call.  The
 * native side refuses APPLY/REMOVE unless it was compiled for AArch64.
 */
internal object InProcessNativeBridge {
    private const val TAG = "WOIF-IP-NATIVE"

    data class LoadResult(
        val ok: Boolean,
        val message: String
    )

    @Volatile
    private var loaded = false

    @Volatile
    private var loadMessage = "not loaded"

    @JvmStatic
    private external fun nativeArchitecture(): String

    @JvmStatic
    private external fun nativeApply(
        dispatcher: Long,
        character: Long,
        effectId: Int
    ): Int

    @JvmStatic
    private external fun nativeRemove(
        remover: Long,
        character: Long,
        effectId: Int
    ): Int

    @JvmStatic
    private external fun nativePowerFamily(
        managerGlobal: Long,
        nativeAdd: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        episodeKeys: IntArray,
        param3: Int
    ): Int

    @JvmStatic
    private external fun nativePowerImmediate(
        managerGlobal: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        character: Long,
        episodeKeys: IntArray,
        layout: LongArray
    ): Int

    @JvmStatic
    private external fun nativePreparePlay2Locator(): Int

    @JvmStatic
    private external fun nativeLocatePreRunScreen(): Int

    @JvmStatic
    private external fun nativePlay2CachedScreenBase(): Long

    @JvmStatic
    private external fun nativePlay2LocatorMatches(): Long

    @JvmStatic
    private external fun nativePlay2LocatorPrimaryHits(): Long

    @JvmStatic
    private external fun nativePlay2LocatorBestScore(): Int

    @JvmStatic
    private external fun nativePlay2LocatorBestBase(): Long

    @JvmStatic
    private external fun nativePlay2LocatorFingerprint(): String

    @JvmStatic
    private external fun nativePlay2LocatorScannedBytes(): Long

    @JvmStatic
    private external fun nativePlay2LocatorScannedRanges(): Long

    @JvmStatic
    private external fun nativePlay2CodeTrigger(): Int

    @JvmStatic
    private external fun nativePowderLocateTreasurePage(): Int
    @JvmStatic
    private external fun nativePowderPageDiagnostics(): String

    @JvmStatic
    private external fun nativePowderBuyBox1(): Int

    @JvmStatic
    private external fun nativePowderBuyBox1Burst(count: Int): Int

    @JvmStatic
    private external fun nativePowderBreakItem(item: Long): Int

    @JvmStatic
    private external fun nativePowderBreakBatch(items: LongArray, count: Int): Int

    @JvmStatic
    private external fun nativePowderForceReload(): Int

    private external fun nativePowderCleanup(): Int

    @JvmStatic
    private external fun nativeTowerState(): String

    @JvmStatic
    private external fun nativeTowerTestMissionSuccess(): String

    @JvmStatic
    private external fun nativeBoxLocateAction(actionId: Int): String

    @JvmStatic
    private external fun nativeBoxCallAction(actionId: Int): Int

    @JvmStatic
    private external fun nativeInitMember3ProbeSnapshot(): String

    @JvmStatic
    private external fun nativeHeartDsCryptoProfileSnapshot(): String

    @JvmStatic
    private external fun nativeHeartSendDsProbeSnapshot(): String

    @JvmStatic
    private external fun nativeHeartSendDsProbeReset(): String

    @JvmStatic
    private external fun nativeSessionStateSnapshot(includeSecret: Boolean): String

    @JvmStatic
    private external fun nativeAuthContextSnapshot(includeSecret: Boolean): String

    @JvmStatic
    private external fun nativeFgsIdSnapshot(): String

    fun loadArm64(context: Context, modulePath: String?): LoadResult {
        if (loaded) return LoadResult(true, loadMessage)

        val attempts = ArrayList<String>()
        val candidates = LinkedHashSet<String>()

        if (!modulePath.isNullOrBlank()) {
            val apk = File(modulePath)
            val installDir = apk.parentFile
            if (installDir != null) {
                candidates += File(installDir, "lib/arm64/libwoif.so").absolutePath
                candidates += File(installDir, "lib/arm64-v8a/libwoif.so").absolutePath
            }
            // Modern Android can dlopen an uncompressed/page-aligned .so directly
            // from an APK using the apk!/lib/<abi>/lib.so form.
            candidates += "$modulePath!/lib/arm64-v8a/libwoif.so"
        }

        // PackageManager fallback. This can be hidden by package-visibility
        // rules on some builds, hence modulePath is always preferred.
        try {
            val ai = context.packageManager.getApplicationInfo(BuildConfig.APPLICATION_ID, 0)
            candidates += File(ai.nativeLibraryDir, "libwoif.so").absolutePath
            val splitPaths = ai.splitSourceDirs ?: emptyArray()
            (arrayOf(ai.sourceDir) + splitPaths).forEach { path ->
                candidates += "$path!/lib/arm64-v8a/libwoif.so"
            }
        } catch (t: Throwable) {
            attempts += "pm:${t.javaClass.simpleName}:${t.message}"
        }

        for (path in candidates) {
            try {
                Log.i(TAG, "Trying ARM64 module native: $path")
                System.load(path)
                val abi = nativeArchitecture()
                if (abi != "arm64-v8a") {
                    loadMessage = "loaded wrong ABI=$abi from $path"
                    Log.e(TAG, loadMessage)
                    return LoadResult(false, loadMessage)
                }
                loaded = true
                loadMessage = "ARM64 native ready • $abi"
                Log.i(TAG, "$loadMessage • $path")
                return LoadResult(true, loadMessage)
            } catch (t: Throwable) {
                attempts += "${path.substringAfterLast('/')}:${t.javaClass.simpleName}:${t.message}"
            }
        }

        loadMessage = "ARM64 native load failed • ${attempts.takeLast(4).joinToString(" | ")}"
        Log.e(TAG, loadMessage)
        return LoadResult(false, loadMessage)
    }

    fun sessionStateSnapshot(includeSecret: Boolean): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeSessionStateSnapshot(includeSecret)
            val ok = report.contains("RESULT=READY")
            LoadResult(ok, report)
        } catch (t: Throwable) {
            LoadResult(
                false,
                "MWOIF_SESSION_STATE_V13\nRESULT=ERROR\nreason=JNI_FAILED\ndetail=${t.javaClass.simpleName}: ${t.message}\n"
            )
        }
    }

    fun authContextSnapshot(includeSecret: Boolean): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeAuthContextSnapshot(includeSecret)
            val ok = report.contains("RESULT=READY")
            LoadResult(ok, report)
        } catch (t: Throwable) {
            LoadResult(
                false,
                "MWOIF_AUTH_CONTEXT_V13_1\nRESULT=ERROR\nreason=JNI_FAILED\ndetail=${t.javaClass.simpleName}: ${t.message}\n"
            )
        }
    }

    fun fgsIdSnapshot(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val value = nativeFgsIdSnapshot().trim()
            LoadResult(value.isNotBlank(), value)
        } catch (_: Throwable) {
            LoadResult(false, "")
        }
    }

    fun statusText(): String = loadMessage

    fun apply(dispatcher: Long, character: Long, effectId: Int): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativeApply(dispatcher, character, effectId)
            if (rc == 0) LoadResult(true, "dispatcher returned • ID$effectId")
            else LoadResult(false, nativeError("apply", rc))
        } catch (t: Throwable) {
            LoadResult(false, "apply JNI failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    fun remove(remover: Long, character: Long, effectId: Int): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativeRemove(remover, character, effectId)
            if (rc == 0) LoadResult(true, "remover returned • ID$effectId")
            else LoadResult(false, nativeError("remove", rc))
        } catch (t: Throwable) {
            LoadResult(false, "remove JNI failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    fun powerFamily(
        managerGlobal: Long,
        nativeAdd: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        episodeKeys: IntArray,
        param3: Int
    ): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePowerFamily(
                managerGlobal,
                nativeAdd,
                nativeHas,
                nativeRefresh,
                episodeKeys,
                param3
            )
            when {
                rc > 0 -> LoadResult(
                    true,
                    "Power+ key=$rc • exact episode • add/refresh OK"
                )
                rc == 0 -> LoadResult(
                    false,
                    "NO_FAMILY_YET • game has not created a Power+ episode object"
                )
                else -> LoadResult(false, nativeError("power_family", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "power_family JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powerImmediate(
        managerGlobal: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        character: Long,
        episodeKeys: IntArray,
        layout: LongArray
    ): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePowerImmediate(
                managerGlobal,
                nativeHas,
                nativeRefresh,
                character,
                episodeKeys,
                layout
            )
            when {
                rc > 0 -> LoadResult(
                    true,
                    "Power+ key=$rc • exact episode • consumer immediate OK"
                )
                rc == 0 -> LoadResult(
                    false,
                    "NO_FAMILY_YET • game has not created a Power+ episode object"
                )
                rc == -16 -> LoadResult(
                    false,
                    "STATE_NOT_READY • GameEvent has not reached the safe consumer state"
                )
                else -> LoadResult(false, nativeError("power_immediate", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "power_immediate JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun preparePlay2Locator(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePreparePlay2Locator()
            if (rc == 0) {
                LoadResult(true, "PRE_RUN locator READY • V6 adaptive primary + semantic resolver validation")
            } else {
                LoadResult(false, nativeError("play2_prepare", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "play2_prepare JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun locatePlay2PreRunObject(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativeLocatePreRunScreen()
            val status = play2LocatorStatus()
            if (rc == 0) {
                LoadResult(true, "PRE_RUN OBJECT FOUND • $status")
            } else {
                LoadResult(false, "${nativeError("play2_locate", rc)} • $status")
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "play2_locate JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun play2LocatorStatus(): String {
        if (!loaded) return "locator native not loaded"
        return try {
            val screen = nativePlay2CachedScreenBase()
            val matches = nativePlay2LocatorMatches()
            val primaryHits = nativePlay2LocatorPrimaryHits()
            val bestScore = nativePlay2LocatorBestScore()
            val bestBase = nativePlay2LocatorBestBase()
            val scannedBytes = nativePlay2LocatorScannedBytes()
            val scannedRanges = nativePlay2LocatorScannedRanges()
            val fingerprint = nativePlay2LocatorFingerprint()
            val scannedMiB = scannedBytes.toDouble() / (1024.0 * 1024.0)
            "screenBase=${hex(screen)} matches=$matches primaryHits=$primaryHits " +
                "best=$bestScore/6 bestBase=${hex(bestBase)} " +
                "$fingerprint ranges=$scannedRanges " +
                "scannedMiB=${String.format(java.util.Locale.US, "%.1f", scannedMiB)}"
        } catch (t: Throwable) {
            "locator status failed: ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    fun play2CodeTrigger(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePlay2CodeTrigger()
            val locator = play2LocatorStatus()
            if (rc == 0) {
                LoadResult(true, "Play #2 native event dispatched • $locator")
            } else {
                LoadResult(false, "${nativeError("play2_code", rc)} • $locator")
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "play2_code JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderLocateTreasurePage(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePowderLocateTreasurePage()
            val diag = runCatching { nativePowderPageDiagnostics() }
                .getOrElse { "diag failed: ${it.javaClass.simpleName}: ${it.message}" }
            if (rc == 0) {
                LoadResult(true, "Treasure Shop page located • high-level BUY ready • $diag")
            } else {
                LoadResult(false, "${nativeError("powder_locate", rc)} • $diag")
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_locate JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderBuyBox1(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePowderBuyBox1()
            if (rc == 0) {
                LoadResult(true, "Powder Pump BUY Box1 dispatched")
            } else {
                LoadResult(false, nativeError("powder_buy", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_buy JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderBuyBox1Burst(count: Int): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        if (count !in 1..128) return LoadResult(false, "powder_buy_burst count invalid=$count")
        return try {
            val rc = nativePowderBuyBox1Burst(count)
            if (rc == count) {
                LoadResult(
                    true,
                    "Powder Pump BURST Box1 actions dispatched • count=$count"
                )
            } else {
                LoadResult(false, nativeError("powder_buy_burst", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_buy_burst JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderBuyBox1Burst10(): LoadResult = powderBuyBox1Burst(10)

    fun powderBreakItem(item: Long): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePowderBreakItem(item)
            if (rc == 0) {
                LoadResult(true, "Powder Pump BREAK dispatched • item=${hex(item)}")
            } else {
                LoadResult(false, nativeError("powder_break", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_break JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderBreakBatch(items: LongArray): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        if (items.isEmpty()) return LoadResult(false, "powder_batch_break empty items")
        return try {
            val rc = nativePowderBreakBatch(items, items.size)
            if (rc > 0) {
                LoadResult(true, "Powder Pump BATCH BREAK dispatched • count=$rc")
            } else {
                LoadResult(false, nativeError("powder_batch_break", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_batch_break JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderForceReload(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val rc = nativePowderForceReload()
            if (rc == 0) {
                LoadResult(true, "Powder Pump game-owned title/reload dispatched")
            } else {
                LoadResult(false, nativeError("powder_force_reload", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_force_reload JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun powderCleanup(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            when (val rc = nativePowderCleanup()) {
                0 -> LoadResult(
                    true,
                    "Powder Pump deferred retained processes released"
                )
                1 -> LoadResult(
                    true,
                    "Powder Pump BREAK retained for result-popup callback safety"
                )
                else -> LoadResult(false, nativeError("powder_cleanup", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "powder_cleanup JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun towerState(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeTowerState()
            LoadResult(
                report.contains("RESULT=OK"),
                report
            )
        } catch (t: Throwable) {
            LoadResult(
                false,
                "TOWER_STATE JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun towerTestMissionSuccess(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeTowerTestMissionSuccess()
            LoadResult(
                report.contains("RESULT=SUCCESS_STATE_SET"),
                report
            )
        } catch (t: Throwable) {
            LoadResult(
                false,
                "TOWER_TEST JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun boxLocateAction(actionId: Int): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        if (actionId !in 1..4) return LoadResult(false, "box action id invalid=$actionId")
        return try {
            val report = nativeBoxLocateAction(actionId)
            LoadResult(
                report.contains("RESULT=FOUND"),
                report
            )
        } catch (t: Throwable) {
            LoadResult(
                false,
                "BOX_LOCATE JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun boxCallAction(actionId: Int): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        if (actionId !in 1..4) return LoadResult(false, "box action id invalid=$actionId")
        return try {
            val rc = nativeBoxCallAction(actionId)
            if (rc == 0) {
                LoadResult(true, "Box action dispatched • id=$actionId")
            } else {
                LoadResult(false, nativeError("box_call[$actionId]", rc))
            }
        } catch (t: Throwable) {
            LoadResult(
                false,
                "BOX_CALL JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }



    fun initMember3ProbeSnapshot(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeInitMember3ProbeSnapshot()
            val ok =
                report.contains("RESULT=FOUND_INITMEMBER3") ||
                report.contains("RESULT=REQUEST_OBJECTS_FOUND")
            LoadResult(ok, report)
        } catch (t: Throwable) {
            LoadResult(
                false,
                "INITMEMBER3_PROBE JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun heartDsCryptoProfileSnapshot(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeHeartDsCryptoProfileSnapshot()
            LoadResult(report.contains("RESULT=FOUND"), report)
        } catch (t: Throwable) {
            LoadResult(
                false,
                "HEART_DS_CRYPTO_PROFILE JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun heartSendDsProbeSnapshot(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeHeartSendDsProbeSnapshot()
            val ok =
                report.contains("RESULT=FOUND_HEART_SEND") ||
                report.contains("RESULT=WAITING")
            LoadResult(ok, report)
        } catch (t: Throwable) {
            LoadResult(
                false,
                "HEART_SEND_DS_PROBE JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    fun heartSendDsProbeReset(): LoadResult {
        if (!loaded) return LoadResult(false, loadMessage)
        return try {
            val report = nativeHeartSendDsProbeReset()
            LoadResult(report.contains("RESULT=RESET"), report)
        } catch (t: Throwable) {
            LoadResult(
                false,
                "HEART_SEND_DS_PROBE reset JNI failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }
    }

    private fun hex(value: Long): String =
        if (value == 0L) "0x0" else "0x${value.toString(16).uppercase()}"

    private fun nativeError(op: String, rc: Int): String = when (rc) {
        -2 -> "$op refused • libwoif is not ARM64"
        -3 -> "$op refused • invalid address/effect id"
        -4 -> "$op refused • target address is not inside libgame.so"
        -5 -> "$op refused • PassiveManager not ready"
        -6 -> "$op refused • invalid episode-key family"
        -7 -> "$op refused • PassiveManager pointer is not mapped"
        -8 -> "$op refused • PassiveManager global/BSS is not mapped"
        -9 -> "$op refused • multiple natural Power+ episode keys are live"
        -10 -> "$op refused • immediate layout is invalid"
        -11 -> "$op refused • natural Power+ object was not found"
        -12 -> "$op refused • Character/GameEvent backref is invalid"
        -13 -> "$op refused • GameEvent vtable/consumer is invalid"
        -14 -> "$op refused • GameEvent vtable does not match the expected build profile"
        -15 -> "$op refused • Power+ object vtable does not match MysteryBox"
        -16 -> "$op waiting • GameEvent state is not ready"
        -17 -> "$op refused • GameEvent state pointer is invalid"
        -20 -> "$op refused • libgame ELF base was not resolved"
        -21 -> "$op refused • EventBus global/object is not ready"
        -23 -> "$op refused • PRE_RUN screenBase is not available"
        -24 -> "$op refused • PRE_RUN screen/context address is invalid"
        -25 -> "$op refused • raw Event 0x69 listener is not ready"
        -26 -> "$op refused • Play resolver global/object is not ready"
        -27 -> "$op refused • Play resolver +0x60 slot is invalid"
        -28 -> "$op refused • resolver returned an invalid Play snapshot"
        -29 -> "$op refused • Event 0x69 +0x4D8 slot is invalid"
        -30 -> "$op refused • EventBus cleanup/dispatch functions are invalid"
        -31 -> "$op refused • StageService says RUN is already active"
        -36 -> "$op refused • dynamic-cast function/typeinfo slots are invalid"
        -38 -> "$op refused • Event 0x69 dynamic-cast interface is invalid"
        -43 -> "$op waiting • no PRE_RUN primary candidate was found"
        -44 -> "$op refused • multiple exact PRE_RUN objects matched; selection is ambiguous"
        -47 -> "$op refused • multiple PRE_RUN primary candidates are live; selection is ambiguous"
        -45 -> "$op refused • PRE_RUN vptr profile does not match this libgame build"
        -46 -> "$op refused • /proc/self/maps could not be opened for PRE_RUN scan"
        -90 -> "$op refused • internal/Lab native build required"
        -100 -> "$op refused • ItemDB global is not mapped"
        -101 -> "$op waiting • ItemDB is not ready"
        -102 -> "$op refused • ItemDB category-list function is invalid"
        -103 -> "$op waiting • Treasure Box1 entry is not available"
        -104 -> "$op refused • Treasure Box1 entry pointer is invalid"
        -105 -> "$op refused • Treasure Box1 stuffSeq/price decode failed"
        -106 -> "$op refused • BUY process function profile is invalid"
        -107 -> "$op refused • BUY request capability check failed"
        -108 -> "$op refused • process start vtable slot is invalid"
        -109 -> "$op refused • previous BUY process is still retained"
        -110 -> "$op refused • Treasure item pointer is invalid"
        -111 -> "$op refused • item is not a type-27 Treasure"
        -112 -> "$op refused • BREAK process function profile is invalid"
        -113 -> "$op refused • previous BREAK process is still retained"
        -114 -> "$op refused • retained process release function is invalid"
        -115 -> "$op refused • native process allocation failed"
        -116 -> "$op refused • Treasure has no valid powder result config"
        -141 -> "$op refused • game-owned reload function unavailable"
        -120 -> "$op refused • Treasure Shop page vptr profile does not match this libgame build"
        -121 -> "$op refused • /proc/self/maps could not be opened for Treasure Shop scan"
        -122 -> "$op waiting • Treasure Shop page is not live; open the Treasure Shop page and retry"
        -123 -> "$op refused • multiple live Treasure Shop pages matched"
        -124 -> "$op waiting • Treasure Shop page exists but is not fully bound/ready"
        -125 -> "$op waiting • cached Treasure Shop page became stale"
        -126 -> "$op refused • high-level Box1 action function is invalid"
        -200 -> "$op refused • invalid Box action id/profile"
        -201 -> "$op waiting • Box action binding is not live yet"
        -202 -> "$op refused • multiple valid Box action bindings matched"
        -203 -> "$op refused • cached Box action is missing or stale"
        -204 -> "$op refused • cached Box action target/vtable changed"
        -205 -> "$op refused • Box action callback address is invalid"
        -206 -> "$op refused • Box action binding scan could not open /proc/self/maps"
        else -> "$op native rc=$rc"
    }
}
