package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Generic memory facade used by feature code.
 *
 * Actual privileged I/O is performed by RootMemoryWorker.
 */
class RootProcessMemory {

    data class MapEntry(
        val start: Long,
        val end: Long,
        val perms: String,
        val offset: Long,
        val path: String
    )

    fun requestRoot(
        context:
        Context
    ): Boolean {

        return RootMemoryClient
            .ensureStarted(
                context
            )
    }

    fun hasRoot():
            Boolean {

        return RootMemoryClient
            .isReady()
    }

    fun pidOf(
        packageName:
        String
    ): Int? {

        return RootMemoryClient
            .findPid(
                packageName
            )
            .takeIf {
                it >
                        0
            }
    }

    fun maps(
        pid:
        Int
    ): List<MapEntry> {

        return RootMemoryClient
            .maps(
                pid
            )
            .lineSequence()
            .mapNotNull {
                parseMapLine(
                    it
                )
            }
            .toList()
    }

    fun readBytes(
        pid:
        Int,
        address:
        Long,
        count:
        Int
    ): ByteArray? {

        if (
            count <=
            0 ||
            count >
            4096
        ) {
            return null
        }

        return RootMemoryClient
            .readBytes(
                pid,
                address,
                count
            )
    }

    fun writeBytes(
        pid:
        Int,
        address:
        Long,
        bytes:
        ByteArray
    ): Boolean {

        if (
            bytes.isEmpty() ||
            bytes.size >
            4096
        ) {
            return false
        }

        return RootMemoryClient
            .writeBytes(
                pid,
                address,
                bytes
            )
    }

    fun readLong(
        pid:
        Int,
        address:
        Long
    ): Long? {

        val bytes =
            readBytes(
                pid,
                address,
                8
            )
                ?: return null

        return ByteBuffer
            .wrap(
                bytes
            )
            .order(
                ByteOrder.LITTLE_ENDIAN
            )
            .long
    }

    fun readFloat(
        pid:
        Int,
        address:
        Long
    ): Float? {

        val bytes =
            readBytes(
                pid,
                address,
                4
            )
                ?: return null

        return ByteBuffer
            .wrap(
                bytes
            )
            .order(
                ByteOrder.LITTLE_ENDIAN
            )
            .float
    }

    fun readInt(
        pid:
        Int,
        address:
        Long
    ): Int? {

        val bytes =
            readBytes(
                pid,
                address,
                4
            )
                ?: return null

        return ByteBuffer
            .wrap(
                bytes
            )
            .order(
                ByteOrder.LITTLE_ENDIAN
            )
            .int
    }

    fun readByteUnsigned(
        pid:
        Int,
        address:
        Long
    ): Int? {

        val bytes =
            readBytes(
                pid,
                address,
                1
            )
                ?: return null

        if (
            bytes.isEmpty()
        ) {
            return null
        }

        return bytes[0]
            .toInt() and
                0xFF
    }

    fun writeFloat(
        pid:
        Int,
        address:
        Long,
        value:
        Float
    ): Boolean {

        val bytes =
            ByteBuffer
                .allocate(
                    4
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )
                .putFloat(
                    value
                )
                .array()

        return writeBytes(
            pid,
            address,
            bytes
        )
    }

    fun writeInt(
        pid:
        Int,
        address:
        Long,
        value:
        Int
    ): Boolean {

        val bytes =
            ByteBuffer
                .allocate(
                    4
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )
                .putInt(
                    value
                )
                .array()

        return writeBytes(
            pid,
            address,
            bytes
        )
    }

    fun startFloatLock(
        pid:
        Int,
        address:
        Long,
        value:
        Float,
        intervalMs:
        Int
    ): Boolean {

        return RootMemoryClient
            .startFloatLock(
                pid,
                address,
                value,
                intervalMs
            )
    }

    fun stopFloatLock():
            Boolean {

        return RootMemoryClient
            .stopLock()
    }

    fun readCString(
        pid:
        Int,
        address:
        Long,
        maximum:
        Int
    ): String? {

        if (
            maximum <=
            0 ||
            maximum >
            1024
        ) {
            return null
        }

        val result =
            ArrayList<Byte>(
                maximum
            )

        var offset =
            0

        while (
            offset <
            maximum
        ) {

            val chunk =
                readBytes(
                    pid,
                    address +
                            offset,
                    minOf(
                        32,
                        maximum -
                                offset
                    )
                )
                    ?: return null

            for (
            byte in
            chunk
            ) {

                if (
                    byte.toInt() ==
                    0
                ) {

                    return result
                        .toByteArray()
                        .toString(
                            Charsets.UTF_8
                        )
                }

                result.add(
                    byte
                )
            }

            offset +=
                chunk.size
        }

        return result
            .toByteArray()
            .toString(
                Charsets.UTF_8
            )
    }

    fun pause(
        pid:
        Int
    ): Boolean {

        return RootMemoryClient
            .signal(
                pid,
                19
            )
    }

    fun resume(
        pid:
        Int
    ): Boolean {

        return RootMemoryClient
            .signal(
                pid,
                18
            )
    }

    private fun parseMapLine(
        line:
        String
    ): MapEntry? {

        val parts =
            line.trim()
                .split(
                    Regex("\\s+"),
                    limit = 6
                )

        if (
            parts.size <
            5
        ) {
            return null
        }

        val range =
            parts[0]
                .split(
                    '-',
                    limit = 2
                )

        if (
            range.size !=
            2
        ) {
            return null
        }

        return MapEntry(
            start =
            range[0]
                .toLongOrNull(
                    16
                )
                ?: return null,

            end =
            range[1]
                .toLongOrNull(
                    16
                )
                ?: return null,

            perms =
            parts[1],

            offset =
            parts[2]
                .toLongOrNull(
                    16
                )
                ?: return null,

            path =
            if (
                parts.size >=
                6
            ) {
                parts[5]
            } else {
                ""
            }
        )
    }

    private fun ArrayList<Byte>
            .toByteArray():
            ByteArray {

        val result =
            ByteArray(
                size
            )

        for (
        index in
        indices
        ) {
            result[index] =
                this[index]
        }

        return result
    }
}
