package com.woif.modmenu

import android.app.Application
import android.app.Instrumentation
import android.content.Context
import android.opengl.GLSurfaceView
import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * V12 LSPosed entry for CookieRun.
 *
 * Changes from V11:
 * - writes a game-private diagnostic marker as soon as handleLoadPackage runs;
 * - installs the game-side bridge from multiple lifecycle points instead of
 *   relying only on Application.attach();
 * - keeps APPLY/REMOVE queued to the renderer/game thread.
 */
class XposedEntry : IXposedHookLoadPackage, IXposedHookZygoteInit {

    companion object {
        @Volatile private var modulePath: String? = null
        @Volatile private var lifecycleHooksInstalled = false
        @Volatile private var rendererDiscoveryHookInstalled = false
        @Volatile private var rendererHookInstalled = false
    }

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam) {
        modulePath = startupParam.modulePath
        XposedBridge.log("WOIF-CRG-V12: modulePath=${startupParam.modulePath}")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != CrgProfile.GAME_PACKAGE) return

        val dataDir = lpparam.appInfo?.dataDir
        InProcessGameControl.markInjectionStage(
            dataDir,
            "handleLoadPackage",
            "pkg=${lpparam.packageName} process=${lpparam.processName} internal=${BuildConfig.INTERNAL_BUILD}"
        )

        Log.i("WOIF-CRG", "V12 XposedEntry ACTIVE in ${lpparam.packageName} process=${lpparam.processName}")
        XposedBridge.log("WOIF-CRG-V12: CookieRun loaded process=${lpparam.processName}")

        if (!BuildConfig.GAME_EFFECT_BRIDGE_ENABLED) {
            InProcessGameControl.markInjectionStage(dataDir, "skip", "game effect bridge disabled")
            return
        }
        if (lpparam.processName != lpparam.packageName) {
            InProcessGameControl.markInjectionStage(dataDir, "skip", "non-main process=${lpparam.processName}")
            return
        }

        InProcessGameControl.setGameDataDir(dataDir)
        installRendererDiscovery(lpparam.classLoader)
        installLifecycleHooks()

        // Do not depend on AndroidAppHelper: it is not exposed by the Xposed API 82
        // compileOnly artifact used by this project. The game Context is obtained
        // from Application.attach()/Instrumentation lifecycle hooks below.
        InProcessGameControl.markInjectionStage(
            dataDir,
            "context",
            "waiting Application/Instrumentation lifecycle hook"
        )
    }

    private fun installRendererDiscovery(classLoader: ClassLoader) {
        synchronized(XposedEntry::class.java) {
            if (rendererDiscoveryHookInstalled) return
            rendererDiscoveryHookInstalled = true
        }

        InProcessGameControl.markInjectionStage(null, "renderer", "discovery armed")

        // Fast path for normal cocos2d-x builds.
        XposedHelpers.findClassIfExists(
            "org.cocos2dx.lib.Cocos2dxRenderer",
            classLoader
        )?.let { hookRendererClass(it, "Cocos2dxRenderer") }

        // Generic path: capture the exact renderer object passed by the game.
        try {
            XposedHelpers.findAndHookMethod(
                GLSurfaceView::class.java,
                "setRenderer",
                GLSurfaceView.Renderer::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val renderer = param.args[0] ?: return
                        InProcessGameControl.markInjectionStage(
                            null,
                            "renderer",
                            "setRenderer class=${renderer.javaClass.name}"
                        )
                        hookRendererClass(renderer.javaClass, renderer.javaClass.name)
                    }
                }
            )
            if (!rendererHookInstalled) {
                InProcessGameControl.markGameThreadHookReady(
                    false,
                    "renderer discovery armed • waiting GLSurfaceView.setRenderer"
                )
            }
            XposedBridge.log("WOIF-CRG-V12: GLSurfaceView renderer discovery armed")
        } catch (t: Throwable) {
            if (!rendererHookInstalled) {
                InProcessGameControl.markGameThreadHookReady(
                    false,
                    "renderer discovery failed: ${t.javaClass.simpleName}"
                )
            }
            InProcessGameControl.markInjectionStage(
                null,
                "renderer",
                "discovery failed=${t.javaClass.simpleName}:${t.message}"
            )
            XposedBridge.log("WOIF-CRG-V12: renderer discovery failed ${t.message}")
        }
    }

    private fun hookRendererClass(rendererClass: Class<*>, source: String) {
        synchronized(XposedEntry::class.java) {
            if (rendererHookInstalled) return

            var current: Class<*>? = rendererClass
            while (current != null && current != Any::class.java && !rendererHookInstalled) {
                val owner = current
                val hooks = try {
                    XposedBridge.hookAllMethods(
                        owner,
                        "onDrawFrame",
                        object : XC_MethodHook() {
                            override fun beforeHookedMethod(param: MethodHookParam) {
                                InProcessGameControl.drainGameThread()
                            }
                        }
                    )
                } catch (t: Throwable) {
                    XposedBridge.log("WOIF-CRG-V12: hook onDrawFrame failed ${owner.name} • ${t.message}")
                    emptySet()
                }

                if (hooks.isNotEmpty()) {
                    rendererHookInstalled = true
                    InProcessGameControl.markGameThreadHookReady(
                        true,
                        "$source -> ${owner.name}.onDrawFrame hooks=${hooks.size}"
                    )
                    XposedBridge.log(
                        "WOIF-CRG-V12: renderer queue READY $source -> ${owner.name} hooks=${hooks.size}"
                    )
                    return
                }
                current = current.superclass
            }
        }
    }

    private fun installLifecycleHooks() {
        synchronized(XposedEntry::class.java) {
            if (lifecycleHooksInstalled) return
            lifecycleHooksInstalled = true
        }

        InProcessGameControl.markInjectionStage(null, "lifecycle", "arming Application.attach + Instrumentation.callApplicationOnCreate")

        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "attach",
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val context = param.args[0] as? Context ?: return
                        InProcessGameControl.markInjectionStage(null, "Application.attach", "hit")
                        InProcessGameControl.installGameSide(
                            context.applicationContext,
                            modulePath,
                            "Application.attach"
                        )
                    }
                }
            )
        } catch (t: Throwable) {
            InProcessGameControl.markInjectionStage(
                null,
                "Application.attach",
                "hook failed=${t.javaClass.simpleName}:${t.message}"
            )
        }

        try {
            XposedHelpers.findAndHookMethod(
                Instrumentation::class.java,
                "callApplicationOnCreate",
                Application::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val application = param.args[0] as? Application ?: return
                        InProcessGameControl.markInjectionStage(null, "callApplicationOnCreate", "hit")
                        InProcessGameControl.installGameSide(
                            application.applicationContext,
                            modulePath,
                            "Instrumentation.callApplicationOnCreate"
                        )
                    }
                }
            )
        } catch (t: Throwable) {
            InProcessGameControl.markInjectionStage(
                null,
                "callApplicationOnCreate",
                "hook failed=${t.javaClass.simpleName}:${t.message}"
            )
        }
    }
}
