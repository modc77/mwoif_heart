package com.woif.modmenu

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/**
 * Lightweight image matcher for BOT LAB route checkpoints.
 *
 * It intentionally samples stable UI bands instead of the animated centre of the
 * game screen. A checkpoint is therefore useful for menus/result screens while
 * still tolerating some animation in the play field.
 */
class BotImageStateDetector(private val context: Context) {

    companion object {
        private const val SAMPLE_COLUMNS = 56
        private const val BAND_ROWS = 10
        private const val MAX_SCREENSHOT_BYTES = 16 * 1024 * 1024
    }

    private val rootDir = File(context.filesDir, "bot_lab_route_refs").apply { mkdirs() }
    private val signatureCache = HashMap<String, IntArray>()

    fun saveCheckpoint(slotRaw: String, checkpointId: Int, png: ByteArray): Boolean {
        val slot = normalizeSlot(slotRaw) ?: return false
        if (checkpointId <= 0 || png.isEmpty() || png.size > MAX_SCREENSHOT_BYTES) return false

        val bitmap = BitmapFactory.decodeByteArray(png, 0, png.size) ?: return false
        val signature = try {
            signature(bitmap)
        } finally {
            bitmap.recycle()
        }

        val file = checkpointFile(slot, checkpointId)
        return try {
            FileOutputStream(file).use { it.write(png) }
            signatureCache[file.absolutePath] = signature
            true
        } catch (_: Exception) {
            false
        }
    }

    fun compareCheckpoint(slotRaw: String, checkpointId: Int, png: ByteArray): Float {
        val slot = normalizeSlot(slotRaw) ?: return 0f
        if (checkpointId <= 0 || png.isEmpty() || png.size > MAX_SCREENSHOT_BYTES) return 0f

        val bitmap = BitmapFactory.decodeByteArray(png, 0, png.size) ?: return 0f
        val current = try {
            signature(bitmap)
        } finally {
            bitmap.recycle()
        }
        val ref = referenceSignature(slot, checkpointId) ?: return 0f
        return similarity(current, ref)
    }

    fun bestMatch(
        slotRaw: String,
        checkpoints: List<BotRouteCheckpoint>,
        png: ByteArray,
        minimumAfterTapIndex: Int = 0
    ): BotCheckpointMatch {
        val slot = normalizeSlot(slotRaw) ?: return BotCheckpointMatch(null, 0f)
        if (png.isEmpty() || png.size > MAX_SCREENSHOT_BYTES) {
            return BotCheckpointMatch(null, 0f)
        }

        val bitmap = BitmapFactory.decodeByteArray(png, 0, png.size)
            ?: return BotCheckpointMatch(null, 0f)
        val current = try {
            signature(bitmap)
        } finally {
            bitmap.recycle()
        }

        var bestCheckpoint: BotRouteCheckpoint? = null
        var bestScore = 0f
        checkpoints.forEach { checkpoint ->
            if (checkpoint.afterTapIndex < minimumAfterTapIndex) return@forEach
            val ref = referenceSignature(slot, checkpoint.id) ?: return@forEach
            val score = similarity(current, ref)
            if (score > bestScore) {
                bestScore = score
                bestCheckpoint = checkpoint
            }
        }
        return BotCheckpointMatch(bestCheckpoint, bestScore)
    }

    fun hasCheckpoint(slotRaw: String, checkpointId: Int): Boolean {
        val slot = normalizeSlot(slotRaw) ?: return false
        return checkpointFile(slot, checkpointId).isFile
    }

    fun clearRoute(slotRaw: String) {
        val slot = normalizeSlot(slotRaw) ?: return
        rootDir.listFiles()?.forEach { file ->
            if (file.name.startsWith("route_${slot}_cp_")) {
                signatureCache.remove(file.absolutePath)
                try { file.delete() } catch (_: Exception) { }
            }
        }
    }

    fun pruneRoute(slotRaw: String, keepIds: Set<Int>) {
        val slot = normalizeSlot(slotRaw) ?: return
        rootDir.listFiles()?.forEach { file ->
            if (!file.name.startsWith("route_${slot}_cp_")) return@forEach
            val id = file.name.substringAfterLast("_").substringBefore(".").toIntOrNull()
            if (id == null || id !in keepIds) {
                signatureCache.remove(file.absolutePath)
                try { file.delete() } catch (_: Exception) { }
            }
        }
    }

    private fun referenceSignature(slot: String, checkpointId: Int): IntArray? {
        val file = checkpointFile(slot, checkpointId)
        signatureCache[file.absolutePath]?.let { return it }
        if (!file.isFile) return null

        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return null
        val value = try {
            signature(bitmap)
        } finally {
            bitmap.recycle()
        }
        signatureCache[file.absolutePath] = value
        return value
    }

    private fun signature(bitmap: Bitmap): IntArray {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val output = IntArray(SAMPLE_COLUMNS * BAND_ROWS * 2 * 3)
        var outIndex = 0

        fun sampleBand(fromTop: Boolean) {
            for (row in 0 until BAND_ROWS) {
                val normalizedY = (row + 0.5f) / BAND_ROWS.toFloat()
                val sourceY = if (fromTop) {
                    (normalizedY * height * 0.32f).toInt()
                } else {
                    (height * 0.68f + normalizedY * height * 0.32f).toInt()
                }.coerceIn(0, height - 1)

                for (column in 0 until SAMPLE_COLUMNS) {
                    val normalizedX = 0.08f +
                        ((column + 0.5f) / SAMPLE_COLUMNS.toFloat()) * 0.84f
                    val sourceX = (normalizedX * width).toInt().coerceIn(0, width - 1)
                    val pixel = bitmap.getPixel(sourceX, sourceY)
                    output[outIndex++] = (pixel shr 16) and 0xFF
                    output[outIndex++] = (pixel shr 8) and 0xFF
                    output[outIndex++] = pixel and 0xFF
                }
            }
        }

        sampleBand(true)
        sampleBand(false)
        return output
    }

    private fun similarity(a: IntArray, b: IntArray): Float {
        if (a.size != b.size || a.isEmpty()) return 0f
        var total = 0L
        for (index in a.indices) total += abs(a[index] - b[index])
        val mean = total.toDouble() / a.size.toDouble()
        return (1.0 - mean / 255.0).toFloat().coerceIn(0f, 1f)
    }

    private fun checkpointFile(slot: String, checkpointId: Int): File =
        File(rootDir, "route_${slot}_cp_${checkpointId}.png")

    private fun normalizeSlot(value: String): String? {
        val slot = value.trim().uppercase()
        return slot.takeIf { it in BotRouteStore.SLOTS }
    }
}
