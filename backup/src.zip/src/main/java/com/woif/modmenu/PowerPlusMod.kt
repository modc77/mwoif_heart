package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Power+ V17 desired-state controller.
 *
 * Internal/Lab path:
 * - ON can be requested in Lobby/loading.
 * - Probe immediately when a live Stage Character appears.
 * - Discover the episode from the Power+ family object created by the game itself.
 * - Resolve the natural Power+ object for that exact key.
 * - Call the game-owned consumer immediately on CookieRun's hooked game thread.
 * - No duplicate passive, executable-code patch, or GameGuardian trampoline is used.
 * - A new Character/PID automatically creates a new stage generation.
 * - Once Power+ has been consumed/armed for a Character, OFF -> ON in the same
 *   Stage does NOT arm it again. The latch resets only on a real Stage/runtime edge.
 *
 * OFF is intentionally non-destructive: it only stops future adds. Existing
 * game-owned passive objects finish their normal lifecycle.
 */
class PowerPlusMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val RECONCILE_MS = 50L
        private const val FAST_DISCOVERY_MS = 50L
        private const val DISCOVERY_WINDOW_MS = 1200L
        private const val GAME_EVENT_READY_WINDOW_MS = 3000L
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val bias: Long,
        val moduleStart: Long,
        val moduleEnd: Long,
        val managerGlobal: Long,
        val nativeAdd: Long,
        val nativeHas: Long,
        val nativeRefresh: Long,
        val stageServiceGlobal: Long
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var profile: PowerPlusProfile? = null
    @Volatile private var enabled = false
    @Volatile private var runtime: Runtime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var status = "ยังไม่ได้เปิด Power+"
    @Volatile private var currentCharacter = 0L
    @Volatile private var characterFirstSeenAt = 0L
    @Volatile private var armedCharacter = 0L
    @Volatile private var nextAttemptAt = 0L
    @Volatile private var stageGeneration = 0L

    fun cacheProfile(value: PowerPlusProfile): ActionResult {
        if (value.episodeKeys.size != 7 || value.episodeKeys.any { it <= 0 }) {
            return failure("PROFILE_KEYS_INVALID", "Power+ EP1–EP7 profile ไม่ครบ")
        }
        if (value.episodeKeys.toSet().size != value.episodeKeys.size) {
            return failure("PROFILE_KEYS_DUPLICATE", "Power+ episode keys ซ้ำ")
        }
        if (
            value.param3 <= 0 ||
            value.retryMs <= 0L ||
            value.commandTimeoutMs <= 0
        ) {
            return failure("PROFILE_RUNTIME_INVALID", "Power+ runtime profile ไม่ครบ")
        }
        if (
            value.imageBase <= 0L ||
            value.managerGlobal <= 0L ||
            value.nativeAddAddress <= 0L ||
            value.nativeHasAddress <= 0L ||
            value.nativeRefreshAddress <= 0L ||
            value.stageServiceGlobal <= 0L ||
            value.serviceCharacterOffset <= 0L ||
            value.characterGameEventBackrefOffset <= 0L ||
            value.gameEventBackrefSubtract <= 0L ||
            value.consumerSlotOffset <= 0L ||
            value.managerListSentinelOffset <= 0L ||
            value.managerListStartOffset <= 0L ||
            value.passiveNodePrevOffset <= 0L ||
            value.passiveNodeObjectOffset <= 0L ||
            value.passiveObjectConfigOffset <= 0L ||
            value.passiveConfigKeyOffset < 0L ||
            value.expectedGameEventVtableAddress <= 0L ||
            value.expectedPowerObjectVtableAddress <= 0L ||
            value.gameEventStateIndexOffset <= 0L ||
            value.gameEventStateArrayOffset <= 0L ||
            value.gameEventStateValueOffset < 0L ||
            value.gameEventReadyState <= 0
        ) {
            return failure("PROFILE_LAYOUT_INVALID", "Power+ profile layout ไม่ครบ")
        }

        profile = value
        ensureTask()
        if (!enabled) status = "Power+ พร้อม • กด ON ได้ทุกหน้า"
        return success("Secure Power+ Profile พร้อม")
    }

    fun enable(value: PowerPlusProfile, callback: (ActionResult) -> Unit) {
        val cached = cacheProfile(value)
        if (!cached.ok) {
            callback(cached)
            return
        }
        if (!BuildConfig.INTERNAL_BUILD) {
            callback(failure("INTERNAL_ONLY", "Power+ V17 ยังเปิดเฉพาะ Internal/Lab"))
            return
        }

        enabled = true
        // IMPORTANT: do not reset Stage tracking here. If Power+ already fired
        // for the current Character, re-enabling in the same Stage must remain
        // latched and must not consume/trigger Power+ a second time.
        status = "ON • พร้อม • รอ CookieRun / Stage"
        ensureTask()
        executor.execute {
            val result = reconcile(force = true)
            callback(result)
        }
    }

    fun disable(callback: (ActionResult) -> Unit) {
        enabled = false
        // Non-destructive disarm. Preserve currentCharacter/armedCharacter so
        // OFF -> ON in the SAME Stage cannot fire Power+ twice. A real new
        // Character/runtime edge resets/re-arms through reconcile().
        status = "OFF • Stage นี้ไม่ย้อนและไม่ยิง Power+ ซ้ำ"
        callback(success(status))
    }

    fun isEnabled(): Boolean = enabled

    fun statusText(): String = status

    fun shutdown() {
        enabled = false
        closed = true
        task?.cancel(false)
        task = null
        profile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleWithFixedDelay(
            { safeReconcile() },
            RECONCILE_MS,
            RECONCILE_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun safeReconcile() {
        try {
            reconcile(force = false)
        } catch (t: Throwable) {
            if (enabled) {
                status = "ON • Power+ retry • ${t.javaClass.simpleName}"
                DevConsole.log("PWR", "tick error ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private fun reconcile(force: Boolean): ActionResult {
        if (!enabled) return success(status)
        if (!BuildConfig.INTERNAL_BUILD) {
            status = "Power+ V17 ใช้ได้เฉพาะ Internal/Lab"
            return failure("INTERNAL_ONLY", status)
        }
        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POWER_PLUS)) {
            status = "ON • Power+ กำลังอัปเดต • รอ Server"
            return success(status)
        }

        val p = SecureProfileManager.getPowerPlus()
        if (p == null) {
            profile = null
            status = "ON • กำลังโหลด Secure Power+ Profile"
            return success(status)
        }
        if (profile !== p) profile = p

        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            status = "ON • รอสิทธิ์ Root"
            return success(status)
        }

        val rt = resolveRuntime(p)
        if (rt == null) {
            status = "ON • รอ CookieRun / libgame"
            resetStageTracking(resetRuntime = false)
            return success(status)
        }

        val character = resolveCharacter(rt, p)
        if (!isPointer(character)) {
            currentCharacter = 0L
            characterFirstSeenAt = 0L
            armedCharacter = 0L
            status = "ON • พร้อม • รอ Stage"
            return success(status)
        }

        val now = SystemClock.elapsedRealtime()
        if (character != currentCharacter) {
            currentCharacter = character
            characterFirstSeenAt = now
            armedCharacter = 0L
            nextAttemptAt = now
            stageGeneration += 1L
            status = "ON • พบ Stage ใหม่ • ตรวจ Power+ ทันที"
            DevConsole.log(
                "PWR",
                "stage#$stageGeneration char=0x${character.toString(16)} probe=IMMEDIATE"
            )
            // V17.2 deliberately continues in this same reconcile pass.
            // There is no fixed settle delay before the first native probe.
        }

        if (armedCharacter == character) {
            status = "ON • Stage นี้ใช้/ตรวจ Power+ แล้ว • รอ Stage ใหม่"
            return success(status)
        }

        if (!force && now < nextAttemptAt) return success(status)

        nextAttemptAt = now + p.retryMs
        status = "ON • ตรวจ Power+ ของ Episode ปัจจุบัน"

        val result = InProcessGameControl.powerImmediate(
            context = appContext,
            managerGlobal = rt.managerGlobal,
            nativeHas = rt.nativeHas,
            nativeRefresh = rt.nativeRefresh,
            character = character,
            episodeKeys = p.episodeKeys,
            layout = p.immediateLayout(rt.bias),
            timeoutMs = p.commandTimeoutMs.toLong()
        )

        return if (result.ok) {
            armedCharacter = character
            status = "ON • Power+ ทันที • ${result.message.substringAfter("Power+ ")}"
            DevConsole.log("PWR", "stage#$stageGeneration PASS • ${result.message}")
            success(status)
        } else if (result.message.contains("NO_FAMILY_YET")) {
            val elapsed = now - characterFirstSeenAt
            if (elapsed < DISCOVERY_WINDOW_MS) {
                nextAttemptAt = now + FAST_DISCOVERY_MS
                status = "ON • ตรวจ Power+ ตั้งแต่ต้น Stage • ${elapsed}ms"
                DevConsole.log(
                    "PWR",
                    "stage#$stageGeneration PROBE • no natural family yet • ${elapsed}ms"
                )
                success(status)
            } else {
                armedCharacter = character
                status = "ON • Episode นี้ไม่มี/ยังไม่เปิด Power+ • เล่นปกติ"
                DevConsole.log(
                    "PWR",
                    "stage#$stageGeneration NORMAL • no natural Power+ family within ${DISCOVERY_WINDOW_MS}ms"
                )
                success(status)
            }
        } else if (result.message.contains("STATE_NOT_READY")) {
            val elapsed = now - characterFirstSeenAt
            if (elapsed < GAME_EVENT_READY_WINDOW_MS) {
                nextAttemptAt = now + FAST_DISCOVERY_MS
                status = "ON • Power+ พร้อม • รอ GameEvent state"
                DevConsole.log(
                    "PWR",
                    "stage#$stageGeneration WAIT_STATE • ${elapsed}ms • ${result.message}"
                )
            } else {
                armedCharacter = character
                status = "ON • Power+ safe-skip • GameEvent ยังไม่พร้อม"
                DevConsole.log(
                    "PWR",
                    "stage#$stageGeneration SAFE_SKIP • GameEvent state timeout ${GAME_EVENT_READY_WINDOW_MS}ms"
                )
            }
            success(status)
        } else {
            status = "ON • Power+ retry • ${result.message}"
            DevConsole.log("PWR", "stage#$stageGeneration RETRY • ${result.message}")
            success(status)
        }
    }

    private fun resolveRuntime(p: PowerPlusProfile): Runtime? {
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE) ?: run {
            runtime = null
            return null
        }
        val maps = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (maps.isEmpty()) {
            runtime = null
            return null
        }

        val moduleStart = maps.minOf { it.start }
        val moduleEnd = maps.maxOf { it.end }
        val bias = moduleStart - p.imageBase
        val current = runtime
        if (current != null && current.pid == pid && current.bias == bias) {
            return current
        }

        resetStageTracking(resetRuntime = false)
        return Runtime(
            pid = pid,
            bias = bias,
            moduleStart = moduleStart,
            moduleEnd = moduleEnd,
            managerGlobal = bias + p.managerGlobal,
            nativeAdd = bias + p.nativeAddAddress,
            nativeHas = bias + p.nativeHasAddress,
            nativeRefresh = bias + p.nativeRefreshAddress,
            stageServiceGlobal = bias + p.stageServiceGlobal
        ).also {
            runtime = it
            DevConsole.log(
                "PWR",
                "runtime pid=$pid bias=0x${bias.toString(16)} add=0x${it.nativeAdd.toString(16)} refresh=0x${it.nativeRefresh.toString(16)}"
            )
        }
    }

    private fun resolveCharacter(rt: Runtime, p: PowerPlusProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun resetStageTracking(resetRuntime: Boolean) {
        currentCharacter = 0L
        characterFirstSeenAt = 0L
        armedCharacter = 0L
        nextAttemptAt = 0L
        if (resetRuntime) runtime = null
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun success(message: String) = ActionResult(true, null, message)

    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
