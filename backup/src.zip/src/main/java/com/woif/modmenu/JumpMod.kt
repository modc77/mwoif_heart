package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Unlimited Jump desired-state controller (f10_v1).
 *
 * Lua/runtime verified action sequence:
 *   Ground/Ready -> Jump #1 -> Jump #2 -> landing -> Ground/Ready
 *
 * CookieRun rejects the next normal jump after Jump #2. This controller lets
 * Jump #2 enter normally first, then rewrites only the current action-ring
 * slot from Jump #2 to Jump #1. The next button press therefore follows the
 * game's original Jump #1 -> Jump #2 transition again.
 *
 * No Y/velocity/physics value is written and no treasure/passive is required.
 */
class JumpMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val TICK_MS = 10L
        private const val PROCESS_RECHECK_TICKS = 50
        private const val CHARACTER_RECHECK_MS = 250L
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val stageServiceGlobal: Long,
        val groundAction: Long,
        val jump1Action: Long,
        val jump2Action: Long
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var profile: JumpProfile? = null
    @Volatile private var runtime: Runtime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var enabled = false
    @Volatile private var status = "Unlimited Jump • ยังไม่ได้เปิด"
    @Volatile private var tickCounter = 0
    @Volatile private var nextResolveAt = 0L

    private var character = 0L
    private var nextCharacterResolveAt = 0L
    private var resetCount = 0
    private var writeErrors = 0

    fun cacheProfile(value: JumpProfile): ActionResult {
        if (
            value.imageBase <= 0L ||
            value.stageServiceGlobal <= value.imageBase ||
            value.serviceCharacterOffset < 0L ||
            value.serviceJellyManagerOffset < 0L ||
            value.jellyManagerCharacterOffset < 0L ||
            value.actionRingOffset <= 0L ||
            value.actionRingIndexOffset <= value.actionRingOffset ||
            value.actionRingSize !in 1..16 ||
            value.groundActionStatic <= value.imageBase ||
            value.jump1ActionStatic <= value.imageBase ||
            value.jump2ActionStatic <= value.imageBase ||
            value.groundVtableStatic <= value.imageBase ||
            value.jump1VtableStatic <= value.imageBase ||
            value.jump2VtableStatic <= value.imageBase ||
            value.groundActionStatic == value.jump1ActionStatic ||
            value.jump1ActionStatic == value.jump2ActionStatic
        ) {
            return failure("PROFILE_INVALID", "Unlimited Jump Secure Profile ไม่ครบ")
        }

        profile = value
        runtime = null
        character = 0L
        nextResolveAt = 0L
        nextCharacterResolveAt = 0L
        if (!enabled) status = "Unlimited Jump พร้อม • เปิด ON ได้ทุกหน้า"
        return success("Secure Unlimited Jump Profile พร้อม")
    }

    fun setEnabled(enable: Boolean, callback: (ActionResult) -> Unit) {
        enabled = enable
        executor.execute {
            if (enable) {
                status = "Unlimited Jump ON • รอ CookieRun / Stage"
                ensureTask()
                safeTick()
            } else {
                stopTask()
                clearRuntime()
                status = "Unlimited Jump OFF"
            }
            callback(success(status))
        }
    }

    fun isEnabled(): Boolean = enabled
    fun statusText(): String = status

    fun disableBlockingBestEffort() {
        enabled = false
        stopTask()
        clearRuntime()
        status = "Unlimited Jump OFF"
    }

    fun shutdown() {
        try {
            disableBlockingBestEffort()
        } catch (_: Exception) {
        }
        closed = true
        profile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleAtFixedRate(
            { safeTick() },
            TICK_MS,
            TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun stopTask() {
        task?.cancel(false)
        task = null
    }

    private fun safeTick() {
        try {
            tick()
        } catch (t: Throwable) {
            if (enabled) status = "Unlimited Jump ON • retry • ${t.javaClass.simpleName}"
            DevConsole.log("JUMP", "tick ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun tick() {
        if (!enabled) return

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_UNLIMITED_JUMP)) {
            status = "Unlimited Jump ON • กำลังอัปเดต • รอ Server"
            return
        }

        tickCounter += 1
        var rt = runtime
        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) return
            nextResolveAt = now + 1000L

            val prepared = prepareRuntime()
            if (!prepared.ok) {
                status = when (prepared.errorCode) {
                    "ROOT_REQUIRED" -> "Unlimited Jump ON • รอ Root Worker"
                    "PROFILE_NOT_READY" -> "Unlimited Jump ON • รอ Secure Profile"
                    "GAME_NOT_RUNNING" -> "Unlimited Jump ON • รอ CookieRun"
                    "ACTION_LAYOUT_MISMATCH" -> "Unlimited Jump ON • Profile ไม่ตรงเกม"
                    else -> "Unlimited Jump ON • กำลังจับ runtime ใหม่"
                }
                return
            }
            rt = runtime ?: return
        }

        if (tickCounter % PROCESS_RECHECK_TICKS == 0) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                clearRuntime()
                nextResolveAt = 0L
                status = if (livePid == null) {
                    "Unlimited Jump ON • รอ CookieRun"
                } else {
                    "Unlimited Jump ON • พบเกมใหม่ • กำลังเชื่อม"
                }
                return
            }
        }

        val p = profile() ?: return
        val now = System.currentTimeMillis()
        if (!isPointer(character) || now >= nextCharacterResolveAt) {
            character = resolveCharacter(rt, p)
            nextCharacterResolveAt = now + CHARACTER_RECHECK_MS
        }

        if (!isPointer(character)) {
            status = "Unlimited Jump ON • พร้อม • รอ Stage"
            return
        }

        val index = memory.readInt(rt.pid, character + p.actionRingIndexOffset)
            ?: return
        if (index !in 0 until p.actionRingSize) {
            status = "Unlimited Jump ON • Action index ไม่ถูกต้อง"
            character = 0L
            return
        }

        val slot = character + p.actionRingOffset + index.toLong() * 8L
        val action = memory.readLong(rt.pid, slot) ?: return
        if (action != rt.jump2Action) {
            status = "Unlimited Jump ON • Native • Reset $resetCount ครั้ง"
            return
        }

        // Freeze only at the exact Jump2 -> Jump1 rewrite. This is not a
        // permanent process lock; it closes the ring-index race between the
        // read and the single 8-byte write.
        if (!memory.pause(rt.pid)) {
            writeErrors += 1
            status = "Unlimited Jump ON • retry pause"
            return
        }

        try {
            val pausedIndex = memory.readInt(rt.pid, character + p.actionRingIndexOffset)
                ?: return
            if (pausedIndex !in 0 until p.actionRingSize) return

            val pausedSlot = character + p.actionRingOffset + pausedIndex.toLong() * 8L
            if (memory.readLong(rt.pid, pausedSlot) != rt.jump2Action) return

            if (!writeLong(rt.pid, pausedSlot, rt.jump1Action)) {
                writeErrors += 1
                status = "Unlimited Jump ON • Write fail $writeErrors"
                return
            }

            if (memory.readLong(rt.pid, pausedSlot) != rt.jump1Action) {
                writeErrors += 1
                status = "Unlimited Jump ON • Verify fail $writeErrors"
                return
            }

            resetCount += 1
            status = "Unlimited Jump ON • Native • Reset $resetCount ครั้ง"
            DevConsole.log(
                "JUMP",
                "reset#$resetCount char=0x${character.toString(16)} slot=0x${pausedSlot.toString(16)}"
            )
        } finally {
            memory.resume(rt.pid)
        }
    }

    private fun prepareRuntime(): ActionResult {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ยังไม่มี Root Worker")
        }

        val p = profile() ?: return failure(
            "PROFILE_NOT_READY",
            "Secure Unlimited Jump Profile ยังไม่พร้อม"
        )
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: return failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return failure("LIBGAME_NOT_READY", "ยังไม่พบ libgame.so")

        val candidates = LinkedHashSet<Long>()
        for (range in ranges) {
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
            ?: return failure("ELF_NOT_FOUND", "หา ARM64 libgame ELF ไม่สำเร็จ")
        val loadBias = parseLoadBias(pid, elfBase)
            ?: return failure("LOAD_BIAS_FAILED", "หา libgame load bias ไม่สำเร็จ")

        fun rt(staticAddress: Long): Long = loadBias + (staticAddress - p.imageBase)

        val stageServiceGlobal = rt(p.stageServiceGlobal)
        val groundAction = rt(p.groundActionStatic)
        val jump1Action = rt(p.jump1ActionStatic)
        val jump2Action = rt(p.jump2ActionStatic)
        val groundVtable = rt(p.groundVtableStatic)
        val jump1Vtable = rt(p.jump1VtableStatic)
        val jump2Vtable = rt(p.jump2VtableStatic)

        if (
            !isPointer(stageServiceGlobal) ||
            !isPointer(groundAction) ||
            !isPointer(jump1Action) ||
            !isPointer(jump2Action)
        ) {
            return failure("RUNTIME_ADDRESS_FAILED", "คำนวณ Unlimited Jump runtime address ไม่สำเร็จ")
        }

        val layoutOk =
            memory.readLong(pid, groundAction) == groundVtable &&
                memory.readLong(pid, jump1Action) == jump1Vtable &&
                memory.readLong(pid, jump2Action) == jump2Vtable
        if (!layoutOk) {
            DevConsole.log(
                "JUMP",
                "layout mismatch ground=${memory.readLong(pid, groundAction)?.toString(16)} " +
                    "jump1=${memory.readLong(pid, jump1Action)?.toString(16)} " +
                    "jump2=${memory.readLong(pid, jump2Action)?.toString(16)}"
            )
            return failure("ACTION_LAYOUT_MISMATCH", "Unlimited Jump action layout ไม่ตรงเกม")
        }

        runtime = Runtime(
            pid = pid,
            stageServiceGlobal = stageServiceGlobal,
            groundAction = groundAction,
            jump1Action = jump1Action,
            jump2Action = jump2Action
        )
        character = 0L
        nextCharacterResolveAt = 0L
        DevConsole.log(
            "JUMP",
            "runtime pid=$pid bias=0x${loadBias.toString(16)} jump1=0x${jump1Action.toString(16)} jump2=0x${jump2Action.toString(16)}"
        )
        return success("Unlimited Jump runtime พร้อม")
    }

    private fun resolveCharacter(rt: Runtime, p: JumpProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun writeLong(pid: Int, address: Long, value: Long): Boolean {
        val bytes = ByteBuffer.allocate(8)
            .order(ByteOrder.LITTLE_ENDIAN)
            .putLong(value)
            .array()
        return memory.writeBytes(pid, address, bytes)
    }

    private fun profile(): JumpProfile? {
        val active = SecureProfileManager.getJump()
        if (active == null) {
            profile = null
            runtime = null
            return null
        }
        if (profile !== active) {
            profile = active
            runtime = null
            character = 0L
            nextResolveAt = 0L
            nextCharacterResolveAt = 0L
        }
        return active
    }

    private fun clearRuntime() {
        runtime = null
        character = 0L
        nextResolveAt = 0L
        nextCharacterResolveAt = 0L
    }

    private fun isPointer(value: Long): Boolean {
        return value >= 0x10000L && value < 0x0001000000000000L
    }

    private fun success(message: String): ActionResult {
        return ActionResult(true, null, message)
    }

    private fun failure(code: String, message: String): ActionResult {
        return ActionResult(false, code, message)
    }
}
