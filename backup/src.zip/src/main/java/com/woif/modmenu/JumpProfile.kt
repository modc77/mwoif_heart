package com.woif.modmenu

/**
 * Secure resolver profile for the base Character jump action state machine.
 *
 * Runtime verification established three native singleton actions:
 * Ground/Ready -> Jump #1 -> Jump #2. Unlimited Jump only rewrites the
 * currently-active Jump #2 ring slot back to Jump #1 after Jump #2 has
 * entered normally, so CookieRun keeps its own jump physics and animation.
 */
data class JumpProfile(
    val imageBase: Long,
    val stageServiceGlobal: Long,

    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,

    val actionRingOffset: Long,
    val actionRingIndexOffset: Long,
    val actionRingSize: Int,

    val groundActionStatic: Long,
    val jump1ActionStatic: Long,
    val jump2ActionStatic: Long,

    val groundVtableStatic: Long,
    val jump1VtableStatic: Long,
    val jump2VtableStatic: Long,

    val revision: String,
    val ttlSeconds: Int
)
