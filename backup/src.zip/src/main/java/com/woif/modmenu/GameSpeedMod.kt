package com.woif.modmenu

import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Game Speed V2 desired-state controller.
 *
 * ON is user intent, not a one-shot writer result. If CookieRun dies/restarts,
 * this controller keeps the desired speed armed, detects the new PID/runtime,
 * resolves the scheduler again and re-arms the root float writer automatically.
 */
class GameSpeedMod(
    private val memory: RootProcessMemory = RootProcessMemory()
) {

    companion object {
        private const val LOCK_INTERVAL_MS = 50
        private const val RECONCILE_MS = 300L
        private const val RESOLVE_RETRY_MS = 800L
    }

    data class ActionResult(
        val ok: Boolean,
        val currentValue: Float?,
        val errorCode: String?,
        val message: String
    )

    private data class ElfContext(
        val pid: Int,
        val elfBase: Long,
        val loadBias: Long
    )

    private data class Resolved(
        val pid: Int,
        val timeAddress: Long
    )

    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var enabled = false
    @Volatile private var desired = 1.0f
    @Volatile private var cached: Resolved? = null
    @Volatile private var activeLock: Resolved? = null
    @Volatile private var preparing = false
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var nextResolveAt = 0L
    @Volatile private var status = "OFF • x1"

    fun isPrepared(): Boolean = cached != null

    fun isEnabled(): Boolean = enabled

    fun statusText(): String = status

    fun prepareAsync(callback: ((ActionResult) -> Unit)? = null) {
        if (preparing) return
        preparing = true

        executor.execute {
            try {
                val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
                val current = cached

                if (
                    current != null &&
                    livePid == current.pid &&
                    memory.readFloat(current.pid, current.timeAddress) != null
                ) {
                    callback?.invoke(success(null, "Game Speed พร้อม"))
                    return@execute
                }

                cached = null
                activeLock = null

                val result = when {
                    !memory.hasRoot() ->
                        failure("ROOT_REQUIRED", "ยังไม่ได้รับสิทธิ์ Root")

                    SecureProfileManager.getGameSpeed() == null ->
                        failure("PROFILE_NOT_READY", "Secure Profile ยังไม่พร้อม")

                    livePid == null ->
                        failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

                    else -> {
                        val resolved = resolve()
                        if (resolved == null) {
                            failure("RESOLVE_FAILED", "หา Game Speed target ไม่สำเร็จ")
                        } else {
                            cached = resolved
                            success(null, "Game Speed พร้อม")
                        }
                    }
                }

                callback?.invoke(result)
            } finally {
                preparing = false
            }
        }
    }

    fun enable(speed: Float, callback: (ActionResult) -> Unit) {
        if (!validSpeed(speed)) {
            callback(failure("INVALID_SPEED", "Speed ไม่ถูกต้อง"))
            return
        }

        desired = speed
        enabled = true
        status = "ON x${format(speed)} • กำลังเชื่อมเกม"

        executor.execute {
            ensureTask()
            val result = reconcile(forceRestart = true)
            callback(result)
        }
    }

    fun setSpeed(speed: Float, callback: (ActionResult) -> Unit) {
        if (!validSpeed(speed)) {
            callback(failure("INVALID_SPEED", "Speed ไม่ถูกต้อง"))
            return
        }

        desired = speed

        if (!enabled) {
            callback(success(speed, "เลือก x${format(speed)}"))
            return
        }

        executor.execute {
            callback(reconcile(forceRestart = true))
        }
    }

    fun disable(callback: (ActionResult) -> Unit) {
        enabled = false
        desired = 1.0f

        executor.execute {
            stopTask()
            memory.stopFloatLock()
            activeLock = null

            val target = cached
            cached = null
            nextResolveAt = 0L

            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            val restored = if (target != null && livePid == target.pid) {
                memory.writeFloat(target.pid, target.timeAddress, 1.0f)
            } else {
                true
            }

            status = if (restored) "OFF • x1" else "OFF • Restore x1 ไม่สำเร็จ"

            callback(
                if (restored) success(1.0f, status)
                else failure("RESTORE_FAILED", status)
            )
        }
    }

    fun restoreBlockingBestEffort(): ActionResult {
        enabled = false
        desired = 1.0f
        stopTask()
        memory.stopFloatLock()
        activeLock = null

        val target = cached
        cached = null
        nextResolveAt = 0L

        val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
        if (target == null || livePid != target.pid) {
            status = "OFF • x1"
            return success(1.0f, status)
        }

        val ok = memory.writeFloat(target.pid, target.timeAddress, 1.0f)
        status = if (ok) "OFF • x1" else "OFF • Restore x1 ไม่สำเร็จ"

        return if (ok) success(1.0f, status)
        else failure("RESTORE_FAILED", status)
    }

    fun shutdown(restore: Boolean) {
        if (restore) {
            try { restoreBlockingBestEffort() } catch (_: Exception) {}
        } else {
            enabled = false
            stopTask()
            memory.stopFloatLock()
            activeLock = null
            cached = null
        }

        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (task != null) return
        task = executor.scheduleWithFixedDelay(
            { safeReconcile() },
            RECONCILE_MS,
            RECONCILE_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun stopTask() {
        task?.cancel(false)
        task = null
    }

    private fun safeReconcile() {
        if (!enabled) return
        try {
            reconcile(forceRestart = false)
        } catch (_: Exception) {
            status = "ON x${format(desired)} • กำลังเชื่อมใหม่"
        }
    }

    private fun reconcile(forceRestart: Boolean): ActionResult {
        if (!enabled) {
            status = "OFF • x1"
            return success(1.0f, status)
        }

        val speed = desired
        val armed = { message: String ->
            status = message
            success(speed, message)
        }

        if (!memory.hasRoot()) {
            clearRuntime(stopWriter = true)
            return armed("ON x${format(speed)} • รอ Root Worker")
        }

        if (SecureProfileManager.getGameSpeed() == null) {
            clearRuntime(stopWriter = true)
            return armed("ON x${format(speed)} • รอ Secure Profile")
        }

        val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
        if (livePid == null) {
            clearRuntime(stopWriter = true)
            return armed("ON x${format(speed)} • รอ CookieRun")
        }

        if (cached?.pid != livePid || activeLock?.pid != livePid) {
            if (cached != null || activeLock != null) {
                memory.stopFloatLock()
            }
            cached = null
            activeLock = null
        }

        var target = cached

        if (target != null) {
            val current = memory.readFloat(target.pid, target.timeAddress)
            if (current == null) {
                memory.stopFloatLock()
                target = null
                cached = null
                activeLock = null
            } else if (
                !forceRestart &&
                activeLock == target &&
                abs(current - speed) <= maxOf(0.02f, abs(speed) * 0.002f)
            ) {
                return armed("ON x${format(speed)} • ทำงาน")
            }
        }

        if (target == null) {
            val now = SystemClock.elapsedRealtime()
            if (!forceRestart && now < nextResolveAt) {
                return armed("ON x${format(speed)} • กำลังจับ runtime ใหม่")
            }

            nextResolveAt = now + RESOLVE_RETRY_MS
            target = resolve()
            if (target == null) {
                cached = null
                activeLock = null
                return armed("ON x${format(speed)} • กำลังจับ runtime ใหม่")
            }

            cached = target
        }

        memory.stopFloatLock()

        val started = memory.startFloatLock(
            pid = target.pid,
            address = target.timeAddress,
            value = speed,
            intervalMs = LOCK_INTERVAL_MS
        )

        if (!started) {
            activeLock = null
            cached = null
            nextResolveAt = SystemClock.elapsedRealtime() + RESOLVE_RETRY_MS
            return armed("ON x${format(speed)} • writer หลุด • กำลังเชื่อมใหม่")
        }

        activeLock = target
        return armed("ON x${format(speed)} • ทำงาน")
    }

    private fun clearRuntime(stopWriter: Boolean) {
        if (stopWriter && (cached != null || activeLock != null)) {
            memory.stopFloatLock()
        }
        cached = null
        activeLock = null
        nextResolveAt = 0L
    }

    private fun validSpeed(speed: Float): Boolean =
        speed >= 0.01f &&
            speed <= 1000.0f &&
            !speed.isNaN() &&
            !speed.isInfinite()

    private fun resolve():
            Resolved? {

        val profile =
            SecureProfileManager
                .getGameSpeed()
                ?: return null

        val context =
            resolveElfContext(
                profile
            )
                ?: return null

        val directorGlobal =
            runtimeFromStatic(
                context.loadBias,
                profile.a1,
                profile.a0
            )

        val director =
            memory.readLong(
                context.pid,
                directorGlobal
            )
                ?: return null

        if (
            director <
            0x10000L
        ) {
            return null
        }

        val scheduler =
            memory.readLong(
                context.pid,
                director +
                        profile.a2
            )
                ?: return null

        if (
            scheduler <
            0x10000L
        ) {
            return null
        }

        val vtableRuntime =
            memory.readLong(
                context.pid,
                scheduler
            )
                ?: return null

        val vtableStatic =
            staticFromRuntime(
                context.loadBias,
                vtableRuntime,
                profile.a0
            )

        if (
            vtableStatic !=
            profile.a4
        ) {
            return null
        }

        val typeInfo =
            memory.readLong(
                context.pid,
                vtableRuntime -
                        8L
            )
                ?: return null

        val typeName =
            memory.readLong(
                context.pid,
                typeInfo +
                        8L
            )
                ?: return null

        val rtti =
            memory.readCString(
                context.pid,
                typeName,
                128
            )
                ?: return null

        if (
            rtti !=
            profile.a6
        ) {
            return null
        }

        val updateRuntime =
            memory.readLong(
                context.pid,
                vtableRuntime +
                        5L *
                        8L
            )
                ?: return null

        val updateStatic =
            staticFromRuntime(
                context.loadBias,
                updateRuntime,
                profile.a0
            )

        if (
            updateStatic !=
            profile.a5
        ) {
            return null
        }

        val timeAddress =
            scheduler +
                    profile.a3

        val current =
            memory.readFloat(
                context.pid,
                timeAddress
            )
                ?: return null

        if (
            current.isNaN() ||
            current.isInfinite() ||
            current <
            0.001f ||
            current >
            2000f
        ) {
            return null
        }

        return Resolved(
            pid =
            context.pid,

            timeAddress =
            timeAddress
        )
    }

    private fun resolveElfContext(
        profile:
        GameSpeedProfile
    ): ElfContext? {

        val pid =
            memory.pidOf(
                CrgProfile
                    .GAME_PACKAGE
            )
                ?: return null

        val ranges =
            memory.maps(
                pid
            )
                .filter {
                    it.path
                        .contains(
                            "libgame.so"
                        )
                }

        if (
            ranges.isEmpty()
        ) {
            return null
        }

        val candidates =
            LinkedHashSet<Long>()

        for (
        range in
        ranges
        ) {

            candidates.add(
                range.start
            )

            if (
                range.offset >
                0L &&
                range.start >
                range.offset
            ) {

                candidates.add(
                    range.start -
                            range.offset
                )
            }
        }

        val elfBase =
            candidates
                .firstOrNull {
                    validateElf(
                        pid,
                        it
                    )
                }
                ?: return null

        val loadBias =
            parseLoadBias(
                pid,
                elfBase
            )
                ?: return null

        return ElfContext(
            pid =
            pid,

            elfBase =
            elfBase,

            loadBias =
            loadBias
        )
    }

    private fun validateElf(
        pid:
        Int,
        address:
        Long
    ): Boolean {

        val header =
            memory.readBytes(
                pid,
                address,
                0x40
            )
                ?: return false

        if (
            header.size <
            0x40
        ) {
            return false
        }

        val machine =
            ByteBuffer
                .wrap(
                    header,
                    0x12,
                    2
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )
                .short
                .toInt() and
                    0xFFFF

        return (
                header[0]
                    .toInt() and
                        0xFF
                ) ==
                0x7F &&
                (
                        header[1]
                            .toInt() and
                                0xFF
                        ) ==
                0x45 &&
                (
                        header[2]
                            .toInt() and
                                0xFF
                        ) ==
                0x4C &&
                (
                        header[3]
                            .toInt() and
                                0xFF
                        ) ==
                0x46 &&
                (
                        header[4]
                            .toInt() and
                                0xFF
                        ) ==
                2 &&
                machine ==
                0xB7
    }

    private fun parseLoadBias(
        pid:
        Int,
        elfBase:
        Long
    ): Long? {

        val header =
            memory.readBytes(
                pid,
                elfBase,
                0x40
            )
                ?: return null

        val buffer =
            ByteBuffer
                .wrap(
                    header
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )

        val phoff =
            buffer.getLong(
                0x20
            )

        val phentsize =
            buffer.getShort(
                0x36
            )
                .toInt() and
                    0xFFFF

        val phnum =
            buffer.getShort(
                0x38
            )
                .toInt() and
                    0xFFFF

        if (
            phoff <=
            0L ||
            phentsize <
            0x38 ||
            phnum <=
            0 ||
            phnum >
            256
        ) {
            return null
        }

        var selected:
                Long? =
            null

        for (
        index in
        0 until phnum
        ) {

            val entry =
                memory.readBytes(
                    pid,
                    elfBase +
                            phoff +
                            index.toLong() *
                            phentsize.toLong(),
                    phentsize
                )
                    ?: return null

            val ph =
                ByteBuffer
                    .wrap(
                        entry
                    )
                    .order(
                        ByteOrder.LITTLE_ENDIAN
                    )

            val type =
                ph.getInt(
                    0
                )

            if (
                type !=
                1
            ) {
                continue
            }

            val fileOffset =
                ph.getLong(
                    0x08
                )

            val vaddr =
                ph.getLong(
                    0x10
                )

            if (
                fileOffset ==
                0L
            ) {
                selected =
                    vaddr
                break
            }

            if (
                selected ==
                null
            ) {
                selected =
                    vaddr
            }
        }

        return elfBase -
                (
                        selected
                            ?: return null
                        )
    }

    private fun runtimeFromStatic(
        loadBias:
        Long,
        static:
        Long,
        imageBase:
        Long
    ): Long {

        return loadBias +
                (
                        static -
                                imageBase
                        )
    }

    private fun staticFromRuntime(
        loadBias:
        Long,
        runtime:
        Long,
        imageBase:
        Long
    ): Long {

        return imageBase +
                (
                        runtime -
                                loadBias
                        )
    }

    private fun format(
        value:
        Float
    ): String {

        return if (
            value ==
            value.toInt()
                .toFloat()
        ) {
            value.toInt()
                .toString()
        } else {
            value.toString()
        }
    }

    private fun success(
        current:
        Float?,
        message:
        String
    ): ActionResult {

        return ActionResult(
            true,
            current,
            null,
            message
        )
    }

    private fun failure(
        code:
        String,
        message:
        String
    ): ActionResult {

        return ActionResult(
            false,
            null,
            code,
            message
        )
    }
}
