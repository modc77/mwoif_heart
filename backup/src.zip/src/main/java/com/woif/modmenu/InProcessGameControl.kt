package com.woif.modmenu

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import java.io.File
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import org.json.JSONObject

/**
 * V12 Internal/Lab IPC between M Woif and the LSPosed code inside CookieRun.
 *
 * APPLY/REMOVE are still executed only from the hooked game/render thread.
 * V12 additionally writes a game-private diagnostic marker so the M Woif app
 * can distinguish LSPosed injection/lifecycle/native/scheduler failures from a
 * plain IPC timeout.
 */
internal object InProcessGameControl {
    private const val TAG = "WOIF-IP-CONTROL"
    private const val MARKER_NAME = "woif_v12_ip_status.txt"

    private const val OP_PING = "ping"
    private const val OP_APPLY = "apply"
    private const val OP_REMOVE = "remove"
    private const val OP_POWER_FAMILY = "power_family"
    private const val OP_POWER_IMMEDIATE = "power_immediate"
    private const val OP_PLAY2_PREPARE = "play2_prepare"
    private const val OP_PLAY2_LOCATE = "play2_locate"
    private const val OP_PLAY2_CODE = "play2_code"
    private const val OP_POWDER_LOCATE = "powder_locate"
    private const val OP_POWDER_BUY = "powder_buy"
    private const val OP_POWDER_BUY_BURST10 = "powder_buy_burst10"
    private const val OP_POWDER_BREAK = "powder_break"
    private const val OP_POWDER_BREAK_BATCH = "powder_break_batch"
    private const val OP_POWDER_CLEANUP = "powder_cleanup"
    private const val OP_POWDER_FORCE_RELOAD = "powder_force_reload"
    private const val OP_TOWER_STATE = "tower_state"
    private const val OP_TOWER_TEST_SUCCESS = "tower_test_success"
    private const val OP_BOX_LOCATE = "box_locate"
    private const val OP_BOX_CALL = "box_call"
    private const val OP_INITMEMBER3_PROBE = "initmember3_probe"
    private const val OP_HEART_DS_CRYPTO_PROFILE = "heart_ds_crypto_profile"
    private const val OP_HEART_SEND_DS_PROBE = "heart_send_ds_probe"
    private const val OP_HEART_SEND_DS_PROBE_RESET = "heart_send_ds_probe_reset"
    private const val OP_SESSION_STATE = "session_state"
    private const val OP_AUTH_CONTEXT = "auth_context"

    private const val EXTRA_TOKEN = "token"
    private const val EXTRA_OP = "op"
    private const val EXTRA_DISPATCHER = "dispatcher"
    private const val EXTRA_REMOVER = "remover"
    private const val EXTRA_CHARACTER = "character"
    private const val EXTRA_EFFECT_ID = "effect_id"
    private const val EXTRA_MANAGER_GLOBAL = "manager_global"
    private const val EXTRA_NATIVE_ADD = "native_add"
    private const val EXTRA_NATIVE_HAS = "native_has"
    private const val EXTRA_NATIVE_REFRESH = "native_refresh"
    private const val EXTRA_EPISODE_KEYS = "episode_keys"
    private const val EXTRA_PARAM3 = "param3"
    private const val EXTRA_POWER_LAYOUT = "power_layout"
    private const val EXTRA_POWDER_ITEM = "powder_item"
    private const val EXTRA_POWDER_ITEMS = "powder_items"
    private const val EXTRA_POWDER_COUNT = "powder_count"
    private const val EXTRA_OK = "ok"
    private const val EXTRA_MESSAGE = "message"

    data class Result(val ok: Boolean, val message: String)

    private data class GameCommand(
        val token: String,
        val op: String,
        val dispatcher: Long,
        val remover: Long,
        val character: Long,
        val effectId: Int,
        val managerGlobal: Long,
        val nativeAdd: Long,
        val nativeHas: Long,
        val nativeRefresh: Long,
        val episodeKeys: IntArray,
        val param3: Int,
        val powerLayout: LongArray,
        val powderItem: Long,
        val powderItems: LongArray,
        val powderCount: Int
    )

    private val pending = ConcurrentHashMap<String, CompletableFuture<Result>>()
    private val gameQueue = ConcurrentLinkedQueue<GameCommand>()
    private val markerLock = Any()

    @Volatile private var appReceiverRegistered = false
    @Volatile private var gameReceiverRegistered = false
    @Volatile private var gameThreadHookReady = false
    @Volatile private var lastGameStatus = "game bridge not pinged"
    @Volatile private var modulePath: String? = null
    @Volatile private var gameContext: Context? = null
    @Volatile private var gameDataDir: String? = null

    private fun commandAction(): String = "${BuildConfig.APPLICATION_ID}.INPROCESS_COMMAND_V12"
    private fun resultAction(): String = "${BuildConfig.APPLICATION_ID}.INPROCESS_RESULT_V12"

    fun setGameDataDir(dataDir: String?) {
        if (!dataDir.isNullOrBlank()) gameDataDir = dataDir
    }

    /** Called from the injected CookieRun process. */
    fun markInjectionStage(dataDir: String?, stage: String, detail: String) {
        if (!dataDir.isNullOrBlank()) gameDataDir = dataDir
        val root = gameDataDir ?: return
        try {
            val files = File(root, "files")
            if (!files.exists()) files.mkdirs()
            val marker = File(files, MARKER_NAME)
            val line = "+${android.os.SystemClock.elapsedRealtime()} pid=${android.os.Process.myPid()} stage=$stage • $detail\n"
            synchronized(markerLock) {
                if (stage == "handleLoadPackage") marker.writeText(line)
                else marker.appendText(line)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "marker write failed stage=$stage", t)
        }
    }

    fun markGameThreadHookReady(ready: Boolean, detail: String) {
        gameThreadHookReady = ready
        lastGameStatus = "scheduler=${if (ready) "READY" else "NOT_READY"} • $detail"
        markInjectionStage(null, "scheduler", lastGameStatus)
        Log.i(TAG, lastGameStatus)
    }


    private fun redactIpcMessageForLog(message: String): String =
        message
            .lineSequence()
            .filterNot { it.startsWith("authJson=") || it.startsWith("sessionJson=") }
            .map { line ->
                when {
                    line.startsWith("sessionKey=") -> "sessionKey=<REDACTED>"
                    line.startsWith("gameAccessToken=") -> "gameAccessToken=<REDACTED>"
                    else -> line
                }
            }
            .joinToString("\n")

    private fun gameOwnedMetadataSnapshot(context: Context, mid: String): JSONObject {
        val meta = JSONObject()
        meta.put("runtime-metadata-version", "V13.6.1")
        if (mid.isNotBlank()) meta.put("player-id", mid)

        runCatching {
            val pkg = context.packageManager.getPackageInfo(context.packageName, 0)
            if (!pkg.versionName.isNullOrBlank()) {
                meta.put("version", pkg.versionName)
            }
            val versionCode = pkg.longVersionCode
            if (versionCode > 0L) {
                meta.put("version-code", versionCode.toString())
            }
        }

        val timezone = TimeZone.getDefault().id.orEmpty()
        if (timezone.isNotBlank()) meta.put("timezone", timezone)

        val locale = Locale.getDefault()
        val country = locale.country.orEmpty()
        if (country.isNotBlank()) meta.put("country", country)

        meta.put("os.type", "A")
        val osVersion = Build.VERSION.RELEASE.orEmpty()
        if (osVersion.isNotBlank()) meta.put("os_version", osVersion)

        val localeTag = if (Build.VERSION.SDK_INT >= 21) locale.toLanguageTag() else locale.toString()
        if (localeTag.isNotBlank()) meta.put("locale", localeTag)

        val model = Build.MODEL.orEmpty()
        if (model.isNotBlank()) {
            meta.put("device-name", model)
            meta.put("device-model", model)
        }

        runCatching {
            val androidId = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ANDROID_ID
            ).orEmpty()
            if (androidId.isNotBlank()) meta.put("device-id", androidId)
        }

        // Exact game preference key recovered from the private-data snapshot.
        // This runs inside com.devsisters.crg, so no root/file copy is needed.
        runCatching {
            val prefs = context.getSharedPreferences(
                "Cocos2dxPrefsFile",
                Context.MODE_PRIVATE
            )
            val hash = prefs.getString("index_file_hash", "").orEmpty()
            if (hash.isNotBlank()) meta.put("index-file-hash", hash)
        }

        runCatching {
            val distanceSeconds =
                TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 1000
            meta.put("time-zone-distance", distanceSeconds.toString())
        }

        runCatching {
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            val processStartElapsed = android.os.Process.getStartElapsedRealtime()
            if (processStartElapsed > 0L && nowElapsed >= processStartElapsed) {
                meta.put(
                    "game-process-elapsed-ms",
                    (nowElapsed - processStartElapsed).toString()
                )
            }
        }

        runCatching {
            val fgs = InProcessNativeBridge.fgsIdSnapshot()
            if (fgs.ok && fgs.message.isNotBlank()) {
                meta.put("fgs-id", fgs.message)
            }
        }

        // 26.8.02 target is the Google Play build. Keep the native spelling.
        meta.put("market_type", "GOOGLE_PLAY")

        return meta
    }

    private fun enrichAuthReportWithGameMetadata(
        context: Context,
        report: String
    ): String {
        val lines = report.lines().toMutableList()
        val index = lines.indexOfFirst { it.startsWith("authJson=") }
        if (index < 0) return report

        val raw = lines[index].substringAfter("authJson=").trim()
        val obj = runCatching { JSONObject(raw) }.getOrNull() ?: return report
        val mid = obj.optString("mid", "")
        obj.put("metadata", gameOwnedMetadataSnapshot(context, mid))
        lines[index] = "authJson=${obj}"
        lines.add(index + 1, "runtimeMetadataVersion=V13.6.1")
        return lines.joinToString("\n").trimEnd() + "\n"
    }

    fun installGameSide(context: Context, moduleApkPath: String?, source: String) {
        if (!BuildConfig.GAME_EFFECT_BRIDGE_ENABLED) {
            markInjectionStage(null, "installGameSide", "refused: game effect bridge disabled source=$source")
            return
        }

        if (gameReceiverRegistered) {
            markInjectionStage(null, "installGameSide", "already ready source=$source")
            return
        }

        synchronized(this) {
            if (gameReceiverRegistered) {
                markInjectionStage(null, "installGameSide", "already ready after lock source=$source")
                return
            }

            modulePath = moduleApkPath
            gameContext = context.applicationContext
            setGameDataDir(context.applicationInfo.dataDir)
            markInjectionStage(
                null,
                "installGameSide",
                "source=$source modulePath=${moduleApkPath ?: "null"}"
            )

            val load = InProcessNativeBridge.loadArm64(context, moduleApkPath)
            lastGameStatus = "${if (gameThreadHookReady) "scheduler=READY" else "scheduler=NOT_READY"} • ${load.message}"
            markInjectionStage(null, "native", "ok=${load.ok} • ${load.message}")

            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action != commandAction()) return
                    val token = intent.getStringExtra(EXTRA_TOKEN) ?: return
                    val op = intent.getStringExtra(EXTRA_OP) ?: ""
                    val dispatcher = intent.getLongExtra(EXTRA_DISPATCHER, 0L)
                    val remover = intent.getLongExtra(EXTRA_REMOVER, 0L)
                    val character = intent.getLongExtra(EXTRA_CHARACTER, 0L)
                    val effectId = intent.getIntExtra(EXTRA_EFFECT_ID, 0)
                    val managerGlobal = intent.getLongExtra(EXTRA_MANAGER_GLOBAL, 0L)
                    val nativeAdd = intent.getLongExtra(EXTRA_NATIVE_ADD, 0L)
                    val nativeHas = intent.getLongExtra(EXTRA_NATIVE_HAS, 0L)
                    val nativeRefresh = intent.getLongExtra(EXTRA_NATIVE_REFRESH, 0L)
                    val episodeKeys = intent.getIntArrayExtra(EXTRA_EPISODE_KEYS) ?: intArrayOf()
                    val param3 = intent.getIntExtra(EXTRA_PARAM3, 0)
                    val powerLayout = intent.getLongArrayExtra(EXTRA_POWER_LAYOUT) ?: longArrayOf()
                    val powderItem = intent.getLongExtra(EXTRA_POWDER_ITEM, 0L)
                    val powderItems = intent.getLongArrayExtra(EXTRA_POWDER_ITEMS) ?: longArrayOf()
                    val powderCount = intent.getIntExtra(EXTRA_POWDER_COUNT, 10)

                    markInjectionStage(
                        null,
                        "command",
                        "recv op=$op id=$effectId scheduler=$gameThreadHookReady"
                    )

                    if (op == OP_PING) {
                        val reload = InProcessNativeBridge.loadArm64(ctx, modulePath)
                        val result = Result(
                            reload.ok && gameThreadHookReady,
                            "receiver=READY • scheduler=${if (gameThreadHookReady) "READY" else "NOT_READY"} • ${reload.message}"
                        )
                        lastGameStatus = result.message
                        sendResult(ctx, token, result)
                        return
                    }

                    if (
                        op != OP_APPLY &&
                        op != OP_REMOVE &&
                        op != OP_POWER_FAMILY &&
                        op != OP_POWER_IMMEDIATE &&
                        op != OP_PLAY2_PREPARE &&
                        op != OP_PLAY2_LOCATE &&
                        op != OP_PLAY2_CODE &&
                        op != OP_POWDER_LOCATE &&
                        op != OP_POWDER_BUY &&
                        op != OP_POWDER_BUY_BURST10 &&
                        op != OP_POWDER_BREAK &&
                        op != OP_POWDER_BREAK_BATCH &&
                        op != OP_POWDER_CLEANUP &&
                        op != OP_POWDER_FORCE_RELOAD &&
                        op != OP_TOWER_STATE &&
                        op != OP_TOWER_TEST_SUCCESS &&
                        op != OP_BOX_LOCATE &&
                        op != OP_BOX_CALL &&
                        op != OP_INITMEMBER3_PROBE &&
                        op != OP_HEART_DS_CRYPTO_PROFILE &&
                        op != OP_HEART_SEND_DS_PROBE &&
                        op != OP_HEART_SEND_DS_PROBE_RESET &&
                        op != OP_SESSION_STATE &&
                        op != OP_AUTH_CONTEXT
                    ) {
                        sendResult(ctx, token, Result(false, "unknown op=$op"))
                        return
                    }

                    // V5 PRE_RUN locating is read-only. Run it on a dedicated game-process
                    // worker instead of blocking CookieRun's render/game thread while scanning
                    // writable native mappings.
                    if (op == OP_PLAY2_LOCATE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.locatePlay2PreRunObject()
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(null, "locator", "result ok=${result.ok} • ${result.message}")
                            sendResult(appCtx, token, result)
                        }, "woif-pre-run-locator").start()
                        return
                    }

                    // Powder page discovery is READ ONLY and may scan native
                    // allocator arenas. Keep it off CookieRun's render thread.
                    if (op == OP_POWDER_LOCATE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.powderLocateTreasurePage()
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(
                                null,
                                "powderLocator",
                                "result ok=${result.ok} • ${result.message}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-powder-page-locator").start()
                        return
                    }

                    // Box action binding discovery scans writable native arenas.
                    // Keep the read-only locator off CookieRun's render/game thread.
                    if (op == OP_BOX_LOCATE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.boxLocateAction(effectId)
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(
                                null,
                                "boxLocator",
                                "action=$effectId ok=${result.ok} • ${result.message}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-box-action-locator").start()
                        return
                    }

                    // V13 established-session export.  This does not scan the request heap;
                    // it resolves the long-lived game state after the normal bootstrap.
                    // effectId=1 is used only for an explicit local clipboard export.
                    if (op == OP_SESSION_STATE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val includeSecret = effectId == 1
                            val r = InProcessNativeBridge.sessionStateSnapshot(includeSecret)
                            val result = Result(r.ok, r.message)
                            lastGameStatus =
                                "sessionState ok=${result.ok} secret=${if (includeSecret) "COPY" else "NO"}"
                            markInjectionStage(
                                null,
                                "sessionState",
                                "ok=${result.ok} secret=${if (includeSecret) "COPY" else "NO"}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-session-state-v13").start()
                        return
                    }

                    // V13.1 Friend/gRPC auth export.
                    // IMPORTANT: this runs inside the injected CookieRun process,
                    // not inside FloatingMenuService. Native calls the game's own
                    // FUN_00EB8EFC materializer; LAB never invokes +0x58/+0x60.
                    if (op == OP_AUTH_CONTEXT) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val includeSecret = effectId == 1
                            val r = InProcessNativeBridge.authContextSnapshot(includeSecret)
                            val message =
                                if (r.ok && includeSecret) {
                                    enrichAuthReportWithGameMetadata(appCtx, r.message)
                                } else {
                                    r.message
                                }
                            val result = Result(r.ok, message)
                            lastGameStatus =
                                "authContext ok=${result.ok} secret=${if (includeSecret) "COPY" else "NO"}"
                            markInjectionStage(
                                null,
                                "authContext",
                                "ok=${result.ok} source=GAME_OWNED_MATERIALIZER"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-auth-context-v13-1").start()
                        return
                    }

                    // initMember3 request-object discovery is READ ONLY.
                    // It scans native allocator arenas for the game's live HTTP request object
                    // and extracts printable endpoint/payload strings. Keep it off the renderer.
                    if (op == OP_INITMEMBER3_PROBE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.initMember3ProbeSnapshot()
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(
                                null,
                                "initMember3Probe",
                                "ok=${result.ok} • ${r.message.lineSequence().firstOrNull().orEmpty()}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-initmember3-probe").start()
                        return
                    }

                    if (op == OP_HEART_DS_CRYPTO_PROFILE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.heartDsCryptoProfileSnapshot()
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(
                                null,
                                "heartDsCryptoProfile",
                                "ok=${result.ok} • ${r.message.lineSequence().firstOrNull().orEmpty()}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-heart-ds-crypto-profile").start()
                        return
                    }

                    if (op == OP_HEART_SEND_DS_PROBE) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.heartSendDsProbeSnapshot()
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(
                                null,
                                "heartSendDsProbe",
                                "ok=${result.ok} • ${r.message.lineSequence().firstOrNull().orEmpty()}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-heart-send-ds-probe").start()
                        return
                    }

                    if (op == OP_HEART_SEND_DS_PROBE_RESET) {
                        val appCtx = ctx.applicationContext
                        Thread({
                            val r = InProcessNativeBridge.heartSendDsProbeReset()
                            val result = Result(r.ok, "game-process • ${r.message}")
                            lastGameStatus = result.message
                            markInjectionStage(
                                null,
                                "heartSendDsProbeReset",
                                "ok=${result.ok} • ${r.message.lineSequence().firstOrNull().orEmpty()}"
                            )
                            sendResult(appCtx, token, result)
                        }, "woif-heart-send-ds-probe-reset").start()
                        return
                    }

                    if (!gameThreadHookReady) {
                        sendResult(ctx, token, Result(false, "game-thread hook not ready"))
                        return
                    }

                    gameQueue.add(
                        GameCommand(
                            token = token,
                            op = op,
                            dispatcher = dispatcher,
                            remover = remover,
                            character = character,
                            effectId = effectId,
                            managerGlobal = managerGlobal,
                            nativeAdd = nativeAdd,
                            nativeHas = nativeHas,
                            nativeRefresh = nativeRefresh,
                            episodeKeys = episodeKeys,
                            param3 = param3,
                            powerLayout = powerLayout,
                            powderItem = powderItem,
                            powderItems = powderItems,
                            powderCount = powderCount
                        )
                    )
                    lastGameStatus = "queued $op ID$effectId • waiting game thread"
                    markInjectionStage(null, "queue", lastGameStatus)
                }
            }

            val filter = IntentFilter(commandAction())
            try {
                // V12 Lab intentionally removes the V11 signature-permission
                // gate. setPackage() + random token are enough for this internal
                // diagnostic path and this eliminates permission routing as an
                // IPC failure source on MuMu/Android 12.
                if (Build.VERSION.SDK_INT >= 33) {
                    context.registerReceiver(
                        receiver,
                        filter,
                        null,
                        Handler(Looper.getMainLooper()),
                        Context.RECEIVER_EXPORTED
                    )
                } else {
                    @Suppress("DEPRECATION")
                    context.registerReceiver(
                        receiver,
                        filter,
                        null,
                        Handler(Looper.getMainLooper())
                    )
                }
                gameReceiverRegistered = true
                markInjectionStage(null, "receiver", "READY action=${commandAction()} • $lastGameStatus")
                Log.i(TAG, "V12 game-side receiver ready action=${commandAction()} • $lastGameStatus")
            } catch (t: Throwable) {
                lastGameStatus = "receiver registration failed: ${t.javaClass.simpleName}: ${t.message}"
                markInjectionStage(null, "receiver", lastGameStatus)
                Log.e(TAG, lastGameStatus, t)
            }
        }
    }

    /** Called only from the hooked renderer/game thread. */
    fun drainGameThread() {
        if (!BuildConfig.GAME_EFFECT_BRIDGE_ENABLED || !gameThreadHookReady) return
        val context = gameContext ?: return

        repeat(4) {
            val cmd = gameQueue.poll() ?: return
            markInjectionStage(null, "gameThread", "drain ${cmd.op} ID${cmd.effectId}")
            val result = when (cmd.op) {
                OP_APPLY -> {
                    val r = InProcessNativeBridge.apply(cmd.dispatcher, cmd.character, cmd.effectId)
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_REMOVE -> {
                    val r = InProcessNativeBridge.remove(cmd.remover, cmd.character, cmd.effectId)
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWER_FAMILY -> {
                    val r = InProcessNativeBridge.powerFamily(
                        managerGlobal = cmd.managerGlobal,
                        nativeAdd = cmd.nativeAdd,
                        nativeHas = cmd.nativeHas,
                        nativeRefresh = cmd.nativeRefresh,
                        episodeKeys = cmd.episodeKeys,
                        param3 = cmd.param3
                    )
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWER_IMMEDIATE -> {
                    val r = InProcessNativeBridge.powerImmediate(
                        managerGlobal = cmd.managerGlobal,
                        nativeHas = cmd.nativeHas,
                        nativeRefresh = cmd.nativeRefresh,
                        character = cmd.character,
                        episodeKeys = cmd.episodeKeys,
                        layout = cmd.powerLayout
                    )
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_PLAY2_PREPARE -> {
                    val r = InProcessNativeBridge.preparePlay2Locator()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_PLAY2_CODE -> {
                    val r = InProcessNativeBridge.play2CodeTrigger()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWDER_BUY -> {
                    val r = InProcessNativeBridge.powderBuyBox1()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWDER_BUY_BURST10 -> {
                    val r = InProcessNativeBridge.powderBuyBox1Burst(cmd.powderCount)
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWDER_BREAK -> {
                    val r = InProcessNativeBridge.powderBreakItem(cmd.powderItem)
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWDER_BREAK_BATCH -> {
                    val r = InProcessNativeBridge.powderBreakBatch(cmd.powderItems)
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWDER_CLEANUP -> {
                    val r = InProcessNativeBridge.powderCleanup()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_POWDER_FORCE_RELOAD -> {
                    val r = InProcessNativeBridge.powderForceReload()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_TOWER_STATE -> {
                    val r = InProcessNativeBridge.towerState()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_TOWER_TEST_SUCCESS -> {
                    val r = InProcessNativeBridge.towerTestMissionSuccess()
                    Result(r.ok, "game-thread • ${r.message}")
                }
                OP_BOX_CALL -> {
                    val r = InProcessNativeBridge.boxCallAction(cmd.effectId)
                    Result(r.ok, "game-thread • ${r.message}")
                }
                else -> Result(false, "invalid queued op=${cmd.op}")
            }
            lastGameStatus = result.message
            markInjectionStage(null, "gameThread", "result ok=${result.ok} • ${result.message}")
            sendResult(context, cmd.token, result)
        }
    }

    fun ping(context: Context, timeoutMs: Long = 2500L): Result =
        request(context, OP_PING, 0L, 0L, 0L, 0, timeoutMs)

    fun apply(
        context: Context,
        dispatcher: Long,
        character: Long,
        effectId: Int,
        timeoutMs: Long = 3500L
    ): Result = request(context, OP_APPLY, dispatcher, 0L, character, effectId, timeoutMs)

    fun remove(
        context: Context,
        remover: Long,
        character: Long,
        effectId: Int,
        timeoutMs: Long = 3500L
    ): Result = request(context, OP_REMOVE, 0L, remover, character, effectId, timeoutMs)

    fun powerFamily(
        context: Context,
        managerGlobal: Long,
        nativeAdd: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        episodeKeys: IntArray,
        param3: Int,
        timeoutMs: Long = 3500L
    ): Result = requestPowerFamily(
        context = context,
        managerGlobal = managerGlobal,
        nativeAdd = nativeAdd,
        nativeHas = nativeHas,
        nativeRefresh = nativeRefresh,
        episodeKeys = episodeKeys,
        param3 = param3,
        timeoutMs = timeoutMs
    )

    fun powerImmediate(
        context: Context,
        managerGlobal: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        character: Long,
        episodeKeys: IntArray,
        layout: LongArray,
        timeoutMs: Long = 3500L
    ): Result = requestPowerImmediate(
        context = context,
        managerGlobal = managerGlobal,
        nativeHas = nativeHas,
        nativeRefresh = nativeRefresh,
        character = character,
        episodeKeys = episodeKeys,
        layout = layout,
        timeoutMs = timeoutMs
    )

    fun preparePlay2Locator(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result = request(
        context = context,
        op = OP_PLAY2_PREPARE,
        dispatcher = 0L,
        remover = 0L,
        character = 0L,
        effectId = 0,
        timeoutMs = timeoutMs
    )

    fun locatePlay2PreRunObject(
        context: Context,
        timeoutMs: Long = 5000L
    ): Result = request(
        context = context,
        op = OP_PLAY2_LOCATE,
        dispatcher = 0L,
        remover = 0L,
        character = 0L,
        effectId = 0,
        timeoutMs = timeoutMs
    )

    fun play2CodeTrigger(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result = request(
        context = context,
        op = OP_PLAY2_CODE,
        dispatcher = 0L,
        remover = 0L,
        character = 0L,
        effectId = 0,
        timeoutMs = timeoutMs
    )

    fun powderLocateTreasurePage(
        context: Context,
        timeoutMs: Long = 6500L
    ): Result = requestPowder(
        context = context,
        op = OP_POWDER_LOCATE,
        powderItem = 0L,
        timeoutMs = timeoutMs
    )

    fun powderBuyBox1(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result = requestPowder(
        context = context,
        op = OP_POWDER_BUY,
        powderItem = 0L,
        timeoutMs = timeoutMs
    )

    fun powderBuyBox1Burst(
        context: Context,
        count: Int,
        timeoutMs: Long = 4500L
    ): Result {
        if (count !in 1..128) return Result(false, "powder burst count invalid=$count")
        return requestPowder(
            context = context,
            op = OP_POWDER_BUY_BURST10,
            powderItem = 0L,
            powderCount = count,
            timeoutMs = timeoutMs
        )
    }

    fun powderBuyBox1Burst10(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result = powderBuyBox1Burst(context, 10, timeoutMs)

    fun powderBreakItem(
        context: Context,
        powderItem: Long,
        timeoutMs: Long = 4500L
    ): Result = requestPowder(
        context = context,
        op = OP_POWDER_BREAK,
        powderItem = powderItem,
        timeoutMs = timeoutMs
    )

    fun powderBreakBatch(
        context: Context,
        powderItems: LongArray,
        timeoutMs: Long = 6500L
    ): Result = requestPowderBatch(
        context = context,
        op = OP_POWDER_BREAK_BATCH,
        powderItems = powderItems,
        timeoutMs = timeoutMs
    )

    fun powderForceReload(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result = requestPowder(
        context = context,
        op = OP_POWDER_FORCE_RELOAD,
        powderItem = 0L,
        timeoutMs = timeoutMs
    )

    fun powderCleanup(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result = requestPowder(
        context = context,
        op = OP_POWDER_CLEANUP,
        powderItem = 0L,
        timeoutMs = timeoutMs
    )

    fun towerState(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_TOWER_STATE,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = 0,
            timeoutMs = timeoutMs
        )
    }

    fun towerTestMissionSuccess(
        context: Context,
        timeoutMs: Long = 4500L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_TOWER_TEST_SUCCESS,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = 0,
            timeoutMs = timeoutMs
        )
    }

    fun boxLocateAction(
        context: Context,
        actionId: Int,
        timeoutMs: Long = 6500L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        if (actionId !in 1..4) return Result(false, "invalid box action id=$actionId")
        return request(
            context = context,
            op = OP_BOX_LOCATE,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = actionId,
            timeoutMs = timeoutMs
        )
    }

    fun boxCallAction(
        context: Context,
        actionId: Int,
        timeoutMs: Long = 5000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        if (actionId !in 1..4) return Result(false, "invalid box action id=$actionId")
        return request(
            context = context,
            op = OP_BOX_CALL,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = actionId,
            timeoutMs = timeoutMs
        )
    }

    fun sessionState(
        context: Context,
        includeSecret: Boolean = false,
        timeoutMs: Long = 5000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_SESSION_STATE,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = if (includeSecret) 1 else 0,
            timeoutMs = timeoutMs
        )
    }

    fun authContext(
        context: Context,
        includeSecret: Boolean = false,
        timeoutMs: Long = 5000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_AUTH_CONTEXT,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = if (includeSecret) 1 else 0,
            timeoutMs = timeoutMs
        )
    }

    fun initMember3Probe(
        context: Context,
        timeoutMs: Long = 8000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_INITMEMBER3_PROBE,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = 0,
            timeoutMs = timeoutMs
        )
    }

    fun heartDsCryptoProfile(
        context: Context,
        timeoutMs: Long = 8000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_HEART_DS_CRYPTO_PROFILE,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = 0,
            timeoutMs = timeoutMs
        )
    }

    fun heartSendDsProbe(
        context: Context,
        timeoutMs: Long = 8000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_HEART_SEND_DS_PROBE,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = 0,
            timeoutMs = timeoutMs
        )
    }

    fun heartSendDsProbeReset(
        context: Context,
        timeoutMs: Long = 8000L
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        return request(
            context = context,
            op = OP_HEART_SEND_DS_PROBE_RESET,
            dispatcher = 0L,
            remover = 0L,
            character = 0L,
            effectId = 0,
            timeoutMs = timeoutMs
        )
    }

    fun statusText(): String = lastGameStatus

    /**
     * Read the game-side marker through root from the M Woif app process.
     * This is diagnostic-only and never writes CookieRun memory.
     */
    fun diagnosticMarkerViaRoot(expectedGamePid: Int?): String {
        if (!BuildConfig.INTERNAL_BUILD) return "marker=disabled (not internal)"

        val pkg = CrgProfile.GAME_PACKAGE
        val command = buildString {
            append("for f in ")
            append("/data/user/0/$pkg/files/$MARKER_NAME ")
            append("/data/data/$pkg/files/$MARKER_NAME; do ")
            append("if [ -f \"\$f\" ]; then tail -n 60 \"\$f\"; exit 0; fi; ")
            append("done; echo __WOIF_MARKER_MISSING__; exit 0")
        }

        return try {
            val process = ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start()
            val finished = process.waitFor(1800L, TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                return "marker=READ_TIMEOUT"
            }
            val text = process.inputStream.bufferedReader().use { it.readText() }.trim()
            if (text.contains("__WOIF_MARKER_MISSING__") || text.isBlank()) {
                return "marker=MISSING • LSPosed XposedEntry ไม่ได้สร้าง marker ใน game process"
            }

            val match = if (expectedGamePid == null) {
                "UNKNOWN"
            } else if (text.contains("pid=$expectedGamePid ")) {
                "YES"
            } else {
                "NO"
            }
            buildString {
                appendLine("marker=FOUND • currentPidMatch=$match expectedPid=${expectedGamePid ?: -1}")
                append(text)
            }.trimEnd()
        } catch (t: Throwable) {
            "marker=READ_FAILED • ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    private fun request(
        context: Context,
        op: String,
        dispatcher: Long,
        remover: Long,
        character: Long,
        effectId: Int,
        timeoutMs: Long
    ): Result {
        if (!BuildConfig.GAME_EFFECT_BRIDGE_ENABLED) {
            return Result(false, "game effect bridge disabled")
        }
        ensureAppResultReceiver(context.applicationContext)

        val token = UUID.randomUUID().toString()
        val future = CompletableFuture<Result>()
        pending[token] = future

        val intent = Intent(commandAction())
            .setPackage(CrgProfile.GAME_PACKAGE)
            .putExtra(EXTRA_TOKEN, token)
            .putExtra(EXTRA_OP, op)
            .putExtra(EXTRA_DISPATCHER, dispatcher)
            .putExtra(EXTRA_REMOVER, remover)
            .putExtra(EXTRA_CHARACTER, character)
            .putExtra(EXTRA_EFFECT_ID, effectId)
            .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)

        return try {
            context.sendBroadcast(intent)
            val result = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            val safe = redactIpcMessageForLog(result.message)
            lastGameStatus = safe
            DevConsole.log("IP", "$op • ${if (result.ok) "OK" else "FAIL"} • $safe")
            result
        } catch (t: Throwable) {
            val result = Result(false, "$op timeout/no result • ${t.javaClass.simpleName}")
            lastGameStatus = result.message
            DevConsole.log("IP", result.message)
            result
        } finally {
            pending.remove(token)
        }
    }

    private fun requestPowerFamily(
        context: Context,
        managerGlobal: Long,
        nativeAdd: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        episodeKeys: IntArray,
        param3: Int,
        timeoutMs: Long
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        if (episodeKeys.isEmpty()) return Result(false, "power_family episode keys empty")
        ensureAppResultReceiver(context.applicationContext)

        val token = UUID.randomUUID().toString()
        val future = CompletableFuture<Result>()
        pending[token] = future

        val intent = Intent(commandAction())
            .setPackage(CrgProfile.GAME_PACKAGE)
            .putExtra(EXTRA_TOKEN, token)
            .putExtra(EXTRA_OP, OP_POWER_FAMILY)
            .putExtra(EXTRA_MANAGER_GLOBAL, managerGlobal)
            .putExtra(EXTRA_NATIVE_ADD, nativeAdd)
            .putExtra(EXTRA_NATIVE_HAS, nativeHas)
            .putExtra(EXTRA_NATIVE_REFRESH, nativeRefresh)
            .putExtra(EXTRA_EPISODE_KEYS, episodeKeys)
            .putExtra(EXTRA_PARAM3, param3)
            .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)

        return try {
            context.sendBroadcast(intent)
            val result = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            lastGameStatus = result.message
            DevConsole.log(
                "IP",
                "$OP_POWER_FAMILY • ${if (result.ok) "OK" else "FAIL"} • ${result.message}"
            )
            result
        } catch (t: Throwable) {
            val result = Result(
                false,
                "$OP_POWER_FAMILY timeout/no result • ${t.javaClass.simpleName}"
            )
            lastGameStatus = result.message
            DevConsole.log("IP", result.message)
            result
        } finally {
            pending.remove(token)
        }
    }

    private fun requestPowerImmediate(
        context: Context,
        managerGlobal: Long,
        nativeHas: Long,
        nativeRefresh: Long,
        character: Long,
        episodeKeys: IntArray,
        layout: LongArray,
        timeoutMs: Long
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        if (episodeKeys.isEmpty()) return Result(false, "power_immediate episode keys empty")
        if (layout.size != 15) return Result(false, "power_immediate layout invalid")
        ensureAppResultReceiver(context.applicationContext)

        val token = UUID.randomUUID().toString()
        val future = CompletableFuture<Result>()
        pending[token] = future

        val intent = Intent(commandAction())
            .setPackage(CrgProfile.GAME_PACKAGE)
            .putExtra(EXTRA_TOKEN, token)
            .putExtra(EXTRA_OP, OP_POWER_IMMEDIATE)
            .putExtra(EXTRA_CHARACTER, character)
            .putExtra(EXTRA_MANAGER_GLOBAL, managerGlobal)
            .putExtra(EXTRA_NATIVE_HAS, nativeHas)
            .putExtra(EXTRA_NATIVE_REFRESH, nativeRefresh)
            .putExtra(EXTRA_EPISODE_KEYS, episodeKeys)
            .putExtra(EXTRA_POWER_LAYOUT, layout)
            .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)

        return try {
            context.sendBroadcast(intent)
            val result = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            lastGameStatus = result.message
            DevConsole.log(
                "IP",
                "$OP_POWER_IMMEDIATE • ${if (result.ok) "OK" else "FAIL"} • ${result.message}"
            )
            result
        } catch (t: Throwable) {
            val result = Result(
                false,
                "$OP_POWER_IMMEDIATE timeout/no result • ${t.javaClass.simpleName}"
            )
            lastGameStatus = result.message
            DevConsole.log("IP", result.message)
            result
        } finally {
            pending.remove(token)
        }
    }

    private fun requestPowder(
        context: Context,
        op: String,
        powderItem: Long,
        powderCount: Int = 0,
        timeoutMs: Long
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        if (op == OP_POWDER_BREAK && powderItem <= 0L) {
            return Result(false, "powder_break item pointer invalid")
        }
        ensureAppResultReceiver(context.applicationContext)

        val token = UUID.randomUUID().toString()
        val future = CompletableFuture<Result>()
        pending[token] = future

        val intent = Intent(commandAction())
            .setPackage(CrgProfile.GAME_PACKAGE)
            .putExtra(EXTRA_TOKEN, token)
            .putExtra(EXTRA_OP, op)
            .putExtra(EXTRA_POWDER_ITEM, powderItem)
            .putExtra(EXTRA_POWDER_COUNT, powderCount)
            .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)

        return try {
            context.sendBroadcast(intent)
            val result = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            lastGameStatus = result.message
            DevConsole.log(
                "PUMP-IP",
                "$op • ${if (result.ok) "OK" else "FAIL"} • ${result.message}"
            )
            result
        } catch (t: Throwable) {
            val result = Result(false, "$op timeout/no result • ${t.javaClass.simpleName}")
            lastGameStatus = result.message
            DevConsole.log("PUMP-IP", result.message)
            result
        } finally {
            pending.remove(token)
        }
    }

    private fun requestPowderBatch(
        context: Context,
        op: String,
        powderItems: LongArray,
        timeoutMs: Long
    ): Result {
        if (!BuildConfig.INTERNAL_BUILD) return Result(false, "internal build required")
        if (op == OP_POWDER_BREAK_BATCH && powderItems.isEmpty()) {
            return Result(false, "powder_break_batch empty items")
        }
        ensureAppResultReceiver(context.applicationContext)

        val token = UUID.randomUUID().toString()
        val future = CompletableFuture<Result>()
        pending[token] = future

        val intent = Intent(commandAction())
            .setPackage(CrgProfile.GAME_PACKAGE)
            .putExtra(EXTRA_TOKEN, token)
            .putExtra(EXTRA_OP, op)
            .putExtra(EXTRA_POWDER_ITEMS, powderItems)
            .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)

        return try {
            context.sendBroadcast(intent)
            val result = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            lastGameStatus = result.message
            DevConsole.log(
                "PUMP-IP",
                "$op • ${if (result.ok) "OK" else "FAIL"} • ${result.message}"
            )
            result
        } catch (t: Throwable) {
            val result = Result(false, "$op timeout/no result • ${t.javaClass.simpleName}")
            lastGameStatus = result.message
            DevConsole.log("PUMP-IP", result.message)
            result
        } finally {
            pending.remove(token)
        }
    }

    private fun ensureAppResultReceiver(context: Context) {
        if (appReceiverRegistered) return
        synchronized(this) {
            if (appReceiverRegistered) return
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    if (intent.action != resultAction()) return
                    val token = intent.getStringExtra(EXTRA_TOKEN) ?: return
                    val ok = intent.getBooleanExtra(EXTRA_OK, false)
                    val message = intent.getStringExtra(EXTRA_MESSAGE) ?: "no message"
                    pending[token]?.complete(Result(ok, message))
                }
            }
            val filter = IntentFilter(resultAction())
            if (Build.VERSION.SDK_INT >= 33) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                context.registerReceiver(receiver, filter)
            }
            appReceiverRegistered = true
        }
    }

    private fun sendResult(context: Context, token: String, result: Result) {
        val intent = Intent(resultAction())
            .setPackage(BuildConfig.APPLICATION_ID)
            .putExtra(EXTRA_TOKEN, token)
            .putExtra(EXTRA_OK, result.ok)
            .putExtra(EXTRA_MESSAGE, result.message)
            .addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
        try {
            context.sendBroadcast(intent)
            val safe = redactIpcMessageForLog(result.message)
            markInjectionStage(null, "result", "sent ok=${result.ok} • $safe")
        } catch (t: Throwable) {
            markInjectionStage(null, "result", "send failed=${t.javaClass.simpleName}:${t.message}")
            Log.e(TAG, "result broadcast failed", t)
        }
    }
}
