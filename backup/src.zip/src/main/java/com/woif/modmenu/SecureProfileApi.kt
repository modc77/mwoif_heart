package com.woif.modmenu

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object SecureProfileApi {

    private const val BASE_URL =
        "https://license.mwoifmod.xyz"

    data class Envelope(
        val featureId: String,
        val revision: String,
        val ttlSeconds: Int,
        val encryptedKey: String,
        val iv: String,
        val tag: String,
        val ciphertext: String,
        val aad: String
    )

    sealed class Result {

        data class Success(
            val envelope:
                Envelope
        ) : Result()

        data class Failure(
            val code: String,
            val message: String
        ) : Result()
    }

    fun fetch(
        session:
            SessionManager.Snapshot,
        featureId:
            String
    ): Result {

        if (!FeatureCatalog.isKnownFeatureId(featureId)) {
            return Result.Failure(
                code = "UNKNOWN_FEATURE",
                message = "Feature is not present in the client catalog"
            )
        }

        val body =
            JSONObject()
                .put(
                    "session_token",
                    session.sessionToken
                )
                .put(
                    "device_id",
                    session.deviceId
                )
                .put(
                    "game_id",
                    session.gameId
                )
                .put(
                    "game_version",
                    session.gameVersion
                )
                .put(
                    "app_version",
                    session.appVersion
                )
                .put(
                    "feature_id",
                    featureId
                )
                .put(
                    "profile_public_key",
                    DeviceProfileKeyStore
                        .publicKeyBase64()
                )

        var connection:
                HttpURLConnection? =
            null

        return try {

            connection =
                URL(
                    "$BASE_URL/api/profile.php"
                )
                    .openConnection()
                    as HttpURLConnection

            connection.requestMethod =
                "POST"

            connection.connectTimeout =
                10_000

            connection.readTimeout =
                12_000

            connection.useCaches =
                false

            connection.doOutput =
                true

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            connection.setRequestProperty(
                "Content-Type",
                "application/json; charset=utf-8"
            )

            val bytes =
                body.toString()
                    .toByteArray(
                        Charsets.UTF_8
                    )

            connection.setFixedLengthStreamingMode(
                bytes.size
            )

            connection.outputStream.use {
                it.write(
                    bytes
                )
            }

            val httpCode =
                connection.responseCode

            val stream =
                if (
                    httpCode in
                    200..299
                ) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val text =
                if (
                    stream != null
                ) {

                    BufferedReader(
                        InputStreamReader(
                            stream,
                            Charsets.UTF_8
                        )
                    )
                        .use {
                            it.readText()
                        }

                } else {
                    ""
                }

            val json =
                if (
                    text.isBlank()
                ) {
                    JSONObject()
                } else {
                    JSONObject(
                        text
                    )
                }

            if (
                httpCode in
                200..299 &&
                json.optBoolean(
                    "ok",
                    false
                )
            ) {

                val returnedFeatureId =
                    json.getString(
                        "feature_id"
                    )

                if (!returnedFeatureId.equals(featureId, ignoreCase = false)) {
                    Result.Failure(
                        code = "FEATURE_MISMATCH",
                        message = "Secure profile response does not match the requested feature"
                    )
                } else Result.Success(
                    Envelope(
                        featureId =
                            returnedFeatureId,

                        revision =
                            json.getString(
                                "profile_revision"
                            ),

                        ttlSeconds =
                            json.optInt(
                                "ttl_seconds",
                                600
                            ),

                        encryptedKey =
                            json.getString(
                                "ek"
                            ),

                        iv =
                            json.getString(
                                "iv"
                            ),

                        tag =
                            json.getString(
                                "tag"
                            ),

                        ciphertext =
                            json.getString(
                                "ct"
                            ),

                        aad =
                            json.getString(
                                "aad"
                            )
                    )
                )

            } else {

                Result.Failure(
                    code =
                        json.optString(
                            "error",
                            "HTTP_$httpCode"
                        ),

                    message =
                        json.optString(
                            "message",
                            "Secure profile request failed"
                        )
                )
            }

        } catch (
            e: Exception
        ) {

            Result.Failure(
                code =
                    "NETWORK_ERROR",

                message =
                    e.message
                        ?: e.javaClass.simpleName
            )

        } finally {

            connection
                ?.disconnect()
        }
    }
}
