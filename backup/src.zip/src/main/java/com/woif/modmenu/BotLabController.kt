package com.woif.modmenu

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * BOT LAB V7
 *
 * Stage-driven bot with UI recovery, serialized input and randomized QA stage actions:
 *  - No touch recorder / no full-screen touch interception.
 *  - Keeps the normal M Woif floating controls visible while BOT is running.
 *  - Handles Play 1/2, Result/Confirm, Mystery Box, Level Up and generic startup X popups.
 *  - Handles the optional 6-card matching mini-game before Result.
 *  - If CookieRun restarts/crashes, waits for the process and relaunches it when needed.
 */
class BotLabController(
    private val context: Context,
    private val windowManager: WindowManager,
    private val mainHandler: Handler,
    private val onUiChanged: () -> Unit
) {

    companion object {
        // Keep the V4 prefs name so existing user settings are preserved.
        private const val PREFS = "bot_lab_v4"

        private const val LOOP_SLEEP_MS = 90L
        private const val STAGE_PROBE_INTERVAL_MS = 180L
        private const val STAGE_EXIT_CONFIRM_COUNT = 3
        private const val SCREEN_SCAN_INTERVAL_MS = 450L
        private const val PLAY_GREEN_RATIO = 0.24f

        private const val MIN_INTERVAL_MS = 250L
        private const val MAX_INTERVAL_MS = 5_000L

        private const val POPUP_X_DELAY_MS = 1_500L
        private const val UI_ACTION_MIN_DELAY_MS = 850L
        private const val RESTART_WAIT_MS = 8_000L
        private const val PROCESS_RECOVERY_GRACE_MS = 1_500L
        private const val GAME_RELAUNCH_INTERVAL_MS = 6_000L
        private const val MINI_PAIR_DELAY_MS = 1_250L
        private const val MINI_PAIR_TAP_GAP_MS = 550L
        private const val GLOBAL_BOT_TAP_GAP_MS = 420L

        // Normalized coordinates based on CookieRun Classic landscape UI.
        private const val START_X = 0.748f
        private const val START_Y = 0.895f

        private const val JUMP_X = 0.135f
        private const val JUMP_Y = 0.885f

        private const val SLIDE_X = 0.875f
        private const val SLIDE_Y = 0.885f

        // Common close button used by startup/news/event/ranking popups.
        private const val POPUP_X = 0.875f
        private const val POPUP_Y = 0.140f
    }

    enum class Phase {
        IDLE,
        NAVIGATE_START,
        IN_STAGE,
        POST_STAGE
    }

    private enum class StageAction {
        JUMP,
        SLIDE
    }

    private data class TapTarget(
        val x: Float,
        val y: Float
    )

    private data class ScreenAction(
        val handled: Boolean,
        val delayMs: Long,
        val text: String,
        val restartLikely: Boolean = false
    )

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val executor = Executors.newSingleThreadExecutor()
    private val stopRequested = AtomicBoolean(false)
    private val stageDetector = BotStageDetector(context)

    // Six card centers in the optional "Find the jumping card" mini-game.
    private val miniCardCenters = arrayOf(
        floatArrayOf(0.310f, 0.405f),
        floatArrayOf(0.490f, 0.405f),
        floatArrayOf(0.670f, 0.405f),
        floatArrayOf(0.310f, 0.765f),
        floatArrayOf(0.490f, 0.765f),
        floatArrayOf(0.670f, 0.765f)
    )

    @Volatile private var running = false
    @Volatile private var phase = Phase.IDLE
    @Volatile private var statusText = "พร้อม • BOT V7"
    @Volatile private var runCount = 0
    @Volatile private var lastStageState = BotStageDetector.State.NOT_READY

    private var stopView: TextView? = null

    // Every synthetic BOT tap is serialized through this gate. This prevents
    // Jump + Slide (or navigation actions) from being injected back-to-back
    // in the same scheduler iteration. It is intentionally independent from
    // the user's normal touch stream: BOT never installs a full-screen touch
    // listener and never reacts to ACTION_DOWN/ACTION_UP from the game.
    private val botTapLock = Any()
    @Volatile private var lastBotTapAt = 0L

    // Persisted user configuration.
    @Volatile private var jumpCount = prefs.getInt("jump_count", 8).coerceIn(0, 100)
    @Volatile private var slideCount = prefs.getInt("slide_count", 4).coerceIn(0, 100)
    @Volatile private var jumpIntervalMs = prefs.getLong("jump_interval", 900L)
        .coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
    @Volatile private var slideIntervalMs = prefs.getLong("slide_interval", 2_200L)
        .coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
    @Volatile private var startTapIntervalMs = prefs.getLong("start_interval", 1_200L)
        .coerceIn(500L, MAX_INTERVAL_MS)
    @Volatile private var postTapIntervalMs = prefs.getLong("post_interval", 850L)
        .coerceIn(400L, MAX_INTERVAL_MS)

    fun isBusy(): Boolean = running
    fun isRunning(): Boolean = running
    fun phase(): Phase = phase
    fun status(): String = statusText
    fun runCount(): Int = runCount
    fun stageStatus(): String = stageDetector.status()
    fun stageStateText(): String = when (lastStageState) {
        BotStageDetector.State.ACTIVE -> "ACTIVE"
        BotStageDetector.State.INACTIVE -> "IDLE"
        BotStageDetector.State.NOT_READY -> "WAIT"
    }

    fun jumpCount(): Int = jumpCount
    fun slideCount(): Int = slideCount
    fun jumpIntervalMs(): Long = jumpIntervalMs
    fun slideIntervalMs(): Long = slideIntervalMs
    fun startTapIntervalMs(): Long = startTapIntervalMs
    fun postTapIntervalMs(): Long = postTapIntervalMs

    fun setJumpCount(value: Int) {
        if (running) return
        jumpCount = value.coerceIn(0, 100)
        prefs.edit().putInt("jump_count", jumpCount).apply()
        notifyUi()
    }

    fun setSlideCount(value: Int) {
        if (running) return
        slideCount = value.coerceIn(0, 100)
        prefs.edit().putInt("slide_count", slideCount).apply()
        notifyUi()
    }

    fun setJumpIntervalMs(value: Long) {
        if (running) return
        jumpIntervalMs = value.coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
        prefs.edit().putLong("jump_interval", jumpIntervalMs).apply()
        notifyUi()
    }

    fun setSlideIntervalMs(value: Long) {
        if (running) return
        slideIntervalMs = value.coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
        prefs.edit().putLong("slide_interval", slideIntervalMs).apply()
        notifyUi()
    }

    fun setStartTapIntervalMs(value: Long) {
        if (running) return
        startTapIntervalMs = value.coerceIn(500L, MAX_INTERVAL_MS)
        prefs.edit().putLong("start_interval", startTapIntervalMs).apply()
        notifyUi()
    }

    fun setPostTapIntervalMs(value: Long) {
        if (running) return
        postTapIntervalMs = value.coerceIn(400L, MAX_INTERVAL_MS)
        prefs.edit().putLong("post_interval", postTapIntervalMs).apply()
        notifyUi()
    }

    fun startBot(): Boolean {
        if (running) return false

        if (!RootMemoryClient.isReady()) {
            statusText = "Root worker ยังไม่พร้อม"
            notifyUi()
            return false
        }

        SecureProfileManager.preloadRunReward(forceRefresh = false, callback = null)

        stopRequested.set(false)
        stageDetector.reset()
        running = true
        phase = Phase.NAVIGATE_START
        runCount = 0
        lastStageState = BotStageDetector.State.NOT_READY
        statusText = "BOT ON • หา Play / Popup / Stage"

        mainHandler.post {
            installStopOverlay()
            notifyUi()
        }

        executor.execute { botLoop() }
        return true
    }

    fun stopBot(reason: String = "หยุดโดยผู้ใช้") {
        if (!running) return
        stopRequested.set(true)
        statusText = reason
        notifyUiFromWorker()
    }

    fun shutdown() {
        stopRequested.set(true)
        running = false
        phase = Phase.IDLE
        mainHandler.post { removeStopOverlay() }
        executor.shutdownNow()
    }

    private fun botLoop() {
        var lastProbeAt = 0L
        var nextScreenActionAt = 0L
        var nextGameLaunchAt = 0L
        var notReadySince = 0L
        var recoveryPauseUntil = 0L

        var stageInactiveCount = 0
        var stageWasActive = false

        var jumpDone = 0
        var slideDone = 0
        var stageActions: List<StageAction> = emptyList()
        var stageActionIndex = 0
        var nextStageActionAt = 0L
        var previousStagePattern: List<StageAction> = emptyList()

        try {
            while (!stopRequested.get()) {
                val now = System.currentTimeMillis()

                if (now - lastProbeAt >= STAGE_PROBE_INTERVAL_MS) {
                    lastProbeAt = now
                    lastStageState = stageDetector.probe()
                }

                if (now < recoveryPauseUntil) {
                    statusText = "Connection/Restart • รอเกมโหลดใหม่"
                    Thread.sleep(LOOP_SLEEP_MS)
                    continue
                }

                when (phase) {
                    Phase.NAVIGATE_START -> {
                        when (lastStageState) {
                            BotStageDetector.State.ACTIVE -> {
                                stageWasActive = true
                                stageInactiveCount = 0
                                jumpDone = 0
                                slideDone = 0
                                stageActions = buildStageActionSequence(previousStagePattern)
                                previousStagePattern = stageActions
                                stageActionIndex = 0
                                nextStageActionAt = now + 250L
                                runCount += 1
                                phase = Phase.IN_STAGE
                                statusText = "RUN $runCount • เข้า Stage แล้ว"
                                notReadySince = 0L
                                notifyUiFromWorker()
                            }

                            BotStageDetector.State.NOT_READY -> {
                                if (notReadySince == 0L) notReadySince = now

                                if (!stageDetector.gameProcessAlive() &&
                                    now - notReadySince >= PROCESS_RECOVERY_GRACE_MS &&
                                    now >= nextGameLaunchAt
                                ) {
                                    val opened = launchGame()
                                    nextGameLaunchAt = now + GAME_RELAUNCH_INTERVAL_MS
                                    statusText = if (opened) {
                                        "เกมปิด/เด้ง • กำลังเปิด CookieRun ใหม่"
                                    } else {
                                        "รอ CookieRun • เปิดเกมอัตโนมัติไม่สำเร็จ"
                                    }
                                    notifyUiFromWorker()
                                } else {
                                    statusText = "BOT ON • ${stageDetector.status()}"
                                }
                            }

                            BotStageDetector.State.INACTIVE -> {
                                notReadySince = 0L
                                if (now >= nextScreenActionAt) {
                                    val action = handleScreenNavigation(postStage = false)
                                    statusText = action.text
                                    nextScreenActionAt = now + action.delayMs
                                    if (action.restartLikely) {
                                        recoveryPauseUntil = now + action.delayMs
                                        stageDetector.reset()
                                        notReadySince = now
                                    }
                                    notifyUiFromWorker()
                                }
                            }
                        }
                    }

                    Phase.IN_STAGE -> {
                        when (lastStageState) {
                            BotStageDetector.State.ACTIVE -> {
                                notReadySince = 0L
                                stageWasActive = true
                                stageInactiveCount = 0

                                // QA variation mode: build one mixed Jump/Slide sequence when the
                                // stage starts, then execute exactly one action at a time. Timing is
                                // still controlled by the configured Jump/Slide intervals.
                                if (stageActionIndex < stageActions.size && now >= nextStageActionAt) {
                                    when (stageActions[stageActionIndex]) {
                                        StageAction.JUMP -> {
                                            if (tapNormalized(JUMP_X, JUMP_Y)) {
                                                jumpDone += 1
                                                stageActionIndex += 1
                                            }
                                            nextStageActionAt = System.currentTimeMillis() + jumpIntervalMs
                                        }

                                        StageAction.SLIDE -> {
                                            if (tapNormalized(SLIDE_X, SLIDE_Y)) {
                                                slideDone += 1
                                                stageActionIndex += 1
                                            }
                                            nextStageActionAt = System.currentTimeMillis() + slideIntervalMs
                                        }
                                    }
                                }

                                statusText =
                                    "RUN $runCount • Mix $stageActionIndex/${stageActions.size} • Jump $jumpDone/$jumpCount • Slide $slideDone/$slideCount"
                            }

                            BotStageDetector.State.INACTIVE -> {
                                notReadySince = 0L
                                if (stageWasActive) {
                                    stageInactiveCount += 1
                                    if (stageInactiveCount >= STAGE_EXIT_CONFIRM_COUNT) {
                                        phase = Phase.POST_STAGE
                                        nextScreenActionAt = now + 500L
                                        statusText = "RUN $runCount • จบด่าน • ตรวจ Mini/Result/Reward"
                                        notifyUiFromWorker()
                                    }
                                }
                            }

                            BotStageDetector.State.NOT_READY -> {
                                if (notReadySince == 0L) notReadySince = now
                                if (now - notReadySince >= PROCESS_RECOVERY_GRACE_MS) {
                                    phase = Phase.NAVIGATE_START
                                    stageDetector.reset()
                                    statusText = "Stage หาย/เกมรีโหลด • เข้าระบบ Recovery"
                                    nextScreenActionAt = now + 1_000L
                                    notifyUiFromWorker()
                                }
                            }
                        }
                    }

                    Phase.POST_STAGE -> {
                        when (lastStageState) {
                            BotStageDetector.State.ACTIVE -> {
                                stageWasActive = true
                                stageInactiveCount = 0
                                jumpDone = 0
                                slideDone = 0
                                stageActions = buildStageActionSequence(previousStagePattern)
                                previousStagePattern = stageActions
                                stageActionIndex = 0
                                nextStageActionAt = now + 250L
                                runCount += 1
                                phase = Phase.IN_STAGE
                                statusText = "RUN $runCount • เข้า Stage ใหม่แล้ว"
                                notReadySince = 0L
                                notifyUiFromWorker()
                            }

                            BotStageDetector.State.NOT_READY -> {
                                if (notReadySince == 0L) notReadySince = now
                                if (now - notReadySince >= PROCESS_RECOVERY_GRACE_MS) {
                                    phase = Phase.NAVIGATE_START
                                    stageDetector.reset()
                                    statusText = "หลังจบ • เกมกำลัง restart/reload • Recovery"
                                    nextScreenActionAt = now + 1_000L
                                    notifyUiFromWorker()
                                }
                            }

                            BotStageDetector.State.INACTIVE -> {
                                notReadySince = 0L
                                if (now >= nextScreenActionAt) {
                                    val action = handleScreenNavigation(postStage = true)
                                    statusText = action.text
                                    nextScreenActionAt = now + action.delayMs
                                    if (action.restartLikely) {
                                        recoveryPauseUntil = now + action.delayMs
                                        phase = Phase.NAVIGATE_START
                                        stageDetector.reset()
                                        notReadySince = now
                                    }
                                    notifyUiFromWorker()
                                }
                            }
                        }
                    }

                    Phase.IDLE -> stopRequested.set(true)
                }

                Thread.sleep(LOOP_SLEEP_MS)
            }
        } catch (t: Throwable) {
            statusText = "BOT error • ${t.javaClass.simpleName}: ${t.message ?: "unknown"}"
        } finally {
            running = false
            phase = Phase.IDLE
            mainHandler.post {
                removeStopOverlay()
                notifyUi()
            }
        }
    }

    /**
     * Builds a mixed Jump/Slide sequence for QA variability. When both action
     * types are present, the exact full sequence is kept different from the
     * immediately previous stage whenever possible. This is functional test
     * variation only; it is not intended to bypass game-side detection.
     */
    private fun buildStageActionSequence(previous: List<StageAction>): List<StageAction> {
        val actions = ArrayList<StageAction>(jumpCount + slideCount)
        repeat(jumpCount) { actions.add(StageAction.JUMP) }
        repeat(slideCount) { actions.add(StageAction.SLIDE) }

        if (actions.size <= 1) return actions

        actions.shuffle()
        if (jumpCount > 0 && slideCount > 0 && actions == previous) {
            repeat(11) {
                if (actions != previous) return@repeat
                actions.shuffle()
            }

            // Extremely unlikely fallback: force one J/S swap so the complete
            // order is not identical to the previous stage.
            if (actions == previous) {
                val first = actions.firstOrNull()
                val differentIndex = actions.indexOfFirst { it != first }
                if (differentIndex > 0) {
                    val tmp = actions[0]
                    actions[0] = actions[differentIndex]
                    actions[differentIndex] = tmp
                }
            }
        }

        return actions.toList()
    }

    /**
     * One screenshot -> one safe navigation decision.
     * Priority matters: modal X and mini-game are checked before normal buttons.
     */
    private fun handleScreenNavigation(postStage: Boolean): ScreenAction {
        val bitmap = captureScreen() ?: return ScreenAction(
            handled = false,
            delayMs = SCREEN_SCAN_INTERVAL_MS,
            text = if (postStage) "หลังจบ • รอภาพหน้าจอ" else "หา Play • รอภาพหน้าจอ"
        )

        return try {
            if (isMatchingMiniGame(bitmap)) {
                val pair = findMinorityPosePair(bitmap)
                if (pair != null) {
                    val first = miniCardCenters[pair.first]
                    val second = miniCardCenters[pair.second]
                    tapNormalized(first[0], first[1])
                    Thread.sleep(MINI_PAIR_TAP_GAP_MS)
                    tapNormalized(second[0], second[1])
                    return ScreenAction(
                        handled = true,
                        delayMs = MINI_PAIR_DELAY_MS,
                        text = "Mini 6 รูป • กลุ่มเป้าหมาย 2 ใบ = ${pair.first + 1} + ${pair.second + 1}"
                    )
                }
                return ScreenAction(
                    handled = false,
                    delayMs = SCREEN_SCAN_INTERVAL_MS,
                    text = "Mini 6 รูป • กำลังแยกกลุ่ม 4 + 2"
                )
            }

            if (hasGenericCloseX(bitmap)) {
                tapNormalized(POPUP_X, POPUP_Y)
                return ScreenAction(
                    handled = true,
                    delayMs = POPUP_X_DELAY_MS,
                    text = "Popup ก่อน Play • กด X แล้ว • รอช้า ๆ"
                )
            }

            if (isPlayButtonVisible(bitmap)) {
                tapNormalized(START_X, START_Y)
                return ScreenAction(
                    handled = true,
                    delayMs = startTapIntervalMs,
                    text = if (postStage) "หลังจบ • เจอ Play • เริ่มรอบใหม่" else "เจอ Play 1/2 • กดแล้ว"
                )
            }

            val greenAction = findGreenAction(bitmap)
            if (greenAction != null) {
                tapNormalized(greenAction.x, greenAction.y)
                val restartLikely = greenAction.y < 0.74f
                return ScreenAction(
                    handled = true,
                    delayMs = if (restartLikely) RESTART_WAIT_MS else maxOf(postTapIntervalMs, UI_ACTION_MIN_DELAY_MS),
                    text = if (restartLikely) {
                        "Connection/Restart Confirm • รอเกมโหลดใหม่"
                    } else {
                        "${if (postStage) "หลังจบ" else "Popup"} • กด OK/Confirm"
                    },
                    restartLikely = restartLikely
                )
            }

            val cyanAction = findCenteredCyanAction(bitmap)
            if (cyanAction != null) {
                tapNormalized(cyanAction.x, cyanAction.y)
                return ScreenAction(
                    handled = true,
                    delayMs = maxOf(postTapIntervalMs, UI_ACTION_MIN_DELAY_MS),
                    text = "หลังจบ • กด Mystery Open/Confirm"
                )
            }

            ScreenAction(
                handled = false,
                delayMs = SCREEN_SCAN_INTERVAL_MS,
                text = if (postStage) "หลังจบ • รอ Result/Reward/Play" else "หา Play • รอ Popup/Play"
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun captureScreen(): Bitmap? {
        val png = RootMemoryClient.botScreenshotPng() ?: return null
        return BitmapFactory.decodeByteArray(png, 0, png.size)
    }

    /** Large lower-right green Play button. */
    private fun isPlayButtonVisible(bitmap: Bitmap): Boolean {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)

        val left = (width * 0.60f).roundToInt().coerceIn(0, width - 1)
        val right = (width * 0.90f).roundToInt().coerceIn(left + 1, width)
        val top = (height * 0.80f).roundToInt().coerceIn(0, height - 1)
        val bottom = (height * 0.96f).roundToInt().coerceIn(top + 1, height)

        var green = 0
        var total = 0
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                if (isGreen(bitmap.getPixel(x, y))) green += 1
                total += 1
                x += 6
            }
            y += 6
        }

        return total > 0 && green.toFloat() / total.toFloat() >= PLAY_GREEN_RATIO
    }

    /**
     * Generic grey circular X used by News / Event / Ranking startup popups.
     * Images/content can change; the X button style and position stay stable.
     */
    private fun hasGenericCloseX(bitmap: Bitmap): Boolean {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val left = (width * 0.82f).roundToInt().coerceIn(0, width - 1)
        val right = (width * 0.94f).roundToInt().coerceIn(left + 1, width)
        val top = (height * 0.05f).roundToInt().coerceIn(0, height - 1)
        val bottom = (height * 0.20f).roundToInt().coerceIn(top + 1, height)

        var gray = 0
        var white = 0
        var total = 0
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF

                if (abs(r - g) < 18 && abs(g - b) < 18 && r in 90..229) gray += 1
                if (r > 225 && g > 225 && b > 225) white += 1
                total += 1
                x += 4
            }
            y += 4
        }

        if (total <= 0) return false
        val grayRatio = gray.toFloat() / total.toFloat()
        val whiteRatio = white.toFloat() / total.toFloat()
        return grayRatio >= 0.08f && whiteRatio >= 0.012f
    }

    /**
     * Green OK/Confirm actions excluding the lower-right Play button.
     * Includes Result OK, Level Up Confirm, Congratulations Confirm and
     * Connection-lost Confirm. The y coordinate also lets us recognize the
     * higher Connection-lost button and wait for a restart.
     */
    private fun findGreenAction(bitmap: Bitmap): TapTarget? {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val left = (width * 0.20f).roundToInt().coerceIn(0, width - 1)
        val right = (width * 0.60f).roundToInt().coerceIn(left + 1, width)
        val top = (height * 0.52f).roundToInt().coerceIn(0, height - 1)
        val bottom = (height * 0.95f).roundToInt().coerceIn(top + 1, height)

        var count = 0
        var total = 0
        var sumX = 0L
        var sumY = 0L
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                if (isGreen(bitmap.getPixel(x, y))) {
                    count += 1
                    sumX += x.toLong()
                    sumY += y.toLong()
                }
                total += 1
                x += 4
            }
            y += 4
        }

        if (total <= 0 || count <= 0) return null
        if (count.toFloat() / total.toFloat() < 0.045f) return null

        return TapTarget(
            x = (sumX.toDouble() / count.toDouble() / width.toDouble()).toFloat().coerceIn(0f, 1f),
            y = (sumY.toDouble() / count.toDouble() / height.toDouble()).toFloat().coerceIn(0f, 1f)
        )
    }

    /** Mystery Box Open all / Confirm uses a centered cyan button. */
    private fun findCenteredCyanAction(bitmap: Bitmap): TapTarget? {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val left = (width * 0.38f).roundToInt().coerceIn(0, width - 1)
        val right = (width * 0.58f).roundToInt().coerceIn(left + 1, width)
        val top = (height * 0.77f).roundToInt().coerceIn(0, height - 1)
        val bottom = (height * 0.96f).roundToInt().coerceIn(top + 1, height)

        var count = 0
        var total = 0
        var sumX = 0L
        var sumY = 0L
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                if (isCyan(bitmap.getPixel(x, y))) {
                    count += 1
                    sumX += x.toLong()
                    sumY += y.toLong()
                }
                total += 1
                x += 4
            }
            y += 4
        }

        if (total <= 0 || count <= 0) return null
        if (count.toFloat() / total.toFloat() < 0.22f) return null

        return TapTarget(
            x = (sumX.toDouble() / count.toDouble() / width.toDouble()).toFloat().coerceIn(0f, 1f),
            y = (sumY.toDouble() / count.toDouble() / height.toDouble()).toFloat().coerceIn(0f, 1f)
        )
    }

    /** Detect the optional six-card matching mini-game. */
    private fun isMatchingMiniGame(bitmap: Bitmap): Boolean {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)

        // Teal title bar across the top-center.
        var teal = 0
        var tealTotal = 0
        var y = 0
        val topBottom = (height * 0.13f).roundToInt().coerceAtLeast(1)
        val topLeft = (width * 0.18f).roundToInt()
        val topRight = (width * 0.82f).roundToInt()
        while (y < topBottom) {
            var x = topLeft
            while (x < topRight) {
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                if (g > 90 && b > 90 && g > r * 1.15f && b > r * 1.05f) teal += 1
                tealTotal += 1
                x += 6
            }
            y += 6
        }
        if (tealTotal <= 0 || teal.toFloat() / tealTotal.toFloat() < 0.38f) return false

        // All six card interiors are large light-beige rectangles.
        for (center in miniCardCenters) {
            if (beigeRatioAround(bitmap, center[0], center[1]) < 0.45f) return false
        }
        return true
    }

    private fun beigeRatioAround(bitmap: Bitmap, nx: Float, ny: Float): Float {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val cx = (width * nx).roundToInt()
        val cy = (height * ny).roundToInt()
        val halfW = (width * 0.045f).roundToInt().coerceAtLeast(1)
        val halfH = (height * 0.11f).roundToInt().coerceAtLeast(1)

        val left = (cx - halfW).coerceIn(0, width - 1)
        val right = (cx + halfW).coerceIn(left + 1, width)
        val top = (cy - halfH).coerceIn(0, height - 1)
        val bottom = (cy + halfH).coerceIn(top + 1, height)

        var beige = 0
        var total = 0
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                if (isBeige(bitmap.getPixel(x, y))) beige += 1
                total += 1
                x += 5
            }
            y += 5
        }
        return if (total > 0) beige.toFloat() / total.toFloat() else 0f
    }

    /**
     * The mini-game is NOT "pick any closest pair". In practice the six cards
     * form two pose groups: four distractors of one pose and two target cards
     * of the other pose. V5 could select two cards from the 4-card group and
     * therefore fail even when its pixel comparison was accurate.
     *
     * V6 evaluates every possible 2-card candidate. A correct candidate must:
     *  - be internally similar,
     *  - leave the other four cards as another tight cluster, and
     *  - be clearly separated from that four-card cluster.
     */
    private fun findMinorityPosePair(bitmap: Bitmap): Pair<Int, Int>? {
        val samples = miniCardCenters.map { center ->
            extractCardSample(bitmap, center[0], center[1])
        }

        val n = samples.size
        val distance = Array(n) { FloatArray(n) }
        for (i in 0 until n - 1) {
            for (j in i + 1 until n) {
                val d = cardPoseDifference(samples[i], samples[j])
                distance[i][j] = d
                distance[j][i] = d
            }
        }

        var bestPair: Pair<Int, Int>? = null
        var bestScore = Float.MAX_VALUE
        var bestPairWithin = Float.MAX_VALUE
        var bestRestWithin = Float.MAX_VALUE
        var bestCross = 0f

        for (i in 0 until n - 1) {
            for (j in i + 1 until n) {
                val rest = ArrayList<Int>(4)
                for (k in 0 until n) {
                    if (k != i && k != j) rest.add(k)
                }

                val pairWithin = distance[i][j]

                var restSum = 0f
                var restCount = 0
                for (a in 0 until rest.size - 1) {
                    for (b in a + 1 until rest.size) {
                        restSum += distance[rest[a]][rest[b]]
                        restCount += 1
                    }
                }
                val restWithin = if (restCount > 0) restSum / restCount.toFloat() else Float.MAX_VALUE

                var crossSum = 0f
                var crossCount = 0
                for (target in intArrayOf(i, j)) {
                    for (other in rest) {
                        crossSum += distance[target][other]
                        crossCount += 1
                    }
                }
                val cross = if (crossCount > 0) crossSum / crossCount.toFloat() else 0f

                // Lower is better. A large cross-cluster separation is rewarded.
                val score = pairWithin + restWithin - (1.20f * cross)
                if (score < bestScore) {
                    bestScore = score
                    bestPair = Pair(i, j)
                    bestPairWithin = pairWithin
                    bestRestWithin = restWithin
                    bestCross = cross
                }
            }
        }

        val pair = bestPair ?: return null

        // Reject ambiguous frames while a card is animating. The two clusters
        // must be substantially farther apart than the noise inside each group.
        val withinNoise = maxOf(bestPairWithin, bestRestWithin)
        val separated = bestCross >= withinNoise * 1.45f + 0.025f
        val targetTight = bestPairWithin <= 0.20f

        return if (separated && targetTight) pair else null
    }

    private fun extractCardSample(bitmap: Bitmap, nx: Float, ny: Float): IntArray {
        val gridW = 40
        val gridH = 40
        val out = IntArray(gridW * gridH)
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val cx = nx * width.toFloat()
        val cy = ny * height.toFloat()

        // Crop only the inner card content: exclude the common brown border,
        // but keep enough area for standing/jumping/sliding pose differences.
        val halfW = width * 0.065f
        val halfH = height * 0.115f

        var index = 0
        for (gy in 0 until gridH) {
            val fy = (gy + 0.5f) / gridH.toFloat()
            val py = (cy - halfH + fy * halfH * 2f)
                .roundToInt()
                .coerceIn(0, height - 1)
            for (gx in 0 until gridW) {
                val fx = (gx + 0.5f) / gridW.toFloat()
                val px = (cx - halfW + fx * halfW * 2f)
                    .roundToInt()
                    .coerceIn(0, width - 1)
                out[index++] = bitmap.getPixel(px, py)
            }
        }
        return out
    }

    /**
     * Pose distance that suppresses the shared beige card background.
     * Different characters are fine; the algorithm compares the six cards
     * from the CURRENT screenshot only and groups them by rendered pose.
     */
    private fun cardPoseDifference(a: IntArray, b: IntArray): Float {
        if (a.size != b.size || a.isEmpty()) return Float.MAX_VALUE

        var sum = 0f
        for (i in a.indices) {
            val pa = a[i]
            val pb = b[i]
            val fgA = !isMiniCardBackground(pa)
            val fgB = !isMiniCardBackground(pb)

            if (fgA != fgB) {
                sum += 1.0f
            } else if (fgA) {
                val ar = (pa shr 16) and 0xFF
                val ag = (pa shr 8) and 0xFF
                val ab = pa and 0xFF
                val br = (pb shr 16) and 0xFF
                val bg = (pb shr 8) and 0xFF
                val bb = pb and 0xFF
                val rgb = (abs(ar - br) + abs(ag - bg) + abs(ab - bb)).toFloat() / (255f * 3f)
                sum += 0.20f * rgb
            }
        }

        return sum / a.size.toFloat()
    }

    private fun isMiniCardBackground(pixel: Int): Boolean {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return r > 185 &&
            g > 165 &&
            b > 135 &&
            (r - g) < 55 &&
            (g - b) < 65
    }

    private fun isGreen(pixel: Int): Boolean {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return g > 110 && g > r * 1.02f && g > b * 1.15f && r > 40
    }

    private fun isCyan(pixel: Int): Boolean {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return g > 110 && b > 110 && g > r * 1.20f && b > r * 1.20f
    }

    private fun isBeige(pixel: Int): Boolean {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return r > 205 && g > 185 && b > 155 && r - g < 45 && g - b < 55
    }

    private fun tapNormalized(nx: Float, ny: Float): Boolean {
        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val x = (nx.coerceIn(0f, 1f) * (width - 1)).roundToInt()
        val y = (ny.coerceIn(0f, 1f) * (height - 1)).roundToInt()

        synchronized(botTapLock) {
            val now = System.currentTimeMillis()
            val waitMs = (lastBotTapAt + GLOBAL_BOT_TAP_GAP_MS) - now
            if (waitMs > 0L) {
                Thread.sleep(waitMs)
            }

            val ok = RootMemoryClient.botTap(x, y)
            if (ok) {
                lastBotTapAt = System.currentTimeMillis()
            }
            return ok
        }
    }

    private fun launchGame(): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(CrgProfile.GAME_PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return runCatching {
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    private fun installStopOverlay() {
        if (stopView != null) return

        val view = TextView(context).apply {
            text = "■ STOP BOT"
            gravity = Gravity.CENTER
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.parseColor("#CCB91C1C"))
            setOnClickListener { stopBot() }
        }

        // Keep top-right free for CookieRun's generic X popup button.
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(180)
        }

        try {
            windowManager.addView(view, lp)
            stopView = view
        } catch (_: Exception) {
            stopView = null
        }
    }

    private fun removeStopOverlay() {
        stopView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }
        stopView = null
    }

    private fun notifyUi() {
        mainHandler.post { onUiChanged() }
    }

    private fun notifyUiFromWorker() {
        mainHandler.post { onUiChanged() }
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).roundToInt()
}
