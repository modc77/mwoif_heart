package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * XP/Coin V18 desired-state controller.
 *
 * Matches the verified Lua behavior:
 * - arm from Lobby
 * - bind the current gameplay-state map only while a Stage Character is live
 * - write raw run Coin/XP protected-int values once per Stage/value change
 * - let the game's own RunMetricConfig calculate final/mirror values
 * - OFF is non-destructive: it only disarms future writes
 * - values already written in the current Stage are NEVER rolled back to the Stage original
 * - re-enabling in the same Stage with the same value does not write again
 * - a new Character/state pair creates a fresh Stage binding automatically
 * - never write stale Stage pointers after a process/Character/state edge
 */
class RunRewardMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val TICK_MS = 50L
        private const val PROCESS_RECHECK_TICKS = 10
        private const val MAX_BUCKET_COUNT = 0x100000L
        private const val MAX_BUCKET_CHAIN = 512
        private const val MAX_LIST_CHAIN = 10000
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val stateGlobal: Long,
        val stageServiceGlobal: Long
    )

    private data class PropInfo(
        val key: Int,
        val node: Long,
        val valuePtr: Long,
        val keyPtr: Long,
        val value: Int
    )

    private data class StageRuntime(
        val character: Long,
        val state: Long,
        var xp: PropInfo?,
        var coin: PropInfo?,
        val originalXp: Int?,
        val originalCoin: Int?,
        var appliedXp: Int?,
        var appliedCoin: Int?
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var profile: RunRewardProfile? = null
    @Volatile private var runtime: Runtime? = null
    @Volatile private var stage: StageRuntime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var tickCounter = 0
    @Volatile private var nextResolveAt = 0L

    @Volatile private var xpEnabled = false
    @Volatile private var coinEnabled = false
    @Volatile private var xpWanted = 15000
    @Volatile private var coinWanted = 350000

    @Volatile private var xpStatus = "XP พร้อม • รอเปิด"
    @Volatile private var coinStatus = "Coin พร้อม • รอเปิด"

    fun cacheProfile(value: RunRewardProfile): ActionResult {
        if (
            value.imageBase <= 0L ||
            value.stateGlobal <= 0L ||
            value.stageServiceGlobal <= 0L ||
            value.mapOffset < 0L ||
            value.bucketArrayOffset < 0L ||
            value.bucketCountOffset < 0L ||
            value.listHeadOffset < 0L ||
            value.nodeNextOffset < 0L ||
            value.nodeHashOffset < 0L ||
            value.nodeKeyOffset < 0L ||
            value.nodeFieldOffset < 0L ||
            value.fieldTypeOffset < 0L ||
            value.fieldValuePtrOffset < 0L ||
            value.fieldFlagOffset < 0L ||
            value.fieldKeyPtrOffset < 0L ||
            value.serviceCharacterOffset < 0L ||
            value.serviceJellyManagerOffset < 0L ||
            value.jellyManagerCharacterOffset < 0L ||
            value.rawCoinKey <= 0 ||
            value.rawXpKey <= 0 ||
            value.finalCoinKey <= 0 ||
            value.finalXpKey <= 0 ||
            value.mirrorCoinKey <= 0 ||
            value.mirrorXpKey <= 0 ||
            value.expectedType <= 0 ||
            value.expectedFlag < 0
        ) {
            return failure("PROFILE_INVALID", "XP/Coin Secure Profile ไม่ครบ")
        }

        profile = value
        if (!xpEnabled) xpStatus = "XP พร้อม • เปิด ON ได้ทุกหน้า"
        if (!coinEnabled) coinStatus = "Coin พร้อม • เปิด ON ได้ทุกหน้า"
        ensureTask()
        return success("Secure XP/Coin Profile พร้อม")
    }

    fun setXpEnabled(
        enabled: Boolean,
        value: Int,
        callback: (ActionResult) -> Unit
    ) {
        if (value !in 0..FeatureCatalog.MAX_XP) {
            callback(failure("VALUE_INVALID", "ค่า XP ต้องอยู่ระหว่าง 0-${FeatureCatalog.MAX_XP}"))
            return
        }

        xpWanted = value
        xpEnabled = enabled
        ensureTask()

        executor.execute {
            if (!enabled) {
                // Non-destructive OFF. Do NOT restore the Stage original here.
                // The raw XP value may already have been consumed by gameplay and
                // rolling it back (commonly to 0) corrupts the current run.
                xpStatus = "XP OFF • ค่าที่ใช้แล้วใน Stage นี้คงไว้"
            } else {
                xpStatus = "XP ON • รอ CookieRun / Stage"
                safeTick()
            }
            callback(success(xpStatus))
        }
    }

    fun setCoinEnabled(
        enabled: Boolean,
        value: Int,
        callback: (ActionResult) -> Unit
    ) {
        if (value !in 0..FeatureCatalog.MAX_COIN) {
            callback(failure("VALUE_INVALID", "ค่า Coin ต้องอยู่ระหว่าง 0-${FeatureCatalog.MAX_COIN}"))
            return
        }

        coinWanted = value
        coinEnabled = enabled
        ensureTask()

        executor.execute {
            if (!enabled) {
                // Non-destructive OFF for the same reason as XP above.
                coinStatus = "Coin OFF • ค่าที่ใช้แล้วใน Stage นี้คงไว้"
            } else {
                coinStatus = "Coin ON • รอ CookieRun / Stage"
                safeTick()
            }
            callback(success(coinStatus))
        }
    }

    fun updateXpValue(value: Int) {
        if (value !in 0..FeatureCatalog.MAX_XP) return
        xpWanted = value
        stage?.appliedXp = null
        ensureTask()
        if (xpEnabled) executor.execute { safeTick() }
    }

    fun updateCoinValue(value: Int) {
        if (value !in 0..FeatureCatalog.MAX_COIN) return
        coinWanted = value
        stage?.appliedCoin = null
        ensureTask()
        if (coinEnabled) executor.execute { safeTick() }
    }

    fun isXpEnabled(): Boolean = xpEnabled
    fun isCoinEnabled(): Boolean = coinEnabled
    fun xpStatusText(): String = xpStatus
    fun coinStatusText(): String = coinStatus

    /**
     * Historical API name kept for service compatibility.
     *
     * V18.6 stage-safe semantics: this is now a DISARM operation only.
     * It intentionally performs no XP/Coin memory rollback.
     */
    fun restoreAllBlockingBestEffort() {
        xpEnabled = false
        coinEnabled = false
        stage = null
        runtime = null
        xpStatus = "XP OFF"
        coinStatus = "Coin OFF"
    }

    fun shutdown(restore: Boolean) {
        if (restore) {
            try {
                restoreAllBlockingBestEffort()
            } catch (_: Exception) {
            }
        }

        xpEnabled = false
        coinEnabled = false
        closed = true
        task?.cancel(false)
        task = null
        stage = null
        runtime = null
        profile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleAtFixedRate(
            { safeTick() },
            TICK_MS,
            TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun safeTick() {
        try {
            tick()
        } catch (t: Throwable) {
            if (xpEnabled) xpStatus = "XP ON • retry • ${t.javaClass.simpleName}"
            if (coinEnabled) coinStatus = "Coin ON • retry • ${t.javaClass.simpleName}"
            DevConsole.log("XPC", "tick ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun tick() {
        if (!xpEnabled && !coinEnabled) return

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RUN_REWARD)) {
            if (xpEnabled) xpStatus = "XP ON • กำลังอัปเดต • รอ Server"
            if (coinEnabled) coinStatus = "Coin ON • กำลังอัปเดต • รอ Server"
            return
        }

        tickCounter += 1

        var rt = runtime
        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) return
            nextResolveAt = now + 1000L

            val prepared = prepareRuntime()
            if (!prepared.ok) {
                val waitText = when (prepared.errorCode) {
                    "ROOT_REQUIRED" -> "รอ Root Worker"
                    "PROFILE_NOT_READY" -> "รอ Secure Profile"
                    "GAME_NOT_RUNNING" -> "รอ CookieRun"
                    else -> "กำลังจับ runtime ใหม่"
                }
                if (xpEnabled) xpStatus = "XP ON • $waitText"
                if (coinEnabled) coinStatus = "Coin ON • $waitText"
                return
            }
            rt = runtime ?: return
        }

        if (tickCounter % PROCESS_RECHECK_TICKS == 0) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                stage = null
                runtime = null
                nextResolveAt = 0L
                if (xpEnabled) xpStatus = if (livePid == null) "XP ON • รอ CookieRun" else "XP ON • พบเกมใหม่ • กำลังเชื่อม"
                if (coinEnabled) coinStatus = if (livePid == null) "Coin ON • รอ CookieRun" else "Coin ON • พบเกมใหม่ • กำลังเชื่อม"
                return
            }
        }

        val p = profile() ?: return
        val character = resolveCharacter(rt, p)
        if (!isPointer(character)) {
            stage = null
            if (xpEnabled) xpStatus = "XP ON • พร้อม • รอ Stage"
            if (coinEnabled) coinStatus = "Coin ON • พร้อม • รอ Stage"
            return
        }

        val statePointer = memory.readLong(rt.pid, rt.stateGlobal)
        if (!isPointer(statePointer ?: 0L)) {
            stage = null
            if (xpEnabled) xpStatus = "XP ON • กำลังจับ Stage..."
            if (coinEnabled) coinStatus = "Coin ON • กำลังจับ Stage..."
            return
        }

        var current = stage
        if (
            current == null ||
            current.character != character ||
            current.state != statePointer
        ) {
            current = bindStage(rt.pid, character, statePointer!!, p)
            if (current == null) {
                if (xpEnabled) xpStatus = "XP ON • กำลังจับ Stage XP..."
                if (coinEnabled) coinStatus = "Coin ON • กำลังจับ Stage Coin..."
                return
            }
            stage = current
            DevConsole.log(
                "XPC",
                "stage char=0x${character.toString(16)} state=0x${statePointer.toString(16)} xp=${current.originalXp} coin=${current.originalCoin}"
            )
        }

        if (xpEnabled && current.appliedXp != xpWanted) {
            val info = current.xp ?: run {
                stage = null
                return
            }
            val written = writeInfo(rt.pid, info, xpWanted, p)
            if (written == null) {
                current.xp = null
                stage = null
                xpStatus = "XP ON • เขียน/Verify ไม่ผ่าน • retry"
                return
            }
            current.xp = written
            current.appliedXp = xpWanted
            xpStatus = "XP ON • Stage = $xpWanted • Verify OK"
            DevConsole.log("XPC", "XP PASS raw=${p.rawXpKey} value=$xpWanted")
        }

        if (coinEnabled && current.appliedCoin != coinWanted) {
            val info = current.coin ?: run {
                stage = null
                return
            }
            val written = writeInfo(rt.pid, info, coinWanted, p)
            if (written == null) {
                current.coin = null
                stage = null
                coinStatus = "Coin ON • เขียน/Verify ไม่ผ่าน • retry"
                return
            }
            current.coin = written
            current.appliedCoin = coinWanted
            coinStatus = "Coin ON • Stage = $coinWanted • Verify OK"
            DevConsole.log("XPC", "COIN PASS raw=${p.rawCoinKey} value=$coinWanted")
        }
    }

    private fun bindStage(
        pid: Int,
        character: Long,
        state: Long,
        p: RunRewardProfile
    ): StageRuntime? {
        if (!probeStateMap(pid, state, p)) return null

        /*
         * Bind both raw metrics even if only one toggle is currently ON.
         * This preserves the true Stage originals when the second toggle is
         * enabled later in the same Stage.
         */
        val xp = findNode(pid, state, p.rawXpKey, p)?.let {
            validateNode(pid, it, p.rawXpKey, p)
        } ?: return null

        val coin = findNode(pid, state, p.rawCoinKey, p)?.let {
            validateNode(pid, it, p.rawCoinKey, p)
        } ?: return null

        return StageRuntime(
            character = character,
            state = state,
            xp = xp,
            coin = coin,
            originalXp = xp?.value,
            originalCoin = coin?.value,
            appliedXp = null,
            appliedCoin = null
        )
    }

    private fun resolveCharacter(rt: Runtime, p: RunRewardProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun probeStateMap(pid: Int, state: Long, p: RunRewardProfile): Boolean {
        val map = state + p.mapOffset
        val buckets = memory.readLong(pid, map + p.bucketArrayOffset) ?: return false
        val bucketCount = memory.readLong(pid, map + p.bucketCountOffset) ?: return false
        val listHead = memory.readLong(pid, map + p.listHeadOffset) ?: return false

        return isPointer(buckets) &&
            bucketCount in 1..MAX_BUCKET_COUNT &&
            isPointer(listHead) &&
            memory.readInt(pid, listHead + p.nodeKeyOffset) != null
    }

    private fun findNode(
        pid: Int,
        state: Long,
        propertyKey: Int,
        p: RunRewardProfile
    ): Long? {
        val map = state + p.mapOffset
        val buckets = memory.readLong(pid, map + p.bucketArrayOffset)
        val bucketCount = memory.readLong(pid, map + p.bucketCountOffset)

        if (
            buckets != null && isPointer(buckets) &&
            bucketCount != null && bucketCount in 1..MAX_BUCKET_COUNT
        ) {
            val unsignedKey = propertyKey.toLong() and 0xFFFFFFFFL
            val bucket = unsignedKey % bucketCount
            val predecessor = memory.readLong(pid, buckets + bucket * 8L)

            var node = if (predecessor != null && isPointer(predecessor)) {
                memory.readLong(pid, predecessor + p.nodeNextOffset)
            } else null

            var guard = 0
            while (node != null && isPointer(node) && guard < MAX_BUCKET_CHAIN) {
                val storedKey = memory.readInt(pid, node + p.nodeKeyOffset)
                val storedHash = memory.readLong(pid, node + p.nodeHashOffset)
                if (storedKey == propertyKey && storedHash == unsignedKey) return node
                node = memory.readLong(pid, node + p.nodeNextOffset)
                guard += 1
            }
        }

        var node = memory.readLong(pid, map + p.listHeadOffset)
        var guard = 0
        while (node != null && isPointer(node) && guard < MAX_LIST_CHAIN) {
            if (memory.readInt(pid, node + p.nodeKeyOffset) == propertyKey) return node
            node = memory.readLong(pid, node + p.nodeNextOffset)
            guard += 1
        }
        return null
    }

    private fun validateNode(
        pid: Int,
        node: Long,
        expectedKey: Int,
        p: RunRewardProfile
    ): PropInfo? {
        if (!isPointer(node)) return null
        if (memory.readInt(pid, node + p.nodeKeyOffset) != expectedKey) return null

        val field = node + p.nodeFieldOffset
        val valueType = memory.readInt(pid, field + p.fieldTypeOffset) ?: return null
        val flag = memory.readByteUnsigned(pid, field + p.fieldFlagOffset) ?: return null

        // Verified Lua XP/Coin profile requires protected int type=1, flag=1.
        if (valueType != p.expectedType || flag != p.expectedFlag) return null

        val valuePtr = memory.readLong(pid, field + p.fieldValuePtrOffset) ?: return null
        val keyPtr = memory.readLong(pid, field + p.fieldKeyPtrOffset) ?: return null
        if (!isPointer(valuePtr) || !isPointer(keyPtr)) return null

        val raw = memory.readInt(pid, valuePtr) ?: return null
        val xorKey = memory.readInt(pid, keyPtr) ?: return null
        val value = raw xor xorKey
        if (value < 0) return null

        return PropInfo(
            key = expectedKey,
            node = node,
            valuePtr = valuePtr,
            keyPtr = keyPtr,
            value = value
        )
    }

    private fun writeInfo(
        pid: Int,
        info: PropInfo,
        wanted: Int,
        p: RunRewardProfile
    ): PropInfo? {
        if (wanted < 0) return null
        val paused = memory.pause(pid)

        return try {
            val refreshed = validateNode(pid, info.node, info.key, p) ?: return null
            val xorKey = memory.readInt(pid, refreshed.keyPtr) ?: return null
            val encoded = wanted xor xorKey

            if (!memory.writeInt(pid, refreshed.valuePtr, encoded)) return null

            val verified = validateNode(pid, refreshed.node, refreshed.key, p)
            if (verified == null || verified.value != wanted) {
                val rollbackKey = memory.readInt(pid, refreshed.keyPtr)
                if (rollbackKey != null) {
                    memory.writeInt(pid, refreshed.valuePtr, refreshed.value xor rollbackKey)
                }
                return null
            }
            verified
        } finally {
            if (paused) memory.resume(pid)
        }
    }

    private fun prepareRuntime(): ActionResult {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ยังไม่มี Root Worker")
        }

        val p = profile() ?: return failure("PROFILE_NOT_READY", "Secure XP/Coin Profile ยังไม่พร้อม")
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: return failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return failure("LIBGAME_NOT_READY", "ยังไม่พบ libgame.so")

        val candidates = LinkedHashSet<Long>()
        for (range in ranges) {
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
            ?: return failure("ELF_NOT_FOUND", "หา ARM64 libgame ELF ไม่สำเร็จ")
        val loadBias = parseLoadBias(pid, elfBase)
            ?: return failure("LOAD_BIAS_FAILED", "หา libgame load bias ไม่สำเร็จ")

        val stateGlobal = loadBias + (p.stateGlobal - p.imageBase)
        val stageServiceGlobal = loadBias + (p.stageServiceGlobal - p.imageBase)
        if (stateGlobal < 0x10000L || stageServiceGlobal < 0x10000L) {
            return failure("GLOBAL_FAILED", "คำนวณ XP/Coin runtime global ไม่สำเร็จ")
        }

        if (memory.readLong(pid, stateGlobal) == null || memory.readLong(pid, stageServiceGlobal) == null) {
            return failure("GLOBAL_READ_FAILED", "อ่าน XP/Coin runtime global ไม่สำเร็จ")
        }

        runtime = Runtime(pid, stateGlobal, stageServiceGlobal)
        if (xpEnabled) xpStatus = "XP ON • พร้อม • รอ Stage"
        if (coinEnabled) coinStatus = "Coin ON • พร้อม • รอ Stage"
        DevConsole.log("XPC", "runtime pid=$pid bias=0x${loadBias.toString(16)}")
        return success("XP/Coin runtime พร้อม")
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF

        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun profile(): RunRewardProfile? = SecureProfileManager.getRunReward()

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun success(message: String) = ActionResult(true, null, message)
    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
