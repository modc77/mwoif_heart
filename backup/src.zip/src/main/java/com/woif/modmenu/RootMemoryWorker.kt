package com.woif.modmenu

import android.net.LocalServerSocket
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Runs inside a separate root `app_process`.
 *
 * No MOD offsets are embedded here.
 * It is only a generic authenticated memory worker.
 */
object RootMemoryWorker {

    private const val MAGIC =
        0x4D574F49

    private const val CMD_PING =
        1

    private const val CMD_FIND_PID =
        2

    private const val CMD_MAPS =
        3

    private const val CMD_OPEN_MEM =
        4

    private const val CMD_READ =
        5

    private const val CMD_WRITE =
        6

    private const val CMD_START_FLOAT_LOCK =
        7

    private const val CMD_STOP_LOCK =
        8

    private const val CMD_SIGNAL =
        9

    private const val CMD_EXIT =
        10

    private const val CMD_NATIVE_EFFECT =
        11

    private const val CMD_BOT_TAP =
        12

    private const val CMD_BOT_SCREENSHOT =
        13

    private const val NATIVE_EFFECT_CHANGED = 0
    private const val NATIVE_EFFECT_ALREADY = 1
    private const val NATIVE_EFFECT_NO_CHARACTER = 2
    private const val NATIVE_EFFECT_TIMEOUT = 3
    private const val NATIVE_EFFECT_INVALID_LAYOUT = 4
    private const val NATIVE_EFFECT_IO_FAILED = 5

    private const val NATIVE_COMMAND_APPLY = 1
    private const val NATIVE_COMMAND_REMOVE = 2

    private const val POINTER_MIN = 0x10000L
    private const val POINTER_MAX = 0x0001000000000000L

    private var memFile:
            RandomAccessFile? =
        null

    private var memChannel:
            FileChannel? =
        null

    private var openedPid =
        -1

    private val lockRunning =
        AtomicBoolean(
            false
        )

    @Volatile
    private var lockThread:
            Thread? =
        null

    @JvmStatic
    fun main(
        args:
            Array<String>
    ) {

        if (
            args.size <
            2
        ) {
            return
        }

        val socketName =
            args[0]

        val expectedToken =
            args[1]

        val server =
            try {

                LocalServerSocket(
                    socketName
                )

            } catch (
                e: Exception
            ) {
                return
            }

        try {

            server.accept()
                .use { socket ->

                    val input =
                        DataInputStream(
                            socket.inputStream
                        )

                    val output =
                        DataOutputStream(
                            socket.outputStream
                        )

                    val magic =
                        input.readInt()

                    val token =
                        input.readUTF()

                    if (
                        magic !=
                        MAGIC ||
                        token !=
                        expectedToken
                    ) {
                        return
                    }

                    output.writeInt(
                        MAGIC
                    )

                    output.flush()

                    loop(
                        input,
                        output
                    )
                }

        } catch (
            ignored: Exception
        ) {

        } finally {

            stopLock()
            closeMem()

            try {
                server.close()
            } catch (
                ignored: Exception
            ) {
            }
        }
    }

    private fun loop(
        input:
            DataInputStream,
        output:
            DataOutputStream
    ) {

        while (
            true
        ) {

            val command =
                try {
                    input.readInt()
                } catch (
                    e: Exception
                ) {
                    return
                }

            try {

                when (
                    command
                ) {

                    CMD_PING -> {
                        output.writeBoolean(
                            true
                        )
                    }

                    CMD_FIND_PID -> {
                        output.writeInt(
                            findPid(
                                input.readUTF()
                            )
                        )
                    }

                    CMD_MAPS -> {

                        val pid =
                            input.readInt()

                        val bytes =
                            readMaps(
                                pid
                            )
                                .toByteArray(
                                    Charsets.UTF_8
                                )

                        output.writeInt(
                            bytes.size
                        )

                        output.write(
                            bytes
                        )
                    }

                    CMD_OPEN_MEM -> {

                        val pid =
                            input.readInt()

                        output.writeBoolean(
                            openMem(
                                pid
                            )
                        )
                    }

                    CMD_READ -> {

                        val address =
                            input.readLong()

                        val count =
                            input.readInt()

                        val bytes =
                            readBytes(
                                address,
                                count
                            )

                        if (
                            bytes ==
                            null
                        ) {

                            output.writeInt(
                                -1
                            )

                        } else {

                            output.writeInt(
                                bytes.size
                            )

                            output.write(
                                bytes
                            )
                        }
                    }

                    CMD_WRITE -> {

                        val address =
                            input.readLong()

                        val count =
                            input.readInt()

                        if (
                            count <=
                            0 ||
                            count >
                            4096
                        ) {

                            output.writeBoolean(
                                false
                            )

                        } else {

                            val bytes =
                                ByteArray(
                                    count
                                )

                            input.readFully(
                                bytes
                            )

                            output.writeBoolean(
                                writeBytes(
                                    address,
                                    bytes
                                )
                            )
                        }
                    }

                    CMD_START_FLOAT_LOCK -> {

                        val address =
                            input.readLong()

                        val value =
                            input.readFloat()

                        val interval =
                            input.readInt()
                                .coerceIn(
                                    20,
                                    1000
                                )

                        output.writeBoolean(
                            startFloatLock(
                                address,
                                value,
                                interval
                            )
                        )
                    }

                    CMD_STOP_LOCK -> {

                        stopLock()

                        output.writeBoolean(
                            true
                        )
                    }

                    CMD_SIGNAL -> {

                        val pid =
                            input.readInt()

                        val signal =
                            input.readInt()

                        output.writeBoolean(
                            try {
                                android.system.Os.kill(
                                    pid,
                                    signal
                                )
                                true
                            } catch (
                                e: Exception
                            ) {
                                false
                            }
                        )
                    }

                    CMD_NATIVE_EFFECT -> {

                        try {
                            val pid = input.readInt()
                            val commandAddress = input.readLong()
                            val idAddress = input.readLong()
                            val nativeCommand = input.readInt()
                            val effectId = input.readInt()
                            val stageServiceGlobal = input.readLong()
                            val serviceCharacterOffset = input.readLong()
                            val serviceJellyManagerOffset = input.readLong()
                            val jellyManagerCharacterOffset = input.readLong()
                            val effectManagerOffset = input.readLong()
                            val effectBeginOffset = input.readLong()
                            val effectEndOffset = input.readLong()
                            val effectCapOffset = input.readLong()
                            val effectIdDirectOffset = input.readLong()
                            val effectIdAdjustedOffset = input.readLong()
                            val expectedCharacterVptr = input.readLong()
                            val expectedEffectManagerVptr = input.readLong()
                            val expectedEffectVptr = input.readLong()
                            val moduleStart = input.readLong()
                            val moduleEnd = input.readLong()
                            val maxEffects = input.readInt().coerceIn(1, 256)
                            val timeoutMs = input.readInt().coerceIn(250, 15000)

                            val result =
                                nativeEffectCommand(
                                    pid = pid,
                                    commandAddress = commandAddress,
                                    idAddress = idAddress,
                                    nativeCommand = nativeCommand,
                                    effectId = effectId,
                                    stageServiceGlobal = stageServiceGlobal,
                                    serviceCharacterOffset = serviceCharacterOffset,
                                    serviceJellyManagerOffset = serviceJellyManagerOffset,
                                    jellyManagerCharacterOffset = jellyManagerCharacterOffset,
                                    effectManagerOffset = effectManagerOffset,
                                    effectBeginOffset = effectBeginOffset,
                                    effectEndOffset = effectEndOffset,
                                    effectCapOffset = effectCapOffset,
                                    effectIdDirectOffset = effectIdDirectOffset,
                                    effectIdAdjustedOffset = effectIdAdjustedOffset,
                                    expectedCharacterVptr = expectedCharacterVptr,
                                    expectedEffectManagerVptr = expectedEffectManagerVptr,
                                    expectedEffectVptr = expectedEffectVptr,
                                    moduleStart = moduleStart,
                                    moduleEnd = moduleEnd,
                                    maxEffects = maxEffects,
                                    timeoutMs = timeoutMs
                                )

                            output.writeInt(result.first)
                            output.writeLong(result.second)

                        } catch (_: Exception) {
                            // Keep the socket protocol aligned for this command even
                            // if an unexpected read/write exception occurs.
                            output.writeInt(NATIVE_EFFECT_IO_FAILED)
                            output.writeLong(0L)
                        }
                    }

                    CMD_BOT_TAP -> {
                        val x = input.readInt()
                        val y = input.readInt()
                        output.writeBoolean(botTap(x, y))
                    }

                    CMD_BOT_SCREENSHOT -> {
                        val bytes = botScreenshotPng()
                        if (bytes == null) {
                            output.writeInt(-1)
                        } else {
                            output.writeInt(bytes.size)
                            output.write(bytes)
                        }
                    }

                    CMD_EXIT -> {

                        output.writeBoolean(
                            true
                        )

                        output.flush()

                        return
                    }

                    else -> {

                        output.writeBoolean(
                            false
                        )
                    }
                }

                output.flush()

            } catch (
                e: Exception
            ) {

                try {
                    output.writeBoolean(
                        false
                    )

                    output.flush()

                } catch (
                    ignored: Exception
                ) {
                    return
                }
            }
        }
    }

    private fun findPid(
        packageName:
            String
    ): Int {

        val proc =
            File(
                "/proc"
            )
                .listFiles()
                ?: return -1

        for (
            entry in
            proc
        ) {

            val pid =
                entry.name
                    .toIntOrNull()
                    ?: continue

            val cmdline =
                try {

                    File(
                        entry,
                        "cmdline"
                    )
                        .readBytes()
                        .takeWhile {
                            it.toInt() !=
                            0
                        }
                        .toByteArray()
                        .toString(
                            Charsets.UTF_8
                        )

                } catch (
                    e: Exception
                ) {
                    continue
                }

            if (
                cmdline ==
                packageName
            ) {
                return pid
            }
        }

        return -1
    }

    private fun readMaps(
        pid:
            Int
    ): String {

        return try {

            File(
                "/proc/$pid/maps"
            )
                .readText()

        } catch (
            e: Exception
        ) {

            ""
        }
    }

    @Synchronized
    private fun openMem(
        pid:
            Int
    ): Boolean {

        if (
            openedPid ==
            pid &&
            memChannel
                ?.isOpen ==
            true
        ) {
            return true
        }

        stopLock()
        closeMem()

        return try {

            val file =
                RandomAccessFile(
                    "/proc/$pid/mem",
                    "rw"
                )

            memFile =
                file

            memChannel =
                file.channel

            openedPid =
                pid

            true

        } catch (
            e: Exception
        ) {

            closeMem()

            false
        }
    }

    private fun readBytes(
        address:
            Long,
        count:
            Int
    ): ByteArray? {

        if (
            address <=
            0L ||
            count <=
            0 ||
            count >
            4096
        ) {
            return null
        }

        val channel =
            memChannel
                ?: return null

        val buffer =
            ByteBuffer.allocate(
                count
            )

        var total =
            0

        while (
            total <
            count
        ) {

            val read =
                channel.read(
                    buffer,
                    address +
                        total
                )

            if (
                read <=
                0
            ) {
                return null
            }

            total +=
                read
        }

        return buffer.array()
    }

    @Synchronized
    private fun writeBytes(
        address:
            Long,
        bytes:
            ByteArray
    ): Boolean {

        if (
            address <=
            0L ||
            bytes.isEmpty()
        ) {
            return false
        }

        val channel =
            memChannel
                ?: return false

        val buffer =
            ByteBuffer.wrap(
                bytes
            )

        var total =
            0

        while (
            buffer.hasRemaining()
        ) {

            val wrote =
                channel.write(
                    buffer,
                    address +
                        total
                )

            if (
                wrote <=
                0
            ) {
                return false
            }

            total +=
                wrote
        }

        return true
    }

    private enum class EffectInspectionState {
        PRESENT,
        ABSENT,
        NO_CHARACTER,
        INVALID
    }

    private data class EffectInspection(
        val state: EffectInspectionState,
        val character: Long = 0L
    )

    private fun nativeEffectCommand(
        pid: Int,
        commandAddress: Long,
        idAddress: Long,
        nativeCommand: Int,
        effectId: Int,
        stageServiceGlobal: Long,
        serviceCharacterOffset: Long,
        serviceJellyManagerOffset: Long,
        jellyManagerCharacterOffset: Long,
        effectManagerOffset: Long,
        effectBeginOffset: Long,
        effectEndOffset: Long,
        effectCapOffset: Long,
        effectIdDirectOffset: Long,
        effectIdAdjustedOffset: Long,
        expectedCharacterVptr: Long,
        expectedEffectManagerVptr: Long,
        expectedEffectVptr: Long,
        moduleStart: Long,
        moduleEnd: Long,
        maxEffects: Int,
        timeoutMs: Int
    ): Pair<Int, Long> {

        if (
            pid <= 0 ||
            openedPid != pid ||
            memChannel?.isOpen != true ||
            commandAddress <= 0L ||
            idAddress <= 0L ||
            stageServiceGlobal <= 0L ||
            moduleStart <= 0L ||
            moduleEnd <= moduleStart ||
            expectedCharacterVptr !in moduleStart until moduleEnd ||
            expectedEffectManagerVptr !in moduleStart until moduleEnd ||
            expectedEffectVptr !in moduleStart until moduleEnd ||
            effectId <= 0 ||
            (nativeCommand != NATIVE_COMMAND_APPLY &&
                nativeCommand != NATIVE_COMMAND_REMOVE)
        ) {
            return NATIVE_EFFECT_IO_FAILED to 0L
        }

        val before = inspectNativeEffect(
            effectId = effectId,
            stageServiceGlobal = stageServiceGlobal,
            serviceCharacterOffset = serviceCharacterOffset,
            serviceJellyManagerOffset = serviceJellyManagerOffset,
            jellyManagerCharacterOffset = jellyManagerCharacterOffset,
            effectManagerOffset = effectManagerOffset,
            effectBeginOffset = effectBeginOffset,
            effectEndOffset = effectEndOffset,
            effectCapOffset = effectCapOffset,
            effectIdDirectOffset = effectIdDirectOffset,
            effectIdAdjustedOffset = effectIdAdjustedOffset,
            expectedCharacterVptr = expectedCharacterVptr,
            expectedEffectManagerVptr = expectedEffectManagerVptr,
            expectedEffectVptr = expectedEffectVptr,
            moduleStart = moduleStart,
            moduleEnd = moduleEnd,
            maxEffects = maxEffects
        )

        if (before.state == EffectInspectionState.NO_CHARACTER) {
            writeIntAt(commandAddress, 0)
            return NATIVE_EFFECT_NO_CHARACTER to 0L
        }

        if (before.state == EffectInspectionState.INVALID) {
            writeIntAt(commandAddress, 0)
            return NATIVE_EFFECT_INVALID_LAYOUT to before.character
        }

        val wantsPresent = nativeCommand == NATIVE_COMMAND_APPLY
        val already =
            (wantsPresent && before.state == EffectInspectionState.PRESENT) ||
                (!wantsPresent && before.state == EffectInspectionState.ABSENT)

        if (already) {
            writeIntAt(commandAddress, 0)
            return NATIVE_EFFECT_ALREADY to before.character
        }

        // Payload first, command last. The target can never observe a new
        // command with a stale effect ID.
        if (!writeIntAt(idAddress, effectId)) {
            writeIntAt(commandAddress, 0)
            return NATIVE_EFFECT_IO_FAILED to before.character
        }

        if (!writeIntAt(commandAddress, nativeCommand)) {
            writeIntAt(commandAddress, 0)
            return NATIVE_EFFECT_IO_FAILED to before.character
        }

        val deadline = System.nanoTime() + timeoutMs.toLong() * 1_000_000L
        var spin = 0

        while (System.nanoTime() < deadline) {
            val current = inspectNativeEffect(
                effectId = effectId,
                stageServiceGlobal = stageServiceGlobal,
                serviceCharacterOffset = serviceCharacterOffset,
                serviceJellyManagerOffset = serviceJellyManagerOffset,
                jellyManagerCharacterOffset = jellyManagerCharacterOffset,
                effectManagerOffset = effectManagerOffset,
                effectBeginOffset = effectBeginOffset,
                effectEndOffset = effectEndOffset,
                effectCapOffset = effectCapOffset,
                effectIdDirectOffset = effectIdDirectOffset,
                effectIdAdjustedOffset = effectIdAdjustedOffset,
                expectedCharacterVptr = expectedCharacterVptr,
                expectedEffectManagerVptr = expectedEffectManagerVptr,
                expectedEffectVptr = expectedEffectVptr,
                moduleStart = moduleStart,
                moduleEnd = moduleEnd,
                maxEffects = maxEffects
            )

            val complete =
                (wantsPresent && current.state == EffectInspectionState.PRESENT) ||
                    (!wantsPresent && current.state == EffectInspectionState.ABSENT)

            if (complete) {
                // Clear the mailbox immediately. Do this before returning over
                // the socket so another Character frame cannot consume it.
                writeIntAt(commandAddress, 0)
                return NATIVE_EFFECT_CHANGED to current.character
            }

            if (current.state == EffectInspectionState.NO_CHARACTER) {
                writeIntAt(commandAddress, 0)
                return NATIVE_EFFECT_NO_CHARACTER to 0L
            }

            if (current.state == EffectInspectionState.INVALID) {
                writeIntAt(commandAddress, 0)
                return NATIVE_EFFECT_INVALID_LAYOUT to current.character
            }

            // Busy-poll the first ~2 ms to minimize the window in which the
            // RX mailbox can be consumed twice. After that, yield lightly.
            spin += 1
            if (spin > 128) {
                try {
                    Thread.sleep(1L)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    writeIntAt(commandAddress, 0)
                    return NATIVE_EFFECT_IO_FAILED to current.character
                }
            }
        }

        writeIntAt(commandAddress, 0)
        return NATIVE_EFFECT_TIMEOUT to before.character
    }

    /**
     * V2 live Character resolver.
     *
     * Ghidra confirmed a natural Super caller reading Character directly from
     * [StageService + serviceCharacterOffset]. The older
     * audited Lua JellyManager route remains a fallback for lifecycle windows.
     *
     * Do not require one exact Character/EffectManager vptr: valid runtime
     * subclasses can use different vtables.  Both vptrs must still point into
     * this exact libgame.so image, while Giant/Super effect vptr remains exact.
     */
    private fun inspectNativeEffect(
        effectId: Int,
        stageServiceGlobal: Long,
        serviceCharacterOffset: Long,
        serviceJellyManagerOffset: Long,
        jellyManagerCharacterOffset: Long,
        effectManagerOffset: Long,
        effectBeginOffset: Long,
        effectEndOffset: Long,
        effectCapOffset: Long,
        effectIdDirectOffset: Long,
        effectIdAdjustedOffset: Long,
        expectedCharacterVptr: Long,
        expectedEffectManagerVptr: Long,
        expectedEffectVptr: Long,
        moduleStart: Long,
        moduleEnd: Long,
        maxEffects: Int
    ): EffectInspection {

        val service = readLongAt(stageServiceGlobal)
            ?: return EffectInspection(EffectInspectionState.NO_CHARACTER)

        if (!isPointer(service)) {
            return EffectInspection(EffectInspectionState.NO_CHARACTER)
        }

        // Source A: Ghidra-confirmed natural caller path.
        val directCharacter =
            readLongAt(service + serviceCharacterOffset)

        if (directCharacter != null && isPointer(directCharacter)) {
            val direct = inspectNativeEffectAtCharacter(
                character = directCharacter,
                effectId = effectId,
                effectManagerOffset = effectManagerOffset,
                effectBeginOffset = effectBeginOffset,
                effectEndOffset = effectEndOffset,
                effectCapOffset = effectCapOffset,
                effectIdDirectOffset = effectIdDirectOffset,
                effectIdAdjustedOffset = effectIdAdjustedOffset,
                expectedEffectVptr = expectedEffectVptr,
                moduleStart = moduleStart,
                moduleEnd = moduleEnd,
                maxEffects = maxEffects
            )

            if (direct.state != EffectInspectionState.INVALID) {
                return direct
            }
        }

        // Source B: audited Lua fallback path.
        val jellyManager =
            readLongAt(service + serviceJellyManagerOffset)

        if (!isPointer(jellyManager ?: 0L)) {
            return EffectInspection(EffectInspectionState.NO_CHARACTER)
        }

        val fallbackCharacter =
            readLongAt(jellyManager!! + jellyManagerCharacterOffset)

        if (!isPointer(fallbackCharacter ?: 0L)) {
            return EffectInspection(EffectInspectionState.NO_CHARACTER)
        }

        return inspectNativeEffectAtCharacter(
            character = fallbackCharacter!!,
            effectId = effectId,
            effectManagerOffset = effectManagerOffset,
            effectBeginOffset = effectBeginOffset,
            effectEndOffset = effectEndOffset,
            effectCapOffset = effectCapOffset,
            effectIdDirectOffset = effectIdDirectOffset,
            effectIdAdjustedOffset = effectIdAdjustedOffset,
            expectedEffectVptr = expectedEffectVptr,
            moduleStart = moduleStart,
            moduleEnd = moduleEnd,
            maxEffects = maxEffects
        )
    }

    private fun inspectNativeEffectAtCharacter(
        character: Long,
        effectId: Int,
        effectManagerOffset: Long,
        effectBeginOffset: Long,
        effectEndOffset: Long,
        effectCapOffset: Long,
        effectIdDirectOffset: Long,
        effectIdAdjustedOffset: Long,
        expectedEffectVptr: Long,
        moduleStart: Long,
        moduleEnd: Long,
        maxEffects: Int
    ): EffectInspection {

        if (!isPointer(character)) {
            return EffectInspection(EffectInspectionState.NO_CHARACTER)
        }

        val characterVptr = readLongAt(character)
            ?: return EffectInspection(EffectInspectionState.INVALID, character)
        val managerVptr = readLongAt(character + effectManagerOffset)
            ?: return EffectInspection(EffectInspectionState.INVALID, character)

        if (
            characterVptr !in moduleStart until moduleEnd ||
            managerVptr !in moduleStart until moduleEnd
        ) {
            return EffectInspection(EffectInspectionState.INVALID, character)
        }

        val begin = readLongAt(character + effectBeginOffset)
            ?: return EffectInspection(EffectInspectionState.INVALID, character)
        val end = readLongAt(character + effectEndOffset)
            ?: return EffectInspection(EffectInspectionState.INVALID, character)
        val cap = readLongAt(character + effectCapOffset)
            ?: return EffectInspection(EffectInspectionState.INVALID, character)

        if (begin == 0L && end == 0L && cap == 0L) {
            return EffectInspection(EffectInspectionState.ABSENT, character)
        }

        if (
            !isPointer(begin) ||
            end < begin ||
            cap < end ||
            (end - begin) % 8L != 0L
        ) {
            return EffectInspection(EffectInspectionState.INVALID, character)
        }

        val count = (end - begin) / 8L
        if (count < 0L || count > maxEffects.toLong()) {
            return EffectInspection(EffectInspectionState.INVALID, character)
        }

        for (index in 0 until count.toInt()) {
            val pointer = readLongAt(begin + index * 8L)
                ?: return EffectInspection(EffectInspectionState.INVALID, character)

            if (!isPointer(pointer)) {
                continue
            }

            val directId = readIntAt(pointer + effectIdDirectOffset)
            if (directId == effectId) {
                val vptr = readLongAt(pointer)
                if (vptr == expectedEffectVptr) {
                    return EffectInspection(EffectInspectionState.PRESENT, character)
                }
            }

            val adjustedId = readIntAt(pointer + effectIdAdjustedOffset)
            if (adjustedId == effectId && pointer >= POINTER_MIN + 8L) {
                val vptr = readLongAt(pointer - 8L)
                if (vptr == expectedEffectVptr) {
                    return EffectInspection(EffectInspectionState.PRESENT, character)
                }
            }
        }

        return EffectInspection(EffectInspectionState.ABSENT, character)
    }

    private fun botTap(x: Int, y: Int): Boolean {
        if (x < 0 || y < 0) return false

        return try {
            val process = ProcessBuilder(
                "/system/bin/input",
                "tap",
                x.toString(),
                y.toString()
            )
                .redirectErrorStream(true)
                .start()

            process.inputStream.use { it.readBytes() }
            process.waitFor() == 0
        } catch (_: Exception) {
            false
        }
    }

    private fun botScreenshotPng(): ByteArray? {
        return try {
            val process = ProcessBuilder(
                "/system/bin/screencap",
                "-p"
            )
                .redirectErrorStream(true)
                .start()

            val bytes = process.inputStream.use { it.readBytes() }
            val ok = process.waitFor() == 0

            if (!ok || bytes.isEmpty() || bytes.size > 16 * 1024 * 1024) {
                null
            } else {
                bytes
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isPointer(value: Long): Boolean =
        value >= POINTER_MIN &&
            value < POINTER_MAX &&
            value % 8L == 0L

    private fun readLongAt(address: Long): Long? {
        val bytes = readBytes(address, 8)
            ?: return null

        return ByteBuffer.wrap(bytes)
            .order(ByteOrder.LITTLE_ENDIAN)
            .long
    }

    private fun readIntAt(address: Long): Int? {
        val bytes = readBytes(address, 4)
            ?: return null

        return ByteBuffer.wrap(bytes)
            .order(ByteOrder.LITTLE_ENDIAN)
            .int
    }

    private fun writeIntAt(address: Long, value: Int): Boolean {
        val bytes = ByteBuffer.allocate(4)
            .order(ByteOrder.LITTLE_ENDIAN)
            .putInt(value)
            .array()

        return writeBytes(address, bytes)
    }

    private fun startFloatLock(
        address:
            Long,
        value:
            Float,
        intervalMs:
            Int
    ): Boolean {

        if (
            memChannel
                ?.isOpen !=
            true ||
            address <=
            0L ||
            value.isNaN() ||
            value.isInfinite()
        ) {
            return false
        }

        stopLock()

        val bytes =
            ByteBuffer
                .allocate(
                    4
                )
                .order(
                    ByteOrder.LITTLE_ENDIAN
                )
                .putFloat(
                    value
                )
                .array()

        if (
            !writeBytes(
                address,
                bytes
            )
        ) {
            return false
        }

        lockRunning.set(
            true
        )

        val thread =
            Thread(
                {

                    while (
                        lockRunning
                            .get()
                    ) {

                        if (
                            !writeBytes(
                                address,
                                bytes
                            )
                        ) {
                            break
                        }

                        try {

                            Thread.sleep(
                                intervalMs
                                    .toLong()
                            )

                        } catch (
                            e: InterruptedException
                        ) {

                            break
                        }
                    }

                    lockRunning.set(
                        false
                    )
                },
                "mw-rw"
            )
                .apply {
                    isDaemon =
                        true
                }

        lockThread =
            thread

        thread.start()

        return true
    }

    private fun stopLock() {

        lockRunning.set(
            false
        )

        lockThread
            ?.interrupt()

        try {
            lockThread
                ?.join(
                    250L
                )
        } catch (
            ignored: Exception
        ) {
        }

        lockThread =
            null
    }

    @Synchronized
    private fun closeMem() {

        try {
            memChannel
                ?.close()
        } catch (
            ignored: Exception
        ) {
        }

        try {
            memFile
                ?.close()
        } catch (
            ignored: Exception
        ) {
        }

        memChannel =
            null

        memFile =
            null

        openedPid =
            -1
    }

    private fun List<Byte>
        .toByteArray():
            ByteArray {

        val result =
            ByteArray(
                size
            )

        for (
            index in
            indices
        ) {
            result[index] =
                this[index]
        }

        return result
    }
}
