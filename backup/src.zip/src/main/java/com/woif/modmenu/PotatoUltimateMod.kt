package com.woif.modmenu

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Potato Ultimate desired-state controller (f07_v2).
 *
 * Lua/Ghidra-verified Potato fields:
 *   object + counterOffset         = protected int, 3-shot state counter
 *   object + durationConfigOffset  = protected float, Ultimate duration config
 *   object + durationCurrentOffset = protected float, live Ultimate countdown
 *
 * Entry is detected from counter 2 -> 0, matching the working Lua flow.
 * LONG keeps the configured duration at the selected value and seeds the live
 * countdown on entry. INFINITE refills the live countdown from 6s back to 8s
 * while Ultimate is active. All touched fields are restored on OFF when the
 * same live Stage/Object can still be verified.
 */
class PotatoUltimateMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val TICK_MS = 50L
        private const val PROCESS_RECHECK_TICKS = 10
        private const val MAX_OBJECTS = 2048
        private const val MIN_DURATION_SECONDS = 1.0f
        private const val MAX_DURATION_SECONDS = 86_400.0f
        private const val INFINITE_HOLD_SECONDS = 8.0f
        private const val INFINITE_REFILL_BELOW_SECONDS = 6.0f
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private data class Runtime(
        val pid: Int,
        val loadBias: Long,
        val stageServiceGlobal: Long,
        val potatoVtableRuntime: Long
    )

    private data class ProtectedFieldInfo(
        val p8: Long,
        val p10: Long,
        val p18: Long,
        val salt: Int
    )

    private data class StageRuntime(
        val character: Long,
        val objectAddress: Long,
        val originalConfigBits: Int,
        val originalCurrentBits: Int,
        var lastCounter: Int,
        var active: Boolean = false,
        var configModified: Boolean = false,
        var currentModified: Boolean = false
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var profile: PotatoProfile? = null
    @Volatile private var runtime: Runtime? = null
    @Volatile private var stage: StageRuntime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var tickCounter = 0
    @Volatile private var nextResolveAt = 0L

    @Volatile private var enabled = false
    @Volatile private var infinite = false
    @Volatile private var targetSeconds = 300.0f
    @Volatile private var status = "Potato อัลติเมต พร้อม • รอเปิด"

    fun cacheProfile(value: PotatoProfile): ActionResult {
        if (
            value.imageBase <= 0L ||
            value.stageServiceGlobal <= 0L ||
            value.serviceCharacterOffset < 0L ||
            value.serviceJellyManagerOffset < 0L ||
            value.jellyManagerCharacterOffset < 0L ||
            value.potatoListPointerOffset < 0L ||
            value.vectorBeginOffset < 0L ||
            value.vectorEndOffset < 0L ||
            value.potatoVtable <= 0L ||
            value.ultimateCounterOffset <= 0L ||
            value.ultimateDurationConfigOffset <= 0L ||
            value.ultimateDurationCurrentOffset <= 0L ||
            value.protectedPtr8Offset < 0L ||
            value.protectedPtr10Offset < 0L ||
            value.protectedPtr18Offset < 0L ||
            value.protectedSaltOffset < 0L ||
            value.protectedTable.size != 100
        ) {
            return failure("PROFILE_INVALID", "Potato Ultimate Secure Profile ยังไม่รองรับ f07_v2")
        }

        profile = value
        if (!enabled) status = "Potato อัลติเมต พร้อม • กด ON ได้ทุกหน้า"
        ensureTask()
        return success("Secure Potato Ultimate Profile พร้อม")
    }

    fun setEnabled(
        enable: Boolean,
        infiniteMode: Boolean,
        seconds: Int,
        callback: (ActionResult) -> Unit
    ) {
        if (seconds.toFloat() !in MIN_DURATION_SECONDS..MAX_DURATION_SECONDS) {
            callback(failure("VALUE_INVALID", "ระยะเวลา Potato Ultimate ไม่ถูกต้อง"))
            return
        }

        infinite = infiniteMode
        targetSeconds = seconds.toFloat()
        enabled = enable
        ensureTask()

        executor.execute {
            if (!enable) {
                restoreIfSafe()
                stage = null
                status = "Potato อัลติเมต OFF"
            } else {
                status = modeWaitingStatus()
                safeTick()
            }
            callback(success(status))
        }
    }

    fun updateValue(infiniteMode: Boolean, seconds: Int) {
        if (seconds.toFloat() !in MIN_DURATION_SECONDS..MAX_DURATION_SECONDS) return
        infinite = infiniteMode
        targetSeconds = seconds.toFloat()
        ensureTask()
        if (enabled) executor.execute { safeTick() }
    }

    fun isEnabled(): Boolean = enabled
    fun isActive(): Boolean = stage?.active == true
    fun statusText(): String = status

    fun restoreBlockingBestEffort() {
        enabled = false
        restoreIfSafe()
        stage = null
        runtime = null
        status = "Potato อัลติเมต OFF"
    }

    fun shutdown(restore: Boolean) {
        if (restore) {
            try {
                restoreBlockingBestEffort()
            } catch (_: Exception) {
            }
        }
        enabled = false
        closed = true
        task?.cancel(false)
        task = null
        stage = null
        runtime = null
        profile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleAtFixedRate(
            { safeTick() },
            TICK_MS,
            TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun safeTick() {
        try {
            tick()
        } catch (t: Throwable) {
            if (enabled) status = "Potato อัลติเมต ON • retry • ${t.javaClass.simpleName}"
            DevConsole.log("POT", "ultimate tick ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun tick() {
        if (!enabled) return

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_POTATO)) {
            status = "Potato อัลติเมต ON • กำลังอัปเดต • รอ Server"
            return
        }

        tickCounter += 1

        var rt = runtime
        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) return
            nextResolveAt = now + 1000L

            val prepared = prepareRuntime()
            if (!prepared.ok) {
                status = when (prepared.errorCode) {
                    "ROOT_REQUIRED" -> "Potato อัลติเมต ON • รอ Root Worker"
                    "PROFILE_NOT_READY" -> "Potato อัลติเมต ON • รอ Secure Profile"
                    "GAME_NOT_RUNNING" -> "Potato อัลติเมต ON • รอ CookieRun"
                    else -> "Potato อัลติเมต ON • กำลังจับ runtime ใหม่"
                }
                return
            }
            rt = runtime ?: return
        }

        if (tickCounter % PROCESS_RECHECK_TICKS == 0) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                stage = null
                runtime = null
                nextResolveAt = 0L
                status = if (livePid == null) {
                    "Potato อัลติเมต ON • รอ CookieRun"
                } else {
                    "Potato อัลติเมต ON • พบเกมใหม่ • กำลังเชื่อม"
                }
                return
            }
        }

        val p = profile() ?: return
        val character = resolveCharacter(rt, p)
        if (!isPointer(character)) {
            stage = null
            status = "Potato อัลติเมต ON • พร้อม • รอ Stage"
            return
        }

        val potato = findPotatoObject(rt, character, p)
        if (!isPointer(potato)) {
            stage = null
            status = "Potato อัลติเมต ON • รอ Potato object"
            return
        }

        var current = stage
        if (current == null || current.character != character || current.objectAddress != potato) {
            val configBits = decodeProtectedBits(
                rt.pid,
                potato + p.ultimateDurationConfigOffset,
                p
            ) ?: return
            val currentBits = decodeProtectedBits(
                rt.pid,
                potato + p.ultimateDurationCurrentOffset,
                p
            ) ?: return
            val counter = decodeProtectedBits(
                rt.pid,
                potato + p.ultimateCounterOffset,
                p
            ) ?: return

            val configValue = java.lang.Float.intBitsToFloat(configBits)
            val currentValue = java.lang.Float.intBitsToFloat(currentBits)
            if (counter !in 0..3 || !configValue.isFinite() || !currentValue.isFinite()) {
                return
            }

            current = StageRuntime(
                character = character,
                objectAddress = potato,
                originalConfigBits = configBits,
                originalCurrentBits = currentBits,
                lastCounter = counter
            )
            stage = current

            if (!infinite && !applyDurationConfig(rt, current, p)) {
                stage = null
                return
            }

            DevConsole.log(
                "POT",
                "ultimate bind char=0x${character.toString(16)} obj=0x${potato.toString(16)} counter=$counter"
            )
        }

        applyUltimate(rt, current, p)
    }

    private fun applyUltimate(rt: Runtime, current: StageRuntime, p: PotatoProfile) {
        val counter = decodeProtectedBits(
            rt.pid,
            current.objectAddress + p.ultimateCounterOffset,
            p
        ) ?: run {
            stage = null
            return
        }
        if (counter !in 0..3) {
            stage = null
            return
        }

        val enteredUltimate = current.lastCounter == 2 && counter == 0
        current.lastCounter = counter

        if (enteredUltimate) {
            current.active = true

            if (infinite) {
                val live = readProtectedFloat(
                    rt.pid,
                    current.objectAddress + p.ultimateDurationCurrentOffset,
                    p
                ) ?: return

                if (live < INFINITE_HOLD_SECONDS) {
                    if (!writeDurationCurrent(rt, current, p, INFINITE_HOLD_SECONDS)) return
                }
            } else {
                if (!applyDurationConfig(rt, current, p)) return
                if (!writeDurationCurrent(rt, current, p, targetSeconds)) return
            }
        }

        if (current.active) {
            val live = readProtectedFloat(
                rt.pid,
                current.objectAddress + p.ultimateDurationCurrentOffset,
                p
            ) ?: return

            if (live <= 0.0f) {
                current.active = false
            } else if (infinite && live < INFINITE_REFILL_BELOW_SECONDS) {
                if (!writeDurationCurrent(rt, current, p, INFINITE_HOLD_SECONDS)) return
            }
        }

        if (!infinite) {
            if (!applyDurationConfig(rt, current, p)) return
        }

        status = if (current.active) {
            if (infinite) {
                "Potato อัลติเมต ON • ไม่หมด • กำลังทำงาน • Verify OK"
            } else {
                "Potato อัลติเมต ON • ${durationLabel()} • กำลังทำงาน • Verify OK"
            }
        } else {
            modeWaitingStatus()
        }
    }

    private fun applyDurationConfig(rt: Runtime, current: StageRuntime, p: PotatoProfile): Boolean {
        if (infinite) return true
        val field = current.objectAddress + p.ultimateDurationConfigOffset
        val value = readProtectedFloat(rt.pid, field, p) ?: return false
        val target = targetSeconds
        val tolerance = maxOf(0.001f, abs(target) * 0.001f)
        if (abs(value - target) <= tolerance) return true

        val bits = java.lang.Float.floatToRawIntBits(target)
        if (!writeProtectedBits(rt.pid, field, bits, p)) {
            status = "Potato อัลติเมต ON • เขียน Duration Config ไม่สำเร็จ"
            return false
        }
        current.configModified = true
        return true
    }

    private fun writeDurationCurrent(
        rt: Runtime,
        current: StageRuntime,
        p: PotatoProfile,
        value: Float
    ): Boolean {
        val bits = java.lang.Float.floatToRawIntBits(value)
        val field = current.objectAddress + p.ultimateDurationCurrentOffset
        if (!writeProtectedBits(rt.pid, field, bits, p)) {
            status = "Potato อัลติเมต ON • เขียน Duration Current ไม่สำเร็จ"
            return false
        }
        current.currentModified = true
        return true
    }

    private fun restoreIfSafe() {
        val p = profile() ?: return
        val rt = runtime ?: return
        val current = stage ?: return

        if (memory.pidOf(CrgProfile.GAME_PACKAGE) != rt.pid) return
        if (resolveCharacter(rt, p) != current.character) return
        if (findPotatoObject(rt, current.character, p) != current.objectAddress) return

        if (current.configModified) {
            writeProtectedBits(
                rt.pid,
                current.objectAddress + p.ultimateDurationConfigOffset,
                current.originalConfigBits,
                p
            )
        }

        if (current.currentModified) {
            writeProtectedBits(
                rt.pid,
                current.objectAddress + p.ultimateDurationCurrentOffset,
                current.originalCurrentBits,
                p
            )
        }

        DevConsole.log("POT", "ultimate restore obj=0x${current.objectAddress.toString(16)}")
    }

    private fun findPotatoObject(rt: Runtime, character: Long, p: PotatoProfile): Long {
        val list = memory.readLong(rt.pid, character + p.potatoListPointerOffset) ?: return 0L
        if (!isPointer(list)) return 0L

        val begin = memory.readLong(rt.pid, list + p.vectorBeginOffset) ?: return 0L
        val end = memory.readLong(rt.pid, list + p.vectorEndOffset) ?: return 0L
        if (!isPointer(begin) || end < begin || end - begin > MAX_OBJECTS.toLong() * 8L) return 0L
        if ((end - begin) % 8L != 0L) return 0L

        var found = 0L
        var cursor = begin
        while (cursor < end) {
            val obj = memory.readLong(rt.pid, cursor) ?: return 0L
            if (isPointer(obj)) {
                val vtable = memory.readLong(rt.pid, obj)
                if (vtable == rt.potatoVtableRuntime) {
                    val counterInfo = protectedFieldInfo(rt.pid, obj + p.ultimateCounterOffset, p)
                    val configInfo = protectedFieldInfo(rt.pid, obj + p.ultimateDurationConfigOffset, p)
                    val currentInfo = protectedFieldInfo(rt.pid, obj + p.ultimateDurationCurrentOffset, p)
                    if (counterInfo != null && configInfo != null && currentInfo != null) {
                        if (found != 0L && found != obj) {
                            DevConsole.log("POT", "multiple Potato objects in current list")
                            return 0L
                        }
                        found = obj
                    }
                }
            }
            cursor += 8L
        }
        return found
    }

    private fun protectedFieldInfo(pid: Int, field: Long, p: PotatoProfile): ProtectedFieldInfo? {
        val p8 = memory.readLong(pid, field + p.protectedPtr8Offset) ?: return null
        val p10 = memory.readLong(pid, field + p.protectedPtr10Offset) ?: return null
        val p18 = memory.readLong(pid, field + p.protectedPtr18Offset) ?: return null
        val salt = memory.readInt(pid, field + p.protectedSaltOffset) ?: return null
        if (!isPointer(p8) || !isPointer(p10) || !isPointer(p18)) return null
        return ProtectedFieldInfo(p8, p10, p18, salt)
    }

    private fun decodeProtectedBits(pid: Int, field: Long, p: PotatoProfile): Int? {
        val info = protectedFieldInfo(pid, field, p) ?: return null
        val bytes = memory.readBytes(pid, info.p8, 4) ?: return null
        if (bytes.size != 4) return null

        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF

        val d0 = ((256 - b3) and 0xFF) xor 0xC6
        val d1 = ((256 - b2) and 0xFF) xor 0x3A
        val d2 = ((256 - b1) and 0xFF) xor 0xC6
        val d3 = ((256 - b0) and 0xFF) xor 0x3A

        return d0 or (d1 shl 8) or (d2 shl 16) or (d3 shl 24)
    }

    private fun readProtectedFloat(pid: Int, field: Long, p: PotatoProfile): Float? {
        val bits = decodeProtectedBits(pid, field, p) ?: return null
        val value = java.lang.Float.intBitsToFloat(bits)
        return if (value.isFinite()) value else null
    }

    private fun writeProtectedBits(pid: Int, field: Long, bits: Int, p: PotatoProfile): Boolean {
        val info = protectedFieldInfo(pid, field, p) ?: return false
        val table = p.protectedTable
        if (table.size != 100) return false

        val b0 = bits and 0xFF
        val b1 = (bits ushr 8) and 0xFF
        val b2 = (bits ushr 16) and 0xFF
        val b3 = (bits ushr 24) and 0xFF

        val e8 = byteArrayOf(
            (((b3 xor 0xC5) + 1) and 0xFF).toByte(),
            (((b2 xor 0x39) + 1) and 0xFF).toByte(),
            (((b1 xor 0xC5) + 1) and 0xFF).toByte(),
            (((b0 xor 0x39) + 1) and 0xFF).toByte()
        )

        val e10 = byteArrayOf(
            (((b0 xor 0x6A) + 1) and 0xFF).toByte(),
            (((b1 xor 0x94) + 1) and 0xFF).toByte(),
            (((b2 xor 0x6A) + 1) and 0xFF).toByte(),
            (((b3 xor 0x94) + 1) and 0xFF).toByte()
        )

        val salt = info.salt.toLong() and 0xFFFF_FFFFL
        fun tableAt(delta: Int): Int {
            val index = ((salt + delta.toLong()) % 100L).toInt()
            return table[index].toInt() and 0xFF
        }

        val e18 = byteArrayOf(
            (b3 xor ((256 - tableAt(0)) and 0xFF)).toByte(),
            (b2 xor tableAt(1)).toByte(),
            (b1 xor ((256 - tableAt(2)) and 0xFF)).toByte(),
            (b0 xor tableAt(3)).toByte()
        )

        val old8 = memory.readBytes(pid, info.p8, 4) ?: return false
        val old10 = memory.readBytes(pid, info.p10, 4) ?: return false
        val old18 = memory.readBytes(pid, info.p18, 4) ?: return false

        val paused = memory.pause(pid)
        return try {
            val wrote = memory.writeBytes(pid, info.p8, e8) &&
                memory.writeBytes(pid, info.p10, e10) &&
                memory.writeBytes(pid, info.p18, e18)
            val verified = wrote && decodeProtectedBits(pid, field, p) == bits

            if (!verified) {
                memory.writeBytes(pid, info.p8, old8)
                memory.writeBytes(pid, info.p10, old10)
                memory.writeBytes(pid, info.p18, old18)
            }

            verified
        } finally {
            if (paused) memory.resume(pid)
        }
    }

    private fun resolveCharacter(rt: Runtime, p: PotatoProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun prepareRuntime(): ActionResult {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ยังไม่มี Root Worker")
        }

        val p = profile() ?: return failure("PROFILE_NOT_READY", "Secure Potato Profile ยังไม่พร้อม")
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: return failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return failure("LIBGAME_NOT_READY", "ยังไม่พบ libgame.so")

        val candidates = LinkedHashSet<Long>()
        for (range in ranges) {
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
            ?: return failure("ELF_NOT_FOUND", "หา ARM64 libgame ELF ไม่สำเร็จ")
        val loadBias = parseLoadBias(pid, elfBase)
            ?: return failure("LOAD_BIAS_FAILED", "หา libgame load bias ไม่สำเร็จ")

        val stageServiceGlobal = loadBias + (p.stageServiceGlobal - p.imageBase)
        val potatoVtableRuntime = loadBias + (p.potatoVtable - p.imageBase)
        if (stageServiceGlobal < 0x10000L || potatoVtableRuntime < 0x10000L) {
            return failure("RUNTIME_ADDRESS_FAILED", "คำนวณ Potato runtime address ไม่สำเร็จ")
        }

        if (memory.readLong(pid, stageServiceGlobal) == null) {
            return failure("GLOBAL_READ_FAILED", "อ่าน Potato StageService global ไม่สำเร็จ")
        }

        runtime = Runtime(pid, loadBias, stageServiceGlobal, potatoVtableRuntime)
        status = "Potato อัลติเมต ON • พร้อม • รอ Stage"
        DevConsole.log(
            "POT",
            "ultimate runtime pid=$pid bias=0x${loadBias.toString(16)} vtable=0x${potatoVtableRuntime.toString(16)}"
        )
        return success("Potato Ultimate runtime พร้อม")
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun durationLabel(): String {
        val seconds = targetSeconds.toInt()
        return if (seconds % 60 == 0) "${seconds / 60} นาที" else "$seconds วินาที"
    }

    private fun modeWaitingStatus(): String = if (infinite) {
        "Potato อัลติเมต ON • ไม่หมด • รอเข้าอัลติเมต"
    } else {
        "Potato อัลติเมต ON • ${durationLabel()} • รอเข้าอัลติเมต"
    }

    private fun profile(): PotatoProfile? {
        val active = SecureProfileManager.getPotato()
        if (active == null) {
            this.profile = null
            return null
        }
        if (this.profile !== active) this.profile = active
        return active
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun success(message: String) = ActionResult(true, null, message)
    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
