package com.woif.modmenu

import android.content.Context
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.util.Log
import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

object RootMemoryClient {

    private const val TAG =
        "WOIF_ROOT"

    private const val MAGIC =
        0x4D574F49

    private const val CMD_PING =
        1

    private const val CMD_FIND_PID =
        2

    private const val CMD_MAPS =
        3

    private const val CMD_OPEN_MEM =
        4

    private const val CMD_READ =
        5

    private const val CMD_WRITE =
        6

    private const val CMD_START_FLOAT_LOCK =
        7

    private const val CMD_STOP_LOCK =
        8

    private const val CMD_SIGNAL =
        9

    private const val CMD_EXIT =
        10

    private const val CMD_NATIVE_EFFECT =
        11

    private const val CMD_BOT_TAP =
        12

    private const val CMD_BOT_SCREENSHOT =
        13

    const val NATIVE_EFFECT_CHANGED = 0
    const val NATIVE_EFFECT_ALREADY = 1
    const val NATIVE_EFFECT_NO_CHARACTER = 2
    const val NATIVE_EFFECT_TIMEOUT = 3
    const val NATIVE_EFFECT_INVALID_LAYOUT = 4
    const val NATIVE_EFFECT_IO_FAILED = 5

    data class NativeEffectCommandResult(
        val status: Int,
        val character: Long
    )

    private val ioLock =
        Any()

    @Volatile
    private var ready =
        false

    private var socket:
            LocalSocket? =
        null

    private var input:
            DataInputStream? =
        null

    private var output:
            DataOutputStream? =
        null

    private var suProcess:
            Process? =
        null

    private var openedPid =
        -1

    fun isReady():
            Boolean {

        if (
            !ready
        ) {
            return false
        }

        return try {
            ping()
        } catch (
            e: Exception
        ) {
            false
        }
    }

    fun ensureStarted(
        context:
        Context
    ): Boolean {

        synchronized(
            ioLock
        ) {

            if (
                ready &&
                pingLocked()
            ) {
                return true
            }

            closeLocked(
                sendExit =
                false
            )

            /*
             * Important for Magisk/MuMu:
             *
             * Trigger a simple, foreground-visible `su -c id -u` request
             * BEFORE launching the long-running app_process worker.
             *
             * This is intentionally the same style that previously caused
             * Magisk to show the Superuser popup reliably.
             */
            if (
                !requestRootPermissionLocked()
            ) {

                Log.w(
                    TAG,
                    "Root preflight denied or timed out"
                )

                return false
            }

            Log.d(
                TAG,
                "Root preflight granted"
            )

            val random =
                SecureRandom()

            val tokenBytes =
                ByteArray(
                    24
                )

            random.nextBytes(
                tokenBytes
            )

            val token =
                tokenBytes
                    .joinToString(
                        ""
                    ) {
                        "%02x".format(
                            it
                        )
                    }

            val socketName =
                "mw_" +
                        token.take(
                            16
                        )

            val apk =
                context
                    .applicationInfo
                    .sourceDir

            val command =
                "export CLASSPATH=" +
                        shellQuote(
                            apk
                        ) +
                        "; exec app_process " +
                        "/system/bin " +
                        "--nice-name=mwcore " +
                        "com.woif.modmenu.RootMemoryWorker " +
                        shellQuote(
                            socketName
                        ) +
                        " " +
                        shellQuote(
                            token
                        )

            val process =
                try {

                    ProcessBuilder(
                        "su",
                        "-c",
                        command
                    )
                        .redirectErrorStream(
                            true
                        )
                        .start()

                } catch (
                    e: Exception
                ) {

                    Log.e(
                        TAG,
                        "Unable to launch root worker",
                        e
                    )

                    return false
                }

            Log.d(
                TAG,
                "Root worker process launched"
            )

            suProcess =
                process

            Thread(
                {
                    try {
                        process.inputStream
                            .bufferedReader()
                            .use { reader ->

                                while (
                                    true
                                ) {

                                    val line =
                                        reader.readLine()
                                            ?: break

                                    Log.d(
                                        TAG,
                                        "worker> $line"
                                    )
                                }
                            }

                    } catch (
                        e: Exception
                    ) {

                        Log.d(
                            TAG,
                            "worker output ended: ${e.message}"
                        )
                    }
                },
                "mw-root-drain"
            )
                .apply {
                    isDaemon =
                        true
                    start()
                }

            val deadline =
                System.currentTimeMillis() +
                        12_000L

            var connected:
                    LocalSocket? =
                null

            while (
                System.currentTimeMillis() <
                deadline
            ) {

                if (
                    !process.isAlive
                ) {
                    break
                }

                val candidate =
                    LocalSocket()

                try {

                    candidate.connect(
                        LocalSocketAddress(
                            socketName,
                            LocalSocketAddress
                                .Namespace
                                .ABSTRACT
                        )
                    )

                    connected =
                        candidate

                    break

                } catch (
                    e: Exception
                ) {

                    try {
                        candidate.close()
                    } catch (
                        ignored: Exception
                    ) {
                    }

                    try {
                        Thread.sleep(
                            80L
                        )
                    } catch (
                        ignored: InterruptedException
                    ) {
                        Thread.currentThread()
                            .interrupt()

                        break
                    }
                }
            }

            val liveSocket =
                connected
                    ?: run {

                        Log.e(
                            TAG,
                            "Root worker socket did not become ready; alive=${process.isAlive}"
                        )

                        closeLocked(
                            sendExit =
                            false
                        )

                        return false
                    }

            val liveInput =
                DataInputStream(
                    liveSocket
                        .inputStream
                )

            val liveOutput =
                DataOutputStream(
                    liveSocket
                        .outputStream
                )

            return try {

                liveOutput.writeInt(
                    MAGIC
                )

                liveOutput.writeUTF(
                    token
                )

                liveOutput.flush()

                val response =
                    liveInput.readInt()

                if (
                    response !=
                    MAGIC
                ) {
                    liveSocket.close()
                    false

                } else {

                    socket =
                        liveSocket

                    input =
                        liveInput

                    output =
                        liveOutput

                    openedPid =
                        -1

                    ready =
                        true

                    Log.d(
                        TAG,
                        "Root worker handshake OK"
                    )

                    true
                }

            } catch (
                e: Exception
            ) {

                try {
                    liveSocket.close()
                } catch (
                    ignored: Exception
                ) {
                }

                closeLocked(
                    sendExit =
                    false
                )

                false
            }
        }
    }

    fun ping():
            Boolean {

        synchronized(
            ioLock
        ) {
            return pingLocked()
        }
    }

    fun findPid(
        packageName:
        String
    ): Int {

        synchronized(
            ioLock
        ) {

            val out =
                output
                    ?: return -1

            val inp =
                input
                    ?: return -1

            return try {

                out.writeInt(
                    CMD_FIND_PID
                )

                out.writeUTF(
                    packageName
                )

                out.flush()

                inp.readInt()

            } catch (
                e: Exception
            ) {

                failLocked()
                -1
            }
        }
    }

    fun maps(
        pid:
        Int
    ): String {

        synchronized(
            ioLock
        ) {

            val out =
                output
                    ?: return ""

            val inp =
                input
                    ?: return ""

            return try {

                out.writeInt(
                    CMD_MAPS
                )

                out.writeInt(
                    pid
                )

                out.flush()

                val count =
                    inp.readInt()

                if (
                    count <
                    0 ||
                    count >
                    4 * 1024 * 1024
                ) {
                    return ""
                }

                val bytes =
                    ByteArray(
                        count
                    )

                inp.readFully(
                    bytes
                )

                bytes.toString(
                    Charsets.UTF_8
                )

            } catch (
                e: Exception
            ) {

                failLocked()
                ""
            }
        }
    }

    fun ensureMemOpen(
        pid:
        Int
    ): Boolean {

        synchronized(
            ioLock
        ) {

            if (
                openedPid ==
                pid
            ) {
                return true
            }

            val out =
                output
                    ?: return false

            val inp =
                input
                    ?: return false

            return try {

                out.writeInt(
                    CMD_OPEN_MEM
                )

                out.writeInt(
                    pid
                )

                out.flush()

                val ok =
                    inp.readBoolean()

                if (
                    ok
                ) {
                    openedPid =
                        pid
                }

                ok

            } catch (
                e: Exception
            ) {

                failLocked()
                false
            }
        }
    }

    fun readBytes(
        pid:
        Int,
        address:
        Long,
        count:
        Int
    ): ByteArray? {

        synchronized(
            ioLock
        ) {

            if (
                !ensureMemOpenLocked(
                    pid
                )
            ) {
                return null
            }

            val out =
                output
                    ?: return null

            val inp =
                input
                    ?: return null

            return try {

                out.writeInt(
                    CMD_READ
                )

                out.writeLong(
                    address
                )

                out.writeInt(
                    count
                )

                out.flush()

                val size =
                    inp.readInt()

                if (
                    size <
                    0 ||
                    size >
                    4096
                ) {
                    return null
                }

                val bytes =
                    ByteArray(
                        size
                    )

                inp.readFully(
                    bytes
                )

                bytes

            } catch (
                e: Exception
            ) {

                failLocked()
                null
            }
        }
    }

    fun writeBytes(
        pid:
        Int,
        address:
        Long,
        bytes:
        ByteArray
    ): Boolean {

        synchronized(
            ioLock
        ) {

            if (
                !ensureMemOpenLocked(
                    pid
                )
            ) {
                return false
            }

            val out =
                output
                    ?: return false

            val inp =
                input
                    ?: return false

            return try {

                out.writeInt(
                    CMD_WRITE
                )

                out.writeLong(
                    address
                )

                out.writeInt(
                    bytes.size
                )

                out.write(
                    bytes
                )

                out.flush()

                inp.readBoolean()

            } catch (
                e: Exception
            ) {

                failLocked()
                false
            }
        }
    }

    fun startFloatLock(
        pid:
        Int,
        address:
        Long,
        value:
        Float,
        intervalMs:
        Int
    ): Boolean {

        synchronized(
            ioLock
        ) {

            if (
                !ensureMemOpenLocked(
                    pid
                )
            ) {
                return false
            }

            val out =
                output
                    ?: return false

            val inp =
                input
                    ?: return false

            return try {

                out.writeInt(
                    CMD_START_FLOAT_LOCK
                )

                out.writeLong(
                    address
                )

                out.writeFloat(
                    value
                )

                out.writeInt(
                    intervalMs
                )

                out.flush()

                inp.readBoolean()

            } catch (
                e: Exception
            ) {

                failLocked()
                false
            }
        }
    }

    fun stopLock():
            Boolean {

        synchronized(
            ioLock
        ) {

            val out =
                output
                    ?: return false

            val inp =
                input
                    ?: return false

            return try {

                out.writeInt(
                    CMD_STOP_LOCK
                )

                out.flush()

                inp.readBoolean()

            } catch (
                e: Exception
            ) {

                failLocked()
                false
            }
        }
    }

    fun signal(
        pid:
        Int,
        signal:
        Int
    ): Boolean {

        synchronized(
            ioLock
        ) {

            val out =
                output
                    ?: return false

            val inp =
                input
                    ?: return false

            return try {

                out.writeInt(
                    CMD_SIGNAL
                )

                out.writeInt(
                    pid
                )

                out.writeInt(
                    signal
                )

                out.flush()

                inp.readBoolean()

            } catch (
                e: Exception
            ) {

                failLocked()
                false
            }
        }
    }

    fun nativeEffectCommand(
        pid: Int,
        commandAddress: Long,
        idAddress: Long,
        command: Int,
        effectId: Int,
        stageServiceGlobal: Long,
        serviceCharacterOffset: Long,
        serviceJellyManagerOffset: Long,
        jellyManagerCharacterOffset: Long,
        effectManagerOffset: Long,
        effectBeginOffset: Long,
        effectEndOffset: Long,
        effectCapOffset: Long,
        effectIdDirectOffset: Long,
        effectIdAdjustedOffset: Long,
        expectedCharacterVptr: Long,
        expectedEffectManagerVptr: Long,
        expectedEffectVptr: Long,
        moduleStart: Long,
        moduleEnd: Long,
        maxEffects: Int,
        timeoutMs: Int
    ): NativeEffectCommandResult {

        synchronized(
            ioLock
        ) {

            if (
                !ensureMemOpenLocked(
                    pid
                )
            ) {
                return NativeEffectCommandResult(
                    NATIVE_EFFECT_IO_FAILED,
                    0L
                )
            }

            val out =
                output
                    ?: return NativeEffectCommandResult(
                        NATIVE_EFFECT_IO_FAILED,
                        0L
                    )

            val inp =
                input
                    ?: return NativeEffectCommandResult(
                        NATIVE_EFFECT_IO_FAILED,
                        0L
                    )

            return try {

                out.writeInt(
                    CMD_NATIVE_EFFECT
                )

                out.writeInt(
                    pid
                )

                out.writeLong(commandAddress)
                out.writeLong(idAddress)
                out.writeInt(command)
                out.writeInt(effectId)
                out.writeLong(stageServiceGlobal)
                out.writeLong(serviceCharacterOffset)
                out.writeLong(serviceJellyManagerOffset)
                out.writeLong(jellyManagerCharacterOffset)
                out.writeLong(effectManagerOffset)
                out.writeLong(effectBeginOffset)
                out.writeLong(effectEndOffset)
                out.writeLong(effectCapOffset)
                out.writeLong(effectIdDirectOffset)
                out.writeLong(effectIdAdjustedOffset)
                out.writeLong(expectedCharacterVptr)
                out.writeLong(expectedEffectManagerVptr)
                out.writeLong(expectedEffectVptr)
                out.writeLong(moduleStart)
                out.writeLong(moduleEnd)
                out.writeInt(maxEffects)
                out.writeInt(timeoutMs)

                out.flush()

                NativeEffectCommandResult(
                    status = inp.readInt(),
                    character = inp.readLong()
                )

            } catch (
                e: Exception
            ) {

                failLocked()

                NativeEffectCommandResult(
                    NATIVE_EFFECT_IO_FAILED,
                    0L
                )
            }
        }
    }

    fun botTap(
        x: Int,
        y: Int
    ): Boolean {

        if (x < 0 || y < 0) return false

        synchronized(ioLock) {
            val out = output ?: return false
            val inp = input ?: return false

            return try {
                out.writeInt(CMD_BOT_TAP)
                out.writeInt(x)
                out.writeInt(y)
                out.flush()
                inp.readBoolean()
            } catch (e: Exception) {
                failLocked()
                false
            }
        }
    }

    fun botScreenshotPng(): ByteArray? {

        synchronized(ioLock) {
            val out = output ?: return null
            val inp = input ?: return null

            return try {
                out.writeInt(CMD_BOT_SCREENSHOT)
                out.flush()

                val size = inp.readInt()
                if (size <= 0 || size > 16 * 1024 * 1024) {
                    return null
                }

                ByteArray(size).also { bytes ->
                    inp.readFully(bytes)
                }
            } catch (e: Exception) {
                failLocked()
                null
            }
        }
    }

    fun shutdown() {

        synchronized(
            ioLock
        ) {
            closeLocked(
                sendExit =
                true
            )
        }
    }

    private fun ensureMemOpenLocked(
        pid:
        Int
    ): Boolean {

        if (
            openedPid ==
            pid
        ) {
            return true
        }

        val out =
            output
                ?: return false

        val inp =
            input
                ?: return false

        return try {

            out.writeInt(
                CMD_OPEN_MEM
            )

            out.writeInt(
                pid
            )

            out.flush()

            val ok =
                inp.readBoolean()

            if (
                ok
            ) {
                openedPid =
                    pid
            }

            ok

        } catch (
            e: Exception
        ) {

            failLocked()
            false
        }
    }

    private fun requestRootPermissionLocked():
            Boolean {

        val process =
            try {

                ProcessBuilder(
                    "su",
                    "-c",
                    "id -u"
                )
                    .redirectErrorStream(
                        true
                    )
                    .start()

            } catch (
                e: Exception
            ) {

                Log.e(
                    TAG,
                    "Cannot execute su",
                    e
                )

                return false
            }

        /*
         * Allow enough time for the user to press Allow in Magisk.
         * This runs on M Woif's background root executor / warm thread,
         * never on the UI thread.
         */
        val finished =
            try {

                process.waitFor(
                    45L,
                    TimeUnit.SECONDS
                )

            } catch (
                e: InterruptedException
            ) {

                Thread.currentThread()
                    .interrupt()

                false
            }

        if (
            !finished
        ) {

            Log.w(
                TAG,
                "su permission request timed out"
            )

            try {
                process.destroy()
            } catch (
                ignored: Exception
            ) {
            }

            return false
        }

        val outputText =
            try {

                process.inputStream
                    .bufferedReader()
                    .use {
                        it.readText()
                    }
                    .trim()

            } catch (
                e: Exception
            ) {

                ""
            }

        val exit =
            try {
                process.exitValue()
            } catch (
                e: Exception
            ) {
                -1
            }

        val granted =
            exit ==
                    0 &&
                    outputText
                        .lineSequence()
                        .any {
                            it.trim() ==
                                    "0"
                        }

        Log.d(
            TAG,
            "su preflight exit=$exit output=${outputText.take(160)} granted=$granted"
        )

        return granted
    }

    private fun pingLocked():
            Boolean {

        if (
            !ready
        ) {
            return false
        }

        val out =
            output
                ?: return false

        val inp =
            input
                ?: return false

        return try {

            out.writeInt(
                CMD_PING
            )

            out.flush()

            inp.readBoolean()

        } catch (
            e: Exception
        ) {

            failLocked()
            false
        }
    }

    private fun failLocked() {

        closeLocked(
            sendExit =
            false
        )
    }

    private fun closeLocked(
        sendExit:
        Boolean
    ) {

        if (
            sendExit
        ) {

            try {

                output
                    ?.writeInt(
                        CMD_EXIT
                    )

                output
                    ?.flush()

                input
                    ?.readBoolean()

            } catch (
                ignored: Exception
            ) {
            }
        }

        ready =
            false

        openedPid =
            -1

        try {
            input
                ?.close()
        } catch (
            ignored: Exception
        ) {
        }

        try {
            output
                ?.close()
        } catch (
            ignored: Exception
        ) {
        }

        try {
            socket
                ?.close()
        } catch (
            ignored: Exception
        ) {
        }

        input =
            null

        output =
            null

        socket =
            null

        try {
            suProcess
                ?.destroy()
        } catch (
            ignored: Exception
        ) {
        }

        suProcess =
            null
    }

    private fun shellQuote(
        text:
        String
    ): String {

        return "'" +
                text.replace(
                    "'",
                    "'\\''"
                ) +
                "'"
    }
}
