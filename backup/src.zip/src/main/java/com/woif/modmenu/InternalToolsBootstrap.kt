package com.woif.modmenu

/**
 * Internal-build-only entry point.
 *
 * IMPORTANT:
 * Keep Scanner/Finder/raw-memory diagnostics/profile testers and other
 * experimental tooling under app/src/internal only.
 *
 * This class is deliberately not referenced by the current stable runtime.
 * Future internal tools can be attached here without placing their code in
 * app/src/main or the stable APK.
 */
internal object InternalToolsBootstrap {
    const val AVAILABLE: Boolean = true
}
