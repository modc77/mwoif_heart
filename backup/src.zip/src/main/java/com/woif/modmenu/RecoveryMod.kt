package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Pit Lift Unlimited + Revive Unlimited desired-state controller (f09_v1).
 *
 * Verified native behavior:
 * - Pit Lift and Revive share the same recovery resource family and subtype.
 * - Each recovery consumes one protected subtype record into a std::list.
 * - Availability is derived from how many matching subtype records already
 *   exist in that list.
 *
 * This controller preserves CookieRun's original rescue/death animation and
 * state machine. It only refunds the newly-created usage node after the native
 * recovery has completed far enough to be safely detached.
 *
 * The two user-facing MODs remain independent:
 * - Pit Lift refunds only a pit-context recovery.
 * - Revive refunds only a non-pit recovery.
 *
 * No executable code is patched and no recovery resource is fabricated from
 * zero. At least one real compatible recovery source must exist in the run.
 */
class RecoveryMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {
    companion object {
        private const val TICK_MS = 50L
        private const val PROCESS_RECHECK_TICKS = 10
        private const val FALLING_EPSILON = 5.0f
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    private enum class RecoveryKind { PIT, REVIVE }

    private data class Runtime(
        val pid: Int,
        val stageServiceGlobal: Long,
        val gameplayStateGlobal: Long
    )

    private data class PendingRefund(
        val state: Long,
        val node: Long,
        val kind: RecoveryKind,
        val dueElapsed: Long
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()

    @Volatile private var profile: RecoveryProfile? = null
    @Volatile private var runtime: Runtime? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var tickCounter = 0
    @Volatile private var nextResolveAt = 0L

    @Volatile private var pitLiftEnabled = false
    @Volatile private var reviveEnabled = false
    @Volatile private var pitLiftStatus = "Pit Lift • ยังไม่ได้เปิด"
    @Volatile private var reviveStatus = "Revive • ยังไม่ได้เปิด"

    private var trackedState = 0L
    private var lastUsageCount = 0L
    private var lastPitLikeElapsed = 0L
    private val pending = ArrayList<PendingRefund>()
    private var pitRefunded = 0
    private var reviveRefunded = 0

    fun cacheProfile(value: RecoveryProfile): ActionResult {
        if (
            value.imageBase <= 0L ||
            value.stageServiceGlobal <= 0L ||
            value.gameplayStateGlobal <= 0L ||
            value.serviceCharacterOffset < 0L ||
            value.serviceJellyManagerOffset < 0L ||
            value.jellyManagerCharacterOffset < 0L ||
            value.characterYOffset < 0L ||
            value.characterYPreviousOffset < 0L ||
            value.recoveryListSentinelOffset <= 0L ||
            value.recoveryListCountOffset <= 0L ||
            value.listNodeNextOffset < 0L ||
            value.listNodePreviousOffset < 0L ||
            value.listNodeValueObjectOffset <= 0L ||
            value.protectedValuePtrOffset <= 0L ||
            value.recoverySubtype <= 0 ||
            !value.pitArmY.isFinite() ||
            value.pitRecentWindowMs !in 100L..5000L ||
            value.refundDelayMs !in 50L..3000L ||
            value.maximumUsageDelta !in 1..32
        ) {
            return failure("PROFILE_INVALID", "Recovery Secure Profile ไม่ครบ")
        }

        profile = value
        if (!pitLiftEnabled) pitLiftStatus = "Pit Lift พร้อม • เปิด ON ได้ทุกหน้า"
        if (!reviveEnabled) reviveStatus = "Revive พร้อม • เปิด ON ได้ทุกหน้า"
        return success("Secure Recovery Profile พร้อม")
    }

    fun setPitLiftEnabled(enable: Boolean, callback: (ActionResult) -> Unit) {
        pitLiftEnabled = enable
        executor.execute {
            if (enable) {
                pitLiftStatus = "Pit Lift ON • รอ CookieRun / Stage"
                ensureTask()
                safeTick()
            } else {
                cancelPending(RecoveryKind.PIT)
                pitLiftStatus = "Pit Lift OFF"
                stopTaskIfIdle()
            }
            callback(success(pitLiftStatus))
        }
    }

    fun setReviveEnabled(enable: Boolean, callback: (ActionResult) -> Unit) {
        reviveEnabled = enable
        executor.execute {
            if (enable) {
                reviveStatus = "Revive ON • รอ CookieRun / Stage"
                ensureTask()
                safeTick()
            } else {
                cancelPending(RecoveryKind.REVIVE)
                reviveStatus = "Revive OFF"
                stopTaskIfIdle()
            }
            callback(success(reviveStatus))
        }
    }

    fun isPitLiftEnabled(): Boolean = pitLiftEnabled
    fun isReviveEnabled(): Boolean = reviveEnabled
    fun pitLiftStatusText(): String = pitLiftStatus
    fun reviveStatusText(): String = reviveStatus

    fun disableAllBlockingBestEffort() {
        pitLiftEnabled = false
        reviveEnabled = false
        pending.clear()
        stopTask()
        clearRuntimeTracking()
        pitLiftStatus = "Pit Lift OFF"
        reviveStatus = "Revive OFF"
    }

    fun shutdown() {
        try {
            disableAllBlockingBestEffort()
        } catch (_: Exception) {
        }
        closed = true
        profile = null
        executor.shutdownNow()
    }

    private fun ensureTask() {
        if (closed || task != null) return
        task = executor.scheduleAtFixedRate(
            { safeTick() },
            TICK_MS,
            TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    private fun stopTaskIfIdle() {
        if (!pitLiftEnabled && !reviveEnabled) {
            stopTask()
            clearRuntimeTracking()
        }
    }

    private fun stopTask() {
        task?.cancel(false)
        task = null
    }

    private fun cancelPending(kind: RecoveryKind) {
        pending.removeAll { it.kind == kind }
    }

    private fun safeTick() {
        try {
            tick()
        } catch (t: Throwable) {
            if (pitLiftEnabled) pitLiftStatus = "Pit Lift ON • retry • ${t.javaClass.simpleName}"
            if (reviveEnabled) reviveStatus = "Revive ON • retry • ${t.javaClass.simpleName}"
            DevConsole.log("RECOVERY", "tick ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun tick() {
        if (!pitLiftEnabled && !reviveEnabled) return

        if (!ControlPlaneState.isFeatureAllowed(CrgProfile.FEATURE_RECOVERY)) {
            if (pitLiftEnabled) pitLiftStatus = "Pit Lift ON • กำลังอัปเดต • รอ Server"
            if (reviveEnabled) reviveStatus = "Revive ON • กำลังอัปเดต • รอ Server"
            return
        }

        tickCounter += 1
        var rt = runtime
        if (rt == null) {
            val now = System.currentTimeMillis()
            if (now < nextResolveAt) return
            nextResolveAt = now + 1000L

            val prepared = prepareRuntime()
            if (!prepared.ok) {
                val text = when (prepared.errorCode) {
                    "ROOT_REQUIRED" -> "รอ Root Worker"
                    "PROFILE_NOT_READY" -> "รอ Secure Profile"
                    "GAME_NOT_RUNNING" -> "รอ CookieRun"
                    else -> "กำลังจับ runtime ใหม่"
                }
                if (pitLiftEnabled) pitLiftStatus = "Pit Lift ON • $text"
                if (reviveEnabled) reviveStatus = "Revive ON • $text"
                return
            }
            rt = runtime ?: return
        }

        if (tickCounter % PROCESS_RECHECK_TICKS == 0) {
            val livePid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            if (livePid == null || livePid != rt.pid) {
                clearRuntimeTracking()
                runtime = null
                nextResolveAt = 0L
                val text = if (livePid == null) "รอ CookieRun" else "พบเกมใหม่ • กำลังเชื่อม"
                if (pitLiftEnabled) pitLiftStatus = "Pit Lift ON • $text"
                if (reviveEnabled) reviveStatus = "Revive ON • $text"
                return
            }
        }

        val p = profile() ?: return
        val state = memory.readLong(rt.pid, rt.gameplayStateGlobal) ?: 0L
        val character = resolveCharacter(rt, p)
        if (!isPointer(state) || !isPointer(character)) {
            resetStageTracking()
            if (pitLiftEnabled) pitLiftStatus = "Pit Lift ON • พร้อม • รอ Stage"
            if (reviveEnabled) reviveStatus = "Revive ON • พร้อม • รอ Stage"
            return
        }

        if (trackedState != state) {
            trackedState = state
            lastUsageCount = readUsageCount(rt.pid, state, p) ?: 0L
            lastPitLikeElapsed = 0L
            pending.clear()
            DevConsole.log(
                "RECOVERY",
                "bind state=0x${state.toString(16)} count=$lastUsageCount"
            )
        }

        val nowElapsed = SystemClock.elapsedRealtime()
        val y = memory.readFloat(rt.pid, character + p.characterYOffset)
        val yPrev = memory.readFloat(rt.pid, character + p.characterYPreviousOffset)
        val falling = y != null && yPrev != null && y < (yPrev - FALLING_EPSILON)

        if (falling && y != null && y < p.pitArmY) {
            lastPitLikeElapsed = nowElapsed
        }

        val pitContext =
            (falling && y != null && y < p.pitArmY) ||
                (lastPitLikeElapsed > 0L && nowElapsed - lastPitLikeElapsed <= p.pitRecentWindowMs)

        val count = readUsageCount(rt.pid, state, p) ?: return
        val delta = count - lastUsageCount

        if (delta > 0L && delta <= p.maximumUsageDelta.toLong()) {
            val nodes = collectNewestNodes(rt.pid, state, p, delta.toInt())
            for (node in nodes) {
                if (decodeNodeSubtype(rt.pid, node, p) != p.recoverySubtype) continue

                val kind = if (pitContext) RecoveryKind.PIT else RecoveryKind.REVIVE
                val enabledForKind = when (kind) {
                    RecoveryKind.PIT -> pitLiftEnabled
                    RecoveryKind.REVIVE -> reviveEnabled
                }

                if (enabledForKind && pending.none { it.node == node && it.state == state }) {
                    pending += PendingRefund(
                        state = state,
                        node = node,
                        kind = kind,
                        dueElapsed = nowElapsed + p.refundDelayMs
                    )
                    DevConsole.log(
                        "RECOVERY",
                        "queue ${kind.name} node=0x${node.toString(16)} count=$count y=$y yPrev=$yPrev"
                    )
                }
            }
        } else if (delta < 0L || delta > p.maximumUsageDelta.toLong()) {
            // The game or another controller changed this list unexpectedly.
            // Rebase rather than guessing which nodes are ours.
            pending.clear()
        }

        processPending(rt.pid, state, p, nowElapsed)
        lastUsageCount = readUsageCount(rt.pid, state, p) ?: count

        if (pitLiftEnabled && pitLiftStatus.startsWith("Pit Lift ON")) {
            pitLiftStatus = "Pit Lift ON • Unlimited • คืนแล้ว $pitRefunded ครั้ง"
        }
        if (reviveEnabled && reviveStatus.startsWith("Revive ON")) {
            reviveStatus = "Revive ON • Unlimited • คืนแล้ว $reviveRefunded ครั้ง"
        }
    }

    private fun processPending(
        pid: Int,
        state: Long,
        p: RecoveryProfile,
        nowElapsed: Long
    ) {
        var index = 0
        while (index < pending.size) {
            val item = pending[index]
            if (item.dueElapsed > nowElapsed) {
                index += 1
                continue
            }

            val stillEnabled = when (item.kind) {
                RecoveryKind.PIT -> pitLiftEnabled
                RecoveryKind.REVIVE -> reviveEnabled
            }

            if (
                stillEnabled &&
                item.state == state &&
                decodeNodeSubtype(pid, item.node, p) == p.recoverySubtype
            ) {
                val result = unlinkUsageNode(pid, state, item.node, p)
                if (result.ok) {
                    when (item.kind) {
                        RecoveryKind.PIT -> pitRefunded += 1
                        RecoveryKind.REVIVE -> reviveRefunded += 1
                    }
                    DevConsole.log(
                        "RECOVERY",
                        "refund ${item.kind.name} node=0x${item.node.toString(16)} count=${readUsageCount(pid, state, p)}"
                    )
                } else {
                    val text = "Refund fail • ${result.errorCode}"
                    when (item.kind) {
                        RecoveryKind.PIT -> if (pitLiftEnabled) pitLiftStatus = "Pit Lift ON • $text"
                        RecoveryKind.REVIVE -> if (reviveEnabled) reviveStatus = "Revive ON • $text"
                    }
                    DevConsole.log("RECOVERY", "refund fail ${item.kind.name}: ${result.errorCode}")
                }
            }

            pending.removeAt(index)
        }
    }

    private fun unlinkUsageNode(
        pid: Int,
        state: Long,
        node: Long,
        p: RecoveryProfile
    ): ActionResult {
        if (!isPointer(node)) return failure("BAD_NODE", "Recovery node ไม่ถูกต้อง")

        val previous = memory.readLong(pid, node + p.listNodePreviousOffset)
            ?: return failure("READ_PREVIOUS", "อ่าน Recovery previous ไม่สำเร็จ")
        val next = memory.readLong(pid, node + p.listNodeNextOffset)
            ?: return failure("READ_NEXT", "อ่าน Recovery next ไม่สำเร็จ")
        if (!isPointer(previous) || !isPointer(next)) {
            return failure("BAD_LINK", "Recovery linked list ไม่ถูกต้อง")
        }

        val previousNextAddress = previous + p.listNodeNextOffset
        val nextPreviousAddress = next + p.listNodePreviousOffset
        if (memory.readLong(pid, previousNextAddress) != node) {
            return failure("PREVIOUS_MISMATCH", "Recovery previous เปลี่ยนไปแล้ว")
        }
        if (memory.readLong(pid, nextPreviousAddress) != node) {
            return failure("NEXT_MISMATCH", "Recovery next เปลี่ยนไปแล้ว")
        }

        val countAddress = state + p.recoveryListCountOffset
        val count = memory.readLong(pid, countAddress)
            ?: return failure("READ_COUNT", "อ่าน Recovery count ไม่สำเร็จ")
        if (count < 1L) return failure("COUNT_ZERO", "Recovery count เป็น 0")

        if (!memory.pause(pid)) {
            return failure("PAUSE_FAILED", "หยุด CookieRun ชั่วคราวไม่สำเร็จ")
        }

        try {
            // Re-check links while the process is paused.
            if (memory.readLong(pid, previousNextAddress) != node ||
                memory.readLong(pid, nextPreviousAddress) != node ||
                memory.readLong(pid, countAddress) != count
            ) {
                return failure("RACE_DETECTED", "Recovery state เปลี่ยนก่อน Refund")
            }

            if (!writeLong(pid, previousNextAddress, next)) {
                return failure("WRITE_PREVIOUS", "เขียน Recovery previous ไม่สำเร็จ")
            }
            if (!writeLong(pid, nextPreviousAddress, previous)) {
                writeLong(pid, previousNextAddress, node)
                return failure("WRITE_NEXT", "เขียน Recovery next ไม่สำเร็จ")
            }
            if (!writeLong(pid, countAddress, count - 1L)) {
                writeLong(pid, previousNextAddress, node)
                writeLong(pid, nextPreviousAddress, node)
                return failure("WRITE_COUNT", "เขียน Recovery count ไม่สำเร็จ")
            }

            val verified =
                memory.readLong(pid, previousNextAddress) == next &&
                    memory.readLong(pid, nextPreviousAddress) == previous &&
                    memory.readLong(pid, countAddress) == count - 1L

            if (!verified) {
                writeLong(pid, previousNextAddress, node)
                writeLong(pid, nextPreviousAddress, node)
                writeLong(pid, countAddress, count)
                return failure("VERIFY_FAILED", "Recovery Refund verify ไม่ผ่าน")
            }

            return success("Recovery Refund OK")
        } finally {
            memory.resume(pid)
        }
    }

    private fun collectNewestNodes(
        pid: Int,
        state: Long,
        p: RecoveryProfile,
        count: Int
    ): List<Long> {
        val sentinel = state + p.recoveryListSentinelOffset
        var node = memory.readLong(pid, sentinel) ?: return emptyList()
        val result = ArrayList<Long>(count)
        var remaining = count
        while (remaining > 0 && isPointer(node) && node != sentinel) {
            result += node
            node = memory.readLong(pid, node + p.listNodeNextOffset) ?: 0L
            remaining -= 1
        }
        return result
    }

    private fun decodeNodeSubtype(pid: Int, node: Long, p: RecoveryProfile): Int? {
        val valueObject = memory.readLong(pid, node + p.listNodeValueObjectOffset) ?: return null
        if (!isPointer(valueObject)) return null
        val encodedPointer = memory.readLong(pid, valueObject + p.protectedValuePtrOffset) ?: return null
        if (!isPointer(encodedPointer)) return null
        val bytes = memory.readBytes(pid, encodedPointer, 4) ?: return null
        if (bytes.size != 4) return null

        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF
        val d0 = ((256 - b3) and 0xFF) xor 0xC6
        val d1 = ((256 - b2) and 0xFF) xor 0x3A
        val d2 = ((256 - b1) and 0xFF) xor 0xC6
        val d3 = ((256 - b0) and 0xFF) xor 0x3A
        return d0 or (d1 shl 8) or (d2 shl 16) or (d3 shl 24)
    }

    private fun readUsageCount(pid: Int, state: Long, p: RecoveryProfile): Long? {
        return memory.readLong(pid, state + p.recoveryListCountOffset)
    }

    private fun writeLong(pid: Int, address: Long, value: Long): Boolean {
        val bytes = ByteBuffer.allocate(8)
            .order(ByteOrder.LITTLE_ENDIAN)
            .putLong(value)
            .array()
        return memory.writeBytes(pid, address, bytes)
    }

    private fun resolveCharacter(rt: Runtime, p: RecoveryProfile): Long {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: return 0L
        if (!isPointer(service)) return 0L

        val direct = memory.readLong(rt.pid, service + p.serviceCharacterOffset) ?: 0L
        if (isPointer(direct)) return direct

        val jelly = memory.readLong(rt.pid, service + p.serviceJellyManagerOffset) ?: 0L
        if (!isPointer(jelly)) return 0L

        val fallback = memory.readLong(rt.pid, jelly + p.jellyManagerCharacterOffset) ?: 0L
        return if (isPointer(fallback)) fallback else 0L
    }

    private fun prepareRuntime(): ActionResult {
        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ยังไม่มี Root Worker")
        }

        val p = profile() ?: return failure("PROFILE_NOT_READY", "Secure Recovery Profile ยังไม่พร้อม")
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: return failure("GAME_NOT_RUNNING", "ยังไม่พบ CookieRun")

        val ranges = memory.maps(pid).filter { it.path.contains("libgame.so") }
        if (ranges.isEmpty()) return failure("LIBGAME_NOT_READY", "ยังไม่พบ libgame.so")

        val candidates = LinkedHashSet<Long>()
        for (range in ranges) {
            candidates.add(range.start)
            if (range.offset > 0L && range.start > range.offset) {
                candidates.add(range.start - range.offset)
            }
        }

        val elfBase = candidates.firstOrNull { validateElf(pid, it) }
            ?: return failure("ELF_NOT_FOUND", "หา ARM64 libgame ELF ไม่สำเร็จ")
        val loadBias = parseLoadBias(pid, elfBase)
            ?: return failure("LOAD_BIAS_FAILED", "หา libgame load bias ไม่สำเร็จ")

        val stageServiceGlobal = loadBias + (p.stageServiceGlobal - p.imageBase)
        val gameplayStateGlobal = loadBias + (p.gameplayStateGlobal - p.imageBase)
        if (stageServiceGlobal < 0x10000L || gameplayStateGlobal < 0x10000L) {
            return failure("RUNTIME_ADDRESS_FAILED", "คำนวณ Recovery runtime address ไม่สำเร็จ")
        }

        if (memory.readLong(pid, stageServiceGlobal) == null ||
            memory.readLong(pid, gameplayStateGlobal) == null
        ) {
            return failure("GLOBAL_READ_FAILED", "อ่าน Recovery globals ไม่สำเร็จ")
        }

        runtime = Runtime(pid, stageServiceGlobal, gameplayStateGlobal)
        resetStageTracking()
        DevConsole.log("RECOVERY", "runtime pid=$pid bias=0x${loadBias.toString(16)}")
        return success("Recovery runtime พร้อม")
    }

    private fun validateElf(pid: Int, address: Long): Boolean {
        val header = memory.readBytes(pid, address, 0x40) ?: return false
        if (header.size < 0x40) return false
        val machine = ByteBuffer.wrap(header, 0x12, 2)
            .order(ByteOrder.LITTLE_ENDIAN)
            .short.toInt() and 0xFFFF

        return (header[0].toInt() and 0xFF) == 0x7F &&
            (header[1].toInt() and 0xFF) == 0x45 &&
            (header[2].toInt() and 0xFF) == 0x4C &&
            (header[3].toInt() and 0xFF) == 0x46 &&
            (header[4].toInt() and 0xFF) == 2 &&
            machine == 0xB7
    }

    private fun parseLoadBias(pid: Int, elfBase: Long): Long? {
        val header = memory.readBytes(pid, elfBase, 0x40) ?: return null
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val phoff = buffer.getLong(0x20)
        val phentsize = buffer.getShort(0x36).toInt() and 0xFFFF
        val phnum = buffer.getShort(0x38).toInt() and 0xFFFF
        if (phoff <= 0L || phentsize < 0x38 || phnum !in 1..256) return null

        var selected: Long? = null
        for (index in 0 until phnum) {
            val entry = memory.readBytes(
                pid,
                elfBase + phoff + index.toLong() * phentsize.toLong(),
                phentsize
            ) ?: return null
            val ph = ByteBuffer.wrap(entry).order(ByteOrder.LITTLE_ENDIAN)
            if (ph.getInt(0) != 1) continue
            val fileOffset = ph.getLong(0x08)
            val vaddr = ph.getLong(0x10)
            if (fileOffset == 0L) {
                selected = vaddr
                break
            }
            if (selected == null) selected = vaddr
        }
        return elfBase - (selected ?: return null)
    }

    private fun profile(): RecoveryProfile? {
        val active = SecureProfileManager.getRecovery()
        if (active == null) {
            profile = null
            return null
        }
        if (profile !== active) profile = active
        return active
    }

    private fun resetStageTracking() {
        trackedState = 0L
        lastUsageCount = 0L
        lastPitLikeElapsed = 0L
        pending.clear()
    }

    private fun clearRuntimeTracking() {
        resetStageTracking()
        runtime = null
        nextResolveAt = 0L
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun success(message: String) = ActionResult(true, null, message)
    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
