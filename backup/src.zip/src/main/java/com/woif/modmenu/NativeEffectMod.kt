package com.woif.modmenu

import android.content.Context
import android.os.SystemClock
import android.system.OsConstants
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * M Woif f03/f04 Native Effect V15 Lab — proven LSPosed + ARM64 in-process backend.
 *
 * Internal/Lab no longer writes executable caves or tries to synthesize CRG
 * effect trees from root memory.  It resolves Character/runtime with the
 * existing Secure Profile, asks the LSPosed code inside CookieRun to execute
 * the game's own dispatcher/remover, then verifies the live EffectManager.
 * Stable keeps the previous one-shot implementation until the in-process path
 * is promoted after Lab verification.
 *
 * Production rule:
 * - NO persistent hook at FUN_00F3C9E0.
 * - ON can be requested from Lobby/loading/any game page. Android keeps a desired state
 *   and applies only after a live Character appears.
 * - NO persistent native heartbeat/command loop across Lobby -> Stage.
 * - Executable caves are discovered dynamically from zero/NOP padding inside
 *   the live libgame executable mapping; server cave addresses are not trusted.
 * - Caves contain an inert one-shot handler only; they are never referenced
 *   until a live Character exists and the user/app needs exactly one action.
 * - The app temporarily replaces Character vtable slot +0x158 with Cave A,
 *   waits for the game thread to execute that virtual callback once, then
 *   restores the original vtable pointer immediately.
 * - APPLY/REMOVE use server-resolved native entry points on the hooked game thread.
 * - The handler always calls the original vfunc and returns its result.
 * - Cross-stage persistence is Android-side only: after a feature has
 *   successfully enabled, Android notices a new Character and performs a new
 *   one-shot action. No native hook remains while in Lobby/loading.
 */
class NativeEffectMod(
    context: Context,
    private val memory: RootProcessMemory = RootProcessMemory()
) {

    companion object {
        private const val TAG = "WOIF_NATIVE_V15"

        private const val COMMAND_NONE = 0
        private const val COMMAND_APPLY = 1
        private const val COMMAND_REMOVE = 2

        private const val CAVE_A_WORDS = 15
        private const val CAVE_B_WORDS = 15
        private const val CAVE_C_WORDS = 13
        private const val NOP = 0xD503201F.toInt()

        // One-shot RW state. Handler ABI stays compact; V7 changes queueing/cave discovery.
        private const val STATE_CMD = 0x00L              // BYTE
        private const val STATE_ID = 0x04L               // DWORD
        private const val STATE_TARGET_CHARACTER = 0x08L // QWORD
        private const val STATE_ORIGINAL_VFUNC = 0x10L   // QWORD
        private const val STATE_DONE = 0x18L             // BYTE
        private const val STATE_MAGIC = 0x20L            // DWORD
        private const val STATE_VERSION = 0x24L          // DWORD

        private const val STATE_MAGIC_VALUE = 0x43524734 // CRG4
        private const val STATE_VERSION_VALUE = 0x000D0700
        private const val STATE_CAVE_A = 0x28L           // QWORD
        private const val STATE_CAVE_B = 0x30L           // QWORD
        private const val STATE_CAVE_C = 0x38L           // QWORD
        private const val STATE_SLOT_SIZE = 0x100L

        private const val DYNAMIC_CAVE_REGION_SIZE = 0x40L
        private const val DYNAMIC_CAVE_FAST_SCAN_BYTES = 0x00200000L
        private const val CAVE_RESCAN_COOLDOWN_MS = 10000L
        private const val DYNAMIC_STATE_SCAN_BYTES = 0x00040000L
        private const val APPLY_RETRY_MS = 700L

        private const val AUTO_TICK_MS = 250L
        private const val VERIFY_DELAY_MS = 80L
        private const val VTABLE_TRIGGER_TIMEOUT_MS = 3000L

        private const val BRANCH_RANGE_26 = 0x08000000L
        private const val BRANCH_RANGE_19 = 0x00100000L

        // Lab-only read-only natural-effect capture/data probes from Ghidra 26.7.12. These are GH addresses;
        // runtime = bias + GH. Stable/User behavior does not depend on them.
        private const val GH_GLOBAL_CONFIG_MANAGER = 0x021C4A08L
        private const val GH_GIANT_SCALE_MANAGER = 0x021C4F08L
        private const val GLOBAL_CONFIG_MAP_OFFSET = 0xD8L
        private const val OWNER_OFFSET = 0x148L
        private const val OWNER_TREE_ROOT_OFFSET = 0x10L
        private const val OWNER_VECTOR_BEGIN_OFFSET = 0x38L
        private const val OWNER_VECTOR_END_OFFSET = 0x40L
        private const val OWNER_NODE_KEY_OFFSET = 0x1CL
        private const val OWNER_NODE_ACTIVE_OFFSET = 0x20L
        private const val CONFIG_TREE_ROOT_OFFSET = 0x08L
        private const val CONFIG_BUCKET_BASE_OFFSET = 0x18L
        private const val CONFIG_NODE_KEY_OFFSET = 0x20L
        private const val CONFIG_NODE_VALUE_OFFSET = 0x28L
        private const val GIANT_SCALE_VECTOR_BEGIN_OFFSET = 0x08L
        private const val GIANT_SCALE_VECTOR_END_OFFSET = 0x10L
        private const val GIANT_SCALE_CURRENT_OFFSET = 0x80L
        private const val GIANT_SCALE_MAX_OFFSET = 0x84L
        // Read-only update diagnostics: natural Super changes Character+0x5F0 while active.
        private const val DEV_SUPER_SPEED_FIELD_OFFSET = 0x5F0L
        // Giant Size build-specific offsets/timing come from encrypted f03
        // Secure Profile (f03 rev6+). The APK only keeps the generic writer.

        // Retained read-only visual diagnostics used by the existing DEV probe.
        private const val DEV_GIANT_VISUAL_PTR_OFFSET = 0x3E0L
        private const val DEV_GIANT_VISUAL_SCALE_A_OFFSET = 0x14L
        private const val DEV_GIANT_VISUAL_SCALE_B_OFFSET = 0x18L
        private val DEV_EFFECT_PROPERTY_IDS = intArrayOf(0x68, 0x65, 0x69, 0x6A, 0x401, 0x49A)
        private const val DEV_EFFECT_PROPERTY_DUMP_SIZE = 0x70
        private const val DEV_MAX_VECTOR_ENTRIES = 8

        // Natural pickup capture. Read-only: arm before collecting a real Giant/Super item.
        private const val DEV_CAPTURE_POLL_MS = 50L
        private const val DEV_CAPTURE_TIMEOUT_MS = 45000L
        private const val DEV_CAPTURE_VISUAL_BLOB_SIZE = 0x120
        private const val DEV_CAPTURE_OWNER_SIZE = 0x60
        private const val DEV_CAPTURE_CHAR_A_OFFSET = 0x130L
        private const val DEV_CAPTURE_CHAR_A_SIZE = 0x110
        private const val DEV_CAPTURE_CHAR_B_OFFSET = 0x3C0L
        private const val DEV_CAPTURE_CHAR_B_SIZE = 0x80
        private const val DEV_CAPTURE_CHAR_C_OFFSET = 0x5B0L
        private const val DEV_CAPTURE_CHAR_C_SIZE = 0x90
        private const val DEV_CAPTURE_EFFECT_SIZE = 0xC0
        private const val DEV_CAPTURE_DIFF_LIMIT = 48
    }

    data class ActionResult(
        val ok: Boolean,
        val errorCode: String?,
        val message: String
    )

    /** Compatibility only for the old Internal probe source set. */
    interface Backend {
        fun cacheProfile(profile: NativeEffectProfile): ActionResult
        fun enable(profile: NativeEffectProfile, callback: (ActionResult) -> Unit)
        fun disable(featureId: String, callback: (ActionResult) -> Unit)
        fun isEnabled(featureId: String): Boolean
        fun statusText(featureId: String): String
        fun restoreFeatureBlockingBestEffort(featureId: String): ActionResult
        fun restoreAllBlockingBestEffort(): ActionResult
        fun shutdown(restore: Boolean)
    }

    private enum class EffectState {
        PRESENT,
        ABSENT,
        NO_CHARACTER,
        INVALID
    }

    private data class Inspection(
        val state: EffectState,
        val character: Long = 0L,
        val source: String = "",
        val count: Int = 0
    )

    private data class Runtime(
        val pid: Int,
        val moduleStart: Long,
        val moduleEnd: Long,
        val bias: Long,
        val dispatcher: Long,
        val remover: Long,
        val stageServiceGlobal: Long,
        val caveA: Long,
        val caveB: Long,
        val caveC: Long,
        val state: Long
    )

    private data class DevEffectProperty(
        val id: Int,
        val node: Long?,
        val bytes: ByteArray?
    )

    private data class DevEffectSummary(
        val node: Long,
        val pointer: Long,
        val vptr: Long,
        val directType: Int?,
        val adjustedType: Int?,
        val bytes: ByteArray?,
        val propertyMap: Long,
        val properties: List<DevEffectProperty>
    )

    private data class DevNaturalSnapshot(
        val label: String,
        val atMs: Long,
        val character: Long,
        val visualPtr: Long,
        val gameplayPtr: Long,
        val superSpeedField: Float?,
        val charA: ByteArray?,
        val charB: ByteArray?,
        val charC: ByteArray?,
        val ownerBytes: ByteArray?,
        val visualBytes: ByteArray?,
        val gameplayBytes: ByteArray?,
        val effectManager: Long,
        val effectCount: Long,
        val ownerVecCount: Int?,
        val giantEntries: List<Pair<Long, ByteArray?>>,
        val effects: List<DevEffectSummary>
    )

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val giantSizeExecutor = Executors.newSingleThreadScheduledExecutor()
    private val profiles = ConcurrentHashMap<String, NativeEffectProfile>()
    private val desired = ConcurrentHashMap<String, Boolean>()
    private val statuses = ConcurrentHashMap<String, String>()
    private val lastAppliedCharacter = ConcurrentHashMap<String, Long>()
    private val lastApplyAttemptAt = ConcurrentHashMap<String, Long>()

    // Internal/Lab-only ring buffer. Stable builds never collect these entries.
    private val labLogLock = Any()
    private val labLogs = ArrayDeque<String>()
    private val labLastByKey = ConcurrentHashMap<String, String>()
    private val labStartedAt = SystemClock.elapsedRealtime()

    @Volatile private var runtime: Runtime? = null
    @Volatile private var bridgeProfile: NativeEffectProfile? = null
    @Volatile private var task: ScheduledFuture<*>? = null
    @Volatile private var closed = false
    @Volatile private var activeCommand = false
    @Volatile private var lastCaveScanAt = 0L
    @Volatile private var lastCaveScanFailure: ActionResult? = null
    @Volatile private var devProbeText: String = "V15 in-process backend: not pinged"

    @Volatile private var giantSizeTask: ScheduledFuture<*>? = null
    @Volatile private var giantSizeEnabled = false
    @Volatile private var giantSizePercent = 30
    @Volatile private var giantSizeCachedCharacter = 0L
    @Volatile private var giantSizeWriteCount = 0L
    @Volatile private var giantSizeRecheckCounter = 0
    @Volatile private var giantSizeStatus = "Giant Size Fast Lock ยังไม่เปิด"

    @Volatile private var devCaptureFeatureId: String? = null
    @Volatile private var devCaptureLastFeatureId: String? = null
    @Volatile private var devCaptureStartedAt = 0L
    @Volatile private var devCaptureSawActive = false
    @Volatile private var devCaptureAbsentStreak = 0
    @Volatile private var devCaptureBaseline: DevNaturalSnapshot? = null
    @Volatile private var devCaptureActive: DevNaturalSnapshot? = null
    @Volatile private var devCaptureEnd: DevNaturalSnapshot? = null
    @Volatile private var devCaptureTask: ScheduledFuture<*>? = null

    fun cacheProfile(profile: NativeEffectProfile): ActionResult {
        if (profile.featureId != CrgProfile.FEATURE_GIANT &&
            profile.featureId != CrgProfile.FEATURE_SUPER
        ) {
            return failure("PROFILE_FEATURE_MISMATCH", "Native effect profile ไม่ถูกต้อง")
        }

        if (profile.dispatcherSignature.size != 4 ||
            profile.removerSignature.size != 4 ||
            profile.factorySignature.size != 4 ||
            profile.triggerVtableSlotOffset <= 0L ||
            profile.triggerVtableTarget <= 0L
        ) {
            return failure("PROFILE_LAYOUT_INVALID", "Native effect V13 profile layout ไม่ครบ")
        }

        val existing = bridgeProfile
        if (existing != null && !existing.sameBridge(profile)) {
            return failure("PROFILE_BRIDGE_CONFLICT", "Giant/Super profile ใช้ bridge profile คนละชุด")
        }

        profiles[profile.featureId] = profile
        bridgeProfile = existing ?: profile
        statuses.putIfAbsent(profile.featureId, "พร้อม • เปิด ON ได้ทุกหน้า")
        ensureTask()
        lab("PROFILE ${profile.featureId} rev=${profile.revision} id=${profile.effectId}")
        return success("Secure Native Effect V13 Profile พร้อม")
    }

    /**
     * ON is a desired state, not a Stage-only action.
     * Lobby/loading/game-not-ready conditions are treated as a successful queue.
     */
    fun enable(profile: NativeEffectProfile, callback: (ActionResult) -> Unit) {
        val cached = cacheProfile(profile)
        if (!cached.ok) {
            callback(cached)
            return
        }

        desired[profile.featureId] = true
        lastAppliedCharacter.remove(profile.featureId)
        lastApplyAttemptAt.remove(profile.featureId)
        statuses[profile.featureId] = "ON • กำลังตรวจ CookieRun / Stage..."
        lab("REQ ${profile.featureId} ON")

        executor.execute {
            val result = syncFeature(profile, wantsPresent = true, explicit = false)
            // ON is a desired state. Operational/runtime failures must not
            // silently flip the toggle back OFF; Lab keeps retrying until the
            // user explicitly disables the feature. Profile validation errors
            // already return before desired[] is set.
            if (result.ok) {
                runtime?.let { rt ->
                    inspectEffect(rt, profile).takeIf { it.state == EffectState.PRESENT }?.let {
                        lastAppliedCharacter[profile.featureId] = it.character
                    }
                }
            }
            statuses[profile.featureId] = result.message
            labState("RESULT:${profile.featureId}", "${result.errorCode ?: "OK"} • ${result.message}")
            Log.d(TAG, "enable ${profile.featureId}: ${result.errorCode ?: "OK"} • ${result.message}")
            callback(result)
        }
    }

    fun disable(featureId: String, callback: (ActionResult) -> Unit) {
        // Giant Size is meaningful only while Giant itself is desired.
        if (featureId == CrgProfile.FEATURE_GIANT) {
            stopGiantSizeFastLockInternal("Giant OFF")
        }

        // OFF must never wait for a future Stage.
        desired[featureId] = false
        lastAppliedCharacter.remove(featureId)
        lastApplyAttemptAt.remove(featureId)
        statuses[featureId] = "กำลังปิด..."
        lab("REQ $featureId OFF")

        executor.execute {
            val profile = profiles[featureId]
            var result = if (profile == null) {
                success("OFF")
            } else {
                syncFeature(profile, wantsPresent = false, explicit = true)
            }

            /*
             * Strong explicit OFF:
             * if one REMOVE leaves another effect node of the same ID behind,
             * repeat REMOVE until verification reaches ABSENT (max 6 passes).
             */
            if (profile != null && !result.ok) {
                var pass = 1
                while (
                    pass < 6 &&
                    desired[featureId] != true &&
                    (
                        result.errorCode == "INPROCESS_VERIFY_FAILED" ||
                        result.errorCode == "INPROCESS_BRIDGE_FAILED"
                    )
                ) {
                    Thread.sleep(90L)
                    pass += 1
                    lab("OFF RETRY $featureId pass=$pass • ${result.errorCode}")
                    result = syncFeature(
                        profile,
                        wantsPresent = false,
                        explicit = true
                    )
                }
            }

            statuses[featureId] = result.message
            Log.d(
                TAG,
                "disable $featureId: ${result.errorCode ?: "OK"} • ${result.message}"
            )
            callback(result)
        }
    }

    fun isEnabled(featureId: String): Boolean = desired[featureId] == true

    fun statusText(featureId: String): String = statuses[featureId] ?: "ยังไม่ได้เปิด"

    fun restoreFeatureBlockingBestEffort(featureId: String): ActionResult {
        desired[featureId] = false
        lastAppliedCharacter.remove(featureId)
        lastApplyAttemptAt.remove(featureId)
        val profile = profiles[featureId] ?: return success("OFF")

        return try {
            val future = executor.submit<ActionResult> {
                syncFeature(profile, wantsPresent = false, explicit = false)
            }
            val result = future.get(6, TimeUnit.SECONDS)
            statuses[featureId] = result.message
            result
        } catch (e: Exception) {
            failure("RESTORE_FAILED", e.message ?: "Native effect restore ไม่สำเร็จ")
        }
    }

    fun restoreAllBlockingBestEffort(): ActionResult {
        stopGiantSizeFastLockInternal("restoreAll")
        desired.keys.forEach { desired[it] = false }
        lastAppliedCharacter.clear()
        lastApplyAttemptAt.clear()

        return try {
            val future = executor.submit<ActionResult> {
                var firstFailure: ActionResult? = null
                listOf(CrgProfile.FEATURE_SUPER, CrgProfile.FEATURE_GIANT).forEach { id ->
                    val profile = profiles[id] ?: return@forEach
                    val result = syncFeature(profile, wantsPresent = false, explicit = false)
                    statuses[id] = result.message
                    if (!result.ok && firstFailure == null) firstFailure = result
                }
                firstFailure ?: success("Giant/Super OFF")
            }
            future.get(8, TimeUnit.SECONDS)
        } catch (e: Exception) {
            failure("RESTORE_FAILED", e.message ?: "Giant/Super restore ไม่สำเร็จ")
        }
    }

    fun shutdown(restore: Boolean) {
        devCaptureTask?.cancel(false)
        devCaptureTask = null
        if (closed) return
        stopGiantSizeFastLockInternal("shutdown")
        if (restore) {
            try { restoreAllBlockingBestEffort() } catch (_: Exception) {}
        }
        closed = true
        task?.cancel(false)
        task = null
        profiles.clear()
        bridgeProfile = null
        executor.shutdownNow()
        giantSizeExecutor.shutdownNow()
    }

    private fun ensureTask() {
        if (task != null || closed) return
        task = executor.scheduleWithFixedDelay(
            {
                try { maintenanceTick() } catch (e: Throwable) {
                    Log.w(TAG, "maintenance tick: ${e.message}")
                }
            },
            AUTO_TICK_MS,
            AUTO_TICK_MS,
            TimeUnit.MILLISECONDS
        )
    }

    /**
     * Android-side cross-stage persistence only.
     * There is no native hook installed while waiting in Lobby/loading.
     */
    private fun maintenanceTick() {
        if (closed || activeCommand) return

        if (BuildConfig.GAME_EFFECT_BRIDGE_ENABLED) {
            // Stable and Internal use the same proven Giant/Super path.
            maintenanceTickLabV8()
            return
        }

        listOf(CrgProfile.FEATURE_GIANT, CrgProfile.FEATURE_SUPER).forEach { featureId ->
            if (desired[featureId] != true || activeCommand) return@forEach
            val profile = profiles[featureId] ?: return@forEach

            val base = prepareRuntime(profile, requireCharacter = false)
            if (!base.ok) {
                if (isDeferredNotReady(base.errorCode)) {
                    statuses[featureId] = "ON • รอ CookieRun / Stage"
                    labState("WAIT:$featureId", "${base.errorCode} • ${base.message}")
                } else {
                    statuses[featureId] = base.message
                    labState("ERR:$featureId", "${base.errorCode} • ${base.message}")
                }
                return@forEach
            }

            val rt = runtime ?: return@forEach
            val inspection = inspectEffect(rt, profile)

            when (inspection.state) {
                EffectState.NO_CHARACTER -> {
                    lastAppliedCharacter.remove(featureId)
                    statuses[featureId] = "ON • รอเข้า Stage"
                    labState("CHAR:$featureId", "NO_CHARACTER • รอ Stage")
                }

                EffectState.PRESENT -> {
                    lastAppliedCharacter[featureId] = inspection.character
                    statuses[featureId] = "ON • Native ID${profile.effectId}"
                    labState(
                        "CHAR:$featureId",
                        "PRESENT char=0x${inspection.character.toString(16)} src=${inspection.source} effects=${inspection.count}"
                    )
                }

                EffectState.ABSENT -> {
                    val now = SystemClock.elapsedRealtime()
                    val lastTry = lastApplyAttemptAt[featureId] ?: 0L
                    labState(
                        "CHAR:$featureId",
                        "ABSENT char=0x${inspection.character.toString(16)} src=${inspection.source} effects=${inspection.count}"
                    )
                    if (now - lastTry >= APPLY_RETRY_MS) {
                        lastApplyAttemptAt[featureId] = now
                        val result = syncFeature(profile, wantsPresent = true, explicit = false)
                        if (result.ok) {
                            statuses[featureId] = result.message
                        } else if (!isDeferredNotReady(result.errorCode)) {
                            statuses[featureId] = result.message
                        }
                        labState("AUTO:$featureId", "${result.errorCode ?: "OK"} • ${result.message}")
                    }
                }

                EffectState.INVALID -> {
                    statuses[featureId] = "Native layout ไม่ตรง • ดู Lab Log"
                    labState(
                        "CHAR:$featureId",
                        "INVALID char=0x${inspection.character.toString(16)} src=${inspection.source} count=${inspection.count}"
                    )
                }
            }
        }
    }

    private fun maintenanceTickLabV8() {
        listOf(CrgProfile.FEATURE_GIANT, CrgProfile.FEATURE_SUPER).forEach { featureId ->
            if (desired[featureId] != true || activeCommand) return@forEach
            val profile = profiles[featureId] ?: return@forEach
            val prepared = prepareRuntime(profile, requireCharacter = false)
            if (!prepared.ok) {
                statuses[featureId] = if (isDeferredNotReady(prepared.errorCode)) {
                    "ON • รอ CookieRun / Stage"
                } else {
                    prepared.message
                }
                labState("IPWAIT:$featureId", "${prepared.errorCode ?: "OK"} • ${statuses[featureId]}")
                return@forEach
            }

            val rt = runtime ?: return@forEach
            val inspection = inspectEffect(rt, profile)
            when (inspection.state) {
                EffectState.NO_CHARACTER -> {
                    lastAppliedCharacter.remove(featureId)
                    statuses[featureId] = "ON • รอเข้า Stage"
                    labState("IPCHAR:$featureId", "NO_CHARACTER")
                }

                EffectState.PRESENT -> {
                    lastAppliedCharacter[featureId] = inspection.character
                    statuses[featureId] = "ON • ${featureDisplayName(profile.featureId)} ทำงาน"
                    labState(
                        "IPCHAR:$featureId",
                        "PRESENT char=0x${inspection.character.toString(16)} effects=${inspection.count}"
                    )
                }

                EffectState.ABSENT -> {
                    val now = SystemClock.elapsedRealtime()
                    val lastTry = lastApplyAttemptAt[featureId] ?: 0L
                    statuses[featureId] = "ON • กำลังเปิด ${featureDisplayName(profile.featureId)}"
                    if (now - lastTry >= APPLY_RETRY_MS) {
                        lastApplyAttemptAt[featureId] = now
                        val result = syncFeature(profile, wantsPresent = true, explicit = false)
                        statuses[featureId] = result.message
                        labState("IPAUTO:$featureId", "${result.errorCode ?: "OK"} • ${result.message}")
                    }
                }

                EffectState.INVALID -> {
                    statuses[featureId] = "Native layout ไม่ตรง • ดู DEV Log"
                    labState("IPCHAR:$featureId", "INVALID")
                }
            }
        }
    }

    private fun syncFeature(
        profile: NativeEffectProfile,
        wantsPresent: Boolean,
        explicit: Boolean
    ): ActionResult {
        if (closed) return failure("SHUTDOWN", "Native effect backend ปิดแล้ว")

        if (!memory.hasRoot() && !memory.requestRoot(appContext)) {
            return failure("ROOT_REQUIRED", "M Woif ต้องได้รับสิทธิ์ Root ก่อน")
        }

        val prepared = prepareRuntime(profile, requireCharacter = false)
        if (!prepared.ok) {
            if (isDeferredNotReady(prepared.errorCode)) {
                return if (wantsPresent) {
                    success("ON • รอ CookieRun / Stage")
                } else {
                    success("OFF • ไม่มี Stage ที่ต้องแก้")
                }
            }
            return prepared
        }
        val rt = runtime ?: return failure("RUNTIME_NOT_READY", "Native runtime ยังไม่พร้อม")

        val inspection = inspectEffect(rt, profile)
        if (inspection.state == EffectState.NO_CHARACTER) {
            return if (wantsPresent) {
                success("ON • รอเข้า Stage")
            } else {
                success("OFF • ไม่มี Character")
            }
        }
        if (inspection.state == EffectState.INVALID) {
            return failure("NATIVE_LAYOUT_INVALID", "โครงสร้าง Character/Effect ไม่ตรง profile")
        }

        if (BuildConfig.GAME_EFFECT_BRIDGE_ENABLED) {
            val already = if (wantsPresent) inspection.state == EffectState.PRESENT
            else inspection.state == EffectState.ABSENT
            if (already) {
                return if (wantsPresent) {
                    success("ON • ${featureDisplayName(profile.featureId)} ทำงาน")
                } else {
                    success("OFF • คืนสถานะแล้ว")
                }
            }

            activeCommand = true
            try {
                return issueInProcessCommand(
                    rt = rt,
                    profile = profile,
                    character = inspection.character,
                    wantsPresent = wantsPresent
                )
            } finally {
                activeCommand = false
            }
        }

        val already = if (wantsPresent) inspection.state == EffectState.PRESENT
        else inspection.state == EffectState.ABSENT
        if (already) {
            return if (wantsPresent) {
                success("ON • Native effect ทำงานอยู่")
            } else {
                success("OFF • Restore แล้ว")
            }
        }

        activeCommand = true
        try {
            val handlerReady = ensureOneShotHandler(rt, profile)
            if (!handlerReady.ok) return handlerReady

            return issueOneShot(
                rt = rt,
                profile = profile,
                character = inspection.character,
                command = if (wantsPresent) COMMAND_APPLY else COMMAND_REMOVE,
                wantsPresent = wantsPresent
            )
        } finally {
            activeCommand = false
        }
    }

    /**
     * V12 Internal/Lab command path.
     *
     * Java stays in the M Woif process for Secure Profile/root inspection. The
     * actual ARM64 game call executes only inside CookieRun through the LSPosed
     * receiver + ARM64 libwoif.so. After the receiver reports that the call
     * returned, root memory is used only to verify the effect state.
     */
    private fun issueInProcessCommand(
        rt: Runtime,
        profile: NativeEffectProfile,
        character: Long,
        wantsPresent: Boolean
    ): ActionResult {
        if (!BuildConfig.GAME_EFFECT_BRIDGE_ENABLED) {
            return failure("INPROCESS_DISABLED", "Game effect bridge ถูกปิด")
        }
        if (!isPointer(character)) {
            return failure("NO_CHARACTER", "ยังไม่พบ Character")
        }

        val bus = if (wantsPresent) {
            InProcessGameControl.apply(
                context = appContext,
                dispatcher = rt.dispatcher,
                character = character,
                effectId = profile.effectId
            )
        } else {
            InProcessGameControl.remove(
                context = appContext,
                remover = rt.remover,
                character = character,
                effectId = profile.effectId
            )
        }

        if (!bus.ok) {
            return failure("INPROCESS_BRIDGE_FAILED", "In-Process • ${bus.message}")
        }

        val deadline = SystemClock.elapsedRealtime() + 1800L
        var last = inspectEffect(rt, profile)
        while (SystemClock.elapsedRealtime() < deadline) {
            val targetReached = if (wantsPresent) {
                last.state == EffectState.PRESENT
            } else {
                last.state == EffectState.ABSENT
            }
            if (targetReached) {
                if (wantsPresent) lastAppliedCharacter[profile.featureId] = last.character
                else lastAppliedCharacter.remove(profile.featureId)
                return success(
                    if (wantsPresent) {
                        "ON • ${featureDisplayName(profile.featureId)} ทำงาน • verify OK"
                    } else {
                        "OFF • คืนสถานะแล้ว • verify OK"
                    }
                )
            }
            Thread.sleep(60L)
            last = inspectEffect(rt, profile)
        }

        return failure(
            "INPROCESS_VERIFY_FAILED",
            "In-Process call กลับมาแล้ว แต่ EffectManager ยังไม่เปลี่ยน • ${bus.message}"
        )
    }

    fun devPingInProcess(callback: (ActionResult) -> Unit) {
        if (!BuildConfig.INTERNAL_BUILD) {
            callback(failure("INTERNAL_ONLY", "DEV disabled"))
            return
        }
        executor.execute {
            val r = InProcessGameControl.ping(appContext)
            devProbeText = buildString {
                appendLine("AUTO A2 IN-PROCESS BRIDGE")
                appendLine("ping=${if (r.ok) "OK" else "FAIL"}")
                appendLine("game=${r.message}")
                appendLine("control=${InProcessGameControl.statusText()}")
                appendLine("expected native ABI=arm64-v8a")
                appendLine("--- LSPOSED GAME MARKER ---")
                append(InProcessGameControl.diagnosticMarkerViaRoot(runtime?.pid))
            }.trimEnd()
            lab("AUTO A2 PING ${if (r.ok) "OK" else "FAIL"} • ${r.message}")
            callback(if (r.ok) success(r.message) else failure("INPROCESS_PING_FAILED", r.message))
        }
    }

    /**
     * Resolve module/runtime and validate build data. This function does not
     * install any native hook.
     */
    private fun prepareRuntime(
        profile: NativeEffectProfile,
        requireCharacter: Boolean
    ): ActionResult {
        val pid = memory.pidOf(CrgProfile.GAME_PACKAGE)
            ?: run {
                runtime = null
                return failure("GAME_NOT_RUNNING", "CookieRun ยังไม่เปิด")
            }

        val maps = memory.maps(pid)
        val moduleMaps = maps.filter { it.path.contains("libgame.so") }
        if (moduleMaps.isEmpty()) {
            runtime = null
            return failure("LIBGAME_NOT_READY", "libgame.so ยังไม่พร้อม")
        }

        val moduleStart = moduleMaps.minOf { it.start }
        val moduleEnd = moduleMaps.maxOf { it.end }
        val bias = moduleStart - profile.imageBase

        val current = runtime
        if (current == null || current.pid != pid || current.bias != bias) {
            runtime = Runtime(
                pid = pid,
                moduleStart = moduleStart,
                moduleEnd = moduleEnd,
                bias = bias,
                dispatcher = bias + profile.dispatcherAddress,
                remover = bias + profile.removerAddress,
                stageServiceGlobal = bias + profile.stageServiceGlobal,
                caveA = 0L,
                caveB = 0L,
                caveC = 0L,
                state = 0L
            )
            lab(
                "RUNTIME pid=$pid base=0x${moduleStart.toString(16)} end=0x${moduleEnd.toString(16)} " +
                    "bias=0x${bias.toString(16)} maps=${moduleMaps.size}"
            )
        }

        val rt = runtime ?: return failure("RUNTIME_NOT_READY", "Native runtime ยังไม่พร้อม")

        val signatures = listOf(
            rt.dispatcher to profile.dispatcherSignature,
            rt.remover to profile.removerSignature,
            (bias + profile.factoryAddress) to profile.factorySignature
        )
        signatures.forEach { (address, expected) ->
            if (!sameWords(pid, address, expected)) {
                return failure(
                    "BUILD_SIGNATURE_MISMATCH",
                    "Native build signature ไม่ตรง @${address.toString(16)}"
                )
            }
        }

        if (requireCharacter && resolveCharacter(rt, profile) == null) {
            labState("PREP:${profile.featureId}", "NO_CHARACTER")
        }

        return success("Native runtime พร้อม")
    }

    /**
     * Install inert handler bytes once. No code hook points at them.
     */
    private fun ensureOneShotHandler(
        base: Runtime,
        profile: NativeEffectProfile
    ): ActionResult {
        if (base.state != 0L && base.caveA != 0L && validateState(base.pid, base.state)) {
            val expected = buildHandlers(base)
            if (expected != null && verifyHandlers(base, expected)) {
                return success("V7 one-shot handler พร้อม")
            }
        }

        val maps = memory.maps(base.pid)

        findExistingDynamicRuntime(base, maps)?.let { existing ->
            runtime = existing
            lab(
                "HANDLER reconnect A=0x${existing.caveA.toString(16)} " +
                    "B=0x${existing.caveB.toString(16)} C=0x${existing.caveC.toString(16)} " +
                    "state=0x${existing.state.toString(16)}"
            )
            return success("V7 one-shot handler reconnect แล้ว")
        }

        val now = SystemClock.elapsedRealtime()
        lastCaveScanFailure?.let { cached ->
            if (now - lastCaveScanAt < CAVE_RESCAN_COOLDOWN_MS) {
                labState("CAVE", "cooldown ${CAVE_RESCAN_COOLDOWN_MS - (now - lastCaveScanAt)}ms • ${cached.errorCode}")
                return cached
            }
        }

        lastCaveScanAt = now
        val caves = selectExecutableCaves(base, maps)
        if (caves == null) {
            val failed = failure(
                "EXEC_CAVE_UNAVAILABLE",
                "ไม่พบ executable zero/NOP caves ของ libgame • เปิด DEV > Copy Log"
            )
            lastCaveScanFailure = failed
            return failed
        }
        lastCaveScanFailure = null

        val state = selectModuleStateSlot(base.pid, maps)
            ?: return failure("RW_STATE_SLOT_UNAVAILABLE", "ไม่พบ zero RW state slot ของ libgame")

        val rt = base.copy(
            caveA = caves.first,
            caveB = caves.second,
            caveC = caves.third,
            state = state
        )

        if (!validateCaveLocations(maps, rt)) {
            return failure("CAVE_MAPPING_MISMATCH", "Dynamic caves ไม่อยู่ executable mapping")
        }

        val handlers = buildHandlers(rt)
            ?: return failure("HANDLER_BUILD_FAILED", "สร้าง V7 one-shot handler ไม่สำเร็จ")

        lab(
            "ALLOC A=0x${rt.caveA.toString(16)} B=0x${rt.caveB.toString(16)} " +
                "C=0x${rt.caveC.toString(16)} state=0x${rt.state.toString(16)}"
        )

        if (!RootMemoryClient.signal(rt.pid, OsConstants.SIGSTOP)) {
            return failure("SIGNAL_FAILED", "หยุดเกมชั่วคราวเพื่อติดตั้ง V7 handler ไม่ได้")
        }

        var resumed = false
        try {
            if (!isCleanCaveRegion(rt.pid, rt.caveA) ||
                !isCleanCaveRegion(rt.pid, rt.caveB) ||
                !isCleanCaveRegion(rt.pid, rt.caveC)
            ) {
                return failure("DYNAMIC_CAVE_DIRTY", "Dynamic code cave ไม่ว่างแล้ว • ลองเปิดใหม่")
            }

            val bytes = memory.readBytes(rt.pid, state, STATE_SLOT_SIZE.toInt())
                ?: return failure("STATE_READ_FAILED", "อ่าน V7 RW state ไม่ได้")
            if (bytes.any { it.toInt() != 0 }) {
                return failure("RW_STATE_SLOT_DIRTY", "V7 RW state slot ไม่ว่าง")
            }

            if (!initializeState(rt)) {
                return failure("STATE_INIT_FAILED", "สร้าง V7 RW state ไม่สำเร็จ")
            }

            // C -> B -> A. Nothing references these caves until a one-shot command.
            if (!writeWords(rt.pid, rt.caveC, handlers.third) ||
                !writeWords(rt.pid, rt.caveB, handlers.second) ||
                !writeWords(rt.pid, rt.caveA, handlers.first)
            ) {
                return failure("HANDLER_WRITE_FAILED", "เขียน V7 one-shot handler ไม่สำเร็จ")
            }

            if (!verifyHandlers(rt, handlers)) {
                return failure("HANDLER_VERIFY_FAILED", "ตรวจ V7 one-shot handler ไม่ผ่าน")
            }
        } finally {
            resumed = RootMemoryClient.signal(rt.pid, OsConstants.SIGCONT)
        }

        if (!resumed) {
            return failure("SIGNAL_FAILED", "ปล่อยเกมหลังติดตั้ง V7 handler ไม่ได้")
        }

        runtime = rt
        return success("V7 one-shot handler พร้อม • dynamic caves")
    }

    private fun issueOneShot(
        rt: Runtime,
        profile: NativeEffectProfile,
        character: Long,
        command: Int,
        wantsPresent: Boolean
    ): ActionResult {
        val vptr = memory.readLong(rt.pid, character)
            ?: return failure("CHARACTER_VPTR_READ_FAILED", "อ่าน Character vptr ไม่ได้")
        if (vptr !in rt.moduleStart until rt.moduleEnd) {
            return failure("CHARACTER_VPTR_MISMATCH", "Character vptr ไม่ได้อยู่ใน libgame build นี้")
        }

        // Character can be a valid runtime subclass.  The authoritative safety
        // check is the exact original function currently stored in slot +0x158,
        // not one hard-coded Character vptr value.
        val slot = vptr + profile.triggerVtableSlotOffset
        val expectedTarget = rt.bias + profile.triggerVtableTarget
        var original = memory.readLong(rt.pid, slot)
            ?: return failure("VTABLE_SLOT_READ_FAILED", "อ่าน V7 trigger slot ไม่ได้")

        // Recover only our own abandoned one-shot pointer after an interrupted app action.
        if (original == rt.caveA) {
            if (!RootMemoryClient.signal(rt.pid, OsConstants.SIGSTOP)) {
                return failure("SIGNAL_FAILED", "หยุดเกมเพื่อกู้ V7 trigger ไม่ได้")
            }
            try {
                if (!writeLong(rt.pid, slot, expectedTarget)) {
                    return failure("VTABLE_RECOVERY_FAILED", "กู้ V7 trigger slot ไม่สำเร็จ")
                }
            } finally {
                RootMemoryClient.signal(rt.pid, OsConstants.SIGCONT)
            }
            original = expectedTarget
        }

        labState(
            "TRIGGER:${profile.featureId}",
            "char=0x${character.toString(16)} vptr=0x${vptr.toString(16)} " +
                "slot=0x${slot.toString(16)} original=0x${original.toString(16)} expected=0x${expectedTarget.toString(16)}"
        )

        if (original != expectedTarget) {
            return failure(
                "VTABLE_TARGET_MISMATCH",
                "V7 trigger target ไม่ตรง @${slot.toString(16)}"
            )
        }

        if (!RootMemoryClient.signal(rt.pid, OsConstants.SIGSTOP)) {
            return failure("SIGNAL_FAILED", "หยุดเกมชั่วคราวเพื่อส่ง V7 one-shot ไม่ได้")
        }

        var resumed = false
        var slotPatched = false
        try {
            val payloadOk = writeByte(rt.pid, rt.state + STATE_DONE, 0) &&
                writeInt(rt.pid, rt.state + STATE_ID, profile.effectId) &&
                writeLong(rt.pid, rt.state + STATE_TARGET_CHARACTER, character) &&
                writeLong(rt.pid, rt.state + STATE_ORIGINAL_VFUNC, original) &&
                writeByte(rt.pid, rt.state + STATE_CMD, command)
            if (!payloadOk) {
                return failure("STATE_WRITE_FAILED", "เขียน V7 one-shot payload ไม่สำเร็จ")
            }

            if (!writeLong(rt.pid, slot, rt.caveA)) {
                writeByte(rt.pid, rt.state + STATE_CMD, COMMAND_NONE)
                return failure("VTABLE_PATCH_FAILED", "ติด V7 one-shot trigger ไม่สำเร็จ")
            }
            slotPatched = true
        } finally {
            resumed = RootMemoryClient.signal(rt.pid, OsConstants.SIGCONT)
        }

        if (!resumed) {
            if (slotPatched) restoreVtableSlotBestEffort(rt.pid, slot, original)
            return failure("SIGNAL_FAILED", "ปล่อยเกมหลังส่ง V7 one-shot ไม่ได้")
        }

        val timeout = minOf(profile.commandTimeoutMs.toLong(), VTABLE_TRIGGER_TIMEOUT_MS)
        val deadline = SystemClock.elapsedRealtime() + timeout
        var done = false

        try {
            while (SystemClock.elapsedRealtime() < deadline) {
                done = (memory.readByteUnsigned(rt.pid, rt.state + STATE_DONE) ?: 0) == 1
                if (done) break
                SystemClock.sleep(2L)
            }
        } finally {
            restoreVtableSlotBestEffort(rt.pid, slot, original)
            writeByte(rt.pid, rt.state + STATE_CMD, COMMAND_NONE)
            writeByte(rt.pid, rt.state + STATE_DONE, 0)
        }

        if (!done) {
            return failure("V7_TRIGGER_TIMEOUT", "V7 one-shot ไม่ถูกเรียกภายใน Stage • ดู Lab Log")
        }

        SystemClock.sleep(VERIFY_DELAY_MS)
        val current = inspectEffect(rt, profile)
        val expected = if (wantsPresent) EffectState.PRESENT else EffectState.ABSENT
        if (current.state != expected) {
            return failure("NATIVE_VERIFY_FAILED", "V7 native call จบ แต่ EffectManager state ไม่ตรง")
        }

        return if (wantsPresent) {
            success("ON • Native ID${profile.effectId} • 9999s")
        } else {
            success("OFF • Native ID${profile.effectId} ถูก remove")
        }
    }

    /**
     * V7 one-shot handler layout, 60 + 60 + 52 bytes.
     *
     * It intercepts a Character vfunc for one call only. It checks x0 against
     * STATE_TARGET_CHARACTER, performs APPLY/REMOVE when requested, then calls
     * STATE_ORIGINAL_VFUNC(x0,w1) and returns that original result.
     */
    private fun buildHandlers(rt: Runtime): Triple<IntArray, IntArray, IntArray>? {
        val a = intArrayOf(
            0xD10183FF.toInt(), // sub sp,sp,#0x60
            0xA90053F3.toInt(), // stp x19,x20,[sp]
            0xA9017BF5.toInt(), // stp x21,x30,[sp,#0x10]
            0xAA0003F3.toInt(), // mov x19,x0
            0x2A0103F4.toInt(), // mov w20,w1
            0,                  // ldr x21, state literal
            0xF94006A8.toInt(), // ldr x8,[x21,#8]
            0xEB08027F.toInt(), // cmp x19,x8
            0,                  // b.ne original
            0x394002A8.toInt(), // ldrb w8,[x21]
            0,                  // cbz w8, original
            0x7100051F.toInt(), // cmp w8,#1
            0,                  // b.eq apply
            0x7100091F.toInt(), // cmp w8,#2
            0                   // b.eq remove
        )

        val b = intArrayOf(
            0xA9027FFF.toInt(), // stp xzr,xzr,[sp,#0x20]
            0xF9001BFF.toInt(), // str xzr,[sp,#0x30]
            0xB94006A8.toInt(), // ldr w8,[x21,#4]
            0xB9002BE8.toInt(), // str w8,[sp,#0x28] -> event+8 id
            0xAA1303E0.toInt(), // mov x0,x19
            0x910083E1.toInt(), // add x1,sp,#0x20
            0,                  // bl dispatcher
            0x52800028.toInt(), // mov w8,#1
            0x390062A8.toInt(), // strb w8,[x21,#0x18]
            0x390002BF.toInt(), // strb wzr,[x21]
            0,                  // b original
            0x91052260.toInt(), // add x0,x19,#0x148
            0xB94006A1.toInt(), // ldr w1,[x21,#4]
            0,                  // bl remover
            0                   // b common done
        )

        val c = intArrayOf(
            0x52800028.toInt(), // mov w8,#1
            0x390062A8.toInt(), // strb w8,[x21,#0x18]
            0x390002BF.toInt(), // strb wzr,[x21]
            0xAA1303E0.toInt(), // mov x0,x19
            0x2A1403E1.toInt(), // mov w1,w20
            0xF9400AA8.toInt(), // ldr x8,[x21,#0x10]
            0xD63F0100.toInt(), // blr x8
            0xA9417BF5.toInt(), // ldp x21,x30,[sp,#0x10]
            0xA94053F3.toInt(), // ldp x19,x20,[sp]
            0x910183FF.toInt(), // add sp,sp,#0x60
            0xD65F03C0.toInt(), // ret
            0,                  // state low literal
            0                   // state high literal
        )

        val originalPath = rt.caveC + 0x0CL
        val applyPath = rt.caveB
        val removePath = rt.caveB + 0x2CL
        val commonDone = rt.caveC
        val stateLiteral = rt.caveC + 0x2CL

        a[5] = encodeLdrLiteralX(rt.caveA + 0x14L, stateLiteral, 21) ?: return null
        a[8] = encodeBCond(rt.caveA + 0x20L, originalPath, 1) ?: return null // NE
        a[10] = encodeCbzW(rt.caveA + 0x28L, originalPath, 8) ?: return null
        a[12] = encodeBCond(rt.caveA + 0x30L, applyPath, 0) ?: return null // EQ
        a[14] = encodeBCond(rt.caveA + 0x38L, removePath, 0) ?: return null // EQ

        b[6] = encodeBranch(rt.caveB + 0x18L, rt.dispatcher, true) ?: return null
        b[10] = encodeBranch(rt.caveB + 0x28L, originalPath, false) ?: return null
        b[13] = encodeBranch(rt.caveB + 0x34L, rt.remover, true) ?: return null
        b[14] = encodeBranch(rt.caveB + 0x38L, commonDone, false) ?: return null

        val low = (rt.state and 0xFFFFFFFFL).toInt()
        val high = ((rt.state ushr 32) and 0xFFFFFFFFL).toInt()
        c[11] = low
        c[12] = high

        return Triple(a, b, c)
    }

    private fun initializeState(rt: Runtime): Boolean {
        return writeByte(rt.pid, rt.state + STATE_CMD, COMMAND_NONE) &&
            writeInt(rt.pid, rt.state + STATE_ID, 0) &&
            writeLong(rt.pid, rt.state + STATE_TARGET_CHARACTER, 0L) &&
            writeLong(rt.pid, rt.state + STATE_ORIGINAL_VFUNC, 0L) &&
            writeByte(rt.pid, rt.state + STATE_DONE, 0) &&
            writeInt(rt.pid, rt.state + STATE_MAGIC, STATE_MAGIC_VALUE) &&
            writeInt(rt.pid, rt.state + STATE_VERSION, STATE_VERSION_VALUE) &&
            writeLong(rt.pid, rt.state + STATE_CAVE_A, rt.caveA) &&
            writeLong(rt.pid, rt.state + STATE_CAVE_B, rt.caveB) &&
            writeLong(rt.pid, rt.state + STATE_CAVE_C, rt.caveC)
    }

    private fun validateState(pid: Int, state: Long): Boolean {
        val map = memory.maps(pid).firstOrNull { state >= it.start && state + STATE_SLOT_SIZE <= it.end }
            ?: return false
        if (!map.perms.contains('w') || map.perms.contains('x')) return false
        return memory.readInt(pid, state + STATE_MAGIC) == STATE_MAGIC_VALUE &&
            memory.readInt(pid, state + STATE_VERSION) == STATE_VERSION_VALUE
    }

    private fun findExistingDynamicRuntime(
        base: Runtime,
        maps: List<RootProcessMemory.MapEntry>
    ): Runtime? {
        val writable = maps.filter {
            it.path.contains("libgame.so") && it.perms.contains('w') && !it.perms.contains('x')
        }

        writable.forEach { map ->
            val scanStart = maxOf(map.start, map.end - DYNAMIC_STATE_SCAN_BYTES)
            var address = alignUp(scanStart, 4L)
            while (address + 8L <= map.end) {
                val chunkSize = minOf(4096L, map.end - address).toInt()
                val bytes = memory.readBytes(base.pid, address, chunkSize) ?: break
                val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var offset = 0
                while (offset + 8 <= bytes.size) {
                    val magic = buffer.getInt(offset)
                    if (magic == STATE_MAGIC_VALUE) {
                        val state = address + offset - STATE_MAGIC
                        if (state >= map.start && state + STATE_SLOT_SIZE <= map.end && validateState(base.pid, state)) {
                            val caveA = memory.readLong(base.pid, state + STATE_CAVE_A) ?: 0L
                            val caveB = memory.readLong(base.pid, state + STATE_CAVE_B) ?: 0L
                            val caveC = memory.readLong(base.pid, state + STATE_CAVE_C) ?: 0L
                            val rt = base.copy(caveA = caveA, caveB = caveB, caveC = caveC, state = state)
                            if (validateCaveLocations(maps, rt)) {
                                val expected = buildHandlers(rt)
                                if (expected != null && verifyHandlers(rt, expected)) return rt
                            }
                        }
                    }
                    offset += 4
                }
                address += bytes.size.toLong()
            }
        }
        return null
    }

    private fun selectExecutableCaves(
        rt: Runtime,
        maps: List<RootProcessMemory.MapEntry>
    ): Triple<Long, Long, Long>? {
        val candidates = ArrayList<Long>()
        val executable = maps.filter {
            it.path.contains("libgame.so") &&
                it.perms.contains('x') &&
                it.end > it.start &&
                abs(it.start - rt.dispatcher) < BRANCH_RANGE_26
        }

        lab(
            "EXEC maps=" + executable.joinToString {
                "[0x${it.start.toString(16)}-0x${it.end.toString(16)} ${it.perms} size=0x${(it.end-it.start).toString(16)}]"
            }
        )

        fun scanRange(map: RootProcessMemory.MapEntry, scanStartRaw: Long, label: String) {
            val scanStart = alignUp(maxOf(map.start, scanStartRaw), 4L)
            var address = scanStart
            var runStart = 0L
            var runBytes = 0L
            val before = candidates.size
            var scanned = 0L

            while (address + 4L <= map.end) {
                val chunkSize = minOf(4096L, map.end - address).toInt()
                val bytes = memory.readBytes(rt.pid, address, chunkSize)
                if (bytes == null) {
                    lab("EXEC $label read-fail @0x${address.toString(16)}")
                    break
                }
                val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var offset = 0
                while (offset + 4 <= bytes.size) {
                    val wordAddress = address + offset
                    val word = buffer.getInt(offset)
                    if (word == 0 || word == NOP) {
                        if (runBytes == 0L) runStart = wordAddress
                        runBytes += 4L
                        val aligned = alignUp(runStart, 16L)
                        if (aligned + DYNAMIC_CAVE_REGION_SIZE <= wordAddress + 4L) {
                            if (candidates.none {
                                    rangesOverlap(
                                        it,
                                        DYNAMIC_CAVE_REGION_SIZE,
                                        aligned,
                                        DYNAMIC_CAVE_REGION_SIZE
                                    )
                                }
                            ) {
                                candidates.add(aligned)
                                runStart = aligned + DYNAMIC_CAVE_REGION_SIZE
                                runBytes = maxOf(0L, wordAddress + 4L - runStart)
                            }
                        }
                    } else {
                        runStart = 0L
                        runBytes = 0L
                    }
                    offset += 4
                }
                scanned += bytes.size.toLong()
                address += bytes.size.toLong()
            }
            lab(
                "EXEC $label range=0x${scanStart.toString(16)}-0x${map.end.toString(16)} " +
                    "scanned=0x${scanned.toString(16)} added=${candidates.size - before}"
            )
        }

        fun pick(): Triple<Long, Long, Long>? {
            val safe = candidates.filter {
                abs(it - rt.dispatcher) < BRANCH_RANGE_26 &&
                    abs(it - rt.remover) < BRANCH_RANGE_26
            }
            lab(
                "EXEC clean-cave candidates=${safe.size} " +
                    safe.takeLast(12).joinToString { "0x${it.toString(16)}" }
            )
            if (safe.size < 3) return null

            for (index in safe.indices.reversed()) {
                val anchor = safe[index]
                val cluster = safe.filter { abs(it - anchor) < BRANCH_RANGE_19 - 0x100L }
                if (cluster.size >= 3) {
                    val selected = cluster.takeLast(3)
                    lab("EXEC selected=" + selected.joinToString { "0x${it.toString(16)}" })
                    return Triple(selected[0], selected[1], selected[2])
                }
            }
            lab("EXEC candidates exist but no 3-cave cluster inside imm19 range")
            return null
        }

        // Fast path: same behavior as V6, search only the tail first.
        executable.forEach { map ->
            scanRange(map, maxOf(map.start, map.end - DYNAMIC_CAVE_FAST_SCAN_BYTES), "FAST")
        }
        pick()?.let { return it }

        // V7 fallback: V6 stopped here. Lab now scans the rest of every
        // executable libgame mapping so a valid cave outside the final 2 MiB
        // is no longer missed. This is intentionally one-shot/cooldown gated.
        lab("EXEC FAST insufficient -> FULL libgame executable scan")
        executable.forEach { map ->
            val fastStart = maxOf(map.start, map.end - DYNAMIC_CAVE_FAST_SCAN_BYTES)
            if (fastStart > map.start) {
                scanRange(map, map.start, "FULL")
            }
        }
        return pick()
    }

    private fun selectModuleStateSlot(
        pid: Int,
        maps: List<RootProcessMemory.MapEntry>
    ): Long? {
        val writable = maps.filter {
            it.path.contains("libgame.so") &&
                it.perms.contains('w') &&
                !it.perms.contains('x') &&
                it.end - it.start >= STATE_SLOT_SIZE
        }.sortedByDescending { it.end }

        writable.forEach { map ->
            // Prefer the very end first; this was the safest V4/V5 location.
            val tail = alignDown(map.end - STATE_SLOT_SIZE, 16L)
            if (tail >= map.start && isZeroRegion(pid, tail, STATE_SLOT_SIZE.toInt())) {
                lab("STATE tail=0x${tail.toString(16)} map=${map.perms}")
                return tail
            }

            // Lab fallback: search only the last 1 MiB for a full 0x100 zero slot.
            val scanStart = maxOf(map.start, map.end - DYNAMIC_STATE_SCAN_BYTES)
            var address = alignUp(scanStart, 16L)
            while (address + STATE_SLOT_SIZE <= map.end) {
                if (isZeroRegion(pid, address, STATE_SLOT_SIZE.toInt())) {
                    lab("STATE scan=0x${address.toString(16)} map=${map.perms}")
                    return address
                }
                address += 0x40L
            }
        }
        lab("STATE no zero RW slot")
        return null
    }

    private fun isCleanCaveRegion(pid: Int, address: Long): Boolean {
        val words = readWords(pid, address, (DYNAMIC_CAVE_REGION_SIZE / 4L).toInt()) ?: return false
        return words.all { it == 0 || it == NOP }
    }

    private fun isZeroRegion(pid: Int, address: Long, size: Int): Boolean {
        val bytes = memory.readBytes(pid, address, size) ?: return false
        return bytes.size == size && bytes.all { it.toInt() == 0 }
    }

    private fun verifyHandlers(
        rt: Runtime,
        expected: Triple<IntArray, IntArray, IntArray>
    ): Boolean {
        return readWords(rt.pid, rt.caveA, CAVE_A_WORDS).contentEqualsSafe(expected.first) &&
            readWords(rt.pid, rt.caveB, CAVE_B_WORDS).contentEqualsSafe(expected.second) &&
            readWords(rt.pid, rt.caveC, CAVE_C_WORDS).contentEqualsSafe(expected.third)
    }

    private fun validateCaveLocations(
        maps: List<RootProcessMemory.MapEntry>,
        rt: Runtime
    ): Boolean {
        if (rt.caveA == 0L || rt.caveB == 0L || rt.caveC == 0L) return false
        val caves = listOf(rt.caveA, rt.caveB, rt.caveC)
        if (caves.distinct().size != 3) return false
        return caves.all { address ->
            val map = maps.firstOrNull { address >= it.start && address + DYNAMIC_CAVE_REGION_SIZE <= it.end }
            map != null && map.path.contains("libgame.so") && map.perms.contains('x') &&
                abs(address - rt.dispatcher) < BRANCH_RANGE_26 &&
                abs(address - rt.remover) < BRANCH_RANGE_26
        }
    }

    private fun rangesOverlap(a: Long, aSize: Long, b: Long, bSize: Long): Boolean =
        a < b + bSize && b < a + aSize

    private fun alignUp(value: Long, alignment: Long): Long =
        (value + alignment - 1L) and -alignment

    private fun alignDown(value: Long, alignment: Long): Long =
        value and -alignment

    private fun restoreVtableSlotBestEffort(pid: Int, slot: Long, original: Long) {
        try {
            if (RootMemoryClient.signal(pid, OsConstants.SIGSTOP)) {
                try {
                    writeLong(pid, slot, original)
                } finally {
                    RootMemoryClient.signal(pid, OsConstants.SIGCONT)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * V7 live-effect inspection.
     *
     * Ghidra confirmed FUN_00F3B2DC(Character) -> *(Character + 0x5E0),
     * and FUN_00E5F77C inserts effects into EffectManager's intrusive list.
     *
     * Stable/older secure profiles are still accepted: when the EffectManager marker
     * offsets are absent we fall back to the legacy Character vector verifier.
     */
    private fun inspectEffect(rt: Runtime, profile: NativeEffectProfile): Inspection {
        return if (isEffectManagerListProfile(profile)) {
            inspectEffectManagerList(rt, profile)
        } else {
            inspectLegacyVectorEffect(rt, profile)
        }
    }

    private fun inspectEffectManagerList(
        rt: Runtime,
        profile: NativeEffectProfile
    ): Inspection {
        val resolved = resolveCharacter(rt, profile) ?: return Inspection(EffectState.NO_CHARACTER)
        val character = resolved.first
        val source = resolved.second

        val manager = memory.readLong(rt.pid, character + profile.effectManagerOffset)
            ?: return Inspection(EffectState.INVALID, character, source)
        if (!isPointer(manager)) {
            return Inspection(EffectState.INVALID, character, source)
        }

        val managerVptr = memory.readLong(rt.pid, manager)
            ?: return Inspection(EffectState.INVALID, character, source)
        if (managerVptr !in rt.moduleStart until rt.moduleEnd) {
            return Inspection(EffectState.INVALID, character, source)
        }

        // V7 uses the same wire offsets for EffectManager verification:
        // b4 = sentinel/head offset (0x18)
        // b5 = count offset         (0x28)
        // b6 = node->effect offset  (0x10)
        val sentinel = manager + profile.effectBeginOffset
        val rawCount = memory.readLong(rt.pid, manager + profile.effectEndOffset)
            ?: return Inspection(EffectState.INVALID, character, source)
        if (rawCount < 0L || rawCount > profile.maxEffects.toLong()) {
            return Inspection(EffectState.INVALID, character, source, rawCount.toInt())
        }

        var node = memory.readLong(rt.pid, sentinel)
            ?: return Inspection(EffectState.INVALID, character, source)
        val expectedEffectVptr = rt.bias + profile.effectVptr
        var visited = 0

        while (node != sentinel) {
            if (!isPointer(node) || visited >= profile.maxEffects) {
                return Inspection(EffectState.INVALID, character, source, visited)
            }

            val pointer = memory.readLong(rt.pid, node + profile.effectCapOffset)
            if (pointer != null && isPointer(pointer) &&
                matchesEffectPointer(rt, profile, pointer, expectedEffectVptr)
            ) {
                return Inspection(EffectState.PRESENT, character, source, rawCount.toInt())
            }

            node = memory.readLong(rt.pid, node)
                ?: return Inspection(EffectState.INVALID, character, source, visited)
            visited++
        }

        return Inspection(EffectState.ABSENT, character, source, rawCount.toInt())
    }

    /** Legacy verifier kept only so stable revisions remain backward-compatible. */
    private fun inspectLegacyVectorEffect(
        rt: Runtime,
        profile: NativeEffectProfile
    ): Inspection {
        val resolved = resolveCharacter(rt, profile) ?: return Inspection(EffectState.NO_CHARACTER)
        val character = resolved.first
        val source = resolved.second

        val begin = memory.readLong(rt.pid, character + profile.effectBeginOffset)
            ?: return Inspection(EffectState.INVALID, character, source)
        val end = memory.readLong(rt.pid, character + profile.effectEndOffset)
            ?: return Inspection(EffectState.INVALID, character, source)
        val cap = memory.readLong(rt.pid, character + profile.effectCapOffset)
            ?: return Inspection(EffectState.INVALID, character, source)

        if (begin == 0L && end == 0L && cap == 0L) {
            return Inspection(EffectState.ABSENT, character, source, 0)
        }
        if (!isPointer(begin) || end < begin || cap < end || (end - begin) % 8L != 0L) {
            return Inspection(EffectState.INVALID, character, source)
        }

        val count = ((end - begin) / 8L).toInt()
        if (count !in 0..profile.maxEffects) {
            return Inspection(EffectState.INVALID, character, source, count)
        }

        val expectedEffectVptr = rt.bias + profile.effectVptr
        repeat(count) { index ->
            val pointer = memory.readLong(rt.pid, begin + index * 8L) ?: return@repeat
            if (isPointer(pointer) && matchesEffectPointer(rt, profile, pointer, expectedEffectVptr)) {
                return Inspection(EffectState.PRESENT, character, source, count)
            }
        }

        return Inspection(EffectState.ABSENT, character, source, count)
    }

    private fun matchesEffectPointer(
        rt: Runtime,
        profile: NativeEffectProfile,
        pointer: Long,
        expectedEffectVptr: Long
    ): Boolean {
        val idDirect = memory.readInt(rt.pid, pointer + profile.effectIdDirectOffset)
        if (idDirect == profile.effectId) {
            val effectVptr = memory.readLong(rt.pid, pointer)
            if (effectVptr == expectedEffectVptr) return true
        }

        // FUN_00E5F77C commonly stores the +8 base-subobject pointer.
        val idAdjusted = memory.readInt(rt.pid, pointer + profile.effectIdAdjustedOffset)
        if (idAdjusted == profile.effectId && pointer >= 0x10008L) {
            val back8 = memory.readLong(rt.pid, pointer - 8L)
            if (back8 == expectedEffectVptr) return true
        }
        return false
    }

    private fun isEffectManagerListProfile(profile: NativeEffectProfile): Boolean {
        return profile.effectManagerOffset == 0x5E0L &&
            profile.effectBeginOffset == 0x18L &&
            profile.effectEndOffset == 0x28L &&
            profile.effectCapOffset == 0x10L
    }

    private fun resolveCharacter(
        rt: Runtime,
        profile: NativeEffectProfile
    ): Pair<Long, String>? {
        val service = memory.readLong(rt.pid, rt.stageServiceGlobal) ?: run {
            labState("RESOLVE:${profile.featureId}", "stageServiceGlobal unreadable @0x${rt.stageServiceGlobal.toString(16)}")
            return null
        }
        if (!isPointer(service)) {
            labState("RESOLVE:${profile.featureId}", "service invalid=0x${service.toString(16)}")
            return null
        }

        val direct = memory.readLong(rt.pid, service + profile.serviceCharacterOffset) ?: 0L
        if (validateCharacter(rt, profile, direct)) {
            labState("RESOLVE:${profile.featureId}", "direct char=0x${direct.toString(16)} service=0x${service.toString(16)}")
            return direct to "direct"
        }

        val jelly = memory.readLong(rt.pid, service + profile.serviceJellyManagerOffset) ?: 0L
        if (isPointer(jelly)) {
            val fallback = memory.readLong(rt.pid, jelly + profile.jellyManagerCharacterOffset) ?: 0L
            if (validateCharacter(rt, profile, fallback)) {
                labState("RESOLVE:${profile.featureId}", "jelly char=0x${fallback.toString(16)} service=0x${service.toString(16)}")
                return fallback to "jelly"
            }
        }
        labState(
            "RESOLVE:${profile.featureId}",
            "no char service=0x${service.toString(16)} direct=0x${direct.toString(16)} jelly=0x${jelly.toString(16)}"
        )
        return null
    }

    private fun validateCharacter(
        rt: Runtime,
        profile: NativeEffectProfile,
        character: Long
    ): Boolean {
        if (!isPointer(character)) return false

        // Runtime subclasses can use different Character vtables.  Stay scoped
        // to this libgame image and verify the exact +0x158 target at command time.
        val characterVptr = memory.readLong(rt.pid, character) ?: return false
        if (characterVptr !in rt.moduleStart until rt.moduleEnd) return false

        if (!isEffectManagerListProfile(profile)) {
            // Legacy stable profile: +b3 was an embedded manager-like vptr.
            val legacyManagerVptr = memory.readLong(rt.pid, character + profile.effectManagerOffset)
                ?: return false
            return legacyManagerVptr in rt.moduleStart until rt.moduleEnd
        }

        val manager = memory.readLong(rt.pid, character + profile.effectManagerOffset) ?: return false
        if (!isPointer(manager)) return false
        val managerVptr = memory.readLong(rt.pid, manager) ?: return false
        if (managerVptr !in rt.moduleStart until rt.moduleEnd) return false

        // Minimal intrusive-list sanity. CRG_CreateCRXWorld_00E5F538 initializes
        // sentinel next/prev to manager+0x18 and count at manager+0x28.
        val sentinel = manager + profile.effectBeginOffset
        val head = memory.readLong(rt.pid, sentinel) ?: return false
        val tail = memory.readLong(rt.pid, sentinel + 8L) ?: return false
        val count = memory.readLong(rt.pid, manager + profile.effectEndOffset) ?: return false
        return isPointer(head) && isPointer(tail) && count in 0L..profile.maxEffects.toLong()
    }

    fun devSnapshotText(): String {
        if (!BuildConfig.INTERNAL_BUILD) return "DEV disabled"
        val rt = runtime
        return buildString {
            appendLine("NativeEffect V15 PLAY / IN-PROCESS LAB")
            if (rt == null) {
                appendLine("runtime: not prepared")
            } else {
                appendLine("pid=${rt.pid}")
                appendLine("libgame=0x${rt.moduleStart.toString(16)}-0x${rt.moduleEnd.toString(16)}")
                appendLine("bias=0x${rt.bias.toString(16)}")
                appendLine("dispatcher=0x${rt.dispatcher.toString(16)} remover=0x${rt.remover.toString(16)}")
                appendLine("stageGlobal=0x${rt.stageServiceGlobal.toString(16)}")
                if (!BuildConfig.INTERNAL_BUILD) {
                    appendLine("legacyCaveA=0x${rt.caveA.toString(16)} legacyCaveB=0x${rt.caveB.toString(16)}")
                    appendLine("legacyCaveC=0x${rt.caveC.toString(16)} legacyState=0x${rt.state.toString(16)}")
                } else {
                    appendLine("backend=LSPOSED_ARM64_IN_PROCESS (no code cave)")
                    appendLine("globalConfigGlobal=0x${(rt.bias + GH_GLOBAL_CONFIG_MANAGER).toString(16)}")
                    appendLine("giantScaleGlobal=0x${(rt.bias + GH_GIANT_SCALE_MANAGER).toString(16)}")
                }
            }
            listOf(CrgProfile.FEATURE_GIANT, CrgProfile.FEATURE_SUPER).forEach { id ->
                appendLine("$id desired=${desired[id] == true} • ${statuses[id] ?: "no status"}")
                val profile = profiles[id]
                if (profile != null) appendLine("  profile=${profile.revision} effectId=${profile.effectId}")
            }
            if (BuildConfig.INTERNAL_BUILD) {
                appendLine(
                    "giantSize enabled=$giantSizeEnabled percent=$giantSizePercent " +
                        "char=0x${giantSizeCachedCharacter.toString(16)} writes=$giantSizeWriteCount"
                )
                appendLine("  $giantSizeStatus")
            }
            if (!BuildConfig.INTERNAL_BUILD) {
                lastCaveScanFailure?.let {
                    appendLine("lastCaveError=${it.errorCode} • ${it.message}")
                }
            }
            if (BuildConfig.INTERNAL_BUILD) {
                appendLine("--- V15 IN-PROCESS / ROOT VERIFY ---")
                appendLine(devProbeText)
            }
        }.trimEnd()
    }

    fun devForceRetry() {
        if (!BuildConfig.INTERNAL_BUILD || closed) return
        lastApplyAttemptAt.clear()
        lastAppliedCharacter.clear()
        lab("DEV V15.1 force-retry/runtime-probe requested")
        devRunDataProbe()
    }

    fun devDataProbeText(): String = if (BuildConfig.INTERNAL_BUILD) devProbeText else "DEV disabled"

    fun devGiantSizeFastLockEnable(percent: Int, callback: (ActionResult) -> Unit) {
        if (desired[CrgProfile.FEATURE_GIANT] != true) {
            callback(failure("GIANT_REQUIRED", "เปิด Giant ก่อน แล้วค่อยเปิด Giant Size"))
            return
        }

        val sizeProfile = giantSizeProfile()
        if (sizeProfile == null) {
            callback(failure("GIANT_SIZE_PROFILE_NOT_READY", "Giant Size Secure Profile ยังไม่พร้อม"))
            return
        }

        val clamped = percent.coerceIn(
            sizeProfile.giantSizeMinPercent,
            sizeProfile.giantSizeMaxPercent
        )

        // Arm first. Do NOT require Stage/Character at toggle time.
        // The server-configured fast worker waits for runtime -> Character ->
        // verified Giant, matching Giant/Super desired-state behavior.
        giantSizePercent = clamped
        giantSizeCachedCharacter = 0L
        giantSizeWriteCount = 0L
        giantSizeRecheckCounter = sizeProfile.giantSizeRecheckWrites
        giantSizeEnabled = true
        giantSizeStatus = "ON • Giant Size +$clamped% • พร้อม • รอ Stage / Giant"

        ensureGiantSizeTask()

        lab(
            "V17 GIANT SIZE ARMED +$clamped% " +
                "target=${giantSizeTarget(sizeProfile, clamped)} • waiting Stage/Giant"
        )

        callback(success(giantSizeStatus))
    }

    fun devGiantSizeFastLockSetPercent(percent: Int): ActionResult {
        val sizeProfile = giantSizeProfile()
            ?: return failure("GIANT_SIZE_PROFILE_NOT_READY", "Giant Size Secure Profile ยังไม่พร้อม")

        val clamped = percent.coerceIn(
            sizeProfile.giantSizeMinPercent,
            sizeProfile.giantSizeMaxPercent
        )
        giantSizePercent = clamped

        val target = giantSizeTarget(sizeProfile, clamped)
        giantSizeStatus =
            if (giantSizeEnabled) {
                "ON • Giant Size +$clamped% • target=${"%.3f".format(target)}"
            } else {
                "พร้อม • Giant Size +$clamped%"
            }

        if (giantSizeEnabled) {
            val rt = runtime
            val character = giantSizeCachedCharacter
            if (rt != null && isPointer(character)) {
                writeGiantSizeVector(rt.pid, character, target, sizeProfile)
            }
        }

        return success(giantSizeStatus)
    }

    fun devGiantSizeFastLockDisable(callback: (ActionResult) -> Unit) {
        stopGiantSizeFastLockInternal("user OFF")
        giantSizeStatus = "OFF • Giant Size Fast Lock"
        lab("V15.1 GIANT SIZE LOCK OFF by user")
        callback(success(giantSizeStatus))
    }

    fun devGiantSizeFastLockIsEnabled(): Boolean =
        giantSizeEnabled

    fun devGiantSizeFastLockStatusText(): String =
        giantSizeStatus

    private fun ensureGiantSizeTask() {
        if (closed) return
        val existing = giantSizeTask
        if (existing != null && !existing.isCancelled && !existing.isDone) return

        val sizeProfile = giantSizeProfile() ?: return
        giantSizeTask = giantSizeExecutor.scheduleWithFixedDelay(
            {
                try {
                    giantSizeFastLockTick()
                } catch (t: Throwable) {
                    giantSizeStatus = "Giant Size Lock error • ${t.message ?: t.javaClass.simpleName}"
                    labState("SIZELOCK", "ERROR ${t.javaClass.simpleName}: ${t.message}")
                }
            },
            0L,
            sizeProfile.giantSizeLockDelayMs,
            TimeUnit.MILLISECONDS
        )
    }

    private fun stopGiantSizeFastLockInternal(reason: String) {
        giantSizeEnabled = false
        giantSizeTask?.cancel(false)
        giantSizeTask = null
        giantSizeCachedCharacter = 0L
        giantSizeRecheckCounter = 0
        giantSizeStatus = "OFF • $reason"
    }

    private fun giantSizeProfile(): NativeEffectProfile? {
        val p = profiles[CrgProfile.FEATURE_GIANT] ?: return null
        if (
            p.giantSizeXOffset <= 0L ||
            p.giantSizeYOffset != p.giantSizeXOffset + 4L ||
            p.giantSizeZOffset != p.giantSizeXOffset + 8L ||
            p.giantSizeNormal <= 0.0f ||
            p.giantSizeMinPercent <= 0 ||
            p.giantSizeMaxPercent < p.giantSizeMinPercent ||
            p.giantSizeLockDelayMs <= 0L ||
            p.giantSizeRecheckWrites <= 0
        ) {
            return null
        }
        return p
    }

    private fun giantSizeTarget(
        profile: NativeEffectProfile,
        percent: Int = giantSizePercent
    ): Float =
        profile.giantSizeNormal * (1.0f + percent.toFloat() / 100.0f)

    private fun writeGiantSizeVector(
        pid: Int,
        character: Long,
        target: Float,
        profile: NativeEffectProfile
    ): Boolean {
        if (!isPointer(character)) return false

        val bytes = ByteBuffer
            .allocate(12)
            .order(ByteOrder.LITTLE_ENDIAN)
            .putFloat(target)
            .putFloat(target)
            .putFloat(target)
            .array()

        return memory.writeBytes(
            pid,
            character + profile.giantSizeXOffset,
            bytes
        )
    }

    private fun giantSizeFastLockTick() {
        if (
            closed ||
            !giantSizeEnabled
        ) {
            return
        }

        // Size lock is subordinate to Giant itself.
        if (desired[CrgProfile.FEATURE_GIANT] != true) {
            stopGiantSizeFastLockInternal("Giant OFF")
            return
        }

        val profile = profiles[CrgProfile.FEATURE_GIANT] ?: return
        val rt = runtime ?: return

        var character = giantSizeCachedCharacter

        giantSizeRecheckCounter++
        if (
            !isPointer(character) ||
            giantSizeRecheckCounter >= profile.giantSizeRecheckWrites
        ) {
            giantSizeRecheckCounter = 0

            val resolved = resolveCharacter(rt, profile)
            val latestCharacter = resolved?.first ?: 0L
            if (!isPointer(latestCharacter)) {
                giantSizeCachedCharacter = 0L
                giantSizeStatus = "ON • Giant Size +$giantSizePercent% • รอ Stage"
                return
            }

            character = latestCharacter
            giantSizeCachedCharacter = latestCharacter
        }

        // Cross-stage safety: do not enlarge a fresh Character before Giant
        // has actually been applied/verified on that Character.
        if (lastAppliedCharacter[CrgProfile.FEATURE_GIANT] != character) {
            giantSizeStatus = "ON • Giant Size +$giantSizePercent% • รอ Giant ติด"
            return
        }

        val target = giantSizeTarget(profile)
        val ok = writeGiantSizeVector(rt.pid, character, target, profile)

        if (ok) {
            giantSizeWriteCount++
            if (giantSizeWriteCount % 250L == 0L) {
                giantSizeStatus =
                    "ON • +$giantSizePercent% • target=${"%.3f".format(target)} • writes=$giantSizeWriteCount"
                labState(
                    "SIZELOCK",
                    "char=0x${character.toString(16)} target=$target writes=$giantSizeWriteCount"
                )
            }
        } else {
            giantSizeStatus = "ON • Giant Size +$giantSizePercent% • write retry"
        }
    }

    fun devRunDataProbe() {
        if (!BuildConfig.INTERNAL_BUILD || closed) return
        executor.execute {
            devProbeText = buildString {
                appendLine("V15 IN-PROCESS STATUS")
                appendLine("control=${InProcessGameControl.statusText()}")
                appendLine("expected native ABI=arm64-v8a")
                appendLine("--- LSPOSED GAME MARKER ---")
                appendLine(InProcessGameControl.diagnosticMarkerViaRoot(runtime?.pid))
                appendLine("--- ROOT RUNTIME VERIFY ---")
                append(buildDataProbeText())
            }.trimEnd()
            lab("V15 runtime/root verify refreshed")
        }
    }

    fun devArmNaturalCapture(featureId: String, callback: (ActionResult) -> Unit) {
        if (!BuildConfig.INTERNAL_BUILD) {
            callback(failure("DEV_DISABLED", "DEV disabled"))
            return
        }
        if (featureId != CrgProfile.FEATURE_GIANT && featureId != CrgProfile.FEATURE_SUPER) {
            callback(failure("CAPTURE_FEATURE_INVALID", "Capture feature ไม่ถูกต้อง"))
            return
        }
        executor.execute {
            val profile = profiles[featureId]
            if (profile == null) {
                callback(failure("PROFILE_NOT_READY", "ยังไม่มี ${featureId} profile"))
                return@execute
            }
            val prepared = prepareRuntime(profile, requireCharacter = true)
            if (!prepared.ok) {
                callback(prepared)
                return@execute
            }
            val rt = runtime
            if (rt == null) {
                callback(failure("RUNTIME_NOT_READY", "runtime ยังไม่พร้อม"))
                return@execute
            }
            stopDevCaptureTask(clearSnapshots = true)
            val baseline = captureNaturalSnapshot(rt, profile, "BASELINE")
            if (baseline == null) {
                callback(failure("CAPTURE_BASELINE_FAILED", "อ่าน baseline ไม่สำเร็จ"))
                return@execute
            }
            devCaptureFeatureId = featureId
            devCaptureLastFeatureId = featureId
            devCaptureStartedAt = SystemClock.elapsedRealtime()
            devCaptureSawActive = false
            devCaptureAbsentStreak = 0
            devCaptureBaseline = baseline
            devCaptureActive = null
            devCaptureEnd = null
            devProbeText = buildCaptureReport("ARMED • ไปเก็บ ${if (featureId == CrgProfile.FEATURE_GIANT) "Giant" else "Super"} จริง 1 ครั้ง")
            lab("V10 CAPTURE ARM $featureId char=0x${baseline.character.toString(16)}")
            devCaptureTask = executor.scheduleWithFixedDelay(
                { pollNaturalCapture() },
                DEV_CAPTURE_POLL_MS,
                DEV_CAPTURE_POLL_MS,
                TimeUnit.MILLISECONDS
            )
            callback(success("ARMED • ไปเก็บ ${if (featureId == CrgProfile.FEATURE_GIANT) "Giant" else "Super"} จริง 1 ครั้ง"))
        }
    }

    fun devStopNaturalCapture(callback: ((ActionResult) -> Unit)? = null) {
        if (!BuildConfig.INTERNAL_BUILD) {
            callback?.invoke(failure("DEV_DISABLED", "DEV disabled"))
            return
        }
        executor.execute {
            val had = devCaptureFeatureId != null
            stopDevCaptureTask(clearSnapshots = false)
            devProbeText = buildCaptureReport(if (had) "STOPPED by DEV" else "Capture idle")
            lab("V10 CAPTURE STOP manual")
            callback?.invoke(success(if (had) "หยุด Natural Capture แล้ว" else "Capture ไม่ได้ทำงาน"))
        }
    }

    private fun stopDevCaptureTask(clearSnapshots: Boolean) {
        devCaptureTask?.cancel(false)
        devCaptureTask = null
        devCaptureFeatureId = null
        devCaptureSawActive = false
        devCaptureAbsentStreak = 0
        if (clearSnapshots) {
            devCaptureBaseline = null
            devCaptureActive = null
            devCaptureEnd = null
        }
    }

    private fun pollNaturalCapture() {
        if (closed || !BuildConfig.INTERNAL_BUILD) return
        val featureId = devCaptureFeatureId ?: return
        val profile = profiles[featureId] ?: return
        val rt = runtime ?: return
        val elapsed = SystemClock.elapsedRealtime() - devCaptureStartedAt
        if (elapsed > DEV_CAPTURE_TIMEOUT_MS) {
            val status = if (devCaptureSawActive) {
                "TIMEOUT • target effect จบแล้วแต่ residual effect/owner state ยังไม่กลับ 0"
            } else {
                "TIMEOUT • ไม่ตรวจพบ target effect ภายใน 45s"
            }
            stopDevCaptureTask(clearSnapshots = false)
            devProbeText = buildCaptureReport(status)
            lab("V10 CAPTURE TIMEOUT $featureId")
            return
        }

        val inspection = inspectEffect(rt, profile)
        if (!devCaptureSawActive) {
            if (inspection.state == EffectState.PRESENT) {
                val snap = captureNaturalSnapshot(rt, profile, "ACTIVE")
                if (snap != null) {
                    devCaptureActive = snap
                    devCaptureSawActive = true
                    devCaptureAbsentStreak = 0
                    devProbeText = buildCaptureReport("ACTIVE detected • รอ effect จบ")
                    lab("V10 CAPTURE ACTIVE $featureId effects=${inspection.count}")
                }
            }
            return
        }

        if (inspection.state == EffectState.PRESENT) {
            devCaptureAbsentStreak = 0
            return
        }
        if (inspection.state == EffectState.ABSENT) {
            val post = captureNaturalSnapshot(rt, profile, "POST_TARGET") ?: return
            devCaptureEnd = post
            val fullyNormal = post.effectCount == 0L && (post.ownerVecCount ?: 0) == 0
            if (fullyNormal) {
                devCaptureAbsentStreak++
            } else {
                devCaptureAbsentStreak = 0
                devProbeText = buildCaptureReport("TARGET ENDED • waiting effectCount/ownerVec to return 0")
            }
            if (devCaptureAbsentStreak >= 3) {
                devCaptureEnd = captureNaturalSnapshot(rt, profile, "NORMAL") ?: post
                stopDevCaptureTask(clearSnapshots = false)
                devProbeText = buildCaptureReport("COMPLETE • baseline / active / normal captured")
                lab("V10 CAPTURE COMPLETE $featureId normal")
            }
        }
    }

    private fun captureNaturalSnapshot(rt: Runtime, profile: NativeEffectProfile, label: String): DevNaturalSnapshot? {
        val resolved = resolveCharacter(rt, profile) ?: return null
        val character = resolved.first
        if (!isPointer(character)) return null
        val visualPtr = memory.readLong(rt.pid, character + 0x3E0L) ?: 0L
        val gameplayPtr = memory.readLong(rt.pid, character + 0x1B8L) ?: 0L
        val owner = character + OWNER_OFFSET
        val ownerVecBegin = memory.readLong(rt.pid, owner + OWNER_VECTOR_BEGIN_OFFSET) ?: 0L
        val ownerVecEnd = memory.readLong(rt.pid, owner + OWNER_VECTOR_END_OFFSET) ?: 0L
        val ownerVecCount = safeVectorCount(ownerVecBegin, ownerVecEnd)
        val manager = memory.readLong(rt.pid, character + profile.effectManagerOffset) ?: 0L
        val effectCount = if (isPointer(manager)) memory.readLong(rt.pid, manager + profile.effectEndOffset) ?: -1L else -1L

        val giantEntries = mutableListOf<Pair<Long, ByteArray?>>()
        val giantManager = memory.readLong(rt.pid, rt.bias + GH_GIANT_SCALE_MANAGER) ?: 0L
        if (isPointer(giantManager)) {
            val begin = memory.readLong(rt.pid, giantManager + GIANT_SCALE_VECTOR_BEGIN_OFFSET) ?: 0L
            val end = memory.readLong(rt.pid, giantManager + GIANT_SCALE_VECTOR_END_OFFSET) ?: 0L
            val count = safeVectorCount(begin, end, DEV_MAX_VECTOR_ENTRIES)
            if (count != null) {
                repeat(minOf(count, DEV_MAX_VECTOR_ENTRIES)) { index ->
                    val entry = memory.readLong(rt.pid, begin + index * 8L) ?: 0L
                    if (isPointer(entry)) giantEntries += entry to memory.readBytes(rt.pid, entry, 0xB0)
                }
            }
        }

        return DevNaturalSnapshot(
            label = label,
            atMs = SystemClock.elapsedRealtime() - devCaptureStartedAt,
            character = character,
            visualPtr = visualPtr,
            gameplayPtr = gameplayPtr,
            superSpeedField = memory.readFloat(rt.pid, character + DEV_SUPER_SPEED_FIELD_OFFSET),
            charA = memory.readBytes(rt.pid, character + DEV_CAPTURE_CHAR_A_OFFSET, DEV_CAPTURE_CHAR_A_SIZE),
            charB = memory.readBytes(rt.pid, character + DEV_CAPTURE_CHAR_B_OFFSET, DEV_CAPTURE_CHAR_B_SIZE),
            charC = memory.readBytes(rt.pid, character + DEV_CAPTURE_CHAR_C_OFFSET, DEV_CAPTURE_CHAR_C_SIZE),
            ownerBytes = memory.readBytes(rt.pid, owner, DEV_CAPTURE_OWNER_SIZE),
            visualBytes = if (isPointer(visualPtr)) memory.readBytes(rt.pid, visualPtr, DEV_CAPTURE_VISUAL_BLOB_SIZE) else null,
            gameplayBytes = if (isPointer(gameplayPtr)) memory.readBytes(rt.pid, gameplayPtr, 0x100) else null,
            effectManager = manager,
            effectCount = effectCount,
            ownerVecCount = ownerVecCount,
            giantEntries = giantEntries,
            effects = captureEffectSummaries(rt, profile, manager)
        )
    }

    private fun captureEffectSummaries(rt: Runtime, profile: NativeEffectProfile, manager: Long): List<DevEffectSummary> {
        if (!isPointer(manager)) return emptyList()
        val out = mutableListOf<DevEffectSummary>()
        val sentinel = manager + profile.effectBeginOffset
        var node = memory.readLong(rt.pid, sentinel) ?: return emptyList()
        var guard = 0
        while (node != sentinel && isPointer(node) && guard++ < profile.maxEffects) {
            val pointer = memory.readLong(rt.pid, node + profile.effectCapOffset) ?: 0L
            if (isPointer(pointer)) {
                val vptr = memory.readLong(rt.pid, pointer) ?: 0L
                val directType = memory.readInt(rt.pid, pointer + profile.effectIdDirectOffset)
                val adjustedType = memory.readInt(rt.pid, pointer + profile.effectIdAdjustedOffset)
                val propertyMap = pointer + 0x88L
                val properties = DEV_EFFECT_PROPERTY_IDS.map { id ->
                    val propertyNode = findConfigNode(rt.pid, propertyMap, id)
                    DevEffectProperty(
                        id = id,
                        node = propertyNode,
                        bytes = propertyNode?.let { memory.readBytes(rt.pid, it, DEV_EFFECT_PROPERTY_DUMP_SIZE) }
                    )
                }
                out += DevEffectSummary(
                    node = node,
                    pointer = pointer,
                    vptr = vptr,
                    directType = directType,
                    adjustedType = adjustedType,
                    bytes = memory.readBytes(rt.pid, pointer, DEV_CAPTURE_EFFECT_SIZE),
                    propertyMap = propertyMap,
                    properties = properties
                )
            }
            node = memory.readLong(rt.pid, node) ?: break
        }
        return out
    }

    private fun buildCaptureReport(status: String): String = buildString {
        appendLine("V10 NATURAL EFFECT CAPTURE")
        appendLine("status=$status")
        appendLine("feature=${devCaptureFeatureId ?: devCaptureLastFeatureId ?: inferCapturedFeature() ?: "none"}")
        val b = devCaptureBaseline
        val a = devCaptureActive
        val e = devCaptureEnd
        if (b != null) appendSnapshotSummary(this, b)
        if (a != null) appendSnapshotSummary(this, a)
        if (e != null) appendSnapshotSummary(this, e)
        if (b != null && a != null) {
            appendLine("--- DIFF BASELINE -> ACTIVE ---")
            appendSnapshotDiff(this, b, a)
        }
        if (a != null && e != null) {
            appendLine("--- DIFF ACTIVE -> ${e.label} ---")
            appendSnapshotDiff(this, a, e)
        }
    }.trimEnd()

    private fun inferCapturedFeature(): String? {
        val active = devCaptureActive ?: return null
        return when {
            active.effects.any { it.directType == 5 || it.adjustedType == 5 } -> CrgProfile.FEATURE_GIANT
            active.effects.any { it.directType == 7 || it.adjustedType == 7 } -> CrgProfile.FEATURE_SUPER
            else -> null
        }
    }

    private fun appendSnapshotSummary(out: StringBuilder, s: DevNaturalSnapshot) {
        out.appendLine("[${s.label}] t=${s.atMs}ms char=0x${s.character.toString(16)} visual=0x${s.visualPtr.toString(16)} gameplay=0x${s.gameplayPtr.toString(16)}")
        out.appendLine("  manager=0x${s.effectManager.toString(16)} effectCount=${s.effectCount} ownerVecCount=${s.ownerVecCount ?: -1} effects=${s.effects.size}")
        out.appendLine("  superField char+0x5f0=${s.superSpeedField?.let { "%.6f".format(it) } ?: "unreadable"}")
        s.giantEntries.forEachIndexed { i, (entry, bytes) ->
            val current = bytes?.let { readLeInt(it, GIANT_SCALE_CURRENT_OFFSET.toInt()) }
            val max = bytes?.let { readLeInt(it, GIANT_SCALE_MAX_OFFSET.toInt()) }
            val root = bytes?.let { readLeLong(it, 0x20) }
            val sentinel = bytes?.let { readLeLong(it, 0x28) }
            val count = bytes?.let { readLeLong(it, 0x30) }
            out.appendLine("  giant[$i]=0x${entry.toString(16)} current=${current ?: -1} max=${max ?: -1} cache20=${hex(root)} cache28=${hex(sentinel)} cache30=${hex(count)}")
        }
        s.effects.forEachIndexed { i, fx ->
            out.appendLine("  effect[$i] node=0x${fx.node.toString(16)} ptr=0x${fx.pointer.toString(16)} vptr=0x${fx.vptr.toString(16)} typeDirect=${fx.directType ?: -1} typeAdj=${fx.adjustedType ?: -1}")
            fx.bytes?.let { bytes ->
                out.appendLine("    effectWords=" + compactWords(bytes, 0, minOf(bytes.size, 0xC0), 12))
            }
            out.appendLine("    propertyMap=0x${fx.propertyMap.toString(16)}")
            fx.properties.forEach { prop ->
                out.appendLine("    prop 0x${prop.id.toString(16)} node=${hex(prop.node)} words=${prop.bytes?.let { compactWords(it, 0, minOf(it.size, DEV_EFFECT_PROPERTY_DUMP_SIZE), 20) } ?: "-"}")
            }
        }
    }

    private fun appendSnapshotDiff(out: StringBuilder, before: DevNaturalSnapshot, after: DevNaturalSnapshot) {
        appendDiff32(out, "char+130", before.charA, after.charA, DEV_CAPTURE_CHAR_A_OFFSET)
        appendDiff32(out, "char+3c0", before.charB, after.charB, DEV_CAPTURE_CHAR_B_OFFSET)
        appendDiff32(out, "char+5b0", before.charC, after.charC, DEV_CAPTURE_CHAR_C_OFFSET)
        appendDiff32(out, "owner+0", before.ownerBytes, after.ownerBytes, OWNER_OFFSET)
        if (before.visualPtr == after.visualPtr && before.visualPtr != 0L) {
            appendDiff32(out, "visual", before.visualBytes, after.visualBytes, 0L)
        } else {
            out.appendLine("visualPtr 0x${before.visualPtr.toString(16)} -> 0x${after.visualPtr.toString(16)}")
        }
        if (before.gameplayPtr == after.gameplayPtr && before.gameplayPtr != 0L) {
            appendDiff32(out, "gameplay", before.gameplayBytes, after.gameplayBytes, 0L)
        } else {
            out.appendLine("gameplayPtr 0x${before.gameplayPtr.toString(16)} -> 0x${after.gameplayPtr.toString(16)}")
        }
        val beforeEntries = before.giantEntries.associate { it.first to it.second }
        val afterEntries = after.giantEntries.associate { it.first to it.second }
        (beforeEntries.keys + afterEntries.keys).distinct().forEach { entry ->
            appendDiff32(out, "giant@${entry.toString(16)}", beforeEntries[entry], afterEntries[entry], 0L)
        }
        out.appendLine("effectCount ${before.effectCount} -> ${after.effectCount}; ownerVec ${before.ownerVecCount ?: -1} -> ${after.ownerVecCount ?: -1}")
    }

    private fun appendDiff32(out: StringBuilder, label: String, before: ByteArray?, after: ByteArray?, baseOffset: Long) {
        if (before == null || after == null) {
            out.appendLine("$label diff=unreadable")
            return
        }
        val size = minOf(before.size, after.size)
        val changes = mutableListOf<String>()
        var off = 0
        while (off + 4 <= size && changes.size < DEV_CAPTURE_DIFF_LIMIT) {
            val a = readLeInt(before, off)
            val b = readLeInt(after, off)
            if (a != b) changes += "+0x${(baseOffset + off).toString(16)}:${a.toUInt().toString(16)}>${b.toUInt().toString(16)}"
            off += 4
        }
        out.appendLine("$label changes=${changes.size}${if (changes.size >= DEV_CAPTURE_DIFF_LIMIT) "+" else ""} ${changes.joinToString(" ")}")
    }

    private fun readLeInt(bytes: ByteArray, offset: Int): Int {
        if (offset < 0 || offset + 4 > bytes.size) return 0
        return ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.LITTLE_ENDIAN).int
    }

    private fun readLeLong(bytes: ByteArray, offset: Int): Long {
        if (offset < 0 || offset + 8 > bytes.size) return 0L
        return ByteBuffer.wrap(bytes, offset, 8).order(ByteOrder.LITTLE_ENDIAN).long
    }

    private fun compactWords(bytes: ByteArray, start: Int, end: Int, maxWords: Int): String {
        val stop = minOf(end, bytes.size)
        val out = mutableListOf<String>()
        var off = start
        while (off + 4 <= stop && out.size < maxWords) {
            val v = readLeInt(bytes, off)
            if (v != 0) out += "+${off.toString(16)}=${v.toUInt().toString(16)}"
            off += 4
        }
        return out.joinToString(" ")
    }

    private fun buildDataProbeText(): String {
        val profile = profiles[CrgProfile.FEATURE_GIANT]
            ?: profiles[CrgProfile.FEATURE_SUPER]
            ?: bridgeProfile
            ?: return "profile: not cached"

        val prepared = prepareRuntime(profile, requireCharacter = false)
        if (!prepared.ok) return "runtime=${prepared.errorCode} • ${prepared.message}"
        val rt = runtime ?: return "runtime: missing"
        val resolved = resolveCharacter(rt, profile)
        val character = resolved?.first ?: 0L

        return buildString {
            if (devCaptureBaseline != null || devCaptureFeatureId != null) {
                appendLine(buildCaptureReport(if (devCaptureFeatureId != null) "RUNNING" else "LAST CAPTURE"))
                appendLine("--- CURRENT DATA PROBE ---")
            }
            appendLine("pid=${rt.pid} bias=0x${rt.bias.toString(16)}")
            appendLine("character=0x${character.toString(16)} src=${resolved?.second ?: "none"}")

            if (character != 0L) {
                val owner = character + OWNER_OFFSET
                val visualPtr = memory.readLong(rt.pid, character + DEV_GIANT_VISUAL_PTR_OFFSET) ?: 0L
                val ownerRoot = memory.readLong(rt.pid, owner + OWNER_TREE_ROOT_OFFSET) ?: 0L
                val ownerVecBegin = memory.readLong(rt.pid, owner + OWNER_VECTOR_BEGIN_OFFSET) ?: 0L
                val ownerVecEnd = memory.readLong(rt.pid, owner + OWNER_VECTOR_END_OFFSET) ?: 0L
                val ownerCount = safeVectorCount(ownerVecBegin, ownerVecEnd)
                appendLine("owner=0x${owner.toString(16)} treeRoot=0x${ownerRoot.toString(16)} vecCount=${ownerCount ?: -1}")
                appendLine("visualBlob=0x${visualPtr.toString(16)} scale14=${if (isPointer(visualPtr)) memory.readFloat(rt.pid, visualPtr + DEV_GIANT_VISUAL_SCALE_A_OFFSET)?.let { "%.6f".format(it) } else null ?: "unreadable"} scale18=${if (isPointer(visualPtr)) memory.readFloat(rt.pid, visualPtr + DEV_GIANT_VISUAL_SCALE_B_OFFSET)?.let { "%.6f".format(it) } else null ?: "unreadable"} v44=${if (isPointer(visualPtr)) memory.readFloat(rt.pid, visualPtr + 0x44L)?.let { "%.6f".format(it) } else null ?: "unreadable"} v48=${if (isPointer(visualPtr)) memory.readFloat(rt.pid, visualPtr + 0x48L)?.let { "%.6f".format(it) } else null ?: "unreadable"}")
                appendLine("superField char+0x5f0=${memory.readFloat(rt.pid, character + DEV_SUPER_SPEED_FIELD_OFFSET)?.let { "%.6f".format(it) } ?: "unreadable"}")
                listOf(0x68, 0x65, 0x69, 0x6A, 0x76, 0x67, 0x577, 0x401, 0x49A, 0x1EA99D).forEach { id ->
                    val ownerNode = findOwnerNode(rt.pid, owner, id)
                    val active = ownerNode?.let { memory.readByteUnsigned(rt.pid, it + OWNER_NODE_ACTIVE_OFFSET) }
                    appendLine("ownerId 0x${id.toString(16)} node=${hex(ownerNode)} active=${active?.and(1) ?: -1}")
                }
                val manager = memory.readLong(rt.pid, character + profile.effectManagerOffset) ?: 0L
                val effectCount = if (manager != 0L) memory.readLong(rt.pid, manager + 0x28L) else null
                appendLine("effectManager=0x${manager.toString(16)} count=${effectCount ?: -1}")
            }

            val cfgGlobal = rt.bias + GH_GLOBAL_CONFIG_MANAGER
            val cfgManager = memory.readLong(rt.pid, cfgGlobal) ?: 0L
            val cfgMap = if (isPointer(cfgManager)) cfgManager + GLOBAL_CONFIG_MAP_OFFSET else 0L
            appendLine("globalConfigGlobal=0x${cfgGlobal.toString(16)} manager=0x${cfgManager.toString(16)} map=0x${cfgMap.toString(16)}")
            if (cfgMap != 0L) {
                listOf(0x68, 0x65, 0x69, 0x6A, 0x76, 0x67, 0x577, 0x423, 0x500, 0x40B, 0x49A, 0x401, 0x426, 0x41F, 0x420, 0x42D, 0x42E, 0x1EA99D).forEach { id ->
                    val bucket = memory.readByteUnsigned(rt.pid, cfgMap + CONFIG_BUCKET_BASE_OFFSET + (id and 0xF))
                    val node = findConfigNode(rt.pid, cfgMap, id)
                    val q0 = node?.let { memory.readLong(rt.pid, it + CONFIG_NODE_VALUE_OFFSET) }
                    val q1 = node?.let { memory.readLong(rt.pid, it + CONFIG_NODE_VALUE_OFFSET + 8L) }
                    appendLine("globalId 0x${id.toString(16)} bucket=${bucket ?: -1} node=${hex(node)} valueQ0=${hex(q0)} valueQ1=${hex(q1)}")
                }
            }

            appendGiantScaleProbe(this, rt)
        }.trimEnd()
    }

    private fun appendGiantScaleProbe(out: StringBuilder, rt: Runtime) {
        val global = rt.bias + GH_GIANT_SCALE_MANAGER
        val manager = memory.readLong(rt.pid, global) ?: 0L
        out.appendLine("giantScaleGlobal=0x${global.toString(16)} manager=0x${manager.toString(16)}")
        if (!isPointer(manager)) return
        val begin = memory.readLong(rt.pid, manager + GIANT_SCALE_VECTOR_BEGIN_OFFSET) ?: 0L
        val end = memory.readLong(rt.pid, manager + GIANT_SCALE_VECTOR_END_OFFSET) ?: 0L
        val count = safeVectorCount(begin, end, DEV_MAX_VECTOR_ENTRIES)
        out.appendLine("giantVec=0x${begin.toString(16)}-0x${end.toString(16)} count=${count ?: -1}")
        if (count == null) return
        repeat(minOf(count, DEV_MAX_VECTOR_ENTRIES)) { index ->
            val entry = memory.readLong(rt.pid, begin + index * 8L) ?: 0L
            val current = if (isPointer(entry)) memory.readInt(rt.pid, entry + GIANT_SCALE_CURRENT_OFFSET) else null
            val max = if (isPointer(entry)) memory.readInt(rt.pid, entry + GIANT_SCALE_MAX_OFFSET) else null
            out.appendLine("giantEntry[$index]=0x${entry.toString(16)} current=${current ?: -1} max=${max ?: -1}")
        }
    }

    private fun findOwnerNode(pid: Int, owner: Long, id: Int): Long? {
        val sentinel = owner + OWNER_TREE_ROOT_OFFSET
        var node = memory.readLong(pid, sentinel) ?: return null
        var candidate = sentinel
        var guard = 0
        while (node != 0L && guard++ < 128) {
            val key = memory.readInt(pid, node + OWNER_NODE_KEY_OFFSET) ?: return null
            if (id <= key) candidate = node
            node = memory.readLong(pid, node + if (key < id) 8L else 0L) ?: return null
        }
        if (candidate == sentinel) return null
        return if (memory.readInt(pid, candidate + OWNER_NODE_KEY_OFFSET) == id) candidate else null
    }

    private fun findConfigNode(pid: Int, map: Long, id: Int): Long? {
        val bucket = memory.readByteUnsigned(pid, map + CONFIG_BUCKET_BASE_OFFSET + (id and 0xF)) ?: return null
        if (bucket == 0) return null
        val sentinel = map + CONFIG_TREE_ROOT_OFFSET
        var node = memory.readLong(pid, sentinel) ?: return null
        var candidate = sentinel
        var guard = 0
        while (node != 0L && guard++ < 256) {
            val key = memory.readInt(pid, node + CONFIG_NODE_KEY_OFFSET) ?: return null
            if (id <= key) candidate = node
            node = memory.readLong(pid, node + if (key < id) 8L else 0L) ?: return null
        }
        if (candidate == sentinel) return null
        return if (memory.readInt(pid, candidate + CONFIG_NODE_KEY_OFFSET) == id) candidate else null
    }

    private fun safeVectorCount(begin: Long, end: Long, maxEntries: Int = 512): Int? {
        if (begin == 0L && end == 0L) return 0
        if (!isPointer(begin) || end < begin || (end - begin) % 8L != 0L) return null
        val count = (end - begin) / 8L
        return count.takeIf { it in 0..maxEntries.toLong() }?.toInt()
    }

    private fun hex(value: Long?): String = if (value == null || value == 0L) "0x0" else "0x${value.toString(16)}"

    fun labLogText(maxLines: Int = 16): String {
        if (!BuildConfig.INTERNAL_BUILD) return ""
        synchronized(labLogLock) {
            return labLogs.toList().takeLast(maxLines).joinToString("\n")
        }
    }

    private fun lab(message: String) {
        if (!BuildConfig.INTERNAL_BUILD) return
        val clean = message.replace('\n', ' ').trim()
        val elapsedDeci = (SystemClock.elapsedRealtime() - labStartedAt) / 100L
        val line = "+${elapsedDeci / 10}.${elapsedDeci % 10}s $clean"
        synchronized(labLogLock) {
            if (labLogs.peekLast()?.endsWith(clean) == true) return
            while (labLogs.size >= 80) labLogs.removeFirst()
            labLogs.addLast(line)
        }
        DevConsole.log("NFX", clean)
        Log.d(TAG, clean)
    }

    private fun labState(key: String, message: String) {
        if (!BuildConfig.INTERNAL_BUILD) return
        if (labLastByKey.put(key, message) != message) {
            lab("$key • $message")
        }
    }

    private fun isDeferredNotReady(code: String?): Boolean =
        code == "GAME_NOT_RUNNING" ||
            code == "LIBGAME_NOT_READY" ||
            code == "STAGE_NOT_READY" ||
            code == "RUNTIME_NOT_READY"

    private fun sameWords(pid: Int, address: Long, expected: IntArray): Boolean {
        val actual = readWords(pid, address, expected.size) ?: return false
        return actual.contentEquals(expected)
    }

    private fun readWords(pid: Int, address: Long, count: Int): IntArray? {
        val bytes = memory.readBytes(pid, address, count * 4) ?: return null
        if (bytes.size != count * 4) return null
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        return IntArray(count) { buffer.int }
    }

    private fun writeWords(pid: Int, address: Long, words: IntArray): Boolean {
        val buffer = ByteBuffer.allocate(words.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        words.forEach { buffer.putInt(it) }
        return memory.writeBytes(pid, address, buffer.array())
    }

    private fun writeByte(pid: Int, address: Long, value: Int): Boolean =
        memory.writeBytes(pid, address, byteArrayOf((value and 0xFF).toByte()))

    private fun writeInt(pid: Int, address: Long, value: Int): Boolean =
        memory.writeInt(pid, address, value)

    private fun writeLong(pid: Int, address: Long, value: Long): Boolean {
        val bytes = ByteBuffer.allocate(8)
            .order(ByteOrder.LITTLE_ENDIAN)
            .putLong(value)
            .array()
        return memory.writeBytes(pid, address, bytes)
    }

    private fun combineWords(low: Int, high: Int): Long {
        return (low.toLong() and 0xFFFFFFFFL) or
            ((high.toLong() and 0xFFFFFFFFL) shl 32)
    }

    private fun encodeBranch(from: Long, target: Long, link: Boolean): Int? {
        val delta = target - from
        if (delta % 4L != 0L || delta <= -BRANCH_RANGE_26 || delta >= BRANCH_RANGE_26) return null
        var imm = delta / 4L
        if (imm < 0) imm += 0x04000000L
        return ((if (link) 0x94000000L else 0x14000000L) + imm).toInt()
    }

    private fun encodeBCond(from: Long, target: Long, condition: Int): Int? {
        val delta = target - from
        if (delta % 4L != 0L || delta <= -BRANCH_RANGE_19 || delta >= BRANCH_RANGE_19) return null
        var imm = delta / 4L
        if (imm < 0) imm += 0x80000L
        return (0x54000000L or ((imm and 0x7FFFFL) shl 5) or (condition.toLong() and 0xFL)).toInt()
    }

    private fun encodeCbzW(from: Long, target: Long, register: Int): Int? {
        val delta = target - from
        if (delta % 4L != 0L || delta <= -BRANCH_RANGE_19 || delta >= BRANCH_RANGE_19) return null
        var imm = delta / 4L
        if (imm < 0) imm += 0x80000L
        return (0x34000000L or ((imm and 0x7FFFFL) shl 5) or (register.toLong() and 0x1FL)).toInt()
    }

    private fun encodeLdrLiteralX(from: Long, literal: Long, register: Int): Int? {
        val delta = literal - from
        if (delta % 4L != 0L || delta <= -BRANCH_RANGE_19 || delta >= BRANCH_RANGE_19) return null
        var imm = delta / 4L
        if (imm < 0) imm += 0x80000L
        return (0x58000000L or ((imm and 0x7FFFFL) shl 5) or (register.toLong() and 0x1FL)).toInt()
    }

    private fun isPointer(value: Long): Boolean =
        value >= 0x10000L && value < 0x0001000000000000L && value % 8L == 0L

    private fun IntArray?.contentEqualsSafe(other: IntArray): Boolean =
        this != null && this.contentEquals(other)

    private fun featureDisplayName(featureId: String): String = when (featureId) {
        CrgProfile.FEATURE_GIANT -> "ตัวใหญ่"
        CrgProfile.FEATURE_SUPER -> "วิ่งเร็ว"
        else -> featureId
    }

    private fun success(message: String) = ActionResult(true, null, message)

    private fun failure(code: String, message: String) = ActionResult(false, code, message)
}
