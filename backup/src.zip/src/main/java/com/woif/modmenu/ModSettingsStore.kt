package com.woif.modmenu

import android.content.Context

/**
 * Persistent user configuration for gameplay MOD values.
 *
 * IMPORTANT:
 * - This store persists configuration values only.
 * - Runtime ON/OFF state is intentionally never stored here.
 * - Every new FloatingMenuService instance starts all MOD engines OFF.
 */
class ModSettingsStore(context: Context) {

    data class Values(
        val gameSpeed: Int,
        val giantSizePercent: Int,
        val xp: Int,
        val coin: Int,
        val potatoCoinMode: String,
        val potatoCoin: Int,
        val potatoCoinInterval: Double,
        val potatoRapid: Double,
        val potatoUltimateInfinite: Boolean,
        val potatoUltimateSeconds: Int,
        val baseSpeedMultiplier: Double,
        val autoSelected: Set<String>
    )

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): Values {
        val mode = prefs.getString(P_POTATO_COIN_MODE, DEFAULT_POTATO_COIN_MODE)
            ?.uppercase()
            ?.takeIf { it in POTATO_COIN_MODES }
            ?: DEFAULT_POTATO_COIN_MODE

        val coinInterval = prefs.getString(P_POTATO_COIN_INTERVAL, null)
            ?.toDoubleOrNull()
            ?.takeIf { it.isFinite() && it >= 0.05 && it <= 10.0 }
            ?: DEFAULT_POTATO_COIN_INTERVAL

        val rapid = prefs.getString(P_POTATO_RAPID, null)
            ?.toDoubleOrNull()
            ?.takeIf { it.isFinite() && it >= 0.01 && it <= 60.0 }
            ?: DEFAULT_POTATO_RAPID

        /*
         * UX V18.5 migration:
         * older builds pre-selected HP/XP/Coin/Giant/Super.
         * The new policy starts every AUTO preset empty (○) once, then keeps
         * the user's explicit selection from that point onward.
         */
        val autoSelectionVersion = prefs.getInt(P_AUTO_SELECTION_VERSION, 0)
        val savedAuto = if (autoSelectionVersion < AUTO_SELECTION_VERSION) {
            prefs.edit()
                .putStringSet(P_AUTO_SELECTED, emptySet())
                .putInt(P_AUTO_SELECTION_VERSION, AUTO_SELECTION_VERSION)
                .apply()
            DEFAULT_AUTO_SELECTED
        } else {
            prefs.getStringSet(P_AUTO_SELECTED, null)
                ?.toSet()
                ?: DEFAULT_AUTO_SELECTED
        }

        return Values(
            gameSpeed = prefs.getInt(P_GAME_SPEED, DEFAULT_GAME_SPEED).coerceIn(1, 1000),
            giantSizePercent = prefs.getInt(P_GIANT_SIZE, DEFAULT_GIANT_SIZE).coerceIn(10, 100),
            xp = prefs.getInt(P_XP, DEFAULT_XP).coerceIn(0, MAX_XP),
            coin = prefs.getInt(P_COIN, DEFAULT_COIN).coerceIn(0, MAX_COIN),
            potatoCoinMode = mode,
            potatoCoin = prefs.getInt(P_POTATO_COIN, DEFAULT_POTATO_COIN).coerceAtLeast(1),
            potatoCoinInterval = coinInterval,
            potatoRapid = rapid,
            potatoUltimateInfinite = prefs.getBoolean(
                P_POTATO_ULTIMATE_INFINITE,
                DEFAULT_POTATO_ULTIMATE_INFINITE
            ),
            potatoUltimateSeconds = prefs.getInt(
                P_POTATO_ULTIMATE_SECONDS,
                DEFAULT_POTATO_ULTIMATE_SECONDS
            ).coerceIn(1, 86_400),
            baseSpeedMultiplier = prefs.getString(P_BASE_SPEED_MULTIPLIER, null)
                ?.toDoubleOrNull()
                ?.takeIf { it.isFinite() && it >= 0.25 && it <= 5.0 }
                ?: DEFAULT_BASE_SPEED_MULTIPLIER,
            autoSelected = savedAuto
        )
    }

    fun saveGameSpeed(value: Int) {
        prefs.edit().putInt(P_GAME_SPEED, value.coerceIn(1, 1000)).apply()
    }

    fun saveGiantSizePercent(value: Int) {
        prefs.edit().putInt(P_GIANT_SIZE, value.coerceIn(10, 100)).apply()
    }

    fun saveXp(value: Int) {
        prefs.edit().putInt(P_XP, value.coerceIn(0, MAX_XP)).apply()
    }

    fun saveCoin(value: Int) {
        prefs.edit().putInt(P_COIN, value.coerceIn(0, MAX_COIN)).apply()
    }

    fun savePotatoCoin(
        mode: String,
        value: Int,
        intervalSeconds: Double = DEFAULT_POTATO_COIN_INTERVAL
    ) {
        val safeMode = mode.uppercase().takeIf { it in POTATO_COIN_MODES }
            ?: DEFAULT_POTATO_COIN_MODE
        val safeInterval = intervalSeconds
            .takeIf { it.isFinite() && it >= 0.05 && it <= 10.0 }
            ?: DEFAULT_POTATO_COIN_INTERVAL

        prefs.edit()
            .putString(P_POTATO_COIN_MODE, safeMode)
            .putInt(P_POTATO_COIN, value.coerceAtLeast(1))
            .putString(P_POTATO_COIN_INTERVAL, safeInterval.toString())
            .apply()
    }

    fun savePotatoRapid(value: Double) {
        if (!value.isFinite() || value < 0.01 || value > 60.0) return
        prefs.edit().putString(P_POTATO_RAPID, value.toString()).apply()
    }

    fun savePotatoUltimate(infinite: Boolean, seconds: Int) {
        prefs.edit()
            .putBoolean(P_POTATO_ULTIMATE_INFINITE, infinite)
            .putInt(P_POTATO_ULTIMATE_SECONDS, seconds.coerceIn(1, 86_400))
            .apply()
    }

    fun saveBaseSpeedMultiplier(value: Double) {
        if (!value.isFinite() || value < 0.25 || value > 5.0) return
        prefs.edit().putString(P_BASE_SPEED_MULTIPLIER, value.toString()).apply()
    }

    fun saveAutoSelected(keys: Set<String>) {
        prefs.edit().putStringSet(P_AUTO_SELECTED, keys.toSet()).apply()
    }

    companion object {
        private const val PREFS = "woif_mod_settings_v1"

        private const val P_GAME_SPEED = "game_speed"
        private const val P_GIANT_SIZE = "giant_size_percent"
        private const val P_XP = "xp_value"
        private const val P_COIN = "coin_value"
        private const val P_POTATO_COIN_MODE = "potato_coin_mode"
        private const val P_POTATO_COIN = "potato_coin_value"
        private const val P_POTATO_COIN_INTERVAL = "potato_coin_interval_seconds"
        private const val P_POTATO_RAPID = "potato_rapid_seconds"
        private const val P_POTATO_ULTIMATE_INFINITE = "potato_ultimate_infinite"
        private const val P_POTATO_ULTIMATE_SECONDS = "potato_ultimate_seconds"
        private const val P_BASE_SPEED_MULTIPLIER = "base_speed_multiplier"
        private const val P_AUTO_SELECTED = "auto_selected"
        private const val P_AUTO_SELECTION_VERSION = "auto_selection_version"
        private const val AUTO_SELECTION_VERSION = 2

        const val DEFAULT_GAME_SPEED = FeatureCatalog.DEFAULT_GAME_SPEED
        const val DEFAULT_GIANT_SIZE = FeatureCatalog.DEFAULT_GIANT_SIZE_PERCENT
        const val DEFAULT_XP = FeatureCatalog.DEFAULT_XP
        const val DEFAULT_COIN = FeatureCatalog.DEFAULT_COIN
        const val MAX_XP = FeatureCatalog.MAX_XP
        const val MAX_COIN = FeatureCatalog.MAX_COIN
        const val DEFAULT_POTATO_COIN_MODE = FeatureCatalog.DEFAULT_POTATO_COIN_MODE
        const val DEFAULT_POTATO_COIN = FeatureCatalog.DEFAULT_POTATO_COIN
        const val DEFAULT_POTATO_COIN_INTERVAL = FeatureCatalog.DEFAULT_POTATO_COIN_INTERVAL
        const val DEFAULT_POTATO_RAPID = FeatureCatalog.DEFAULT_POTATO_RAPID
        const val DEFAULT_POTATO_ULTIMATE_INFINITE = FeatureCatalog.DEFAULT_POTATO_ULTIMATE_INFINITE
        const val DEFAULT_POTATO_ULTIMATE_SECONDS = FeatureCatalog.DEFAULT_POTATO_ULTIMATE_SECONDS
        const val DEFAULT_BASE_SPEED_MULTIPLIER = FeatureCatalog.DEFAULT_BASE_SPEED_MULTIPLIER

        val DEFAULT_AUTO_SELECTED: Set<String> =
            FeatureCatalog.DEFAULT_AUTO_SELECTED

        private val POTATO_COIN_MODES = setOf("FIXED", "MASSIVE", "CONTINUOUS")
    }
}
