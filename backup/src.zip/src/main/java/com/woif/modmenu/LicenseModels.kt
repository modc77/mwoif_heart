package com.woif.modmenu

data class ControlSnapshot(
    val writeAllowed: Boolean,
    val gameVersionStatus: String,
    val message: String?,
    val disabledFeatures: List<String>
)

data class AppContentSupport(
    val telegramUrl: String,
    val websiteUrl: String
)

data class AppContentAnnouncement(
    val enabled: Boolean,
    val level: String,
    val titleTh: String,
    val titleEn: String,
    val messageTh: String,
    val messageEn: String
)

data class AppContentGuide(
    val enabled: Boolean,
    val titleTh: String,
    val titleEn: String,
    val bodyTh: String,
    val bodyEn: String,
    val noteTh: String,
    val noteEn: String
)

data class AppContentWarning(
    val enabled: Boolean,
    val revision: Long,
    val titleTh: String,
    val titleEn: String,
    val bodyTh: String,
    val bodyEn: String,
    val pointsTh: String,
    val pointsEn: String
)

data class AppContentSnapshot(
    val revision: Long,
    val support: AppContentSupport,
    val announcement: AppContentAnnouncement,
    val guide: AppContentGuide,
    val warning: AppContentWarning
) {
    companion object {
        fun empty(): AppContentSnapshot =
            AppContentSnapshot(
                revision = 0L,
                support = AppContentSupport(
                    telegramUrl = "",
                    websiteUrl = ""
                ),
                announcement = AppContentAnnouncement(
                    enabled = false,
                    level = "info",
                    titleTh = "",
                    titleEn = "",
                    messageTh = "",
                    messageEn = ""
                ),
                guide = AppContentGuide(
                    enabled = false,
                    titleTh = "",
                    titleEn = "",
                    bodyTh = "",
                    bodyEn = "",
                    noteTh = "",
                    noteEn = ""
                ),
                warning = AppContentWarning(
                    enabled = false,
                    revision = 0L,
                    titleTh = "",
                    titleEn = "",
                    bodyTh = "",
                    bodyEn = "",
                    pointsTh = "",
                    pointsEn = ""
                )
            )
    }
}

data class LoginResponse(
    val sessionToken: String,
    val deviceId: String,
    val gameId: String,
    val gameVersion: String,
    val expiresAt: String,
    val sessionExpiresAt: String,
    val serverTime: String,
    val remainingSeconds: Long,
    val heartbeatSeconds: Int,
    val currentAppVersion: String?,
    val minimumAppVersion: String?,
    val control: ControlSnapshot,
    val appContent: AppContentSnapshot
)

data class CheckResponse(
    val gameVersion: String,
    val expiresAt: String,
    val sessionExpiresAt: String,
    val serverTime: String,
    val remainingSeconds: Long,
    val heartbeatSeconds: Int,
    val currentAppVersion: String?,
    val minimumAppVersion: String?,
    val control: ControlSnapshot,
    val appContentRevision: Long,
    val appContent: AppContentSnapshot?
)

sealed class ApiResult<out T> {

    data class Success<T>(
        val value: T
    ) : ApiResult<T>()

    data class Failure(
        val httpCode: Int,
        val error: String,
        val message: String,
        val serverTime: String?,
        val expiresAt: String? = null,
        val supportTelegramUrl: String? = null,
        val websiteUrl: String? = null
    ) : ApiResult<Nothing>()

    data class NetworkFailure(
        val message: String
    ) : ApiResult<Nothing>()
}
