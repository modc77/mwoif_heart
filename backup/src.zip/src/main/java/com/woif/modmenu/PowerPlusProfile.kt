package com.woif.modmenu

/**
 * Decrypted in-memory Power+ Mystery Box profile.
 *
 * All build-specific libgame addresses and object-layout offsets come from the
 * encrypted server profile. The APK only contains the generic controller.
 */
data class PowerPlusProfile(
    val imageBase: Long,
    val managerGlobal: Long,
    val nativeAddAddress: Long,
    val nativeHasAddress: Long,
    val nativeRefreshAddress: Long,
    val stageServiceGlobal: Long,
    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,
    val characterGameEventBackrefOffset: Long,
    val gameEventBackrefSubtract: Long,
    val consumerSlotOffset: Long,
    val managerListSentinelOffset: Long,
    val managerListStartOffset: Long,
    val passiveNodePrevOffset: Long,
    val passiveNodeObjectOffset: Long,
    val passiveObjectConfigOffset: Long,
    val passiveConfigKeyOffset: Long,
    val expectedGameEventVtableAddress: Long,
    val expectedPowerObjectVtableAddress: Long,
    val gameEventStateIndexOffset: Long,
    val gameEventStateArrayOffset: Long,
    val gameEventStateValueOffset: Long,
    val gameEventReadyState: Int,
    val episodeKeys: IntArray,
    val param3: Int,
    val stageSettleMs: Long,
    val retryMs: Long,
    val commandTimeoutMs: Int,
    val revision: String,
    val ttlSeconds: Int
) {
    fun immediateLayout(runtimeBias: Long): LongArray = longArrayOf(
        characterGameEventBackrefOffset,
        gameEventBackrefSubtract,
        consumerSlotOffset,
        managerListSentinelOffset,
        managerListStartOffset,
        passiveNodePrevOffset,
        passiveNodeObjectOffset,
        passiveObjectConfigOffset,
        passiveConfigKeyOffset,
        runtimeBias + expectedGameEventVtableAddress,
        runtimeBias + expectedPowerObjectVtableAddress,
        gameEventStateIndexOffset,
        gameEventStateArrayOffset,
        gameEventStateValueOffset,
        gameEventReadyState.toLong()
    )
}
