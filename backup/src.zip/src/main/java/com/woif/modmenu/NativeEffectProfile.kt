package com.woif.modmenu

/**
 * Decrypted, in-memory native-effect profile.
 *
 * All game/build-specific addresses and structure offsets come from the
 * encrypted server profile. None of those raw values are compiled into the APK.
 */
data class NativeEffectProfile(
    val featureId: String,
    val imageBase: Long,
    val hookAddress: Long,
    val dispatcherAddress: Long,
    val removerAddress: Long,
    val stageServiceGlobal: Long,
    val caveA: Long,
    val caveB: Long,
    val caveC: Long,
    val factoryAddress: Long,
    val characterVptr: Long,
    val effectManagerVptr: Long,
    val effectVptr: Long,
    val mmapAddress: Long,
    val triggerVtableSlotOffset: Long,
    val triggerVtableTarget: Long,
    val effectId: Int,
    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,
    // V5 semantics (wire keys kept compatible):
    // effectManagerOffset = Character field containing EffectManager* (0x5E0)
    // effectBeginOffset   = manager intrusive-list sentinel offset (0x18)
    // effectEndOffset     = manager effect-count offset (0x28)
    // effectCapOffset     = node offset containing effect* (0x10)
    val effectManagerOffset: Long,
    val effectBeginOffset: Long,
    val effectEndOffset: Long,
    val effectCapOffset: Long,
    val effectIdDirectOffset: Long,
    val effectIdAdjustedOffset: Long,
    val hookSignature: IntArray,
    val dispatcherSignature: IntArray,
    val removerSignature: IntArray,
    val factorySignature: IntArray,
    val mmapSignature: IntArray,
    val caveBOriginal: IntArray,
    val maxEffects: Int,
    val commandTimeoutMs: Int,

    // Optional Giant Size sub-profile. Only f03 uses these values.
    val giantSizeXOffset: Long,
    val giantSizeYOffset: Long,
    val giantSizeZOffset: Long,
    val giantSizeNormal: Float,
    val giantSizeMinPercent: Int,
    val giantSizeMaxPercent: Int,
    val giantSizeLockDelayMs: Long,
    val giantSizeRecheckWrites: Int,

    val revision: String,
    val ttlSeconds: Int
) {
    fun sameBridge(other: NativeEffectProfile): Boolean {
        return imageBase == other.imageBase &&
            hookAddress == other.hookAddress &&
            dispatcherAddress == other.dispatcherAddress &&
            removerAddress == other.removerAddress &&
            stageServiceGlobal == other.stageServiceGlobal &&
            caveA == other.caveA &&
            caveB == other.caveB &&
            caveC == other.caveC &&
            mmapAddress == other.mmapAddress &&
            triggerVtableSlotOffset == other.triggerVtableSlotOffset &&
            triggerVtableTarget == other.triggerVtableTarget &&
            serviceCharacterOffset == other.serviceCharacterOffset &&
            serviceJellyManagerOffset == other.serviceJellyManagerOffset &&
            jellyManagerCharacterOffset == other.jellyManagerCharacterOffset &&
            effectManagerOffset == other.effectManagerOffset &&
            effectBeginOffset == other.effectBeginOffset &&
            effectEndOffset == other.effectEndOffset &&
            effectCapOffset == other.effectCapOffset &&
            effectIdDirectOffset == other.effectIdDirectOffset &&
            effectIdAdjustedOffset == other.effectIdAdjustedOffset &&
            // hookAddress/hookSignature are legacy V1-V3 data. V4/V5 do not
            // install that persistent hook, so it must not split the shared
            // Giant/Super one-shot bridge.
            dispatcherSignature.contentEquals(other.dispatcherSignature) &&
            removerSignature.contentEquals(other.removerSignature) &&
            mmapSignature.contentEquals(other.mmapSignature) &&
            caveBOriginal.contentEquals(other.caveBOriginal)
    }
}
