package com.woif.modmenu

/**
 * Decrypted in-memory Potato system profile.
 *
 * All build-specific resolver values stay server-driven.
 * f07_v1 uses Rapid fields. f07_v2 adds Ultimate. f07_v3 adds Potato Coin
 * including the short-lived Continuous one-shot code hook. All build-specific
 * addresses remain server-driven under the same f07 feature family.
 */
data class PotatoProfile(
    val imageBase: Long,
    val stageServiceGlobal: Long,

    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,

    val potatoListPointerOffset: Long,
    val vectorBeginOffset: Long,
    val vectorEndOffset: Long,
    val potatoVtable: Long,

    val shotConfigOffset: Long,
    val shotCurrentOffset: Long,

    val ultimateCounterOffset: Long,
    val ultimateDurationConfigOffset: Long,
    val ultimateDurationCurrentOffset: Long,

    // f07_v3 Potato Coin + one-shot Continuous hook.
    val coinCountOffset: Long,
    val ultimateCursorOffset: Long,
    val continuousHookFunctionAddress: Long,
    val continuousCoinFunctionAddress: Long,
    val continuousPatchAddresses: LongArray,
    val continuousExpectedOriginal: IntArray,
    val continuousHookFunctionSignature: Int,
    val continuousMoveObjectOpcode: Int,
    val continuousNopOpcode: Int,

    val protectedPtr8Offset: Long,
    val protectedPtr10Offset: Long,
    val protectedPtr18Offset: Long,
    val protectedSaltOffset: Long,
    val protectedTable: ByteArray,

    val revision: String,
    val ttlSeconds: Int
)
