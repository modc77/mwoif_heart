package com.woif.modmenu

/**
 * Secure resolver profile for Cookie Base Speed (f08_v1).
 *
 * f08 changes the Character's normal protected base-speed source. It does not
 * use the game's full-result override gate, so normal treasure/passive speed
 * multipliers continue to run through CookieRun's original calculation path.
 */
data class BaseSpeedProfile(
    val imageBase: Long,
    val stageServiceGlobal: Long,

    val serviceCharacterOffset: Long,
    val serviceJellyManagerOffset: Long,
    val jellyManagerCharacterOffset: Long,

    val baseSourceOffset: Long,

    val protectedPtr8Offset: Long,
    val protectedPtr10Offset: Long,
    val protectedPtr18Offset: Long,
    val protectedSaltOffset: Long,

    val revision: String,
    val ttlSeconds: Int
)
