package com.woif.modmenu

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object LicenseApi {

    private const val BASE_URL =
        "https://license.mwoifmod.xyz"

    private const val CONNECT_TIMEOUT_MS =
        10_000

    private const val READ_TIMEOUT_MS =
        12_000

    fun login(
        key: String,
        deviceId: String,
        gameId: String,
        gameVersion: String,
        appVersion: String
    ): ApiResult<LoginResponse> {

        val body =
            JSONObject()
                .put("key", key)
                .put("device_id", deviceId)
                .put("game_id", gameId)
                .put("game_version", gameVersion)
                .put("app_version", appVersion)
                .put("feature_ids", featureIdsJson())

        return when (
            val result =
                requestJson(
                    "/api/login.php",
                    "POST",
                    body
                )
        ) {
            is RawResult.Success -> {
                val json = result.json

                try {
                    ApiResult.Success(
                        LoginResponse(
                            sessionToken =
                                json.getString("session_token"),
                            deviceId =
                                json.getString("device_id"),
                            gameId =
                                json.getString("game_id"),
                            gameVersion =
                                json.optString(
                                    "game_version",
                                    gameVersion
                                ),
                            expiresAt =
                                json.getString("expires_at"),
                            sessionExpiresAt =
                                json.getString("session_expires_at"),
                            serverTime =
                                json.getString("server_time"),
                            remainingSeconds =
                                json.optLong(
                                    "remaining_seconds",
                                    0L
                                ),
                            heartbeatSeconds =
                                json.optInt(
                                    "heartbeat_seconds",
                                    60
                                ),
                            currentAppVersion =
                                json.optNullableString(
                                    "current_app_version"
                                ),
                            minimumAppVersion =
                                json.optNullableString(
                                    "minimum_app_version"
                                ),
                            control =
                                parseControl(json),
                            appContent =
                                parseAppContent(
                                    json.optJSONObject("app_content")
                                )
                        )
                    )
                } catch (e: Exception) {
                    ApiResult.NetworkFailure(
                        "Invalid login response: ${e.message ?: "unknown"}"
                    )
                }
            }

            is RawResult.Failure -> {
                ApiResult.Failure(
                    httpCode = result.httpCode,
                    error = result.error,
                    message = result.message,
                    serverTime = result.serverTime,
                    expiresAt = result.expiresAt,
                    supportTelegramUrl = result.supportTelegramUrl,
                    websiteUrl = result.websiteUrl
                )
            }

            is RawResult.NetworkFailure -> {
                ApiResult.NetworkFailure(
                    result.message
                )
            }
        }
    }

    fun check(
        sessionToken: String,
        deviceId: String,
        gameId: String,
        gameVersion: String,
        appVersion: String,
        appContentRevision: Long
    ): ApiResult<CheckResponse> {

        val body =
            JSONObject()
                .put("session_token", sessionToken)
                .put("device_id", deviceId)
                .put("game_id", gameId)
                .put("game_version", gameVersion)
                .put("app_version", appVersion)
                .put("app_content_revision", appContentRevision)
                .put("feature_ids", featureIdsJson())

        return when (
            val result =
                requestJson(
                    "/api/check.php",
                    "POST",
                    body
                )
        ) {
            is RawResult.Success -> {
                val json = result.json

                try {
                    ApiResult.Success(
                        CheckResponse(
                            gameVersion =
                                json.optString(
                                    "game_version",
                                    gameVersion
                                ),
                            expiresAt =
                                json.getString("expires_at"),
                            sessionExpiresAt =
                                json.getString("session_expires_at"),
                            serverTime =
                                json.getString("server_time"),
                            remainingSeconds =
                                json.optLong(
                                    "remaining_seconds",
                                    0L
                                ),
                            heartbeatSeconds =
                                json.optInt(
                                    "heartbeat_seconds",
                                    60
                                ),
                            currentAppVersion =
                                json.optNullableString(
                                    "current_app_version"
                                ),
                            minimumAppVersion =
                                json.optNullableString(
                                    "minimum_app_version"
                                ),
                            control =
                                parseControl(json),
                            appContentRevision =
                                json.optLong(
                                    "app_content_revision",
                                    appContentRevision
                                ),
                            appContent =
                                json.optJSONObject("app_content")
                                    ?.let { parseAppContent(it) }
                        )
                    )
                } catch (e: Exception) {
                    ApiResult.NetworkFailure(
                        "Invalid heartbeat response: ${e.message ?: "unknown"}"
                    )
                }
            }

            is RawResult.Failure -> {
                ApiResult.Failure(
                    httpCode = result.httpCode,
                    error = result.error,
                    message = result.message,
                    serverTime = result.serverTime,
                    expiresAt = result.expiresAt,
                    supportTelegramUrl = result.supportTelegramUrl,
                    websiteUrl = result.websiteUrl
                )
            }

            is RawResult.NetworkFailure -> {
                ApiResult.NetworkFailure(
                    result.message
                )
            }
        }
    }

    fun logout(
        sessionToken: String
    ): ApiResult<Unit> {

        val body =
            JSONObject()
                .put(
                    "session_token",
                    sessionToken
                )

        return when (
            val result =
                requestJson(
                    "/api/logout.php",
                    "POST",
                    body
                )
        ) {
            is RawResult.Success ->
                ApiResult.Success(Unit)

            is RawResult.Failure ->
                ApiResult.Failure(
                    httpCode = result.httpCode,
                    error = result.error,
                    message = result.message,
                    serverTime = result.serverTime,
                    expiresAt = result.expiresAt,
                    supportTelegramUrl = result.supportTelegramUrl,
                    websiteUrl = result.websiteUrl
                )

            is RawResult.NetworkFailure ->
                ApiResult.NetworkFailure(
                    result.message
                )
        }
    }

    private fun featureIdsJson(): JSONArray {
        val array = JSONArray()
        FeatureCatalog.SERVER_FEATURE_IDS.forEach {
            array.put(it)
        }
        return array
    }

    private fun parseControl(json: JSONObject): ControlSnapshot {
        val control =
            json.optJSONObject("control")
                ?: return ControlSnapshot(
                    writeAllowed = true,
                    gameVersionStatus = "supported",
                    message = null,
                    disabledFeatures = emptyList()
                )

        val disabled = mutableListOf<String>()
        val array = control.optJSONArray("disabled_features")

        if (array != null) {
            for (index in 0 until array.length()) {
                val value = array.optString(index, "").trim()
                if (value.isNotEmpty()) {
                    disabled += value
                }
            }
        }

        return ControlSnapshot(
            writeAllowed =
                control.optBoolean(
                    "write_allowed",
                    true
                ),
            gameVersionStatus =
                control.optString(
                    "game_version_status",
                    "supported"
                ),
            message =
                control.optNullableString("message"),
            disabledFeatures =
                disabled.distinct()
        )
    }

    private fun parseAppContent(json: JSONObject?): AppContentSnapshot {
        if (json == null) {
            return AppContentSnapshot.empty()
        }

        val support =
            json.optJSONObject("support")
                ?: JSONObject()
        val announcement =
            json.optJSONObject("announcement")
                ?: JSONObject()
        val guide =
            json.optJSONObject("guide")
                ?: JSONObject()
        val warning =
            json.optJSONObject("warning")
                ?: JSONObject()

        return AppContentSnapshot(
            revision = json.optLong("revision", 0L),
            support = AppContentSupport(
                telegramUrl =
                    support.optString("telegram_url", "").trim(),
                websiteUrl =
                    support.optString("website_url", "").trim()
            ),
            announcement = AppContentAnnouncement(
                enabled =
                    announcement.optBoolean("enabled", false),
                level =
                    announcement.optString("level", "info")
                        .trim()
                        .lowercase(),
                titleTh =
                    announcement.optString("title_th", "").trim(),
                titleEn =
                    announcement.optString("title_en", "").trim(),
                messageTh =
                    announcement.optString("message_th", "").trim(),
                messageEn =
                    announcement.optString("message_en", "").trim()
            ),
            guide = AppContentGuide(
                enabled =
                    guide.optBoolean("enabled", false),
                titleTh =
                    guide.optString("title_th", "").trim(),
                titleEn =
                    guide.optString("title_en", "").trim(),
                bodyTh =
                    guide.optString("body_th", "").trim(),
                bodyEn =
                    guide.optString("body_en", "").trim(),
                noteTh =
                    guide.optString("note_th", "").trim(),
                noteEn =
                    guide.optString("note_en", "").trim()
            ),
            warning = AppContentWarning(
                enabled =
                    warning.optBoolean("enabled", false),
                revision =
                    warning.optLong("revision", 0L),
                titleTh =
                    warning.optString("title_th", "").trim(),
                titleEn =
                    warning.optString("title_en", "").trim(),
                bodyTh =
                    warning.optString("body_th", "").trim(),
                bodyEn =
                    warning.optString("body_en", "").trim(),
                pointsTh =
                    warning.optString("points_th", "").trim(),
                pointsEn =
                    warning.optString("points_en", "").trim()
            )
        )
    }

    private fun requestJson(
        path: String,
        method: String,
        body: JSONObject?
    ): RawResult {

        var connection: HttpURLConnection? = null

        return try {
            val url = URL(BASE_URL + path)

            connection =
                url.openConnection()
                    as HttpURLConnection

            connection.requestMethod = method
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.useCaches = false
            connection.instanceFollowRedirects = false
            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
                )

                val bytes =
                    body.toString()
                        .toByteArray(Charsets.UTF_8)

                connection.setFixedLengthStreamingMode(
                    bytes.size
                )

                connection.outputStream.use {
                    it.write(bytes)
                }
            }

            val httpCode = connection.responseCode

            val stream =
                if (httpCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val text =
                if (stream != null) {
                    BufferedReader(
                        InputStreamReader(
                            stream,
                            Charsets.UTF_8
                        )
                    ).use {
                        it.readText()
                    }
                } else {
                    ""
                }

            val json =
                if (text.isNotBlank()) {
                    JSONObject(text)
                } else {
                    JSONObject()
                }

            if (
                httpCode in 200..299 &&
                json.optBoolean("ok", false)
            ) {
                RawResult.Success(json)
            } else {
                RawResult.Failure(
                    httpCode = httpCode,
                    error =
                        json.optString(
                            "error",
                            "HTTP_$httpCode"
                        ),
                    message =
                        json.optString(
                            "message",
                            "Request failed"
                        ),
                    serverTime =
                        json.optNullableString(
                            "server_time"
                        ),
                    expiresAt =
                        json.optNullableString(
                            "expires_at"
                        ),
                    supportTelegramUrl =
                        json.optNullableString(
                            "support_telegram_url"
                        ),
                    websiteUrl =
                        json.optNullableString(
                            "website_url"
                        )
                )
            }
        } catch (e: Exception) {
            RawResult.NetworkFailure(
                e.message ?: e.javaClass.simpleName
            )
        } finally {
            connection?.disconnect()
        }
    }

    private sealed class RawResult {
        data class Success(
            val json: JSONObject
        ) : RawResult()

        data class Failure(
            val httpCode: Int,
            val error: String,
            val message: String,
            val serverTime: String?,
            val expiresAt: String?,
            val supportTelegramUrl: String?,
            val websiteUrl: String?
        ) : RawResult()

        data class NetworkFailure(
            val message: String
        ) : RawResult()
    }

    private fun JSONObject.optNullableString(
        key: String
    ): String? {
        if (!has(key) || isNull(key)) {
            return null
        }

        return optString(key, "")
            .takeIf { it.isNotBlank() }
    }
}
