package com.woif.modmenu

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.util.Base64
import javax.crypto.Cipher

object DeviceProfileKeyStore {

    private const val STORE =
        "AndroidKeyStore"

    private const val ALIAS =
        "mw_pf_01"

    private fun keyStore():
            KeyStore {

        return KeyStore
            .getInstance(
                STORE
            )
            .apply {
                load(
                    null
                )
            }
    }

    @Synchronized
    fun ensureKeyPair() {

        val store =
            keyStore()

        if (
            store.containsAlias(
                ALIAS
            )
        ) {
            return
        }

        val generator =
            KeyPairGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_RSA,
                STORE
            )

        val spec =
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(
                    2048
                )
                .setDigests(
                    KeyProperties.DIGEST_SHA1,
                    KeyProperties.DIGEST_SHA256
                )
                .setEncryptionPaddings(
                    KeyProperties.ENCRYPTION_PADDING_RSA_OAEP
                )
                .build()

        generator.initialize(
            spec
        )

        generator.generateKeyPair()
    }

    fun publicKeyBase64():
            String {

        ensureKeyPair()

        val certificate =
            keyStore()
                .getCertificate(
                    ALIAS
                )
                ?: error(
                    "Profile certificate missing"
                )

        return Base64
            .getEncoder()
            .encodeToString(
                certificate
                    .publicKey
                    .encoded
            )
    }

    fun unwrapAesKey(
        wrapped:
            ByteArray
    ): ByteArray {

        ensureKeyPair()

        val key =
            keyStore()
                .getKey(
                    ALIAS,
                    null
                )
                as? PrivateKey
                ?: error(
                    "Profile private key missing"
                )

        val cipher =
            Cipher.getInstance(
                "RSA/ECB/OAEPWithSHA-1AndMGF1Padding"
            )

        cipher.init(
            Cipher.DECRYPT_MODE,
            key
        )

        return cipher.doFinal(
            wrapped
        )
    }
}
