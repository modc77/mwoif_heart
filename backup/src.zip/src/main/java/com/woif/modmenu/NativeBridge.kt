package com.woif.modmenu

import android.util.Log

object NativeBridge {

    @Volatile
    private var loaded = false

    fun load(): Boolean {
        if (loaded) return true

        return try {
            System.loadLibrary("woif")
            loaded = true
            Log.i("WOIF-CRG", "libwoif.so loaded")
            true
        } catch (e: Throwable) {
            Log.e("WOIF-CRG", "Failed to load libwoif.so", e)
            false
        }
    }
}