package com.mwoif.lab.heart

import com.woif.modmenu.R
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

/**
 * Attach this section BELOW the existing V13 Session Export block.
 * It does not modify any V13 Session button/callback.
 */
object V13_1AuthContextSection {
    fun attach(context: Context, parent: ViewGroup): View {
        val view = LayoutInflater.from(context)
            .inflate(R.layout.view_heart_auth_context_v13_1, parent, false)
        parent.addView(view)
        AuthContextExportController(context, view).bind()
        return view
    }
}
