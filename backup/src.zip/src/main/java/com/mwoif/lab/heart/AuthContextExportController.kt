package com.mwoif.lab.heart

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.woif.modmenu.InProcessGameControl
import com.woif.modmenu.R

/**
 * Optional standalone V13.1 Auth section.
 *
 * The main dev page renders Auth directly in FloatingMenuService, but this
 * controller is kept safe too: it delegates through the game-process IPC and
 * never calls the old app-process native getter route.
 */
class AuthContextExportController(
    private val context: Context,
    private val root: View
) {
    private val status: TextView = root.findViewById(R.id.authContextStatus)
    private val readButton: Button = root.findViewById(R.id.readAuthContextButton)
    private val copyButton: Button = root.findViewById(R.id.copyAuthContextJsonButton)

    fun bind() {
        status.text = "AUTH CONTEXT: NOT READ"

        readButton.setOnClickListener {
            status.text = "AUTH CONTEXT: READING GAME PROCESS..."
            Thread({
                val result = InProcessGameControl.authContext(
                    context = context,
                    includeSecret = false,
                    timeoutMs = 5000L
                )
                val report = clean(result.message)
                root.post {
                    status.text = redact(report)
                    val reason = report.lineSequence()
                        .firstOrNull { it.startsWith("reason=") }
                        ?.substringAfter("reason=")
                        .orEmpty()
                    Toast.makeText(
                        context,
                        if (result.ok) "AUTH CONTEXT READY"
                        else "AUTH CONTEXT: ${reason.ifBlank { "NOT_READY" }}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }, "mw-auth-section-read").start()
        }

        copyButton.setOnClickListener {
            status.text = "AUTH CONTEXT: COPYING FROM GAME PROCESS..."
            Thread({
                val result = InProcessGameControl.authContext(
                    context = context,
                    includeSecret = true,
                    timeoutMs = 5000L
                )
                val report = clean(result.message)
                val json = report.lineSequence()
                    .firstOrNull { it.startsWith("authJson=") }
                    ?.substringAfter("authJson=")
                    ?.trim()
                    .orEmpty()

                root.post {
                    if (!result.ok || json.isBlank()) {
                        status.text = redact(report)
                        Toast.makeText(
                            context,
                            "AUTH CONTEXT COPY FAILED",
                            Toast.LENGTH_SHORT
                        ).show()
                        return@post
                    }

                    val clipboard =
                        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(
                        ClipData.newPlainText("MWOIF Auth Context", json)
                    )
                    status.text = "AUTH CONTEXT: COPIED • secret not displayed"
                    Toast.makeText(
                        context,
                        "AUTH CONTEXT JSON COPIED",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }, "mw-auth-section-copy").start()
        }
    }

    private fun clean(message: String): String {
        val marker = "MWOIF_AUTH_CONTEXT_V13_1"
        val index = message.indexOf(marker)
        return if (index >= 0) message.substring(index).trim() else message.trim()
    }

    private fun redact(report: String): String =
        report.lineSequence()
            .filterNot { it.startsWith("authJson=") }
            .map {
                if (it.startsWith("gameAccessToken=")) {
                    "gameAccessToken=<REDACTED>"
                } else {
                    it
                }
            }
            .joinToString("\n")
}
