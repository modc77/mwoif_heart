package com.mwoif.lab.heart

/**
 * Legacy marker only.
 *
 * V13.1 Auth no longer calls native code from the M Woif app process.
 * The live route is:
 * FloatingMenuService -> InProcessGameControl -> injected CookieRun process
 * -> InProcessNativeBridge -> FUN_00EB8EFC game-owned materializer.
 */
@Deprecated("Use InProcessGameControl.authContext() in the game process")
object AuthContextNative
