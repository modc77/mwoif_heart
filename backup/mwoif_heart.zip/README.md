# MWOIF HEART V6.2 — FRIEND gRPC

**Base contract:** `MWOIF_HEART_V6_1_SIMPLE_SESSION_IMPORT`

V6.2 keeps the V6.1 established Session A/B flow and adds a separate Auth Context store for Friend gRPC.

## New commands

```powershell
python main.py import-auth A --file import/auth_A.json
python main.py import-auth B --file import/auth_B.json
python main.py auth-show B
python main.py friend-list B
```

Known V6.1 session commands remain:

```powershell
python main.py import-session A --file import/session_A.json
python main.py import-session B --file import/session_B.json
python main.py session-show
```

## Auth rule

Native evidence:

```text
authorization = Bearer <game_access_token>
player-id     = <MID>
```

`session_key` is not used as Bearer auth.

## Friend transport

```text
host = streaming.live.prod.devsnova.cloud:443

/service.api.FriendAPI/ListFriends
/service.api.FriendAPI/SendFriendRequest
/service.api.FriendAPI/HandleFriendRequest
/service.api.FriendAPI/RemoveFriend
```

`friend-list` is the only live network action in V6.2. It is read-only.

`friend-add`, `friend-accept`, and `friend-remove` remain dry-run until ListFriends succeeds and field #3 for Add/Accept is frozen.

## ListFriends request body

The ListFriends request path/type is known, but the request body is **not frozen as definitely empty**.

V6.2 therefore:
- accepts captured bytes with `--request-hex`
- accepts `friend_list_request_hex` inside auth JSON
- otherwise sends an empty body but labels it `EMPTY_TENTATIVE_NOT_FROZEN`

## Dynamic native metadata

The native metadata builder also contains dynamic keys including:

```text
combo-name
index-file-hash
login_platform
```

If the server requires them, provide them with `--metadata-file config/native_metadata.json`
or `MWOIF_GRPC_METADATA_JSON`.

Tokens are always redacted in CLI output.
