#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import json
import sys
from pathlib import Path
from typing import Any

from mwoif.action_runner import dry_run
from mwoif.auth_store import AuthStore
from mwoif.clipboard import get_clipboard_text
from mwoif.config import load_config
from mwoif.devplay import login as devplay_login
from mwoif.endpoint_registry import public_registry
from mwoif.friend_grpc import (
    GRPC_HOST,
    LIST_FRIENDS_METHOD,
    handle_friend_request,
    list_friends,
    remove_friend,
    send_friend_request,
)
from mwoif.grpc_metadata import load_metadata_file
from mwoif.heart_ds import preview_heart_send
from mwoif.heart_mailbox import preview_mail_list
from mwoif.heart_receive import preview_heart_receive
from mwoif.planner import build_plan
from mwoif.secrets_store import SecretsStore
from mwoif.session_store import SessionStore

VERSION = "6.2-heart-ds-v4"


def dump(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def root_dir() -> Path:
    return Path(__file__).resolve().parent


def parse_hex(value: str) -> bytes:
    cleaned = "".join(ch for ch in value if ch in "0123456789abcdefABCDEF")
    if len(cleaned) % 2:
        raise ValueError("request hex length must be even")
    return bytes.fromhex(cleaned)


def read_source(args) -> str:
    if getattr(args, "clipboard", False):
        return get_clipboard_text()
    path = getattr(args, "file", None)
    if path:
        return Path(path).read_text(encoding="utf-8")
    raise ValueError("use --file FILE or --clipboard")


def get_context():
    cfg = load_config(root_dir())
    sessions = SessionStore(cfg.root)
    auths = AuthStore(cfg.root)
    secrets = SecretsStore(cfg.root)
    return cfg, sessions, auths, secrets


def existing_slots(store, prefix: str) -> list[str]:
    state = root_dir() / ".state"
    if not state.exists():
        return []
    result = []
    for path in sorted(state.glob(f"{prefix}_*.json")):
        result.append(path.stem[len(prefix) + 1:].upper())
    return result


def cmd_doctor(_):
    cfg, sessions, auths, secrets = get_context()

    try:
        import requests  # noqa
        requests_ok = True
    except Exception:
        requests_ok = False

    try:
        import grpc  # noqa
        grpc_ok = True
    except Exception:
        grpc_ok = False

    dump({
        "ok": True,
        "version": VERSION,
        "architecture": "single-package:mwoif",
        "requests": requests_ok,
        "grpcio": grpc_ok,
        "grpc_host": GRPC_HOST,
        "session_slots": existing_slots(sessions, "session"),
        "auth_slots": existing_slots(auths, "auth"),
        "friend_list_live": True,
        "friend_write_live": False,
        "heart_write_live": False,
        "heart_write_live_guarded": True,
        "heart_ds_v4_encoder": True,
    })


def cmd_setup_secrets(args):
    _, _, _, secrets = get_context()
    data = secrets.load()

    slots = [args.slot.upper()] if args.slot else ["A", "B"]
    for slot in slots:
        password = getpass.getpass(f"Password for account {slot}: ")
        if password:
            data[f"account_{slot}_password"] = password

    secrets.save(data)
    dump({
        "ok": True,
        "action": "setup-secrets",
        "slots": slots,
        "stored": True,
        "path": ".state/secrets.local.json",
    })


def cmd_login(args):
    cfg, _, _, secrets = get_context()
    slot = args.slot.upper()
    auth = devplay_login(
        cfg=cfg,
        slot=slot,
        password=secrets.get_password(slot),
    )
    dump({
        "ok": True,
        "action": "login",
        "note": "optional legacy DevPlay path; does not replace V13/V13.1 import",
        "result": auth.public_dict(),
    })


def cmd_import_session(args):
    _, sessions, _, _ = get_context()
    slot = args.slot.upper()
    record = sessions.import_v13(
        slot=slot,
        raw=read_source(args),
    )
    dump({
        "ok": True,
        "action": "import-session",
        "session": record.public_dict(),
    })


def cmd_session_show(args):
    _, sessions, _, _ = get_context()
    slots = [args.slot.upper()] if args.slot else existing_slots(sessions, "session")
    dump({
        "version": VERSION,
        "sessions": {
            slot: sessions.load(slot).public_dict()
            for slot in slots
            if sessions.load(slot) is not None
        },
    })


def cmd_import_auth(args):
    _, _, auths, _ = get_context()
    slot = args.slot.upper()
    record = auths.import_v13_1(
        slot=slot,
        raw=read_source(args),
    )
    dump({
        "ok": True,
        "action": "import-auth",
        "auth": record.public_dict(),
    })


def cmd_auth_show(args):
    _, _, auths, _ = get_context()
    slots = [args.slot.upper()] if args.slot else existing_slots(auths, "auth")
    dump({
        "version": VERSION,
        "auth_contexts": {
            slot: auths.load(slot).public_dict()
            for slot in slots
            if auths.load(slot) is not None
        },
    })


def pair_status(slot: str, sessions, auths) -> dict[str, Any]:
    slot = slot.upper()
    session = sessions.load(slot)
    auth = auths.load(slot)

    # Session V13 has no MID/email. Auth V13.1 owns MID.
    # A/B slot is the pairing boundary between the two imported snapshots.
    slot_pair_ready = bool(session and auth)

    return {
        "slot": slot,
        "session_present": session is not None,
        "session_established": bool(session and session.established),
        "auth_present": auth is not None,
        "auth_ready": bool(auth and auth.ready),
        "mid_source": "auth",
        "auth_mid": auth.mid if auth else "",
        "slot_pair_ready": slot_pair_ready,
        "ready_for_friend_list": bool(
            session
            and session.established
            and auth
            and auth.ready
        ),
    }

def cmd_pair_show(args):
    _, sessions, auths, _ = get_context()
    slots = [args.slot.upper()] if args.slot else ["A", "B"]
    dump({
        "version": VERSION,
        "pairs": {
            slot: pair_status(slot, sessions, auths)
            for slot in slots
        },
    })


def cmd_endpoints(_):
    dump({
        "version": VERSION,
        "registry": public_registry(),
        "friend_grpc": {
            "host": GRPC_HOST,
            "list_method": LIST_FRIENDS_METHOD,
            "authorization": "Bearer <game_access_token>",
            "player_id_metadata": "MID",
            "session_key_as_bearer": False,
        },
    })


def cmd_plan(args):
    plan = build_plan(
        args.sender.upper(),
        args.receiver.upper(),
        include_receive=args.include_receive,
    )
    dump({
        "ok": True,
        "version": VERSION,
        "steps": [step.as_dict() for step in plan],
    })


def cmd_friend_list(args):
    cfg, sessions, auths, _ = get_context()
    slot = args.slot.upper()

    pair = pair_status(slot, sessions, auths)
    if not pair["ready_for_friend_list"]:
        raise ValueError(
            f"slot {slot} is not paired; run session-show/auth-show/pair-show first"
        )

    auth = auths.load(slot)
    assert auth is not None

    body = b""
    source = "empty"
    if args.request_hex:
        body = parse_hex(args.request_hex)
        source = "--request-hex"

    result = list_friends(
        cfg=cfg,
        slot=slot,
        auth=auth,
        request_body=body,
        extra_metadata=load_metadata_file(args.metadata_file),
        timeout=args.timeout,
    )
    result["slot"] = slot
    result["request_source"] = source
    result["pair"] = pair
    dump(result)


def _dry_action(command: str, action: str, actor: str, target: str):
    cfg, sessions, auths, _ = get_context()
    actor = actor.upper()
    target = target.upper()

    base = dry_run(
        action,
        actor,
        target,
        sessions.load(actor),
        sessions.load(target),
    )

    if action.startswith("friend_"):
        actor_auth = auths.load(actor)
        target_auth = auths.load(target)
        base["actor_auth_ready"] = bool(actor_auth and actor_auth.ready)
        base["target_auth_ready"] = bool(target_auth and target_auth.ready)
        base["reason"] = (
            "Friend write remains dry-run until ListFriends passes and "
            "Add/Accept field #3 is frozen"
        )
    else:
        base["reason"] = (
            "Heart write remains dry-run until Friend gRPC and Heart mailbox/"
            "DS common wrapper are frozen"
        )

    base["command"] = command
    dump(base)


def _friend_write_pair(actor: str, target: str):
    cfg, sessions, auths, _ = get_context()
    actor = actor.upper()
    target = target.upper()

    actor_pair = pair_status(actor, sessions, auths)
    target_pair = pair_status(target, sessions, auths)
    if not actor_pair["ready_for_friend_list"]:
        raise ValueError(f"actor slot {actor} is not ready")
    if not target_pair["ready_for_friend_list"]:
        raise ValueError(f"target slot {target} is not ready")

    actor_auth = auths.load(actor)
    target_auth = auths.load(target)
    assert actor_auth is not None
    assert target_auth is not None
    if not target_auth.mid:
        raise ValueError(f"target slot {target} has no Auth MID")

    return cfg, actor, target, actor_auth, target_auth, actor_pair, target_pair


def cmd_friend_add(args):
    (
        cfg, actor, target, actor_auth, target_auth, actor_pair, target_pair
    ) = _friend_write_pair(args.actor, args.target)

    if args.source_type is None:
        dump({
            "ok": False,
            "action": "friend-add",
            "read_only": True,
            "network_action_enabled": False,
            "error": "SOURCE_TYPE_REQUIRED",
            "message": (
                "Ghidra confirmed SendFriendRequest field #3 accepts 1..4, "
                "but the exact UI source value is not guessed. "
                "Pass --source-type 1|2|3|4 after it is frozen."
            ),
            "actor": actor,
            "target": target,
            "target_mid": target_auth.mid,
        })
        return

    result = send_friend_request(
        cfg=cfg,
        slot=actor,
        auth=actor_auth,
        target_mid=target_auth.mid,
        source_type=args.source_type,
        extra_metadata=load_metadata_file(args.metadata_file),
        timeout=args.timeout,
        live=args.live,
    )
    result["actor"] = actor
    result["target"] = target
    result["target_mid"] = target_auth.mid
    result["actor_pair"] = actor_pair
    result["target_pair"] = target_pair
    dump(result)


def cmd_friend_accept(args):
    (
        cfg, actor, target, actor_auth, target_auth, actor_pair, target_pair
    ) = _friend_write_pair(args.actor, args.target)

    result = handle_friend_request(
        cfg=cfg,
        slot=actor,
        auth=actor_auth,
        target_mid=target_auth.mid,
        accept=True,
        extra_metadata=load_metadata_file(args.metadata_file),
        timeout=args.timeout,
        live=args.live,
    )
    result["actor"] = actor
    result["target"] = target
    result["target_mid"] = target_auth.mid
    result["actor_pair"] = actor_pair
    result["target_pair"] = target_pair
    dump(result)


def cmd_friend_remove(args):
    (
        cfg, actor, target, actor_auth, target_auth, actor_pair, target_pair
    ) = _friend_write_pair(args.actor, args.target)

    result = remove_friend(
        cfg=cfg,
        slot=actor,
        auth=actor_auth,
        target_mids=[target_auth.mid],
        extra_metadata=load_metadata_file(args.metadata_file),
        timeout=args.timeout,
        live=args.live,
    )
    result["actor"] = actor
    result["target"] = target
    result["target_mid"] = target_auth.mid
    result["actor_pair"] = actor_pair
    result["target_pair"] = target_pair
    dump(result)


def cmd_heart_send(args):
    cfg, sessions, auths, _ = get_context()
    actor = args.actor.upper()
    target = args.target.upper()

    actor_session = sessions.load(actor)
    target_session = sessions.load(target)
    actor_auth = auths.load(actor)
    if actor_session is None or not actor_session.established:
        raise ValueError(f"actor slot {actor} has no established Session")
    if target_session is None or not target_session.established:
        raise ValueError(f"target slot {target} has no established Session")
    if actor_auth is None or not actor_auth.ready:
        raise ValueError(f"actor slot {actor} has no ready Auth context")

    result = preview_heart_send(
        cfg=cfg,
        actor_slot=actor,
        target_slot=target,
        actor_session=actor_session,
        target_session=target_session,
        actor_auth=actor_auth,
        live=args.live,
        timeout=args.timeout,
        padding_spaces=args.pad_spaces,
        ms=args.ms,
        cable=args.cable or None,
        fgs_id=args.fgs_id or None,
        timezone_distance=args.time_zone_distance,
    )
    result["actor_session"] = {
        "member_seq": actor_session.member_seq,
        "established": actor_session.established,
    }
    result["target_session"] = {
        "member_seq": target_session.member_seq,
        "established": target_session.established,
    }
    dump(result)



def cmd_heart_mail_list(args):
    cfg, sessions, auths, _ = get_context()
    slot = args.slot.upper()

    session = sessions.load(slot)
    auth = auths.load(slot)
    if session is None or not session.established:
        raise ValueError(f"slot {slot} has no established Session")
    if auth is None or not auth.ready:
        raise ValueError(f"slot {slot} has no ready Auth context")

    from_slot = (args.from_slot or "").upper()
    from_member_seq = None
    if from_slot:
        sender_session = sessions.load(from_slot)
        if sender_session is None or not sender_session.established:
            raise ValueError(
                f"from-slot {from_slot} has no established Session"
            )
        from_member_seq = int(sender_session.member_seq)

    result = preview_mail_list(
        cfg=cfg,
        slot=slot,
        session=session,
        auth=auth,
        from_slot=from_slot or None,
        from_member_seq=from_member_seq,
        live=args.live,
        timeout=args.timeout,
        padding_spaces=args.pad_spaces,
        ms=args.ms,
        cable=args.cable or None,
        fgs_id=args.fgs_id or None,
        timezone_distance=args.time_zone_distance,
    )
    result["session"] = {
        "member_seq": session.member_seq,
        "established": session.established,
    }
    dump(result)


def cmd_heart_receive(args):
    cfg, sessions, auths, _ = get_context()
    actor = args.actor.upper()

    actor_session = sessions.load(actor)
    actor_auth = auths.load(actor)
    if actor_session is None or not actor_session.established:
        raise ValueError(
            f"actor slot {actor} has no established Session"
        )
    if actor_auth is None or not actor_auth.ready:
        raise ValueError(
            f"actor slot {actor} has no ready Auth context"
        )

    result = preview_heart_receive(
        cfg=cfg,
        actor_slot=actor,
        actor_session=actor_session,
        actor_auth=actor_auth,
        life_mail_box_seqs=args.seq,
        live=args.live,
        timeout=args.timeout,
        padding_spaces=args.pad_spaces,
        ms=args.ms,
        cable=args.cable or None,
        fgs_id=args.fgs_id or None,
        timezone_distance=args.time_zone_distance,
    )
    result["actor_session"] = {
        "member_seq": actor_session.member_seq,
        "established": actor_session.established,
    }
    dump(result)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="main.py",
        description="MWOIF Heart V6.2 integrated on V6.1",
    )
    sp = p.add_subparsers(dest="cmd", required=True)

    q = sp.add_parser("doctor")
    q.set_defaults(func=cmd_doctor)

    q = sp.add_parser("setup-secrets")
    q.add_argument("slot", nargs="?")
    q.set_defaults(func=cmd_setup_secrets)

    q = sp.add_parser("login")
    q.add_argument("slot")
    q.set_defaults(func=cmd_login)

    q = sp.add_parser("import-session")
    q.add_argument("slot")
    g = q.add_mutually_exclusive_group(required=True)
    g.add_argument("--file")
    g.add_argument("--clipboard", action="store_true")
    q.set_defaults(func=cmd_import_session)

    q = sp.add_parser("session-show")
    q.add_argument("slot", nargs="?")
    q.set_defaults(func=cmd_session_show)

    q = sp.add_parser("import-auth")
    q.add_argument("slot")
    g = q.add_mutually_exclusive_group(required=True)
    g.add_argument("--file")
    g.add_argument("--clipboard", action="store_true")
    q.set_defaults(func=cmd_import_auth)

    q = sp.add_parser("auth-show")
    q.add_argument("slot", nargs="?")
    q.set_defaults(func=cmd_auth_show)

    q = sp.add_parser("pair-show")
    q.add_argument("slot", nargs="?")
    q.set_defaults(func=cmd_pair_show)

    q = sp.add_parser("endpoints")
    q.set_defaults(func=cmd_endpoints)

    q = sp.add_parser("plan")
    q.add_argument("sender")
    q.add_argument("receiver")
    q.add_argument("--include-receive", action="store_true")
    q.set_defaults(func=cmd_plan)

    q = sp.add_parser("friend-list")
    q.add_argument("slot")
    q.add_argument("--timeout", type=float, default=12.0)
    q.add_argument("--request-hex", default="")
    q.add_argument("--metadata-file", default="")
    q.set_defaults(func=cmd_friend_list)

    q = sp.add_parser("friend-add")
    q.add_argument("actor")
    q.add_argument("target")
    q.add_argument("--source-type", type=int, choices=(1, 2, 3, 4))
    q.add_argument("--timeout", type=float, default=12.0)
    q.add_argument("--metadata-file", default="")
    q.add_argument("--live", action="store_true")
    q.set_defaults(func=cmd_friend_add)

    q = sp.add_parser("friend-accept")
    q.add_argument("actor")
    q.add_argument("target")
    q.add_argument("--timeout", type=float, default=12.0)
    q.add_argument("--metadata-file", default="")
    q.add_argument("--live", action="store_true")
    q.set_defaults(func=cmd_friend_accept)

    q = sp.add_parser("friend-remove")
    q.add_argument("actor")
    q.add_argument("target")
    q.add_argument("--timeout", type=float, default=12.0)
    q.add_argument("--metadata-file", default="")
    q.add_argument("--live", action="store_true")
    q.set_defaults(func=cmd_friend_remove)

    q = sp.add_parser("heart-send")
    q.add_argument("actor")
    q.add_argument("target")
    q.add_argument("--timeout", type=float, default=20.0)
    q.add_argument("--pad-spaces", type=int, choices=range(0, 16))
    q.add_argument("--ms", type=int)
    q.add_argument("--cable", default="")
    q.add_argument("--fgs-id", default="")
    q.add_argument("--time-zone-distance", type=int)
    q.add_argument("--live", action="store_true")
    q.set_defaults(func=cmd_heart_send)

    q = sp.add_parser("heart-mail-list")
    q.add_argument("slot")
    q.add_argument("--from-slot", default="")
    q.add_argument("--timeout", type=float, default=20.0)
    q.add_argument("--pad-spaces", type=int, choices=range(0, 16))
    q.add_argument("--ms", type=int)
    q.add_argument("--cable", default="")
    q.add_argument("--fgs-id", default="")
    q.add_argument("--time-zone-distance", type=int)
    q.add_argument("--live", action="store_true")
    q.set_defaults(func=cmd_heart_mail_list)

    q = sp.add_parser("heart-receive")
    q.add_argument("actor")
    q.add_argument(
        "--seq",
        action="append",
        type=int,
        required=True,
        help="lifeMailBoxSeq; repeat --seq to claim multiple lives",
    )
    q.add_argument("--timeout", type=float, default=20.0)
    q.add_argument("--pad-spaces", type=int, choices=range(0, 16))
    q.add_argument("--ms", type=int)
    q.add_argument("--cable", default="")
    q.add_argument("--fgs-id", default="")
    q.add_argument("--time-zone-distance", type=int)
    q.add_argument("--live", action="store_true")
    q.set_defaults(func=cmd_heart_receive)

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as exc:
        dump({
            "ok": False,
            "error": type(exc).__name__,
            "message": str(exc),
        })
        raise SystemExit(2)


if __name__ == "__main__":
    main()
