MWOIF HEART V6.2 runtime field fix
Consumes LAB V13.6 Auth metadata: fgs-id, game-process-elapsed-ms, time-zone-distance.
DELETE: NONE
