# Heart/Friend discovery map — 26.8.02

สถานะ ณ V6 fresh rebuild

| Action | Transport | Native path | Request evidence | Status |
|---|---|---|---|---|
| Friend list | gRPC | `/service.api.FriendAPI/ListFriends` | `ListFriendsRequest` | path found |
| Add friend | gRPC | `/service.api.FriendAPI/SendFriendRequest` | `SendFriendRequestRequest.player_id` | path + primary field found |
| Accept friend | gRPC | `/service.api.FriendAPI/HandleFriendRequest` | `HandleFriendRequestRequest.player_id` | path + primary field found |
| Remove friend | gRPC | `/service.api.FriendAPI/RemoveFriend` | `RemoveFriendRequest.player_ids` | path + primary field found |
| Send heart | DS | `game/sendLifeMail2.ds` | request fields still to map | path found |
| Receive heart | DS | `game/acceptLifeMail4.ds` | request fields still to map | path found |

## Next research

1. Resolve FriendAPI gRPC host/channel and metadata/auth source.
2. Confirm protobuf field numbers/types for `player_id` / `player_ids`.
3. Trace `sendLifeMail2.ds` request builder and exact request fields.
4. Trace `acceptLifeMail4.ds` request builder and exact request fields.
5. Wire live commands only after those shapes are confirmed from the native path.
