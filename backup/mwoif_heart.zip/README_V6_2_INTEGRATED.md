# MWOIF HEART V6.2 — INTEGRATED ON YOUR V6.1

This revision uses the existing `mwoif/` package as the single codebase.

There is **no second `mwoif_heart/` package**.

## Kept from V6.1

```text
mwoif/config.py
mwoif/devplay.py
mwoif/session_store.py
mwoif/planner.py
mwoif/endpoint_registry.py
mwoif/action_runner.py
mwoif/secrets_store.py

import-session
session-show
login
setup-secrets
endpoints
plan
friend/heart dry-run commands
```

Existing:

```text
.state/session_A.json
.state/session_B.json
```

are not replaced by this patch.

## Added in V6.2

```text
mwoif/auth_store.py
mwoif/grpc_metadata.py
mwoif/friend_grpc.py
mwoif/wire.py

import-auth
auth-show
pair-show
friend-list
```

## Correct flow

For each account:

```powershell
python main.py import-session A --file import/session_A.json
python main.py import-auth A --file import/auth_A.json

python main.py import-session B --file import/session_B.json
python main.py import-auth B --file import/auth_B.json
```

Check pairing:

```powershell
python main.py pair-show
```

Then only the read-only live call:

```powershell
python main.py friend-list B
```

Friend writes remain dry-run.

## Auth rule

```text
authorization = Bearer <gameAccessToken>
player-id = MID
```

`session_key` is never used as Bearer auth.
