@echo off
setlocal
cd /d "%~dp0"
python main.py import-session B --file import\session_B.json
if errorlevel 1 (
  echo.
  echo Import B failed. Paste the V13 Session JSON into import\session_B.json and save it.
)
pause
