@echo off
python main.py import-auth B --file import\auth_B.json
pause
