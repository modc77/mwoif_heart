@echo off
python main.py import-auth A --file import\auth_A.json
pause
