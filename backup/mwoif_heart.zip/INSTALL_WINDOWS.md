# Windows install

```powershell
cd E:\xam\htdocs\mwoif_heart_v6
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python main.py doctor
```

## Import V13 session from clipboard

1. Game login ให้ถึง Lobby
2. M Woif Lab V13 -> `READ SESSION`
3. ต้องได้ `RESULT=READY`
4. กด `COPY SESSION JSON`
5. กลับ PowerShell:

```powershell
python main.py import-session B --clipboard
python main.py session-show B
```

สลับบัญชีแล้วทำ A เหมือนกัน
