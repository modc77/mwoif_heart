# V6.2 Notes

- Python only.
- Continues V6.1 established SessionStore concept.
- Adds `AuthContextStore`, not a replacement for SessionStore.
- Primary auth source is V13.1 `COPY AUTH CONTEXT JSON`.
- `friend-list` is live/read-only.
- Friend writes remain disabled.
- Heart transport remains DS and is not activated in this revision.
- No password, sessionKey, gameAccessToken, or device secret is embedded in this package.
