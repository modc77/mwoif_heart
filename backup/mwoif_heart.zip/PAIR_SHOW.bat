@echo off
python main.py pair-show
pause
