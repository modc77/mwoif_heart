# MWOIF HEART V6.1 — SIMPLE SESSION IMPORT

This revision removes clipboard sync from the normal workflow.

## B account

1. In Android Lab V13 press `COPY SESSION JSON`.
2. Open `import/session_B.json` on Windows.
3. Replace the entire file content with the copied one-line JSON and save.
4. Double-click `IMPORT_SESSION_B.bat`.

Equivalent command:

```powershell
python main.py import-session B --file import/session_B.json
```

## A account

Use `import/session_A.json` and `IMPORT_SESSION_A.bat`.

The importer also accepts a full V13 report containing a `sessionJson=` line.
Imported session secrets remain in `.state/session_A.json` / `.state/session_B.json` and normal CLI output redacts `session_key`.
