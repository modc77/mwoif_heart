MWOIF HEART V6.2 — ACCEPT LIFE MAIL

Ghidra-frozen:
- endpoint: game/acceptLifeMail4.ds
- endpoint string GH: 0x0073B69B
- builder: FUN_013D518C
- caller: FUN_01422AC0
- request fields:
    memberSeq
    lifeMailBoxSeqList

Current known A <- B pending heart:
- A memberSeq: 446648701
- B memberSeq: 953705101
- lifeMailBoxSeq: 4096132218942896394

Preview:
  python main.py heart-receive A --seq 4096132218942896394

Live claim:
  python main.py heart-receive A --seq 4096132218942896394 --live

Expected live success:
  ok=true
  http_status=200
  response_code=200
  response_message=COMPLETE

After success verify with:
  python main.py heart-mail-list A --from-slot B --live

The claimed seq should no longer appear.

Changed/new:
- main.py
- mwoif/endpoint_registry.py
- mwoif/heart_receive.py
- tests/test_heart_receive.py
- HEART_ACCEPT_LIFE_V6_2.md

DELETE: NONE
