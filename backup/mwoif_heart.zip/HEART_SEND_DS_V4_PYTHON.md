# M W O I F Heart — Python DS v4 Send

Status: encoder implemented; live path is explicit `--live` and remains guarded until the first B -> A validation.

## Frozen game route

- Endpoint: `game/sendLifeMail2.ds`
- Builder GH: `0x013D4D10`
- Request vtable GH: `0x020EC238`
- Serializer GH: `0x00F17830`
- Protocol: `isEncryptedData=4&data=...`
- Compression: FastLZ level 1 compatible stream
- Cipher: ChaCha20, counter 0
- Key GH: `0x007D2310`
- Base nonce GH: `0x007D2330`
- Nonce derivation: add `(preCipherLength & 0xFF)` to every base-nonce byte, modulo 256
- Final encoding: URL-safe Base64 with padding

The implementation uses a valid literal-only FastLZ level-1 encoder. It does not need to reproduce the game's exact match-selection; the decoder format is the same.

## Heart request

Normal UI path:

```text
fromMemberSeq = actor Session.member_seq
toMemberSeq   = target Session.member_seq
requestId     = ""
```

Common DS fields are generated from the actor Session/Auth context. `sessionKey` and `accessToken` are redacted from preview output.

## First test — no Heart is sent

For the current cooldown state, preview B -> A only:

```powershell
python main.py heart-send B A
```

Do not use `--live` until preview reports all of:

```text
ok=true
crypto_self_check=true
missing_live_fields=[]
request.fromMemberSeq=<B member_seq>
request.toMemberSeq=<A member_seq>
```

## First live test

Only after preview is reviewed:

```powershell
python main.py heart-send B A --live
```

A -> B remains on the one-hour Heart send cooldown and is not used for this test.
