MWOIF HEART V6.2 — FRIEND REMOVE

Final cycle:
B SEND HEART A        PASS
A READ MAILBOX        PASS
A RECEIVE HEART       PASS
B REMOVE FRIEND A     THIS PATCH

FriendAPI method:
  /service.api.FriendAPI/RemoveFriend

RemoveFriendRequest:
  field #1 = player_ids (repeated string)

Current B removes A:
  A MID = KMSLM6355
  expected request_hex = 0a094b4d534c4d36333535

Preview:
  python main.py friend-remove B A

Live:
  python main.py friend-remove B A --live

Verify:
  python main.py friend-list B
  python main.py friend-list A

DELETE: NONE
