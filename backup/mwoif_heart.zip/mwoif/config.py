from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class Config:
    root: Path
    raw: dict[str, Any]

    @property
    def server(self) -> dict[str, Any]:
        return self.raw["server"]

    @property
    def devplay(self) -> dict[str, Any]:
        return self.raw["devplay"]

    @property
    def game(self) -> dict[str, Any]:
        return self.raw["game"]

    def account(self, slot: str) -> dict[str, Any]:
        key = slot.upper()
        try:
            return self.raw["accounts"][key]
        except KeyError as exc:
            raise ValueError(f"unknown slot {slot!r}; expected A or B") from exc


def load_config(root: Path | None = None) -> Config:
    root = (root or Path(__file__).resolve().parents[1]).resolve()
    path = root / "config.json"
    raw = json.loads(path.read_text(encoding="utf-8"))
    return Config(root=root, raw=raw)
