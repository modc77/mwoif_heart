from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True, slots=True)
class EndpointInfo:
    action: str
    transport: str
    endpoint: str
    request_shape: str
    status: str
    evidence: str


ENDPOINTS: dict[str, EndpointInfo] = {
    "friend_list": EndpointInfo(
        "friend_list",
        "grpc",
        "/service.api.FriendAPI/ListFriends",
        "protobuf ListFriendsRequest",
        "PATH_DISCOVERED",
        "native string/service.api FriendAPI descriptor",
    ),
    "friend_add": EndpointInfo(
        "friend_add",
        "grpc",
        "/service.api.FriendAPI/SendFriendRequest",
        "protobuf SendFriendRequestRequest.player_id",
        "PATH_AND_PRIMARY_FIELD_DISCOVERED",
        "native protobuf descriptor string",
    ),
    "friend_accept": EndpointInfo(
        "friend_accept",
        "grpc",
        "/service.api.FriendAPI/HandleFriendRequest",
        "protobuf HandleFriendRequestRequest.player_id",
        "PATH_AND_PRIMARY_FIELD_DISCOVERED",
        "native protobuf descriptor string",
    ),
    "friend_remove": EndpointInfo(
        "friend_remove",
        "grpc",
        "/service.api.FriendAPI/RemoveFriend",
        "protobuf RemoveFriendRequest{field#2 player_ids: repeated string}",
        "REQUEST_SCHEMA_FROZEN_LIVE_GUARDED",
        "FriendAPI method string + generated descriptor service.api.RemoveFriendRequest.player_ids",
    ),
    "heart_send": EndpointInfo(
        "heart_send",
        "ds",
        "game/sendLifeMail2.ds",
        "ValueMap{fromMemberSeq:int64,toMemberSeq:int64,requestId:string(empty on normal UI path)}",
        "DS_V4_TRANSPORT_FROZEN_LIVE_GUARDED",
        "FUN_01464104 -> FUN_013D4D10; V13.4 envelope capture; V13.5 crypto profile",
    ),
    "heart_receive": EndpointInfo(
        "heart_receive",
        "ds",
        "game/acceptLifeMail4.ds",
        "ValueMap{memberSeq:int64,lifeMailBoxSeqList:int64[]}",
        "REQUEST_FIELDS_FROZEN_DS_V4_LIVE_GUARDED",
        "FUN_01422AC0 -> FUN_013D518C; mailbox seq from game/myMailList.ds",
    ),
}


def public_registry() -> dict[str, dict[str, str]]:
    return {name: asdict(info) for name, info in ENDPOINTS.items()}
