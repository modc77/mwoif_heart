from __future__ import annotations

import hashlib
import json
import secrets
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests


class DevPlayError(RuntimeError):
    pass


@dataclass(slots=True)
class DevPlayAuth:
    slot: str
    email: str
    mid: str
    access_token: str
    oven_access_token: str
    refresh_token: str
    device_secret: str
    fgs_id: str
    game_device_id: str
    semi_device_id: str
    raw_shape: dict[str, str]

    def public_dict(self) -> dict[str, Any]:
        return {
            "slot": self.slot,
            "email": self.email,
            "mid": self.mid,
            "access_token": "<REDACTED>" if self.access_token else "",
            "oven_access_token": "<REDACTED>" if self.oven_access_token else "",
            "refresh_token": "<REDACTED>" if self.refresh_token else "",
            "device_secret": "<REDACTED>" if self.device_secret else "",
            "fgs_id": self.fgs_id,
            "game_device_id": self.game_device_id,
            "semi_device_id": self.semi_device_id,
            "raw_shape": self.raw_shape,
        }


def _stable_hex16(seed: str) -> str:
    return hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]


def _state_path(root: Path, slot: str) -> Path:
    return root / ".state" / f"devplay_{slot}.json"


def _load_or_create_state(root: Path, slot: str, account: dict[str, Any]) -> dict[str, str]:
    path = _state_path(root, slot)
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("email") == account["email"]:
                data["fgs_id"] = str(account.get("fgs_id") or data.get("fgs_id") or "")
                data["game_device_id"] = str(
                    account.get("game_device_id") or data.get("game_device_id") or ""
                )
                path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
                return {str(k): str(v) for k, v in data.items()}
        except Exception:
            pass

    email = str(account["email"])
    data = {
        "email": email,
        "devplay_device_id": str(uuid.uuid4()),
        "game_device_id": str(account.get("game_device_id") or _stable_hex16(f"{email}:game")),
        "fgs_id": str(account.get("fgs_id") or uuid.uuid4()),
        "anonymous_id": str(uuid.uuid4()),
        "app_installed_id": str(uuid.uuid4()),
        "devsisters_id": str(uuid.uuid4()),
        "semi_device_id": secrets.token_hex(8),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def _headers(cfg) -> dict[str, str]:
    d = cfg.devplay
    return {
        "Accept": "application/json, text/plain, */*",
        "Referer": "https://app.devplay.com/",
        "X-Bundle-Id": str(d["bundle_id"]),
        "X-API-Key": str(d["api_key"]),
        "Authorization": "Bearer",
        "Content-Type": "application/json",
    }


def _lc(cfg, state: dict[str, str]) -> dict[str, Any]:
    d, g = cfg.devplay, cfg.game
    osv = str(d.get("os_version") or "12")
    return {
        "app_build": str(g["build_version"]),
        "app_version": str(g["version"]),
        "locale_on_game": str(d.get("locale_on_game") or "en"),
        "location_country": str(d.get("location_country") or "LA"),
        "os_name": "android",
        "os_version": osv,
        "platform": ["email"],
        "timezone": str(d.get("timezone") or "Asia/Vientiane"),
        "fgs_id": state["fgs_id"],
        "new_fgs_id": "",
        "library_version": str(d.get("library_version") or "0.3.3-rc25"),
        "library_name": str(d.get("library_name") or "DevPlay Cocos SDK"),
        "anonymous_id": state["anonymous_id"],
        "app_installed_id": state["app_installed_id"],
        "devsisters_id": state["devsisters_id"],
        "semi_device_id": state["semi_device_id"],
        "store": "playstore",
        "device": {
            "traits": [""],
            "manufacturer": str(d.get("manufacturer") or "Samsung"),
            "model": str(d.get("model") or "SM-A156E"),
            "version": f"Android OS {osv}",
        },
    }


def _post_json(http, url: str, headers: dict[str, str], body: dict[str, Any], timeout: float, verify: bool) -> dict[str, Any]:
    try:
        response = http.post(url, headers=headers, json=body, timeout=timeout, verify=verify)
    except requests.RequestException as exc:
        raise DevPlayError(f"request failed: {type(exc).__name__}: {exc}") from exc
    if response.status_code != 200:
        raise DevPlayError(f"HTTP {response.status_code}: {response.text[:300]}")
    try:
        data = response.json()
    except ValueError as exc:
        raise DevPlayError(f"non-JSON response: {response.text[:300]!r}") from exc
    if not isinstance(data, dict):
        raise DevPlayError("DevPlay response root is not an object")
    return data


def login(*, cfg, slot: str, password: str, http: requests.Session | None = None) -> DevPlayAuth:
    slot = slot.upper()
    account = cfg.account(slot)
    if not password:
        raise DevPlayError("password is empty; run setup-secrets")

    state = _load_or_create_state(cfg.root, slot, account)
    http = http or requests.Session()
    base = str(cfg.server["devplay_base_url"]).rstrip("/")
    timeout = float(cfg.server.get("timeout_seconds", 20))
    verify = bool(cfg.server.get("verify_ssl", True))
    headers = _headers(cfg)
    lc = _lc(cfg, state)

    _post_json(
        http,
        f"{base}/v4/checkemail",
        headers,
        {"email": account["email"], "lc": lc},
        timeout,
        verify,
    )

    now = int(time.time())
    body = {
        "device_type": "android",
        "device_id": state["devplay_device_id"],
        "push_token": "",
        "user_token": "",
        "lang": "en",
        "timezone": str(cfg.devplay.get("timezone") or "Asia/Vientiane"),
        "recall_session_id": "",
        "oven_access_token": "",
        "email": account["email"],
        "password": password,
        "use_terms_v2": True,
        "terms_updates": [
            {"id": 28, "is_agreed": True, "agree_dt": now},
            {"id": 30, "is_agreed": True, "agree_dt": now},
            {"id": 32, "is_agreed": True, "agree_dt": now},
        ],
        "agree_ad_day_push": "true",
        "agree_ad_night_push": "true",
        "lc": lc,
    }
    data = _post_json(
        http,
        f"{base}/v3/login/devsisters",
        headers,
        body,
        timeout,
        verify,
    )

    code = data.get("code")
    if code is not None and int(code) != 20000:
        message = data.get("message") or data.get("error") or data.get("error_message") or "rejected"
        raise DevPlayError(f"DevPlay code={code}: {message}")

    member = data.get("member") if isinstance(data.get("member"), dict) else {}
    mid = str(member.get("mid") or "")
    access = str(data.get("game_access_token") or "")
    if not mid or not access:
        raise DevPlayError("login response missing member.mid or game_access_token")

    return DevPlayAuth(
        slot=slot,
        email=str(account["email"]),
        mid=mid,
        access_token=access,
        oven_access_token=str(data.get("oven_access_token") or ""),
        refresh_token=str(data.get("refresh_token") or ""),
        device_secret=str(data.get("device_secret") or ""),
        fgs_id=state["fgs_id"],
        game_device_id=state["game_device_id"],
        semi_device_id=state["semi_device_id"],
        raw_shape={k: type(v).__name__ for k, v in data.items()},
    )
