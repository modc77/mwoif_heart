from __future__ import annotations

import json
from pathlib import Path


class SecretsStore:
    def __init__(self, root: Path):
        self.path = root / ".state" / "secrets.local.json"

    def load(self) -> dict[str, str]:
        if not self.path.is_file():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {}
        return {str(k): str(v) for k, v in data.items()}

    def save(self, values: dict[str, str]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(values, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def get_password(self, slot: str) -> str:
        return self.load().get(f"account_{slot.upper()}_password", "")
