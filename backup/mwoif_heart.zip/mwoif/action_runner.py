from __future__ import annotations

from typing import Any

from .endpoint_registry import ENDPOINTS


class ActionNotWired(RuntimeError):
    pass


def dry_run(action: str, actor: str, target: str, actor_session, target_session) -> dict[str, Any]:
    info = ENDPOINTS[action]
    return {
        "ok": True,
        "dry_run": True,
        "action": action,
        "actor": actor,
        "target": target,
        "endpoint": info.endpoint,
        "transport": info.transport,
        "request_shape": info.request_shape,
        "endpoint_status": info.status,
        "actor_session_established": bool(actor_session and actor_session.established),
        "target_session_established": bool(target_session and target_session.established),
        "network_action_enabled": False,
        "next": "TRACE_NATIVE_TRANSPORT_AND_REQUEST_FIELDS",
    }
