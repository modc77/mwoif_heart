from __future__ import annotations


def get_clipboard_text() -> str:
    try:
        import tkinter as tk

        root = tk.Tk()
        root.withdraw()
        try:
            return str(root.clipboard_get())
        finally:
            root.destroy()
    except Exception as exc:
        raise RuntimeError(
            "cannot read clipboard; use --file instead or run in a desktop Windows session"
        ) from exc
