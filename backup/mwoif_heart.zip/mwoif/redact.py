from __future__ import annotations

from typing import Any

SECRET_KEYS = {
    "password",
    "access_token",
    "game_access_token",
    "oven_access_token",
    "refresh_token",
    "device_secret",
    "session_key",
    "push_token",
}


def redact(value: Any, key: str | None = None) -> Any:
    if key and key.lower() in SECRET_KEYS:
        return "<REDACTED>" if value else ""
    if isinstance(value, dict):
        return {k: redact(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v) for v in value]
    return value
