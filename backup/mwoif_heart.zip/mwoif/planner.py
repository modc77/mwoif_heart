from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .endpoint_registry import ENDPOINTS


@dataclass(frozen=True, slots=True)
class PlanStep:
    order: int
    action: str
    actor: str
    target: str
    endpoint: str
    transport: str
    implementation: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "order": self.order,
            "action": self.action,
            "actor": self.actor,
            "target": self.target,
            "endpoint": self.endpoint,
            "transport": self.transport,
            "implementation": self.implementation,
        }


def build_plan(sender: str, receiver: str, *, include_receive: bool = False) -> list[PlanStep]:
    sender, receiver = sender.upper(), receiver.upper()
    actions = [
        ("friend_add", sender, receiver),
        ("friend_accept", receiver, sender),
        ("heart_send", sender, receiver),
    ]
    if include_receive:
        actions.append(("heart_receive", receiver, sender))
    actions.append(("friend_remove", sender, receiver))

    out: list[PlanStep] = []
    for i, (action, actor, target) in enumerate(actions, 1):
        ep = ENDPOINTS[action]
        out.append(
            PlanStep(
                order=i,
                action=action,
                actor=actor,
                target=target,
                endpoint=ep.endpoint,
                transport=ep.transport,
                implementation="DISCOVERY_ONLY_NOT_WIRED",
            )
        )
    return out
