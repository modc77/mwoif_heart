from mwoif.friend_proto import build_remove_friend_request


def test_single():
    body = build_remove_friend_request(["KMSLM6355"])
    assert body.hex() == "12094b4d534c4d36333535"


def test_repeated():
    body = build_remove_friend_request(["AAA", "BBB"])
    assert body.hex() == "12034141411203424242"


if __name__ == "__main__":
    test_single()
    test_repeated()
    print("PASS")
