from datetime import datetime, timezone
from types import SimpleNamespace

from mwoif.auth_store import AuthRecord
from mwoif.heart_receive import (
    ACCEPT_LIFE_MAIL_ENDPOINT,
    build_accept_life_payload,
    build_heart_receive_request,
)
from mwoif.session_store import SessionRecord


def _session():
    return SessionRecord(
        schema="mwoif-session-cache-v1",
        slot="A",
        member_seq=446648701,
        current_lv=1,
        session_key="S" * 64,
        source="established_game_state",
        imported_at=datetime.now(timezone.utc).isoformat(),
    )


def _auth():
    return AuthRecord(
        schema="mwoif-auth-cache-v1",
        slot="A",
        mid="KMSLM6355",
        game_access_token="T" * 247,
        fgs_id="8dc7e612-cbad-4e9d-82f8-c577672a1180",
        device_id="ffa0229d7ac5e676",
        source="game_owned_materializer",
        metadata={
            "version": "26.8.02",
            "version-code": "651",
            "timezone": "Asia/Bangkok",
            "country": "US",
            "os.type": "A",
            "os_version": "12",
            "market_type": "GOOGLE_PLAY",
            "locale": "en-US",
            "device-id": "ffa0229d7ac5e676",
            "device-name": "SM-A156E",
            "device-model": "SM-A156E",
            "fgs-id": "8dc7e612-cbad-4e9d-82f8-c577672a1180",
            "game-process-elapsed-ms": "281903",
            "time-zone-distance": "25200",
        },
        imported_at=datetime.now(timezone.utc).isoformat(),
    )


def _cfg():
    return SimpleNamespace(
        devplay={
            "timezone": "Asia/Bangkok",
            "location_country": "US",
            "os_version": "12",
            "model": "SM-A156E",
        },
        game={
            "version": "26.8.02",
            "build_version": "651",
        },
        server={
            "game_base_url": "https://server.live.prod.devsnova.cloud/",
            "verify_ssl": True,
        },
    )


def test_request():
    req = build_heart_receive_request(
        _session(),
        [4096132218942896394],
    )
    assert req.member_seq == 446648701
    assert req.life_mail_box_seq_list == (
        4096132218942896394,
    )


def test_payload():
    req, payload, missing, _ = build_accept_life_payload(
        cfg=_cfg(),
        actor_session=_session(),
        actor_auth=_auth(),
        life_mail_box_seqs=[4096132218942896394],
        cable="A" * 20,
    )
    assert req.member_seq == 446648701
    assert payload["memberSeq"] == 446648701
    assert payload["lifeMailBoxSeqList"] == [
        4096132218942896394
    ]
    assert payload["pid"] == ACCEPT_LIFE_MAIL_ENDPOINT
    assert payload["timeZoneDistance"] == 25200
    assert payload["fgsId"]
    assert missing == {}


if __name__ == "__main__":
    test_request()
    test_payload()
    print("PASS")
