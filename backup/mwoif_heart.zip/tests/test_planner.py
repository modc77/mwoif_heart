import unittest

from mwoif.planner import build_plan


class PlannerTests(unittest.TestCase):
    def test_send_only_plan(self):
        plan = build_plan("A", "B")
        self.assertEqual(
            [x.action for x in plan],
            ["friend_add", "friend_accept", "heart_send", "friend_remove"],
        )
        self.assertEqual(plan[1].actor, "B")

    def test_full_plan(self):
        plan = build_plan("B", "A", include_receive=True)
        self.assertEqual(
            [x.action for x in plan],
            ["friend_add", "friend_accept", "heart_send", "heart_receive", "friend_remove"],
        )


if __name__ == "__main__":
    unittest.main()
