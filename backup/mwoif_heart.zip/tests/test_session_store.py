import tempfile
import unittest
from pathlib import Path

from mwoif.session_store import SessionStore


class SessionStoreTests(unittest.TestCase):
    def test_import_v13(self):
        with tempfile.TemporaryDirectory() as td:
            store = SessionStore(Path(td))
            account = {"email": "b@example.test", "mid_expected": "MIDB"}
            record = store.import_v13(
                slot="B",
                account=account,
                raw='{"schema":"mwoif-session-v13","member_seq":123,"current_lv":7,"session_key":"abc","source":"established_game_state"}',
            )
            self.assertTrue(record.established)
            self.assertEqual(record.member_seq, 123)
            self.assertEqual(record.public_dict()["session_key"], "<REDACTED>")


if __name__ == "__main__":
    unittest.main()
