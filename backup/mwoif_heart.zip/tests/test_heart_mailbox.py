from mwoif.heart_mailbox import extract_life_mail_items


def test_extract_sender_and_latest():
    payload = {
        "mailList": [
            {"seq": 1001, "fromMemberSeq": 953705101, "insertDt": 100.0},
            {"seq": 1002, "fromMemberSeq": 111, "insertDt": 200.0},
            {"seq": 1003, "fromMemberSeq": 953705101, "insertDt": 300.0},
        ]
    }

    rows = extract_life_mail_items(
        payload,
        from_member_seq=953705101,
    )
    assert [x["seq"] for x in rows] == [1003, 1001]


if __name__ == "__main__":
    test_extract_sender_and_latest()
    print("PASS")
