import unittest

from mwoif.endpoint_registry import ENDPOINTS


class RegistryTests(unittest.TestCase):
    def test_discovery_map(self):
        self.assertTrue(ENDPOINTS["friend_add"].endpoint.endswith("/SendFriendRequest"))
        self.assertTrue(ENDPOINTS["friend_accept"].request_shape.endswith("player_id"))
        self.assertTrue(ENDPOINTS["friend_remove"].request_shape.endswith("player_ids"))
        self.assertEqual(ENDPOINTS["heart_send"].endpoint, "game/sendLifeMail2.ds")
        self.assertEqual(ENDPOINTS["heart_receive"].endpoint, "game/acceptLifeMail4.ds")


if __name__ == "__main__":
    unittest.main()
