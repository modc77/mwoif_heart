import tempfile
import unittest
from pathlib import Path

from mwoif.session_store import SessionStore


class EasySessionImportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.account = {"email":"b@example.test","mid_expected":"MIDB"}

    def tearDown(self):
        self.tmp.cleanup()

    def test_direct_json(self):
        raw='{"schema":"mwoif-session-v13","member_seq":123,"current_lv":7,"session_key":"abc","source":"established_game_state"}'
        rec=SessionStore(self.root).import_v13(slot="B", account=self.account, raw=raw)
        self.assertTrue(rec.established)
        self.assertEqual(rec.member_seq,123)

    def test_full_report_sessionjson_line(self):
        raw='MWOIF_SESSION_STATE_V13\\nRESULT=READY\\nsessionJson={"schema":"mwoif-session-v13","member_seq":456,"current_lv":8,"session_key":"xyz","source":"established_game_state"}\\n'
        rec=SessionStore(self.root).import_v13(slot="B", account=self.account, raw=raw)
        self.assertEqual(rec.member_seq,456)

    def test_placeholder_rejected(self):
        with self.assertRaisesRegex(Exception, "placeholder"):
            SessionStore(self.root).import_v13(slot="B", account=self.account, raw="PASTE_V13_SESSION_JSON_HERE")


if __name__ == '__main__':
    unittest.main()
