import tempfile
import unittest
from pathlib import Path

from mwoif.auth_store import AuthStore


class AuthStoreTests(unittest.TestCase):
    def test_import_auth(self):
        with tempfile.TemporaryDirectory() as td:
            store = AuthStore(Path(td))
            account = {"email":"x@example.test","mid_expected":"MID1"}
            rec = store.import_v13_1(
                slot="A",
                account=account,
                raw='{"schema":"mwoif-auth-v13.1","mid":"MID1","game_access_token":"tok","source":"game_owned_materializer"}',
            )
            self.assertTrue(rec.ready)
            self.assertEqual(rec.public_dict()["game_access_token"], "PRESENT(len=3)")

    def test_wrong_mid_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            store = AuthStore(Path(td))
            account = {"email":"x@example.test","mid_expected":"MID1"}
            with self.assertRaisesRegex(Exception, "MID mismatch"):
                store.import_v13_1(
                    slot="A",
                    account=account,
                    raw='{"schema":"mwoif-auth-v13.1","mid":"MID2","game_access_token":"tok"}',
                )


if __name__ == "__main__":
    unittest.main()
