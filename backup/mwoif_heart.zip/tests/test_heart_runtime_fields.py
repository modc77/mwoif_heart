from datetime import datetime, timezone
from types import SimpleNamespace
from mwoif.auth_store import AuthRecord
from mwoif.heart_ds import build_common_ds_payload
from mwoif.session_store import SessionRecord

cfg=SimpleNamespace(devplay={"timezone":"Asia/Bangkok","location_country":"US","os_version":"12","model":"SM-A156E"},game={"version":"26.8.02","build_version":"651"},server={})
now=datetime.now(timezone.utc).isoformat()
auth=AuthRecord(schema="mwoif-auth-cache-v1",slot="B",mid="WSVXV3143",game_access_token="T"*247,fgs_id="FGS-REAL",device_id="ffa0229d7ac5e676",source="game_owned_materializer",metadata={"version":"26.8.02","version-code":"651","timezone":"Asia/Bangkok","country":"US","os.type":"A","os_version":"12","market_type":"GOOGLE_PLAY","locale":"en-US","device-id":"ffa0229d7ac5e676","device-name":"SM-A156E","device-model":"SM-A156E","fgs-id":"FGS-REAL","game-process-elapsed-ms":"200640","time-zone-distance":"25200"},imported_at=now)
actor=SessionRecord(schema="mwoif-session-cache-v1",slot="B",member_seq=953705101,current_lv=1,session_key="S"*64,source="established_game_state",imported_at=now)
target=SessionRecord(schema="mwoif-session-cache-v1",slot="A",member_seq=446648701,current_lv=1,session_key="X"*64,source="established_game_state",imported_at=now)
payload,missing,sources=build_common_ds_payload(cfg=cfg,actor_session=actor,target_session=target,actor_auth=auth,cable="A"*20)
assert payload["fromMemberSeq"]==953705101
assert payload["toMemberSeq"]==446648701
assert payload["fgsId"]=="FGS-REAL"
assert payload["timeZoneDistance"]==25200
assert payload["ms"]>=200640
assert missing=={}
assert sources["fgsId"]=="AUTH_METADATA"
print("PASS")
