MWOIF HEART V6.2 — MAILBOX LIST / lifeMailBoxSeq discovery

Ghidra-frozen route:
- endpoint: game/myMailList.ds
- endpoint string GH: 0x007BC9F2
- request builder: FUN_01624E58
- response dispatch: FUN_013D0CA4
- mailList parser: FUN_013D3530
- life mail item parser: FUN_013BDB34

FUN_013BDB34 reads normal life-mail item fields:
- insertDt
- fromMemberSeq
- seq

Python command:
  python main.py heart-mail-list A --from-slot B
  python main.py heart-mail-list A --from-slot B --live

The --live request only reads the mailbox list. It does NOT call Claim and
does NOT call game/acceptLifeMail4.ds.

On success:
  life_mail_candidates = [...]
  suggested_life_mail_seq = <latest seq from B>

Do not Claim in the game until acceptLifeMail4.ds is implemented/tested.

Changed/new:
- main.py                         MODIFY
- mwoif/ds_v4.py                 MODIFY
- mwoif/heart_mailbox.py         ADD
- tests/test_heart_mailbox.py    ADD
- HEART_MAIL_LIST_V6_2.md        ADD

DELETE: NONE
