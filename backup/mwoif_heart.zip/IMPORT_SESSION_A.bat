@echo off
setlocal
cd /d "%~dp0"
python main.py import-session A --file import\session_A.json
if errorlevel 1 (
  echo.
  echo Import A failed. Paste the V13 Session JSON into import\session_A.json and save it.
)
pause
