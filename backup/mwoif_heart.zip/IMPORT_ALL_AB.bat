﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title M WOIF - Import A+B Session/Auth

echo ============================================================
echo  M WOIF - IMPORT ALL A+B
echo ============================================================
echo.

REM Prefer project virtualenv Python without requiring manual activation.
if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

REM Validate required import files first.
set "MISSING=0"

for %%F in (
    "import\session_A.json"
    "import\auth_A.json"
    "import\session_B.json"
    "import\auth_B.json"
) do (
    if not exist "%%~F" (
        echo [MISSING] %%~F
        set "MISSING=1"
    )
)

if "%MISSING%"=="1" (
    echo.
    echo [ERROR] Required import file is missing.
    echo Put all 4 JSON files inside the import folder and run again.
    echo.
    pause
    exit /b 1
)

echo [1/4] Import Session A...
"%PY%" main.py import-session A --file "import\session_A.json"
if errorlevel 1 goto :failed

echo.
echo [2/4] Import Auth A...
"%PY%" main.py import-auth A --file "import\auth_A.json"
if errorlevel 1 goto :failed

echo.
echo [3/4] Import Session B...
"%PY%" main.py import-session B --file "import\session_B.json"
if errorlevel 1 goto :failed

echo.
echo [4/4] Import Auth B...
"%PY%" main.py import-auth B --file "import\auth_B.json"
if errorlevel 1 goto :failed

echo.
echo ============================================================
echo  IMPORT COMPLETE
echo ============================================================
echo.
echo [PAIR STATUS]
"%PY%" main.py pair-show

echo.
echo Done.
pause
exit /b 0

:failed
echo.
echo ============================================================
echo  IMPORT FAILED
echo ============================================================
echo One of the import commands returned an error.
echo Fix the JSON for the failed step and run this BAT again.
echo.
pause
exit /b 1
