MWOIF HEART V6.2 — FRIEND REMOVE FIELD #2 FIX

Why the previous live request failed
------------------------------------
Previous request:
  0a 09 "KMSLM6355"

That encoded player_ids as protobuf field #1.

Ghidra comparison with the game's generated Friend protobuf classes shows
field #1 is the optional common/request message slot, while player_ids is
field #2.

Evidence:
- SendFriendRequest serializer FUN_016F3160:
    field #1 = optional nested/common message
    field #2 = player_id
    field #3 = type
- HandleFriendRequest serializer FUN_016F39D0:
    field #1 = optional nested/common message
    field #2 = player_id
    field #3 = accepted
- RemoveFriendRequest class layout:
    FUN_016F51A0 / FUN_016F5298 / FUN_016F54A8
  matches the repeated-player-id request layout with the optional field #1
  message at +0x30 and repeated strings at +0x18.

Correct RemoveFriendRequest:
  field #2 = player_ids (repeated string)

B removes A (A MID KMSLM6355):
  expected request_hex:
  12094b4d534c4d36333535

Preview:
  python main.py friend-remove B A

Live:
  python main.py friend-remove B A --live

Verify:
  python main.py friend-list B
  python main.py friend-list A

Changed:
- mwoif/friend_proto.py
- mwoif/friend_grpc.py
- mwoif/endpoint_registry.py
- tests/test_friend_remove.py

DELETE: NONE
