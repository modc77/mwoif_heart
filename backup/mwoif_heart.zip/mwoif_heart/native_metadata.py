from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence, Tuple

# Native order observed in FUN_00eb97fc.
NATIVE_METADATA_ORDER = [
    "authorization",
    "player-id",
    "combo-name",
    "index-file-hash",
    "version",
    "version-code",
    "timezone",
    "country",
    "os.type",
    "os_version",
    "login_platform",
    "market_type",
    "fgs-id",
    "locale",
    "device-id",
    "device-name",
    "device-model",
]

# These are static/reference values already recovered for build 26.8.02.
# Dynamic account/device values override them.
DEFAULTS = {
    "version": "26.8.02",
    "version-code": "651",
    "timezone": "Asia/Bangkok",
    "country": "US",
    "os.type": "A",
    "os_version": "12",
    "market_type": "GOOGLE_PLAY",
    "locale": "en-US",
    "device-name": "SM-A156E",
    "device-model": "SM-A156E",
}

ALIASES = {
    "player_id": "player-id",
    "player-id": "player-id",
    "mid": "player-id",
    "fgs_id": "fgs-id",
    "fgs-id": "fgs-id",
    "device_id": "device-id",
    "device-id": "device-id",
    "device_name": "device-name",
    "device-name": "device-name",
    "device_model": "device-model",
    "device-model": "device-model",
    "index_file_hash": "index-file-hash",
    "index-file-hash": "index-file-hash",
    "combo_name": "combo-name",
    "combo-name": "combo-name",
    "login_platform": "login_platform",
    "market_type": "market_type",
    "version_code": "version-code",
    "os_type": "os.type",
    "os_version": "os_version",
}


def _merge_named(dst: Dict[str, str], src: Mapping[str, Any]) -> None:
    for raw_k, raw_v in src.items():
        if raw_v is None:
            continue
        k = ALIASES.get(str(raw_k), str(raw_k).lower())
        if k in NATIVE_METADATA_ORDER and k not in ("authorization",):
            dst[k] = str(raw_v)


def build_native_metadata(
    auth: Mapping[str, Any],
    session: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> Tuple[List[Tuple[str, str]], List[str]]:
    """
    Build gRPC metadata in native order.

    IMPORTANT:
    authorization is ALWAYS Bearer <game_access_token>.
    session_key is intentionally ignored as an auth source.
    """
    token = str(auth.get("game_access_token") or auth.get("gameAccessToken") or "").strip()
    mid = str(auth.get("mid") or auth.get("player_id") or "").strip()

    if not token or token == "****":
        raise ValueError("real game_access_token is required; sessionKey is not a Bearer token")
    if not mid:
        raise ValueError("mid/player-id is required")

    values: Dict[str, str] = dict(DEFAULTS)
    values["authorization"] = "Bearer " + token
    values["player-id"] = mid

    _merge_named(values, auth)

    meta_obj = auth.get("metadata")
    if isinstance(meta_obj, Mapping):
        _merge_named(values, meta_obj)

    if session:
        _merge_named(values, session)

    if extra:
        _merge_named(values, extra)

    env = os.getenv("MWOIF_GRPC_METADATA_JSON", "").strip()
    if env:
        parsed = json.loads(env)
        if not isinstance(parsed, Mapping):
            raise ValueError("MWOIF_GRPC_METADATA_JSON must be a JSON object")
        _merge_named(values, parsed)

    metadata: List[Tuple[str, str]] = []
    for key in NATIVE_METADATA_ORDER:
        value = values.get(key)
        if value not in (None, ""):
            metadata.append((key, str(value)))

    # Native builder contains these keys, but they can be dynamic and may not
    # exist in the exported V13.1 minimum auth JSON.
    missing = [
        key for key in ("combo-name", "index-file-hash", "login_platform")
        if not values.get(key)
    ]
    return metadata, missing


def redacted_metadata(metadata: Sequence[Tuple[str, str]]) -> List[Tuple[str, str]]:
    out = []
    for k, v in metadata:
        if k == "authorization":
            token_len = max(0, len(v) - len("Bearer "))
            out.append((k, f"Bearer <REDACTED len={token_len}>"))
        else:
            out.append((k, v))
    return out
