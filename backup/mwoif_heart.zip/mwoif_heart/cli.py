from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Mapping

from . import __version__
from .stores import SessionStore, AuthContextStore, redact_auth, redact_session
from .friend_grpc import friend_list, FRIEND_ENDPOINTS, GRPC_HOST

session_store = SessionStore()
auth_store = AuthContextStore()


def dump(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def load_extra_metadata(path: str) -> Dict[str, Any]:
    if not path:
        return {}
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("metadata file must be JSON object")
    return data


def parse_hex(value: str) -> bytes:
    cleaned = "".join(c for c in value if c in "0123456789abcdefABCDEF")
    if len(cleaned) % 2:
        raise ValueError("request hex length must be even")
    return bytes.fromhex(cleaned)


def cmd_doctor(_: argparse.Namespace) -> None:
    try:
        import grpc  # noqa
        grpc_ok = True
    except Exception:
        grpc_ok = False
    dump({
        "ok": True,
        "version": __version__,
        "grpcio": grpc_ok,
        "grpc_host": GRPC_HOST,
        "state_dir": str(Path(os.getenv("MWOIF_HEART_STATE_DIR", ".state"))),
        "friend_write_enabled": False,
        "heart_write_enabled": False,
    })


def cmd_import_session(args: argparse.Namespace) -> None:
    data = session_store.import_file(args.slot, Path(args.file))
    dump({
        "ok": True,
        "action": "import-session",
        "slot": args.slot.upper(),
        "established": bool(data.get("established")),
        "member_seq": data.get("member_seq"),
        "current_lv": data.get("current_lv"),
        "session_key": (
            f"PRESENT(len={len(str(data.get('session_key')))})"
            if data.get("session_key") else "MISSING"
        ),
        "source": data.get("source"),
    })


def cmd_session_show(args: argparse.Namespace) -> None:
    slots = [args.slot.upper()] if args.slot else list(session_store.existing_slots())
    dump({
        "version": __version__,
        "sessions": {
            slot: redact_session(session_store.load(slot))
            for slot in slots
        }
    })


def cmd_import_auth(args: argparse.Namespace) -> None:
    data = auth_store.import_file(args.slot, Path(args.file))
    token = str(data.get("game_access_token") or "")
    dump({
        "ok": True,
        "action": "import-auth",
        "slot": args.slot.upper(),
        "schema": data.get("schema"),
        "mid": data.get("mid"),
        "game_access_token": f"PRESENT(len={len(token)})",
        "fgs_id": data.get("fgs_id"),
        "device_id": data.get("device_id"),
        "source": data.get("source"),
    })


def cmd_auth_show(args: argparse.Namespace) -> None:
    slots = [args.slot.upper()] if args.slot else list(auth_store.existing_slots())
    dump({
        "version": __version__,
        "auth_contexts": {
            slot: redact_auth(auth_store.load(slot))
            for slot in slots
        }
    })


def cmd_endpoints(_: argparse.Namespace) -> None:
    dump({
        "version": __version__,
        "friend": {
            "host": GRPC_HOST,
            "transport": "gRPC/TLS",
            "methods": FRIEND_ENDPOINTS,
        },
        "heart": {
            "transport": "legacy DS",
            "send": "game/sendLifeMail2.ds",
            "receive": "game/acceptLifeMail4.ds",
        },
        "auth_rule": "authorization = Bearer <game_access_token>; player-id = MID",
        "friend_write_enabled": False,
        "heart_write_enabled": False,
    })


def cmd_friend_list(args: argparse.Namespace) -> None:
    slot = args.slot.upper()
    auth = auth_store.load(slot)
    try:
        session = session_store.load(slot)
    except FileNotFoundError:
        session = None

    body = b""
    source = "empty"
    if args.request_hex:
        body = parse_hex(args.request_hex)
        source = "--request-hex"
    else:
        raw_hex = auth.get("friend_list_request_hex")
        if isinstance(raw_hex, str) and raw_hex.strip():
            body = parse_hex(raw_hex)
            source = "auth.friend_list_request_hex"

    extra = load_extra_metadata(args.metadata_file)
    result = friend_list(
        auth=auth,
        session=session,
        request_body=body,
        extra_metadata=extra,
        timeout=args.timeout,
    )
    result["slot"] = slot
    result["request_source"] = source
    dump(result)


def _dry_write(action: str, actor: str, target: str | None) -> None:
    actor_auth = auth_store.load(actor)
    target_mid = None
    if target:
        target_auth = auth_store.load(target)
        target_mid = target_auth.get("mid")

    route = {
        "friend-add": FRIEND_ENDPOINTS["add"],
        "friend-accept": FRIEND_ENDPOINTS["accept"],
        "friend-remove": FRIEND_ENDPOINTS["remove"],
        "heart-send": "game/sendLifeMail2.ds",
        "heart-receive": "game/acceptLifeMail4.ds",
    }[action]

    dump({
        "ok": True,
        "dry_run": True,
        "network_action_enabled": False,
        "action": action,
        "actor_slot": actor,
        "actor_mid": actor_auth.get("mid"),
        "target_slot": target,
        "target_mid": target_mid,
        "route": route,
        "reason": (
            "Friend write remains locked until friend-list passes and Add/Accept field #3 is frozen"
            if action.startswith("friend-")
            else "Heart write remains locked until mailbox/common DS wrapper is frozen"
        ),
    })


def cmd_friend_add(args: argparse.Namespace) -> None:
    _dry_write("friend-add", args.actor.upper(), args.target.upper())


def cmd_friend_accept(args: argparse.Namespace) -> None:
    _dry_write("friend-accept", args.actor.upper(), args.target.upper())


def cmd_friend_remove(args: argparse.Namespace) -> None:
    _dry_write("friend-remove", args.actor.upper(), args.target.upper())


def cmd_heart_send(args: argparse.Namespace) -> None:
    _dry_write("heart-send", args.actor.upper(), args.target.upper())


def cmd_heart_receive(args: argparse.Namespace) -> None:
    _dry_write("heart-receive", args.actor.upper(), None)


def cmd_plan(args: argparse.Namespace) -> None:
    dump({
        "ok": True,
        "version": __version__,
        "actor": args.actor.upper(),
        "target": args.target.upper(),
        "sequence": [
            "friend-list actor (READ ONLY)",
            "friend-add actor target (LOCKED/DRY-RUN)",
            "friend-accept target actor (LOCKED/DRY-RUN)",
            "heart-send actor target (LOCKED/DRY-RUN)",
            "heart-receive target (LOCKED/DRY-RUN)",
            "friend-remove actor target (LOCKED/DRY-RUN)",
        ],
    })


def cmd_login(_: argparse.Namespace) -> None:
    dump({
        "ok": False,
        "action": "login",
        "message": "V6.2 keeps V6.1 established-session import as the primary route. DevPlay login remains optional/legacy and is not used for friend-list.",
    })


def cmd_setup_secrets(_: argparse.Namespace) -> None:
    dump({
        "ok": True,
        "action": "setup-secrets",
        "message": "No token/sessionKey is written to public logs. Use import-session/import-auth and keep .state local.",
    })


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="main.py", description="MWOIF Heart V6.2 Friend gRPC")
    sp = p.add_subparsers(dest="cmd", required=True)

    q = sp.add_parser("doctor")
    q.set_defaults(func=cmd_doctor)

    q = sp.add_parser("setup-secrets")
    q.set_defaults(func=cmd_setup_secrets)

    q = sp.add_parser("login")
    q.set_defaults(func=cmd_login)

    q = sp.add_parser("import-session")
    q.add_argument("slot")
    q.add_argument("--file", required=True)
    q.set_defaults(func=cmd_import_session)

    q = sp.add_parser("session-show")
    q.add_argument("slot", nargs="?")
    q.set_defaults(func=cmd_session_show)

    q = sp.add_parser("import-auth")
    q.add_argument("slot")
    q.add_argument("--file", required=True)
    q.set_defaults(func=cmd_import_auth)

    q = sp.add_parser("auth-show")
    q.add_argument("slot", nargs="?")
    q.set_defaults(func=cmd_auth_show)

    q = sp.add_parser("endpoints")
    q.set_defaults(func=cmd_endpoints)

    q = sp.add_parser("plan")
    q.add_argument("actor")
    q.add_argument("target")
    q.set_defaults(func=cmd_plan)

    q = sp.add_parser("friend-list")
    q.add_argument("slot")
    q.add_argument("--timeout", type=float, default=12.0)
    q.add_argument("--request-hex", default="")
    q.add_argument("--metadata-file", default="")
    q.set_defaults(func=cmd_friend_list)

    for name, func in (
        ("friend-add", cmd_friend_add),
        ("friend-accept", cmd_friend_accept),
        ("friend-remove", cmd_friend_remove),
        ("heart-send", cmd_heart_send),
    ):
        q = sp.add_parser(name)
        q.add_argument("actor")
        q.add_argument("target")
        q.set_defaults(func=func)

    q = sp.add_parser("heart-receive")
    q.add_argument("actor")
    q.set_defaults(func=cmd_heart_receive)

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as exc:
        dump({
            "ok": False,
            "error": type(exc).__name__,
            "message": str(exc),
        })
        raise SystemExit(2)
