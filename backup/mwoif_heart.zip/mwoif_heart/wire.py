from __future__ import annotations

from typing import Any, Dict, List, Tuple


class WireError(ValueError):
    pass


def _varint(buf: bytes, pos: int) -> Tuple[int, int]:
    value = 0
    shift = 0
    while pos < len(buf):
        b = buf[pos]
        pos += 1
        value |= (b & 0x7F) << shift
        if not (b & 0x80):
            return value, pos
        shift += 7
        if shift > 70:
            raise WireError("varint too long")
    raise WireError("truncated varint")


def inspect_message(buf: bytes, max_fields: int = 256) -> List[Dict[str, Any]]:
    """
    Generic protobuf wire inspector. It does not invent field names.
    Useful until ListFriendsResponse descriptor mapping is frozen.
    """
    pos = 0
    out: List[Dict[str, Any]] = []
    while pos < len(buf) and len(out) < max_fields:
        tag, pos = _varint(buf, pos)
        field = tag >> 3
        wt = tag & 7
        item: Dict[str, Any] = {"field": field, "wire_type": wt}

        if field == 0:
            raise WireError("field number 0")

        if wt == 0:
            value, pos = _varint(buf, pos)
            item["varint"] = value
        elif wt == 1:
            if pos + 8 > len(buf):
                raise WireError("truncated fixed64")
            item["fixed64_hex"] = buf[pos:pos+8].hex()
            pos += 8
        elif wt == 2:
            n, pos = _varint(buf, pos)
            if pos + n > len(buf):
                raise WireError("truncated length-delimited")
            raw = buf[pos:pos+n]
            pos += n
            item["length"] = n
            item["hex"] = raw.hex()
            try:
                txt = raw.decode("utf-8")
                if txt.isprintable():
                    item["utf8"] = txt
            except UnicodeDecodeError:
                pass
        elif wt == 5:
            if pos + 4 > len(buf):
                raise WireError("truncated fixed32")
            item["fixed32_hex"] = buf[pos:pos+4].hex()
            pos += 4
        else:
            raise WireError(f"unsupported wire type {wt}")

        out.append(item)
    return out
