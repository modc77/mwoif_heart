from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional

STATE_DIR = Path(os.getenv("MWOIF_HEART_STATE_DIR", ".state"))


def _safe_slot(slot: str) -> str:
    s = "".join(ch for ch in slot.upper() if ch.isalnum() or ch in "_-")
    if not s:
        raise ValueError("invalid slot")
    return s


def _atomic_json_write(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    tmp.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _load_object(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path}: JSON root must be an object")
    return data


class SessionStore:
    """V6.1-compatible established-session cache. Values stay local."""

    def path(self, slot: str) -> Path:
        return STATE_DIR / f"session_{_safe_slot(slot)}.json"

    def import_file(self, slot: str, src: Path) -> Dict[str, Any]:
        data = _load_object(src)
        normalized = dict(data)
        normalized.setdefault("slot", _safe_slot(slot))
        normalized["established"] = bool(
            normalized.get("session_key")
            and normalized.get("member_seq") is not None
        )
        _atomic_json_write(self.path(slot), normalized)
        return normalized

    def load(self, slot: str) -> Dict[str, Any]:
        p = self.path(slot)
        if not p.exists():
            raise FileNotFoundError(f"missing established session: {p}")
        return _load_object(p)

    def existing_slots(self) -> Iterable[str]:
        if not STATE_DIR.exists():
            return []
        out = []
        for p in sorted(STATE_DIR.glob("session_*.json")):
            out.append(p.stem[len("session_"):])
        return out


class AuthContextStore:
    """V6.2 auth-context cache. Real gameAccessToken is never printed by show()."""

    def path(self, slot: str) -> Path:
        return STATE_DIR / f"auth_{_safe_slot(slot)}.json"

    def import_file(self, slot: str, src: Path) -> Dict[str, Any]:
        data = _load_object(src)
        mid = str(data.get("mid") or data.get("player_id") or "").strip()
        token = str(data.get("game_access_token") or data.get("gameAccessToken") or "").strip()

        if not mid:
            raise ValueError("auth JSON missing mid")
        if not token or token == "****":
            raise ValueError("auth JSON missing real game_access_token")

        normalized = dict(data)
        normalized["schema"] = str(data.get("schema") or "mwoif-auth-v13.1")
        normalized["slot"] = _safe_slot(slot)
        normalized["mid"] = mid
        normalized["game_access_token"] = token
        normalized.setdefault("source", "established_game_state")
        _atomic_json_write(self.path(slot), normalized)
        return normalized

    def load(self, slot: str) -> Dict[str, Any]:
        p = self.path(slot)
        if not p.exists():
            raise FileNotFoundError(
                f"missing auth context: {p}; import V13.1 COPY AUTH CONTEXT JSON first"
            )
        return _load_object(p)

    def existing_slots(self) -> Iterable[str]:
        if not STATE_DIR.exists():
            return []
        out = []
        for p in sorted(STATE_DIR.glob("auth_*.json")):
            out.append(p.stem[len("auth_"):])
        return out


def redact_session(data: Mapping[str, Any]) -> Dict[str, Any]:
    out = dict(data)
    key = out.get("session_key")
    if key:
        out["session_key"] = f"PRESENT(len={len(str(key))})"
    return out


def redact_auth(data: Mapping[str, Any]) -> Dict[str, Any]:
    out = dict(data)
    token = str(out.get("game_access_token") or "")
    out["game_access_token"] = (
        f"PRESENT(len={len(token)})" if token else "MISSING"
    )
    # Common alias, if imported from another format.
    if "gameAccessToken" in out:
        out["gameAccessToken"] = "<REDACTED>"
    return out
