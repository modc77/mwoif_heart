from __future__ import annotations

import base64
import time
from typing import Any, Dict, Mapping, Optional

from .native_metadata import build_native_metadata, redacted_metadata
from .wire import inspect_message, WireError

GRPC_HOST = "streaming.live.prod.devsnova.cloud:443"

FRIEND_ENDPOINTS = {
    "list": "/service.api.FriendAPI/ListFriends",
    "add": "/service.api.FriendAPI/SendFriendRequest",
    "accept": "/service.api.FriendAPI/HandleFriendRequest",
    "remove": "/service.api.FriendAPI/RemoveFriend",
}


def classify_grpc_failure(code_name: str) -> str:
    return {
        "UNAUTHENTICATED": "auth_token_or_authorization",
        "PERMISSION_DENIED": "auth_or_common_metadata",
        "UNIMPLEMENTED": "wrong_method_path_or_service",
        "INVALID_ARGUMENT": "protobuf_or_required_metadata",
        "FAILED_PRECONDITION": "account_or_server_state",
        "UNAVAILABLE": "dns_tls_connectivity_or_backend",
        "DEADLINE_EXCEEDED": "network_or_backend_timeout",
    }.get(code_name, "grpc_or_server")


def friend_list(
    auth: Mapping[str, Any],
    session: Mapping[str, Any] | None = None,
    request_body: bytes = b"",
    extra_metadata: Mapping[str, Any] | None = None,
    timeout: float = 12.0,
) -> Dict[str, Any]:
    try:
        import grpc  # type: ignore
    except Exception as exc:
        return {
            "ok": False,
            "read_only": True,
            "network_action_enabled": False,
            "error": "GRPCIO_MISSING",
            "detail": str(exc),
            "install": "pip install -r requirements.txt",
        }

    metadata, missing_native = build_native_metadata(auth, session, extra_metadata)
    start = time.monotonic()
    channel = grpc.secure_channel(GRPC_HOST, grpc.ssl_channel_credentials())
    method = channel.unary_unary(
        FRIEND_ENDPOINTS["list"],
        request_serializer=lambda x: x,
        response_deserializer=lambda x: x,
    )

    try:
        raw = method(
            request_body,
            timeout=timeout,
            metadata=metadata,
        )
        elapsed_ms = round((time.monotonic() - start) * 1000, 1)
        try:
            wire = inspect_message(raw)
            wire_error = None
        except WireError as exc:
            wire = []
            wire_error = str(exc)

        return {
            "ok": True,
            "read_only": True,
            "network_action_enabled": True,
            "action": "friend-list",
            "host": GRPC_HOST,
            "endpoint": FRIEND_ENDPOINTS["list"],
            "elapsed_ms": elapsed_ms,
            "request_bytes": len(request_body),
            "request_policy": (
                "CAPTURED_OR_EXPLICIT"
                if request_body
                else "EMPTY_TENTATIVE_NOT_FROZEN"
            ),
            "metadata": redacted_metadata(metadata),
            "missing_native_metadata": missing_native,
            "response_bytes": len(raw),
            "response_b64": base64.b64encode(raw).decode("ascii"),
            "response_hex": raw.hex(),
            "wire_fields": wire,
            "wire_error": wire_error,
        }

    except grpc.RpcError as exc:
        elapsed_ms = round((time.monotonic() - start) * 1000, 1)
        code = exc.code()
        code_name = code.name if code is not None else "UNKNOWN"
        details = exc.details() or ""
        trailing = []
        try:
            for k, v in exc.trailing_metadata() or []:
                if isinstance(v, bytes):
                    v = v.decode("utf-8", "replace")
                trailing.append([k, str(v)])
        except Exception:
            pass

        return {
            "ok": False,
            "read_only": True,
            "network_action_enabled": True,
            "action": "friend-list",
            "host": GRPC_HOST,
            "endpoint": FRIEND_ENDPOINTS["list"],
            "elapsed_ms": elapsed_ms,
            "request_bytes": len(request_body),
            "request_policy": (
                "CAPTURED_OR_EXPLICIT"
                if request_body
                else "EMPTY_TENTATIVE_NOT_FROZEN"
            ),
            "metadata": redacted_metadata(metadata),
            "missing_native_metadata": missing_native,
            "grpc_code": code_name,
            "grpc_details": details,
            "failure_class": classify_grpc_failure(code_name),
            "trailing_metadata": trailing,
        }
    finally:
        channel.close()
