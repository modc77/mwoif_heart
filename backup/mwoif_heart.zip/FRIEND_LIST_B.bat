@echo off
python main.py pair-show B
python main.py friend-list B
pause
